
/* ====== DB ====== */
const KEY='vg_db_full_v6';
const LEGACY_KEYS=['vg_db_full_v5','vg_v7_web','vanity_glamour_v9_db'];
const PHOTO_DB='vg_photos_v1';
const PHOTO_STORE='photos';
const PROVINCE=[ "AG","AL","AN","AO","AP","AQ","AR","AT","AV","BA","BG","BI","BL","BN","BO","BR","BS","BT","BZ","CA","CB","CE","CH","CL","CN","CO","CR","CS","CT","CZ","EN","FC","FE","FG","FI","FM","FR","GE","GO","GR","IM","IS","KR","LC","LE","LI","LO","LT","LU","MB","MC","ME","MI","MN","MO","MS","MT","NA","NO","NU","OR","PA","PC","PD","PE","PG","PI","PN","PO","PR","PT","PU","PV","PZ","RA","RC","RE","RG","RI","RM","RN","RO","SA","SI","SO","SP","SR","SS","SU","SV","TA","TE","TN","TO","TP","TR","TS","TV","UD","VA","VB","VC","VE","VI","VR","VT","VV" ];
const uid=()=>Math.random().toString(36).slice(2,10)+Date.now().toString(36);
const esc=s=>String(s??'').replace(/[&<>"]/g,m=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;" }[m]));
const money=n=>Number(n||0).toLocaleString('it-IT',{minimumFractionDigits:2,maximumFractionDigits:2});
const round5=n=>Math.round(n/5)*5;

function defDB(){
  return {version:'v6.5',articoli:[],clienti:[],ordini:[],categorie:[],brands:[],createdAt:new Date().toISOString()};
}
function normalizeDBShape(o){
  if(!o || typeof o!=='object') return defDB();
  const db={
    version:o.version||'v6',
    articoli:Array.isArray(o.articoli)?o.articoli:[],
    clienti:Array.isArray(o.clienti)?o.clienti:[],
    ordini:Array.isArray(o.ordini)?o.ordini:[],
    categorie:Array.isArray(o.categorie)?o.categorie:[],
    brands:Array.isArray(o.brands)?o.brands:[],
    createdAt:o.createdAt||new Date().toISOString()
  };
  db.articoli=db.articoli.map(x=>({
    ...x,
    codice:normalizeSpaceText(x?.codice||x?.sku||''),
    brand:normalizeSpaceText(x?.brand||x?.marca||''),
    categoria:normalizeSpaceText(x?.categoria||''),
    costoUsd:firstFiniteNumber(x?.costoUsd, x?.costoUSD, x?.usd, 0),
    costoEur:firstFiniteNumber(x?.costoEur, x?.costoEUR, x?.prezzo_acquisto, x?.costo, x?.costo_eur, 0),
    prezzoVendita:firstFiniteNumber(x?.prezzoVendita, x?.prezzo_vendita, x?.prezzo, x?.prezzo_vendita_iva, 0),
    promoAttiva:(typeof x?.promoAttiva==='boolean') ? x.promoAttiva : !!x?.promo_on,
    prezzoPromo:firstFiniteNumber(x?.prezzoPromo, x?.promoPrezzo, x?.promo_price, 0),
    scadenzaPromo:normalizeSpaceText(x?.scadenzaPromo||x?.promoScadenza||x?.promo_date||''),
    foto:Array.isArray(x?.foto)?x.foto.filter(Boolean).slice(0,6):[],
    photoIds:Array.isArray(x?.photoIds)?x.photoIds.filter(Boolean).slice(0,6):[]
  }));
  db.clienti=db.clienti.map(x=>({
    ...x,
    nome:normalizeSpaceText(x?.nome||x?.name||''),
    cognome:normalizeSpaceText(x?.cognome||x?.surname||''),
    telefono:normalizePhone(x?.telefono||x?.tel||x?.phone||''),
    email:normalizeEmail(x?.email||''),
    indirizzo:normalizeSpaceText(x?.indirizzo||x?.address||''),
    cap:normalizeSpaceText(x?.cap||''),
    citta:normalizeSpaceText(x?.citta||x?.city||''),
    provincia:normalizeSpaceText(x?.provincia||x?.province||''),
    note:typeof x?.note==='string'?x.note:(x?.note||'')
  }));
  db.ordini=db.ordini.map(x=>{
    const righe=Array.isArray(x?.righe)?x.righe.map(r=>({
      ...r,
      articoloId:String(r?.articoloId||''),
      codice:normalizeSpaceText(r?.codice||r?.sku||''),
      modello:normalizeSpaceText(r?.modello||r?.nome||''),
      prezzo:Number(r?.prezzo||r?.prezzo_unitario||0),
      sconto:Number(r?.sconto||0)
    })):[];
    const scontoCliente=calcOrderDiscount(x);
    const subTotale=calcOrderSubtotal(righe);
    const totalValue=Number(x?.totale);
    return {
      ...x,
      numeroOrdine:ensureOrderNumber(x),
      clienteId:String(x?.clienteId||''),
      righe,
      foto:Array.isArray(x?.foto)?x.foto.filter(Boolean).slice(0,12):[],
      fotoManuali:Array.isArray(x?.fotoManuali)?x.fotoManuali.filter(Boolean).slice(0,12):[],
      fotoArticoli:Array.isArray(x?.fotoArticoli)?x.fotoArticoli.filter(Boolean).slice(0,12):[],
      orderPhotoIds:Array.isArray(x?.orderPhotoIds)?x.orderPhotoIds.filter(Boolean).slice(0,12):[],
      scontoCliente,
      subTotale,
      totale:(totalValue>0 || subTotale===0) ? totalValue : calcOrderNetTotal(righe, scontoCliente),
      incassato:Number(x?.incassato||0)
    };
  });

  const artDedup=dedupeArticoliWithMap(db.articoli||[]);
  db.articoli=artDedup.items;

  db.clienti=db.clienti.map(c=>({...c, nome:normalizeClientDisplayName(c)}));
  const cliDedup=dedupeClientiWithMap(db.clienti||[]);
  db.clienti=cliDedup.items.map(c=>({...c, nome:normalizeClientDisplayName(c)}));

  db.ordini=db.ordini.map(o=>({
    ...o,
    numeroOrdine:ensureOrderNumber(o),
    clienteId:cliDedup.idMap.get(String(o?.clienteId||'')) || String(o?.clienteId||''),
    righe:(Array.isArray(o?.righe)?o.righe:[]).map(r=>({
      ...r,
      articoloId:artDedup.idMap.get(String(r?.articoloId||'')) || String(r?.articoloId||''),
      codice:normalizeSpaceText(r?.codice||r?.sku||''),
      modello:normalizeSpaceText(r?.modello||r?.nome||''),
      prezzo:Number(r?.prezzo||r?.prezzo_unitario||0)
    }))
  }));
  const ordDedup=dedupeOrdiniWithMap(db.ordini||[]);
  db.ordini=ordDedup.items.map(o=>({
    ...o,
    numeroOrdine:ensureOrderNumber(o),
    righe:Array.isArray(o?.righe)?o.righe:[]
  }));

  db.categorie=[...new Set((db.categorie||[]).map(x=>normalizeSpaceText(x)).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'it',{sensitivity:'base'}));
  db.brands=[...new Set((db.brands||[]).map(x=>normalizeSpaceText(x)).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'it',{sensitivity:'base'}));
  return db;
}

function normalizeSpaceText(v){ return String(v==null?'':v).trim().replace(/\s+/g,' '); }
function normalizeTextKey(v){ return normalizeSpaceText(v).toLowerCase(); }
function normalizePhone(v){
  let out=normalizeSpaceText(v).replace(/[^\d+]/g,'');
  if(out.startsWith('00')) out='+'+out.slice(2);
  if(out.startsWith('+39')) out=out.slice(3);
  else if(out.startsWith('39') && out.length>=11) out=out.slice(2);
  return out;
}
function normalizeEmail(v){ return normalizeTextKey(v); }
function looksLikeUuid(v){ return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(v||'')); }
function choosePreferredId(){
  const ids=Array.from(arguments).flat().map(v=>normalizeSpaceText(v)).filter(Boolean);
  return ids.find(looksLikeUuid) || ids[0] || '';
}
function recordRichnessScore(rec){
  let score=Number(rec?._ts||0);
  if(!rec || typeof rec!=='object') return score;
  Object.entries(rec).forEach(([k,v])=>{
    if(k==='_ts') return;
    if(Array.isArray(v)) score += v.filter(Boolean).length * 4;
    else if(v && typeof v==='object') score += 3;
    else if(typeof v==='number') score += Number.isFinite(v) ? 2 : 0;
    else if(normalizeSpaceText(v)) score += 1;
  });
  return score;
}
function normalizeClientDisplayName(x){
  const nome=normalizeSpaceText(x?.nome||x?.name||x?.nomeCompleto||'');
  const cognome=normalizeSpaceText(x?.cognome||x?.surname||'');
  if(nome && cognome){
    const cognKey=normalizeTextKey(cognome);
    const nomeKey=normalizeTextKey(nome);
    if(nomeKey===cognKey || nomeKey.endsWith(' '+cognKey)) return nome;
    return `${nome} ${cognome}`.trim();
  }
  return nome || cognome;
}
function splitClientNameForCloud(cli){
  const full=normalizeClientDisplayName(cli) || 'Cliente';
  const explicitSurname=normalizeSpaceText(cli?.cognome||'');
  if(explicitSurname){
    let rawName=normalizeSpaceText(cli?.nome||'');
    const tailKey=normalizeTextKey(rawName.split(' ').slice(-explicitSurname.split(' ').length).join(' '));
    if(tailKey && tailKey===normalizeTextKey(explicitSurname)) rawName=normalizeSpaceText(rawName.slice(0, Math.max(0, rawName.length-explicitSurname.length)));
    return { nome: rawName || full, cognome: explicitSurname };
  }
  const parts=full.split(' ').filter(Boolean);
  if(parts.length>=2) return { nome: parts.slice(0,-1).join(' '), cognome: parts.slice(-1).join(' ') };
  return { nome: full, cognome: '' };
}

function normalizeClientDedupKey(x){
  const full=normalizeTextKey(normalizeClientDisplayName(x));
  const telefono=normalizePhone(x?.telefono||x?.tel||x?.phone||'');
  const email=normalizeEmail(x?.email||'');
  const citta=normalizeTextKey(x?.citta||x?.city||'');
  const cap=normalizeTextKey(x?.cap||'');
  const indirizzo=normalizeTextKey(x?.indirizzo||x?.address||'');
  if(email) return `email|${email}`;
  if(telefono && telefono.replace(/\D/g,'').length>=6) return `tel|${telefono}`;
  if(full) return `name|${full}|${citta}|${cap}|${indirizzo}`;
  return '';
}
function mergeClientRecords(prev,item){
  if(!prev) return {
    ...item,
    id:choosePreferredId(item?.id),
    nome:normalizeClientDisplayName(item),
    cognome:normalizeSpaceText(item?.cognome||''),
    telefono:normalizePhone(item?.telefono||item?.tel||item?.phone||''),
    email:normalizeEmail(item?.email||''),
    indirizzo:normalizeSpaceText(item?.indirizzo||item?.address||''),
    cap:normalizeSpaceText(item?.cap||''),
    citta:normalizeSpaceText(item?.citta||item?.city||''),
    provincia:normalizeSpaceText(item?.provincia||item?.province||'')
  };
  const nextWins=recordRichnessScore(item) >= recordRichnessScore(prev);
  const merged=nextWins ? {...prev, ...item} : {...item, ...prev};
  merged.id=choosePreferredId(prev?.id, item?.id) || merged.id;
  merged.nome=normalizeClientDisplayName(merged);
  merged.cognome=normalizeSpaceText(merged?.cognome||'');
  merged.telefono=normalizePhone(merged?.telefono||merged?.tel||merged?.phone||'');
  merged.email=normalizeEmail(merged?.email||'');
  merged.indirizzo=normalizeSpaceText(merged?.indirizzo||merged?.address||'');
  merged.cap=normalizeSpaceText(merged?.cap||'');
  merged.citta=normalizeSpaceText(merged?.citta||merged?.city||'');
  merged.provincia=normalizeSpaceText(merged?.provincia||merged?.province||'');
  return merged;
}
function dedupeSemanticList(list, keyFn, mergeFn){
  const items=[];
  const idToIndex=new Map();
  const keyToIndex=new Map();
  const idMap=new Map();
  for(const raw of (Array.isArray(list)?list:[])){
    if(!raw) continue;
    const item={...raw};
    const rawId=normalizeSpaceText(item?.id||'');
    const rawKey=keyFn(item);
    let idx=(rawId && idToIndex.has(rawId)) ? idToIndex.get(rawId) : null;
    if(idx==null && rawKey && keyToIndex.has(rawKey)) idx=keyToIndex.get(rawKey);
    if(idx==null){
      const merged=mergeFn(null,item);
      items.push(merged);
      idx=items.length-1;
    }else{
      const prev=items[idx];
      const merged=mergeFn(prev,item);
      const prevId=normalizeSpaceText(prev?.id||'');
      const nextId=normalizeSpaceText(merged?.id||'');
      if(prevId && nextId && prevId!==nextId) idMap.set(prevId,nextId);
      items[idx]=merged;
    }
    const final=items[idx];
    const finalId=normalizeSpaceText(final?.id||'');
    if(rawId && finalId && rawId!==finalId) idMap.set(rawId, finalId);
    if(rawId) idToIndex.set(rawId, idx);
    if(finalId) idToIndex.set(finalId, idx);
    if(rawKey) keyToIndex.set(rawKey, idx);
    const finalKey=keyFn(final);
    if(finalKey) keyToIndex.set(finalKey, idx);
  }
  return {items,idMap};
}
function dedupeClientiWithMap(list=[]){ return dedupeSemanticList(list, normalizeClientDedupKey, mergeClientRecords); }
function dedupeClienti(list=[]){ return dedupeClientiWithMap(list).items; }

function normalizeArticleDedupKey(x){
  const code=normalizeTextKey(x?.codice||x?.sku||'');
  return code ? `code|${code}` : '';
}
function mergeArticleRecords(prev,item){
  if(!prev) return {
    ...item,
    id:choosePreferredId(item?.id),
    codice:normalizeSpaceText(item?.codice||item?.sku||''),
    brand:normalizeSpaceText(item?.brand||item?.marca||''),
    categoria:normalizeSpaceText(item?.categoria||''),
    foto:Array.isArray(item?.foto)?item.foto.filter(Boolean).slice(0,6):[],
    photoIds:Array.isArray(item?.photoIds)?item.photoIds.filter(Boolean).slice(0,6):[]
  };
  const nextWins=recordRichnessScore(item) >= recordRichnessScore(prev);
  const merged=nextWins ? {...prev, ...item} : {...item, ...prev};
  merged.id=choosePreferredId(prev?.id, item?.id) || merged.id;
  merged.codice=normalizeSpaceText(merged?.codice||merged?.sku||'');
  merged.brand=normalizeSpaceText(merged?.brand||item?.brand||item?.marca||prev?.brand||prev?.marca||'');
  merged.categoria=normalizeSpaceText(merged?.categoria||'');
  merged.costoUsd=firstFiniteNumber(merged?.costoUsd, merged?.costoUSD, item?.costoUsd, item?.costoUSD, prev?.costoUsd, prev?.costoUSD, 0);
  merged.costoEur=firstFiniteNumber(merged?.costoEur, merged?.costoEUR, item?.costoEur, item?.costoEUR, item?.prezzo_acquisto, item?.costo, item?.costo_eur, prev?.costoEur, prev?.costoEUR, prev?.prezzo_acquisto, prev?.costo, prev?.costo_eur, 0);
  merged.prezzoVendita=firstFiniteNumber(merged?.prezzoVendita, merged?.prezzo_vendita, item?.prezzoVendita, item?.prezzo_vendita, item?.prezzo, item?.prezzo_vendita_iva, prev?.prezzoVendita, prev?.prezzo_vendita, prev?.prezzo, prev?.prezzo_vendita_iva, 0);
  merged.promoAttiva=(typeof merged?.promoAttiva==='boolean') ? merged.promoAttiva : ((typeof item?.promoAttiva==='boolean') ? item.promoAttiva : ((typeof prev?.promoAttiva==='boolean') ? prev.promoAttiva : false));
  merged.prezzoPromo=firstFiniteNumber(merged?.prezzoPromo, merged?.promoPrezzo, item?.prezzoPromo, item?.promoPrezzo, prev?.prezzoPromo, prev?.promoPrezzo, 0);
  merged.scadenzaPromo=normalizeSpaceText(merged?.scadenzaPromo||merged?.promoScadenza||item?.scadenzaPromo||item?.promoScadenza||prev?.scadenzaPromo||prev?.promoScadenza||'');
  merged.foto=mergeUniquePics(prev?.foto||[], item?.foto||[]).slice(0,6);
  merged.photoIds=[...new Set([...(prev?.photoIds||[]), ...(item?.photoIds||[])].filter(Boolean).map(String))].slice(0,6);
  return merged;
}
function dedupeArticoliWithMap(list=[]){ return dedupeSemanticList(list, normalizeArticleDedupKey, mergeArticleRecords); }

function ensureOrderNumber(order){
  const explicit=normalizeSpaceText(order?.numeroOrdine||order?.numero_ordine||'');
  if(explicit) return explicit;
  const id=normalizeSpaceText(order?.id||'');
  if(!id) return '';
  const clean=id.replace(/[^a-z0-9]+/gi,'').toUpperCase();
  return clean ? `VGAPP-${clean.slice(0,24)}` : '';
}
function normalizeOrderRowKey(r){
  const code=normalizeTextKey(r?.codice||r?.sku||r?.articoloId||'');
  const price=Number(r?.prezzo||r?.prezzo_unitario||0).toFixed(2);
  return `${code}|${price}`;
}
function normalizeOrderFingerprint(o){
  const num=normalizeTextKey(ensureOrderNumber(o));
  if(num) return `num|${num}`;
  const data=normalizeTextKey(o?.data||o?.data_ordine||'');
  const tracking=normalizeTextKey(o?.tracking||o?.tracking_code||'');
  const totale=Number(o?.totale||0).toFixed(2);
  const note=normalizeTextKey(o?.note||'');
  const righe=(Array.isArray(o?.righe)?o.righe:[]).map(normalizeOrderRowKey).sort().join('~');
  return [data,tracking,totale,righe,note].some(Boolean) ? `fp|${data}|${tracking}|${totale}|${righe}|${note}` : '';
}
function mergeOrderRecords(prev,item){
  if(!prev){
    const righe=Array.isArray(item?.righe)?item.righe:[];
    const scontoCliente=calcOrderDiscount(item);
    const subTotale=calcOrderSubtotal(righe);
    const totalValue=Number(item?.totale);
    return {
      ...item,
      id:choosePreferredId(item?.id),
      numeroOrdine:ensureOrderNumber(item),
      righe,
      foto:Array.isArray(item?.foto)?item.foto.filter(Boolean).slice(0,12):[],
      fotoManuali:Array.isArray(item?.fotoManuali)?item.fotoManuali.filter(Boolean).slice(0,12):[],
      fotoArticoli:Array.isArray(item?.fotoArticoli)?item.fotoArticoli.filter(Boolean).slice(0,12):[],
      orderPhotoIds:Array.isArray(item?.orderPhotoIds)?item.orderPhotoIds.filter(Boolean).slice(0,12):[],
      scontoCliente,
      subTotale,
      totale:(totalValue>0 || subTotale===0) ? totalValue : calcOrderNetTotal(righe, scontoCliente),
      incassato:Number(item?.incassato||0)
    };
  }
  const nextWins=recordRichnessScore(item) >= recordRichnessScore(prev);
  const primary=nextWins ? item : prev;
  const secondary=nextWins ? prev : item;
  const merged=nextWins ? {...prev, ...item} : {...item, ...prev};
  merged.id=choosePreferredId(prev?.id, item?.id) || merged.id;
  merged.numeroOrdine=ensureOrderNumber(merged);
  merged.righe=(Array.isArray(primary?.righe) && primary.righe.length) ? primary.righe : (Array.isArray(secondary?.righe) ? secondary.righe : []);
  merged.foto=mergeUniquePics(prev?.foto||[], item?.foto||[]).slice(0,12);
  merged.fotoManuali=mergeUniquePics(prev?.fotoManuali||[], item?.fotoManuali||[]).slice(0,12);
  merged.fotoArticoli=mergeUniquePics(prev?.fotoArticoli||[], item?.fotoArticoli||[]).slice(0,12);
  merged.orderPhotoIds=[...new Set([...(prev?.orderPhotoIds||[]), ...(item?.orderPhotoIds||[])].filter(Boolean).map(String))].slice(0,12);
  merged.scontoCliente=calcOrderDiscount(primary) || calcOrderDiscount(secondary) || 0;
  merged.subTotale=calcOrderSubtotal(merged.righe);
  const totalValue=Number(merged?.totale);
  merged.totale=(totalValue>0 || merged.subTotale===0) ? totalValue : calcOrderNetTotal(merged.righe, merged.scontoCliente);
  merged.incassato=Number(merged?.incassato||0);
  return merged;
}
function dedupeOrdiniWithMap(list=[]){ return dedupeSemanticList(list, normalizeOrderFingerprint, mergeOrderRecords); }

function mergeById(arrA=[], arrB=[]){
  const map=new Map();
  [...arrA, ...arrB].forEach(it=>{
    if(!it || !it.id) return;
    const prev=map.get(it.id);
    if(!prev){ map.set(it.id, it); return; }
    const prevScore=(prev._ts||0)+(Array.isArray(prev.righe)?prev.righe.length:0);
    const nextScore=(it._ts||0)+(Array.isArray(it.righe)?it.righe.length:0);
    if(nextScore>=prevScore) map.set(it.id, {...prev, ...it});
  });
  return Array.from(map.values());
}
function loadDB(){
  try{
    const legacyKeys = (typeof LEGACY_KEYS!=='undefined' ? LEGACY_KEYS : []);
    const keys=[...legacyKeys, KEY];
    const found=[];
    keys.forEach(k=>{
      const raw=localStorage.getItem(k);
      if(!raw) return;
      try{ found.push({key:k, db:normalizeDBShape(JSON.parse(raw))}); }catch(_e){}
    });
    if(!found.length) return defDB();

    let merged=defDB();
    found.forEach(({db})=>{
      merged={
        version:'v6.1',
        createdAt: merged.createdAt||db.createdAt||new Date().toISOString(),
        articoli:[...(merged.articoli||[]), ...(db.articoli||[])],
        clienti:[...(merged.clienti||[]), ...(db.clienti||[])],
        ordini:[...(merged.ordini||[]), ...(db.ordini||[])],
        categorie: [...new Set([...(merged.categorie||[]), ...(db.categorie||[])])].sort((a,b)=>a.localeCompare(b,'it',{sensitivity:'base'})),
        brands: [...new Set([...(merged.brands||[]), ...(db.brands||[])])].sort((a,b)=>a.localeCompare(b,'it',{sensitivity:'base'}))
      };
    });

    merged=normalizeDBShape(merged);

    const mergedRaw = JSON.stringify(merged);
    const rawMain=localStorage.getItem(KEY);
    if(rawMain!==mergedRaw) localStorage.setItem(KEY, mergedRaw);

    // Dopo la migrazione, le chiavi legacy non devono più rimettere in vita record cancellati.
    legacyKeys.forEach(k=>{ try{ localStorage.removeItem(k); }catch(_e){} });
    return merged;
  }catch(e){ return defDB(); }
}
function saveDB(db){
  try{
    const cleanDb=normalizeDBShape(db||defDB());
    const raw=JSON.stringify(cleanDb);
    localStorage.setItem(KEY, raw);
    try{ localStorage.setItem(KEY+'_backup_latest', raw); }catch(_e){}
    const legacyKeys = (typeof LEGACY_KEYS!=='undefined' ? LEGACY_KEYS : []);
    legacyKeys.forEach(k=>{ try{ localStorage.removeItem(k); }catch(_e){} });
  }catch(err){
    const msg=String(err?.message||err||'');
    if(/quota|storage/i.test(msg)) toast('Salvataggio fallito: archivio locale pieno o sporco');
    else toast('Salvataggio fallito');
    return false;
  }
  try{ renderAll(); }catch(err){ console.error('Render post-salvataggio fallito', err); }
  refreshArticleBrandSelects();
  return true;
}
function safeLower(v){ return String(v==null?'':v).trim().toLowerCase(); }

function openPhotoDB(){
  return new Promise((res,rej)=>{
    const req=indexedDB.open(PHOTO_DB,1);
    req.onupgradeneeded=()=>{
      const db=req.result;
      if(!db.objectStoreNames.contains(PHOTO_STORE)) db.createObjectStore(PHOTO_STORE);
    };
    req.onsuccess=()=>res(req.result);
    req.onerror=()=>rej(req.error||new Error('IndexedDB non disponibile'));
  });
}
async function idbSet(key,val){
  const db=await openPhotoDB();
  return new Promise((res,rej)=>{
    const tx=db.transaction(PHOTO_STORE,'readwrite');
    tx.objectStore(PHOTO_STORE).put(val,key);
    tx.oncomplete=()=>res(true);
    tx.onerror=()=>rej(tx.error||new Error('Errore salvataggio foto'));
    tx.onabort=()=>rej(tx.error||new Error('Salvataggio foto abortito'));
  });
}
async function idbGet(key){
  const db=await openPhotoDB();
  return new Promise((res,rej)=>{
    const tx=db.transaction(PHOTO_STORE,'readonly');
    const req=tx.objectStore(PHOTO_STORE).get(key);
    req.onsuccess=()=>res(req.result||null);
    req.onerror=()=>rej(req.error||new Error('Errore lettura foto'));
  });
}
async function idbDelete(key){
  const db=await openPhotoDB();
  return new Promise((res,rej)=>{
    const tx=db.transaction(PHOTO_STORE,'readwrite');
    tx.objectStore(PHOTO_STORE).delete(key);
    tx.oncomplete=()=>res(true);
    tx.onerror=()=>rej(tx.error||new Error('Errore eliminazione foto'));
    tx.onabort=()=>rej(tx.error||new Error('Eliminazione foto abortita'));
  });
}
async function idbListKeys(){
  const db=await openPhotoDB();
  return new Promise((res,rej)=>{
    const tx=db.transaction(PHOTO_STORE,'readonly');
    const store=tx.objectStore(PHOTO_STORE);
    const req=store.getAllKeys ? store.getAllKeys() : null;
    if(req){
      req.onsuccess=()=>res((req.result||[]).map(String));
      req.onerror=()=>rej(req.error||new Error('Errore lettura chiavi foto'));
      return;
    }
    const out=[];
    const cur=store.openCursor();
    cur.onsuccess=(e)=>{
      const cursor=e.target.result;
      if(cursor){ out.push(String(cursor.key)); cursor.continue(); }
      else res(out);
    };
    cur.onerror=()=>rej(cur.error||new Error('Errore cursore foto'));
  });
}
async function idbCount(){
  const db=await openPhotoDB();
  return new Promise((res,rej)=>{
    const tx=db.transaction(PHOTO_STORE,'readonly');
    const req=tx.objectStore(PHOTO_STORE).count();
    req.onsuccess=()=>res(Number(req.result||0));
    req.onerror=()=>rej(req.error||new Error('Errore conteggio foto'));
  });
}
async function getPublicFotoUrl(path){
  const src=String(path||'').trim();
  if(!src) return '';
  if(/^data:|^https?:\/\//i.test(src)) return src;
  if(isTemporaryLocalPhotoRef(src)) return '';
  const sb=await ensureCloud();
  if(!sb) return src;
  const clean=src.replace(/^\/+/, '').replace(new RegExp('^'+SUPABASE_BUCKET+'\/'), '');
  const { data } = sb.storage.from(SUPABASE_BUCKET).getPublicUrl(clean);
  return data?.publicUrl || src;
}

async function listCloudFotoPathsByCode(codice){
  const code=String(codice||'').trim();
  if(!code) return [];
  const sb=await ensureCloud();
  if(!sb) return [];
  try{
    const { data, error } = await sb.storage.from(SUPABASE_BUCKET).list(code, { limit: 20, sortBy: { column: 'name', order: 'asc' } });
    if(error || !Array.isArray(data)) return [];
    return data
      .filter(f=>f && f.name && !String(f.name).endsWith('/'))
      .map(f=> `${code}/${f.name}`)
      .filter(Boolean)
      .slice(0,6);
  }catch(_e){
    return [];
  }
}

async function getArticlePics(a){
  if(!a) return [];
  const out=[];
  const pushPic=(src)=>{
    const clean=String(src||'').trim();
    if(!clean || out.includes(clean)) return;
    out.push(clean);
  };
  if(Array.isArray(a.foto) && a.foto.length){
    for(const path of a.foto.slice(0,6)){
      const url=await getPublicFotoUrl(path);
      if(url) pushPic(url);
      if(out.length>=6) return out.slice(0,6);
    }
  }
  if(Array.isArray(a.photoIds) && a.photoIds.length){
    for(const id of a.photoIds){
      const x=await idbGet(id);
      if(!x) continue;
      if(typeof x==='string') pushPic(x);
      else if(x instanceof Blob) pushPic(URL.createObjectURL(x));
      if(out.length>=6) break;
    }
  }
  return out.slice(0,6);
}
async function getArticleCloudSyncSources(a){
  if(!a) return [];
  const out=[];
  const pushRef=(src)=>{
    const clean=String(src||'').trim();
    if(!clean || out.includes(clean)) return;
    out.push(clean);
  };
  if(Array.isArray(a.foto) && a.foto.length){
    for(const src of a.foto.slice(0,6)){
      const clean=String(src||'').trim();
      if(!clean) continue;
      if(/^data:|^https?:\/\//i.test(clean)) pushRef(clean);
      else pushRef(clean.replace(/^\/+/, '').replace(new RegExp('^'+SUPABASE_BUCKET+'\/'), ''));
      if(out.length>=6) return out.slice(0,6);
    }
  }
  if(Array.isArray(a.photoIds) && a.photoIds.length){
    for(const id of a.photoIds){
      const x=await idbGet(id);
      if(!x) continue;
      if(typeof x==='string') pushRef(x);
      else if(x instanceof Blob) pushRef(URL.createObjectURL(x));
      if(out.length>=6) break;
    }
  }
  return out.slice(0,6);
}
async function getStoredPhotoSources(ids=[]){
  const out=[];
  for(const id of (ids||[])){
    try{
      const x=await idbGet(id);
      if(!x) continue;
      if(typeof x==='string') out.push(x);
      else if(x instanceof Blob) out.push(URL.createObjectURL(x));
    }catch(_e){}
  }
  return out;
}
async function getOrderManualPics(ord){
  const legacy=Array.isArray(ord?.fotoManuali)?ord.fotoManuali.filter(Boolean).slice(0,12):[];
  const stored=await getStoredPhotoSources(Array.isArray(ord?.orderPhotoIds)?ord.orderPhotoIds.filter(Boolean).slice(0,12):[]);
  return mergeUniquePics(legacy, stored).slice(0,12);
}
async function getOrderPics(ord, db){
  const articlePics=await getOrderArticleSnapshotPhotos(ord?.righe||[], db||loadDB());
  const manualPics=await getOrderManualPics(ord||{});
  return mergeUniquePics(articlePics, manualPics).slice(0,12);
}
async function blobToDataUrl(blob){
  return await new Promise((res,rej)=>{
    const fr=new FileReader();
    fr.onload=()=>res(String(fr.result||''));
    fr.onerror=()=>rej(fr.error||new Error('Lettura file fallita'));
    fr.readAsDataURL(blob);
  });
}
async function requestPersistentStorage(){
  try{
    if(navigator.storage?.persist) await navigator.storage.persist();
  }catch(_e){}
}
async function blobFromPhotoSrc(src){
  const val=String(src||'').trim();
  if(!val) throw new Error('Sorgente foto vuota');
  if(/^data:/i.test(val)){
    const res=await fetch(val);
    return await res.blob();
  }
  const res=await fetch(val, { mode:'cors', cache:'no-store' });
  if(!res.ok) throw new Error('Download foto fallito');
  return await res.blob();
}
function guessPhotoExtension(src, blob){
  const clean=String(src||'').split('?')[0].split('#')[0];
  const match=clean.match(/\.([a-z0-9]{2,5})$/i);
  if(match) return match[1].toLowerCase();
  const mime=String(blob?.type||'').toLowerCase();
  if(mime.includes('png')) return 'png';
  if(mime.includes('webp')) return 'webp';
  if(mime.includes('gif')) return 'gif';
  return 'jpg';
}
let __articlePhotoShareCache = null;
function canNativeShareFiles(files){
  try{
    if(typeof navigator==='undefined' || typeof navigator.share!=='function') return false;
    if(!files?.length) return false;
    if(typeof navigator.canShare!=='function') return true;
    if(navigator.canShare({ files })) return true;
    if(files.length===1 && navigator.canShare({ files:[files[0]] })) return 'single';
    return false;
  }catch(_e){
    return false;
  }
}
async function tryNativeShareArticleFiles(files, baseName){
  const mode = canNativeShareFiles(files);
  if(!mode) return false;
  if(mode==='single'){
    await navigator.share({
      files:[files[0]],
      title:`Foto ${baseName}`,
      text:`Salva la foto dell'articolo ${baseName}`
    });
    return 'single';
  }
  await navigator.share({
    files,
    title:`Foto ${baseName}`,
    text:`Salva ${files.length} foto dell'articolo ${baseName}`
  });
  return 'multi';
}
async function buildArticlePhotoFiles(art, pics, baseName){
  const files=[];
  for(let i=0;i<pics.length;i++){
    try{
      const rawSrc=String(pics[i]||'').trim();
      const fetchSrc = (/^data:|^https?:\/\/|^blob:/i.test(rawSrc)) ? rawSrc : (await getPublicFotoUrl(rawSrc));
      if(!fetchSrc) throw new Error('URL foto non disponibile');
      const blob=await blobFromPhotoSrc(fetchSrc);
      const ext=guessPhotoExtension(fetchSrc || rawSrc, blob);
      const type=blob?.type || (ext==='png' ? 'image/png' : ext==='webp' ? 'image/webp' : ext==='gif' ? 'image/gif' : 'image/jpeg');
      const name=`${baseName}_${String(i+1).padStart(2,'0')}.${ext}`;
      files.push(new File([blob], name, { type, lastModified: Date.now() }));
    }catch(err){
      console.warn('Preparazione foto articolo fallita', err);
    }
  }
  return files;
}
async function tryNativeShareArticleLinks(pics, baseName){
  try{
    if(typeof navigator==='undefined' || typeof navigator.share!=='function' || !pics?.length) return false;
    const urls=[];
    for(const raw of pics){
      const clean=String(raw||'').trim();
      if(!clean) continue;
      const url = (/^https?:\/\//i.test(clean)) ? clean : await getPublicFotoUrl(clean);
      if(url && /^https?:\/\//i.test(url) && !urls.includes(url)) urls.push(url);
      if(urls.length>=10) break;
    }
    if(!urls.length) return false;
    const payload = {
      title:`Foto ${baseName}`,
      text:`Foto articolo ${baseName}\n\n${urls.join('\n')}`
    };
    if(urls.length===1) payload.url = urls[0];
    await navigator.share(payload);
    return true;
  }catch(err){
    if(err && err.name==='AbortError') return 'abort';
    console.warn('Condivisione link foto fallita', err);
    return false;
  }
}
async function downloadCurrentArticlePhotos(){
  const db=loadDB();
  const art=db.articoli.find(x=>x.id===currentArtId);
  if(!art){ toast('Articolo non trovato'); return; }
  const pics=await getArticleCloudSyncSources(art);
  if(!pics.length){ toast('Nessuna foto da scaricare'); return; }
  const baseName=(art.codice||art.brand||art.modello||'articolo').toString().trim().replace(/[^a-z0-9_-]+/gi,'_').replace(/^_+|_+$/g,'')||'articolo';
  const cacheKey=`${art.id||''}::${pics.join('|')}`;

  if(__articlePhotoShareCache && __articlePhotoShareCache.key===cacheKey && Array.isArray(__articlePhotoShareCache.files) && __articlePhotoShareCache.files.length){
    try{
      const shared = await tryNativeShareArticleFiles(__articlePhotoShareCache.files, baseName);
      if(shared){
        toast(shared==='single'
          ? 'Condivisione aperta. Il browser supporta una foto per volta.'
          : `Seleziona Galleria, Foto o File per salvare ${__articlePhotoShareCache.files.length} foto.`);
        return;
      }
      const sharedLinks = await tryNativeShareArticleLinks(pics, baseName);
      if(sharedLinks===true){
        toast('Condivisione aperta. Il browser sta inviando i link delle foto.');
        return;
      }
      if(sharedLinks==='abort') return;
    }catch(err){
      if(err && err.name==='AbortError') return;
      console.warn('Condivisione nativa foto da cache fallita', err);
    }
  }

  toast(`Preparo ${pics.length} foto...`);
  const files=await buildArticlePhotoFiles(art, pics, baseName);
  if(!files.length){
    const sharedLinks = await tryNativeShareArticleLinks(pics, baseName);
    if(sharedLinks===true){
      toast('Condivisione aperta. Il browser sta inviando i link delle foto.');
      return;
    }
    if(sharedLinks==='abort') return;
    toast('Condivisione foto fallita');
    return;
  }
  __articlePhotoShareCache = { key: cacheKey, files, at: Date.now() };

  try{
    const shared = await tryNativeShareArticleFiles(files, baseName);
    if(shared){
      toast(shared==='single'
        ? 'Condivisione aperta. Il browser supporta una foto per volta.'
        : `Seleziona Galleria, Foto o File per salvare ${files.length} foto.`);
      return;
    }
  }catch(err){
    if(err && err.name==='AbortError') return;
    console.warn('Condivisione nativa foto fallita', err);
    const activationErr = /activation|user gesture|notallowed/i.test(String(err && (err.message||err.name)||''));
    if(activationErr){
      toast('Foto pronte. Premi di nuovo “Scarica foto” per aprire la condivisione.');
      return;
    }
  }

  const sharedLinks = await tryNativeShareArticleLinks(pics, baseName);
  if(sharedLinks===true){
    toast('Condivisione aperta. Il browser sta inviando i link delle foto.');
    return;
  }
  if(sharedLinks==='abort') return;

  let ok=0;
  for(let i=0;i<files.length;i++){
    try{
      const file=files[i];
      const url=URL.createObjectURL(file);
      const a=document.createElement('a');
      a.href=url;
      a.download=file.name;
      a.rel='noopener';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(()=>URL.revokeObjectURL(url), 12000);
      ok++;
      await new Promise(r=>setTimeout(r, 1400));
    }catch(err){
      console.warn('Download foto articolo fallito', err);
    }
  }
  toast(ok===files.length
    ? `Avviate ${ok} foto. Le trovi nei Download e poi in Galleria.`
    : (ok
      ? `Avviate ${ok} foto su ${files.length}. Se il browser ne blocca qualcuna, premi di nuovo Scarica foto per condividere.`
      : 'Download foto fallito'));
}
async function uploadArticlePhotoToSupabase(file, codice, slot){
  const sb=await ensureCloud();
  if(!sb) throw new Error('Supabase non disponibile');
  const ext=((file?.name||'').split('.').pop()||'jpg').toLowerCase().replace(/[^a-z0-9]/g,'') || 'jpg';
  const cleanCode=String(codice||'').trim();
  if(!cleanCode) throw new Error('Codice articolo mancante');
  const path=`${cleanCode}/${slot}.${ext}`;
  const { error } = await sb.storage.from(SUPABASE_BUCKET).upload(path, file, {
    cacheControl: '3600',
    upsert: true,
    contentType: file?.type || 'image/jpeg'
  });
  if(error) throw error;
  return path;
}
async function syncArticlePhotosToCloud(artId, codice, pics){
  const sb=await ensureCloud();
  if(!sb||!cloudSession||!artId) return [];
  const cleanCode=String(codice||artId||'art').trim() || String(artId);
  const normalized=(pics||[]).filter(Boolean).slice(0,6);
  const { data:existingRows } = await sb.from('prodotti_foto').select('path,ordine').eq('prodotto_id', artId).order('ordine',{ascending:true});
  const existingPaths=(existingRows||[]).map(r=>String(r?.path||'').trim()).filter(Boolean);
  const savedPaths=[];
  const uploadErrors=[];
  for(let i=0;i<normalized.length;i++){
    const src=String(normalized[i]||'').trim();
    if(!src) continue;

    if(isLikelyCloudPhotoPath(src)){
      const cleanPath = src.replace(/^\/+/, '').replace(new RegExp('^'+SUPABASE_BUCKET+'\/'), '');
      if(cleanPath){
        savedPaths.push(cleanPath);
        continue;
      }
    }

    try{
      const res=await fetch(src);
      if(!res.ok) throw new Error('Download foto cloud fallito');
      const blob=await res.blob();
      const ext=((blob.type||'image/jpeg').split('/').pop()||'jpg').replace(/[^a-z0-9]/gi,'').toLowerCase() || 'jpg';
      const fileObj=new File([blob], `${cleanCode}-${i+1}.${ext}`, {type: blob.type || 'image/jpeg'});
      const path=await uploadArticlePhotoToSupabase(fileObj, cleanCode, i+1);
      savedPaths.push(path);
    }catch(err){
      const fallback=existingPaths[i];
      if(fallback && !savedPaths.includes(fallback)) savedPaths.push(fallback);
      uploadErrors.push(err);
    }
  }
  const finalPaths=normalized.length===0 ? [] : normalizeCloudPhotoPathList(savedPaths.length ? savedPaths : existingPaths);
  let deleted=false;
  try{
    await sb.from('prodotti_foto').delete().eq('prodotto_id', artId);
    deleted=true;
    if(finalPaths.length){
      const rows=finalPaths.map((path,idx)=>({prodotto_id: artId, path, ordine: idx}));
      const { error } = await sb.from('prodotti_foto').insert(rows);
      if(error) throw error;
    }
  }catch(err){
    if(deleted && existingPaths.length){
      try{
        const restoreRows=existingPaths.map((path,idx)=>({prodotto_id: artId, path, ordine: idx}));
        await sb.from('prodotti_foto').insert(restoreRows);
      }catch(_restoreErr){}
    }
    throw err;
  }
  if(uploadErrors.length) console.warn('Sync foto cloud parziale', uploadErrors);
  return finalPaths;
}
async function getCloudArticlePhotoUrls(artId){
  const sb=await ensureCloud();
  if(!sb||!cloudSession||!artId) return [];
  const { data, error } = await sb.from('prodotti_foto').select('path,ordine').eq('prodotto_id', artId).order('ordine',{ascending:true});
  if(error) throw error;
  return (data||[]).map(r=>{
    const { data:urlData } = sb.storage.from(SUPABASE_BUCKET).getPublicUrl(r.path);
    return urlData?.publicUrl || '';
  }).filter(Boolean);
}

async function deleteArticlePhotosFromSupabase(paths=[]){
  const sb=await ensureCloud();
  if(!sb) return;
  const clean=(paths||[]).map(x=>String(x||'').trim()).filter(Boolean).map(x=>x.replace(/^\/+/, '').replace(new RegExp('^'+SUPABASE_BUCKET+'\/'), ''));
  if(!clean.length) return;
  const { error } = await sb.storage.from(SUPABASE_BUCKET).remove(clean);
  if(error) console.warn('Eliminazione foto Supabase fallita', error);
}
async function migratePhotosToIndexedDB(){
  const db=loadDB();
  let changed=false;
  for(const a of db.articoli||[]){
    if(Array.isArray(a.foto) && a.foto.length && (!Array.isArray(a.photoIds) || !a.photoIds.length)){
      a.photoIds=[];
      for(const src of a.foto.slice(0,6)){
        const pid='ph_'+uid();
        await idbSet(pid,src);
        a.photoIds.push(pid);
      }
      a.foto=[];
      changed=true;
    }
    if(!Array.isArray(a.photoIds)) a.photoIds=[];
  }
  if(changed) localStorage.setItem(KEY, JSON.stringify(db));
}
async function estimateStorageInfo(){
  if(navigator.storage && navigator.storage.estimate){
    const e=await navigator.storage.estimate();
    return {usage:Number(e.usage||0), quota:Number(e.quota||0)};
  }
  return null;
}
function fmtMB(n){ return (n/1024/1024).toFixed(2)+' MB'; }
function isTemporaryLocalPhotoRef(src){
  return /^(?:blob:|data:|file:|filesystem:)/i.test(String(src||'').trim());
}
function isLikelyCloudPhotoPath(src){
  const clean=String(src||'').trim().replace(/^\/+/, '').replace(new RegExp('^'+SUPABASE_BUCKET+'\/'), '');
  if(!clean || isTemporaryLocalPhotoRef(clean) || /^https?:\/\//i.test(clean)) return false;
  if(clean.includes('://')) return false;
  return /.+\/.+/.test(clean);
}
function normalizeCloudPhotoPathList(list){
  const out=[];
  for(const raw of (Array.isArray(list)?list:[])){
    const clean=String(raw||'').trim().replace(/^\/+/, '').replace(new RegExp('^'+SUPABASE_BUCKET+'\/'), '');
    if(!clean || !isLikelyCloudPhotoPath(clean) || out.includes(clean)) continue;
    out.push(clean);
    if(out.length>=6) break;
  }
  return out;
}
function firstFiniteNumber(){
  for(const value of arguments){
    const n=Number(value);
    if(Number.isFinite(n)) return n;
  }
  return 0;
}
function parseFlexibleAmount(value){
  if(typeof value==='number') return Number.isFinite(value) ? Math.max(0, value) : 0;
  const raw=String(value==null?'':value).trim().replace(/\s+/g,'').replace(',', '.');
  const n=Number(raw);
  return Number.isFinite(n) ? Math.max(0, n) : 0;
}
function calcOrderSubtotal(rows){
  return (Array.isArray(rows)?rows:[]).reduce((sum,row)=>sum+Math.max(0, Number(row?.prezzo||0)),0);
}
function calcOrderDiscount(orderLike){
  return parseFlexibleAmount(orderLike?.scontoCliente ?? orderLike?.sconto ?? 0);
}
function calcOrderNetTotal(rows, discount){
  return Math.max(0, calcOrderSubtotal(rows) - calcOrderDiscount({scontoCliente:discount}));
}
function updateOrderTotalsPreview(){
  const subtotal=calcOrderSubtotal(ordRows);
  const discount=Math.min(parseFlexibleAmount(document.getElementById('o_discount')?.value||0), subtotal);
  const total=Math.max(0, subtotal-discount);
  const totalEl=document.getElementById('o_tot');
  if(totalEl) totalEl.textContent=money(total);
  const metaEl=document.getElementById('o_tot_meta');
  if(metaEl) metaEl.textContent=`Subtotale ${money(subtotal)} • Sconto ${money(discount)}`;
  return {subtotal, discount, total};
}
function buildOrderCloudNote(ord){
  const parts=[];
  const base=String(ord?.note||'').trim();
  if(base) parts.push(base);
  if(ord?.mis) parts.push(`[MIS:${ord.mis}]`);
  const discount=calcOrderDiscount(ord);
  if(discount>0) parts.push(`[SCONTO:${discount.toFixed(2)}]`);
  return parts.join(' ') || null;
}
function extractOrderNoteMeta(rawNote){
  const raw=String(rawNote||'');
  const misMatch=raw.match(/\[MIS:([^\]]+)\]/i);
  const discountMatch=raw.match(/\[SCONTO:([^\]]+)\]/i);
  const cleanNote=raw.replace(/\s*\[MIS:[^\]]+\]\s*/gi,' ').replace(/\s*\[SCONTO:[^\]]+\]\s*/gi,' ').trim();
  return { cleanNote, mis: misMatch ? misMatch[1].trim() : '', scontoCliente: parseFlexibleAmount(discountMatch ? discountMatch[1] : 0) };
}

/* ====== DATE LINE ====== */
function setDateLine(){
  const x=document.getElementById('dateLine');
  if(!x) return;
  const d=new Date();
  const days=["domenica","lunedì","martedì","mercoledì","giovedì","venerdì","sabato"];
  const dd=String(d.getDate()).padStart(2,'0');
  const mm=String(d.getMonth()+1).padStart(2,'0');
  const yyyy=d.getFullYear();
  x.textContent=`${days[d.getDay()]} ${dd}/${mm}/${yyyy} • ${d.toLocaleTimeString('it-IT')}`;
}
setInterval(setDateLine, 1000); document.addEventListener('DOMContentLoaded', setDateLine);

/* ====== QUALITY + PRICE RULES ====== */
function qualityFromCode(code){
  const c=String(code||'').trim();
  if(!c) return '';
  const first=c[0];
  if(first==='2' || first==='3') return 'ORIGINALE';
  if(first==='1' || /[A-Za-z]/.test(first)) return 'STANDARD';
  return 'STANDARD';
}
function supplierRuleFromCode(code){
  const c=String(code||'').trim();
  if(!c) return {mode:'free', options:['Jessica','Daniel'], value:''};
  const first=c[0];
  if(first==='2' || first==='3') return {mode:'fixed', options:['Jayden'], value:'Jayden'};
  if(first==='1' || /[A-Za-z]/.test(first)) return {mode:'choice', options:['Jessica','Daniel'], value:''};
  return {mode:'choice', options:['Jessica','Daniel'], value:''};
}
function getArticleBrandValue(){
  const sel=document.getElementById('a_brand');
  const custom=document.getElementById('a_brand_custom');
  if(!sel) return "";
  if(sel.value==='__ALTRO__') return String(custom?.value||'').trim();
  return String(sel.value||'').trim();
}
function syncBrandField(value=''){
  const sel=document.getElementById('a_brand');
  const custom=document.getElementById('a_brand_custom');
  if(!sel || !custom) return;
  const clean=String(value||'').trim();
  const known=getBrandPresetList().includes(clean);
  if(clean && !known){
    sel.value='__ALTRO__';
    custom.style.display='block';
    custom.value=clean;
  }else{
    sel.value=clean||'';
    custom.style.display=sel.value==='__ALTRO__' ? 'block' : 'none';
    if(sel.value!=='__ALTRO__') custom.value='';
  }
}
function handleBrandSelectionChange(){
  const sel=document.getElementById('a_brand');
  const custom=document.getElementById('a_brand_custom');
  if(!sel || !custom) return;
  const show=sel.value==='__ALTRO__';
  custom.style.display=show ? 'block' : 'none';
  if(!show) custom.value='';
  renderArtAutoFields();
  if(show) setTimeout(()=>custom.focus(),0);
}

function updateSupplierField(preferredValue=''){
  const sel=document.getElementById('a_forn');
  const hint=document.getElementById('a_forn_hint');
  if(!sel) return;
  const rule=supplierRuleFromCode(document.getElementById('a_cod')?.value||'');
  const current=String(preferredValue || sel.value || '').trim();
  sel.innerHTML='';
  if(rule.mode==='fixed'){
    sel.innerHTML='<option value="Jayden">Jayden</option>';
    sel.value='Jayden';
    sel.disabled=true;
    if(hint) hint.textContent='Codice che inizia per 2 o 3: fornitore fisso Jayden.';
    return;
  }
  sel.disabled=false;
  const ph=document.createElement('option');
  ph.value='';
  ph.textContent='Seleziona fornitore';
  sel.appendChild(ph);
  rule.options.forEach(name=>{
    const opt=document.createElement('option');
    opt.value=name;
    opt.textContent=name;
    sel.appendChild(opt);
  });
  sel.value=rule.options.includes(current)?current:'';
  if(hint) hint.textContent='Codice standard: scegli Jessica oppure Daniel.';
}
function calcFromUsd(usd, qual){
  const costo=(Number(usd||0)*0.90)+5;
  if(!isFinite(costo)) return {costo:0, sell:0, marg:0};
  if(qual==='ORIGINALE'){
    let guad=costo*0.30;
    if(guad<60) guad=60;
    if(guad>75) guad=75;
    const sell=round5(costo+guad);
    return {costo, sell, marg:guad};
  }else{
    let marg=costo*0.55;
    if(marg<50) marg=50;
    if(marg>60) marg=60;
    const sell=round5(costo+marg);
    return {costo, sell, marg};
  }
}
function promoValid(a){
  if(!a.promoAttiva) return false;
  const p=Number(a.prezzoPromo||0);
  const d=String(a.scadenzaPromo||'').trim(); // yyyy-mm-dd
  if(!(p>0) || d.length<8) return false;
  const today=todayStr();
  return d>=today;
}
function currentPrice(a){
  return promoValid(a) ? Number(a.prezzoPromo) : Number(a.prezzoVendita||0);
}


function orderPaidStatus(o){
  const stato=String(o?.stato||'').trim().toLowerCase();
  const autoPaidStatuses=new Set(['pagato','in lavorazione','spedito','consegnato']);
  return autoPaidStatuses.has(stato);
}

function orderIncassato(o){
  if(orderPaidStatus(o)) return Number(o?.totale||0);
  return Number(o?.incassato||0);
}

function orderMargin(o, db){
  const righe=Array.isArray(o?.righe)?o.righe:[];
  let margin=0;
  for(const r of righe){
    const prezzo=Number(r?.prezzo||0);
    const art=(db?.articoli||[]).find(x=>x.id===r.articoloId || (r.codice && x.codice===r.codice));
    const costo=Number(art?.costoEur||r?.costoEur||0);
    margin += Math.max(0, prezzo - costo);
  }
  return margin;
}

/* ====== POST (rules) ====== */
function emojiQualityForPost(a){
  const q=qualityFromCode(a.codice);
  return (q==='ORIGINALE') ? '🥇' : '🔝💯';
}
function escapeRegExp(str){
  return String(str||'').replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
}
function brandVariants(brand){
  const clean=String(brand||'').trim();
  if(!clean) return [];
  const words=clean.split(/\s+/).map(x=>x.trim()).filter(Boolean);
  const variants=[clean, ...words];
  const acronym=words.map(w=>w[0]||'').join('').toUpperCase();
  if(acronym && acronym.length>=2) variants.push(acronym);
  const compact=clean.replace(/[^a-z0-9]/gi,'');
  if(compact && compact.length<=5) variants.push(compact);
  const uniq=[];
  for(const part of variants){
    const key=String(part||'').trim().toLowerCase();
    if(!key || uniq.some(x=>x.toLowerCase()===key)) continue;
    uniq.push(String(part).trim());
  }
  return uniq.sort((a,b)=>b.length-a.length);
}
function stripBrandFromText(text, brand){
  let out=String(text||'').replace(/\s+/g,' ').trim();
  const variants=brandVariants(brand);
  if(!out || !variants.length) return out;
  variants.forEach(part=>{
    const rx=/[a-z0-9]/i.test(part)
      ? new RegExp(`\\b${escapeRegExp(part)}\\b`,'gi')
      : new RegExp(escapeRegExp(part),'gi');
    out=out.replace(rx,' ');
  });
  return out.replace(/\s{2,}/g,' ').replace(/^[-–—:;,\.\s]+|[-–—:;,\.\s]+$/g,'').trim();
}
function normalizePostLine(text, brand){
  return stripBrandFromText(text, brand).replace(/\s+/g,' ').trim();
}
function uniquePostLines(lines=[]){
  const out=[];
  const seen=new Set();
  for(const raw of lines){
    const line=String(raw||'').replace(/\s+/g,' ').trim();
    if(!line) continue;
    const key=line.toLowerCase();
    if(seen.has(key)) continue;
    seen.add(key);
    out.push(line);
  }
  return out;
}
function formatPostMisura(misura){
  const clean=String(misura||'').replace(/^mis\.?\s*/i,'').trim();
  return clean ? `Mis. ${clean}` : '';
}
function buildPost(a){
  if(!a.codice) return '';
  const brand=(a.brand||'').trim();
  const modello=normalizePostLine(a.modello||'', brand);
  const descrizione=normalizePostLine(a.descrizione||'', brand);
  const variante=normalizePostLine(a.variante||'', brand);
  const colore=normalizePostLine(a.colore||'', brand);
  const materiale=normalizePostLine(a.materiale||'', brand);
  const colori=normalizePostLine(a.colori||'', brand);
  const tracolla=normalizePostLine(a.tracolla||'', brand);
  const misura=normalizePostLine(a.misura||'', brand);
  const taglia=normalizePostLine(a.taglia||'', brand);
  const qemoji=emojiQualityForPost(a);
  const lines=[];
  if(a.promoAttiva){
    const scadenzaRaw=String(a.scadenzaPromo||'').trim();
    let scadenzaLabel=scadenzaRaw;
    if(/^\d{4}-\d{2}-\d{2}$/.test(scadenzaRaw)){
      const [yyyy,mm,dd]=scadenzaRaw.split('-');
      scadenzaLabel=`${dd}/${mm}/${yyyy}`;
    }
    const tipoMateriale=materiale || variante;
    lines.push('⭕️ PROMOZIONE ⭕️');
    if(scadenzaLabel) lines.push(`(fino al ${scadenzaLabel})`);
    if(modello || qemoji) lines.push([modello,qemoji].filter(Boolean).join(' ').trim());
    if(tipoMateriale) lines.push(tipoMateriale);
    if(colore) lines.push(colore);
    if(misura) lines.push(formatPostMisura(misura));
    lines.push(`cod. ${a.codice}`);
    return uniquePostLines(lines).join('\n');
  }
  if(modello || qemoji) lines.push([modello,qemoji].filter(Boolean).join(' ').trim());
  if(descrizione) lines.push(descrizione);
  if(taglia) lines.push(`Taglia ${taglia}`);
  if(variante) lines.push(variante);
  if(colore) lines.push(colore);
  if(misura) lines.push(formatPostMisura(misura));
  if(a.scatola) lines.push('Con scatola 🎁');
  if(materiale) lines.push(`🧵 ${materiale}`);
  if(colori) lines.push(colori);
  if(tracolla) lines.push(tracolla);
  lines.push(`cod. ${a.codice}`);
  return uniquePostLines(lines).join('\n');
}
function buildCloudArticleMeta(art){
  return {
    brand: art?.brand||'',
    modello: art?.modello||'',
    categoria: art?.categoria||'',
    descrizione: art?.descrizione||'',
    fornitore: art?.fornitore||'',
    fornitoreLink: art?.fornitoreLink||'',
    taglia: art?.taglia||'',
    variante: art?.variante||'',
    colore: art?.colore||'',
    misura: art?.misura||'',
    costoUsd: Number(art?.costoUsd||0),
    costoEur: Number(art?.costoEur||0),
    prezzoVendita: Number(art?.prezzoVendita||0),
    promoAttiva: !!art?.promoAttiva,
    prezzoPromo: Number(art?.prezzoPromo||0),
    scadenzaPromo: art?.scadenzaPromo||'',
    post: art?.post||'',
    note: art?.note||'',
    foto: normalizeCloudPhotoPathList(art?.foto||[])
  };
}
function packCloudArticleDescription(art){
  const plain=[String(art?.descrizione||'').trim(), String(art?.note||'').trim()].filter(Boolean).join('\n\n');
  let meta='';
  try{ meta=`\n\n[VGMETA]${JSON.stringify(buildCloudArticleMeta(art))}[/VGMETA]`; }catch(_e){}
  return (plain + meta).trim() || null;
}
function unpackCloudArticleDescription(text){
  const raw=String(text||'');
  const match=raw.match(/\[VGMETA\]([\s\S]*?)\[\/VGMETA\]/i);
  let meta={};
  if(match?.[1]){
    try{ meta=JSON.parse(match[1]); }catch(_e){}
  }
  const plain=raw.replace(/\s*\[VGMETA\][\s\S]*?\[\/VGMETA\]\s*/gi,' ').replace(/\s{3,}/g,'\n\n').trim();
  return { plain, meta: (meta && typeof meta==='object') ? meta : {} };
}
function parseLegacyCloudDescription(text){
  const raw=String(text||'').trim();
  if(!raw) return { descrizione:'', note:'', post:'' };
  const noteMatch=raw.match(/(?:^|\n\n)Note:\s*([\s\S]*?)(?=(?:\n\nPost:)|$)/i);
  const postMatch=raw.match(/(?:^|\n\n)Post:\s*([\s\S]*?)$/i);
  const descrizione=raw
    .replace(/(?:^|\n\n)Note:\s*[\s\S]*?(?=(?:\n\nPost:)|$)/i,' ')
    .replace(/(?:^|\n\n)Post:\s*[\s\S]*$/i,' ')
    .replace(/\s{3,}/g,'\n\n')
    .trim();
  return { descrizione, note:(noteMatch?.[1]||'').trim(), post:(postMatch?.[1]||'').trim() };
}

function withIntlPrefix(tel){
  const raw=String(tel||'').trim();
  if(!raw) return '';
  if(raw.startsWith('+')) return raw;
  if(raw.startsWith('00')) return '+'+raw.slice(2).replace(/\s+/g,'');
  const digits=raw.replace(/\D+/g,'');
  if(!digits) return raw;
  if(digits.startsWith('39')) return '+'+digits;
  return '+39 '+digits;
}
function buildShippingAddress(c){
  const name=(c?.nome||'').trim();
  const addr=(c?.indirizzo||'').trim();
  const cap=(c?.cap||'').trim();
  const city=(c?.citta||'').trim();
  const prov=(c?.provincia||'').trim();
  const phone=withIntlPrefix(c?.telefono||'');
  const cityLine=[cap,city,prov].filter(Boolean).join(' ');
  return ['Shipping Address',name,addr,cityLine,'Italy',phone].filter(Boolean).join('\n');
}
function refreshClientShipping(){
  const el=document.getElementById('c_ship');
  if(!el) return;
  const c={
    nome:document.getElementById('c_nome')?.value||'',
    telefono:document.getElementById('c_tel')?.value||'',
    indirizzo:document.getElementById('c_ind')?.value||'',
    cap:document.getElementById('c_cap')?.value||'',
    citta:document.getElementById('c_citta')?.value||'',
    provincia:document.getElementById('c_prov')?.value||''
  };
  el.value=buildShippingAddress(c);
  fitTextarea(el);
}

/* ====== NAV ====== */
let activeModalId=null;
function renderPageState(name){
  document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));
  const sec=document.getElementById('sec_'+name); if(sec) sec.classList.add('active');
  document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active', t.dataset.go===name));
  document.querySelectorAll('.navBottom button').forEach(b=>b.classList.toggle('active', b.dataset.go===name));
}
function currentHistoryPage(){
  return (history.state&&history.state.page) || location.hash.replace('#','') || 'home';
}
function go(name, push=true){
  renderPageState(name);
  const state={page:name};
  if(name==='articoli') state.artBrowse={...artBrowseState};
  if(push) history.pushState(state,'', '#'+name);
  else history.replaceState({...history.state, ...state},'', '#'+name);
}
window.addEventListener('popstate',(e)=>{
  if(activeModalId){ const mid=activeModalId; activeModalId=null; document.getElementById(mid).style.display='none'; return; }
  const state=e.state||{};
  const page=state.page || location.hash.replace('#','') || 'home';
  renderPageState(page);
  if(page==='articoli'){
    const b=state.artBrowse||{level:'categorie',categoria:'',brand:''};
    setArtBrowse(b.level||'categorie', b.categoria||'', b.brand||'', false);
    renderArt();
  }
});

/* ====== UI helpers ====== */
function show(id, push=true){ const el=document.getElementById(id); if(!el) return; el.style.display='flex'; activeModalId=id; if(push) history.pushState({page:location.hash.replace('#','')||'home', modal:id},'', location.href); }
function hide(id, fromPop=false){ const el=document.getElementById(id); if(!el) return; el.style.display='none'; if(activeModalId===id) activeModalId=null; if(!fromPop && history.state && history.state.modal===id) history.back(); }
function toast(msg){
  let t=document.getElementById('vg_toast');
  if(!t){ t=document.createElement('div'); t.id='vg_toast';
    t.style.cssText='position:fixed;left:50%;bottom:78px;transform:translateX(-50%);background:#111827;color:#fff;padding:10px 12px;border-radius:12px;font-weight:900;font-size:12px;z-index:9999;box-shadow:0 12px 24px rgba(0,0,0,.25);max-width:90vw;text-align:center;display:none';
    document.body.appendChild(t);
  }
  t.textContent=msg; t.style.display='block';
  clearTimeout(window.__t); window.__t=setTimeout(()=>t.style.display='none',1400);
}
let confirmCallback=null;
function askConfirm(text, cb, title='Conferma'){ document.getElementById('confirmTitle').textContent=title; document.getElementById('confirmText').textContent=text; confirmCallback=cb; show('mConfirm'); }
function closeConfirm(run){ hide('mConfirm'); const fn=confirmCallback; confirmCallback=null; if(run && typeof fn==='function') fn(); }
function toggleCloudSyncMini(){ return; }
function copyTextFrom(el){
  const t=el.value||el.textContent||'';
  if(!t) return toast('Niente da copiare');
  navigator.clipboard?.writeText(t).then(()=>toast('Copiato')).catch(()=>{ try{ el.select(); document.execCommand('copy'); toast('Copiato'); }catch(e){ toast('Copia non disponibile'); } });
}

const UI_KEY='vg_ui_prefs_v1';
function defaultUiPrefs(){
  return {
    title:'Vanity & Glamour',
    cloud:'Cloud',
    tabs:{home:'Dashboard',articoli:'Articoli',clienti:'Clienti',ordini:'Ordini',finanze:'Finanze',impostazioni:'Impost.'},
    buttons:{save:'Salva',cancel:'Annulla',delete:'Elimina'},
    css:''
  };
}
function normalizeUiPrefs(v){
  const d=defaultUiPrefs();
  const o=v&&typeof v==='object'?v:{};
  return {
    title:String(o.title||d.title),
    cloud:String(o.cloud||d.cloud),
    tabs:{...d.tabs,...(o.tabs||{})},
    buttons:{...d.buttons,...(o.buttons||{})},
    css:String(o.css||'')
  };
}
function loadUiPrefs(){ try{ return normalizeUiPrefs(JSON.parse(localStorage.getItem(UI_KEY)||'{}')); }catch(e){ return defaultUiPrefs(); } }
function saveUiPrefsData(prefs){ localStorage.setItem(UI_KEY, JSON.stringify(normalizeUiPrefs(prefs))); }
function fillUiEditor(){
  const p=loadUiPrefs();
  const set=(id,val)=>{ const el=document.getElementById(id); if(el) el.value=val||''; };
  set('e_title',p.title); set('e_cloud',p.cloud);
  set('e_tab_home',p.tabs.home); set('e_tab_articoli',p.tabs.articoli); set('e_tab_clienti',p.tabs.clienti);
  set('e_tab_ordini',p.tabs.ordini); set('e_tab_finanze',p.tabs.finanze); set('e_tab_impostazioni',p.tabs.impostazioni);
  set('e_btn_save',p.buttons.save); set('e_btn_cancel',p.buttons.cancel); set('e_btn_delete',p.buttons.delete);
  set('e_css',p.css);
}
function readUiEditor(){
  const get=id=>document.getElementById(id)?.value?.trim()||'';
  return normalizeUiPrefs({
    title:get('e_title'), cloud:get('e_cloud'),
    tabs:{home:get('e_tab_home'),articoli:get('e_tab_articoli'),clienti:get('e_tab_clienti'),ordini:get('e_tab_ordini'),finanze:get('e_tab_finanze'),impostazioni:get('e_tab_impostazioni')},
    buttons:{save:get('e_btn_save'),cancel:get('e_btn_cancel'),delete:get('e_btn_delete')},
    css:document.getElementById('e_css')?.value||''
  });
}
function applyUiPrefs(){
  const p=loadUiPrefs();
  const titleEl=document.getElementById('appTitle'); if(titleEl) titleEl.textContent=p.title;
  document.title=p.title;
  document.querySelectorAll('[data-tab]').forEach(el=>{ const k=el.dataset.tab; if(p.tabs[k]) el.textContent=p.tabs[k]; });
  document.querySelectorAll('[data-nav]').forEach(el=>{ const k=el.dataset.nav; if(p.tabs[k]) el.textContent=p.tabs[k]; });
  document.querySelectorAll('[data-action="saveArt"],[data-action="saveCli"],[data-action="saveOrd"]').forEach(el=>el.textContent=p.buttons.save);
  document.querySelectorAll('[data-action="closeEdit"],[data-action="closeCli"],[data-action="closeOrd"],[data-action="closeCloudLogin"],[data-action="confirmNo"]').forEach(el=>el.textContent=p.buttons.cancel);
  document.querySelectorAll('[data-action="deleteArt"],[data-action="deleteCli"],[data-action="deleteOrd"],[data-action="confirmYes"]').forEach(el=>el.textContent=p.buttons.delete);
  if(!cloudBusy && !cloudSession){ const cloudEl=document.getElementById('cloudState'); if(cloudEl) cloudEl.textContent=p.cloud; }
  let styleEl=document.getElementById('uiCustomStyle');
  if(!styleEl){ styleEl=document.createElement('style'); styleEl.id='uiCustomStyle'; document.head.appendChild(styleEl); }
  styleEl.textContent=p.css||'';
}

/* ====== RENDER ====== */
const SHIP_ALERTS_KEY='vg_ship_alerts_v1';
const SHIP_SNAPSHOT_KEY='vg_ship_snapshot_v1';
function getOrderSnapshotMap(ordini=[]){
  const map={};
  (ordini||[]).forEach(o=>{
    const key=String(o.id||o.numeroOrdine||'').trim();
    if(!key) return;
    map[key]={id:o.id||key, numeroOrdine:o.numeroOrdine||'',stato:o.stato||'',tracking:o.tracking||'',data:o.data||''};
  });
  return map;
}
function loadShipAlerts(){
  try{ return JSON.parse(localStorage.getItem(SHIP_ALERTS_KEY)||'[]'); }catch{ return []; }
}
function saveShipAlerts(items){
  try{ localStorage.setItem(SHIP_ALERTS_KEY, JSON.stringify((items||[]).slice(0,20))); }catch{}
}
function renderShipAlerts(){
  const box=document.getElementById('shipAlerts');
  if(!box) return;
  const items=loadShipAlerts();
  if(!items.length){
    box.innerHTML='<div class="shipAlertEmpty">Nessun aggiornamento spedizioni.</div>';
    return;
  }
  const db=loadDB();
  box.innerHTML=items.map(a=>{
    let orderId=String(a.orderId||'').trim();
    if(!orderId){
      const m=String(a.title||'').match(/Ordine\s+([^:]+):/i);
      const num=m ? String(m[1]||'').trim() : '';
      if(num){
        const ord=(db.ordini||[]).find(o=>String(o.numeroOrdine||'').trim()===num || String(o.id||'').trim()===num);
        if(ord) orderId=String(ord.id||'').trim();
      }
    }
    return `<div class="shipAlert"${orderId?` data-open="ord" data-id="${esc(orderId)}"`:''}><div class="t">${esc(a.title||'Aggiornamento spedizione')}</div><div class="s">${esc(a.text||'')}</div><div class="meta">${esc(a.when||'')}</div></div>`;
  }).join('');
}
function updateShippingNotifications(db, source='app'){
  const curr=getOrderSnapshotMap(db?.ordini||[]);
  let prev={};
  try{ prev=JSON.parse(localStorage.getItem(SHIP_SNAPSHOT_KEY)||'{}'); }catch{}
  const alerts=loadShipAlerts();
  const fresh=[];
  Object.keys(curr).forEach(key=>{
    const now=curr[key], old=prev[key];
    if(!old) return;
    if((now.stato||'') !== (old.stato||'')){
      fresh.push({orderId:now.id||key, title:`Ordine ${now.numeroOrdine||key}: stato aggiornato`, text:`Da ${old.stato||'-'} a ${now.stato||'-'}.`, when:new Date().toLocaleString('it-IT')});
    }
    if((now.tracking||'') !== (old.tracking||'')){
      const t=now.tracking?`Nuovo tracking ${now.tracking}.`:'Tracking rimosso o svuotato.';
      fresh.push({orderId:now.id||key, title:`Ordine ${now.numeroOrdine||key}: tracking aggiornato`, text:t, when:new Date().toLocaleString('it-IT')});
    }
  });
  if(fresh.length){
    const merged=[...fresh,...alerts].slice(0,20);
    saveShipAlerts(merged);
    toast(fresh.length===1 ? '1 aggiornamento spedizione' : `${fresh.length} aggiornamenti spedizione`);
  }
  try{ localStorage.setItem(SHIP_SNAPSHOT_KEY, JSON.stringify(curr)); }catch{}
  renderShipAlerts();
}

function moodPick(seed, items){
  if(!items || !items.length) return '';
  return items[Math.abs(Number(seed)||0) % items.length];
}
function dashboardMood(incMonth, prevMonth, openOrders, totalOrders){
  const ratio = prevMonth>0 ? incMonth/prevMonth : (incMonth>0 ? 1.2 : 0);
  const now=new Date();
  const seed=(now.getFullYear()*100)+(now.getMonth()+1)+Math.round(incMonth)+openOrders+(totalOrders*3);
  if(totalOrders===0) return {
    title:moodPick(seed,["Si riparte da qui","Base pronta a fare scintille","Si comincia senza zavorra"]),
    sub:moodPick(seed+7,["Nessun ordine registrato: dashboard pronta a ripartire.","Zero ordini, zero drammi: è il momento perfetto per spingere forte.","Foglio pulito: ora tocca riempirlo di vendite belle pesanti."])
  };
  if(incMonth===0 && openOrders>0) return {
    title:moodPick(seed,["Vendite ferme, ordini da chiudere","Pacchi in giro, cassa ferma","Ordini aperti, soldi ancora in giro"]),
    sub:moodPick(seed+7,["Questo mese non risulta ancora incassato: conviene spingere le chiusure.","Hai movimento ma pochi incassi: meglio chiudere il cerchio e far entrare i soldi.","C'è roba da consegnare: serve una stretta finale per trasformarla in incasso."])
  };
  if(incMonth===0) return {
    title:moodPick(seed,["Mese molto lento","Mese moscio","Qui serve una sveglia bella forte"]),
    sub:moodPick(seed+7,["Poche vendite registrate: serve rimettere movimento.","Le vendite stanno dormendo: è ora di smuovere un po' il banco.","Situazione tranquilla fin troppo: tocca dare una scossa ai contatti."])
  };
  if(openOrders>=6 && incMonth>0) return {
    title:moodPick(seed,["Bel movimento, occhio ai tempi","Banco acceso, calendario sotto pressione","Gira bene, ma non addormentarti"]),
    sub:moodPick(seed+7,["Le vendite girano ma hai parecchi ordini ancora aperti.","Stai vendendo bene, però hai un po' di roba da chiudere senza perdere il ritmo.","C'è traffico buono: conviene tenere le spedizioni sul pezzo."])
  };
  if(ratio>=1.25) return {
    title:moodPick(seed,["Vendite in spinta","Mese bello cattivo","Qui si corre sul serio"]),
    sub:moodPick(seed+7,["Questo mese sta andando meglio del precedente.","Il ritmo è salito: stai pestando bene sull'acceleratore.","Numeri più alti del mese scorso: bella botta, continua così."])
  };
  if(ratio>=0.9) return {
    title:moodPick(seed,["Andamento stabile","Regolare ma vivo","Tutto sotto controllo, senza fiacca"]),
    sub:moodPick(seed+7,["Flusso regolare: numeri sotto controllo.","Stai tenendo una linea solida: niente fuochi d'artificio, ma neanche buchi.","Mese equilibrato: gira pulito e senza stonature."])
  };
  if(ratio>=0.5) return {
    title:moodPick(seed,["Si muove, ma può fare meglio","C'è vita, ma manca il colpo grosso","Sta girando, però non basta ancora"]),
    sub:moodPick(seed+7,["Le vendite ci sono, però il ritmo è ancora basso.","Qualcosa entra, ma puoi spremere di più senza ammazzarti.","Movimento discreto: con due spinte giuste può diventare un bel mese."])
  };
  return {
    title:moodPick(seed,["Vendite basse, da scuotere","Mese fiacco da prendere a schiaffi","Qui serve una bella svegliata"]),
    sub:moodPick(seed+7,["Il mese è fiacco: conviene spingere ordini e follow-up.","Serve una botta di energia su clienti e ordini, sennò resta tutto moscio.","Pochi numeri e poca spinta: meglio tornare a martellare bene."])
  };
}

function monthSalesDetails(db, year, month){
  const items=(db?.ordini||[]).filter(o=>{
    const d=new Date((o?.data||'')+'T12:00:00');
    return !isNaN(d) && d.getFullYear()===Number(year) && d.getMonth()===Number(month);
  }).sort((a,b)=>String(b.data||'').localeCompare(String(a.data||'')));
  const clienti=new Map((db?.clienti||[]).map(c=>[String(c.id), c]));
  const incassato=items.reduce((s,o)=>s+orderIncassato(o),0);
  const rows=items.map(o=>({
    id:o.id||'',
    data:o.data||'',
    cliente:clienti.get(String(o.clienteId||''))?.nome || '-',
    stato:o.stato||'-',
    totale:orderIncassato(o)
  }));
  return {rows, incassato};
}

function openMonthSales(year, month, label){
  const db=loadDB();
  const info=monthSalesDetails(db, year, month);
  const title=document.getElementById('monthSalesTitle');
  const sub=document.getElementById('monthSalesSub');
  const list=document.getElementById('monthSalesList');
  if(title) title.textContent=`Vendite ${label||''}`.trim();
  if(sub) sub.textContent=`Ordini del mese: ${info.rows.length} • Incassato ${money(info.incassato)}`;
  if(list){
    list.innerHTML = info.rows.length
      ? info.rows.map(r=>`<div class="row" style="grid-template-columns:1fr auto"><div class="main"><div class="t">${esc(r.cliente)}</div><div class="s">${esc(r.data)} • ${esc(r.stato)}${r.id?` • #${esc(r.id)}`:''}</div></div><div class="pricePaid">${money(r.totale)}</div></div>`).join('')
      : '<div class="small">Nessuna vendita in questo mese.</div>';
  }
  show('mMonthSales');
}

function renderHome(){
  const db=loadDB();
  const now=new Date(), curMonth=now.getMonth(), curYear=now.getFullYear();
  const ordini=db.ordini||[];
  const inCorso=ordini.filter(o=>String(o.stato||'').trim().toLowerCase()!=='consegnato').length;
  const totaleOrdini=ordini.reduce((s,o)=>s+Number(o.totale||0),0);
  const mediaOrdini=ordini.length ? totaleOrdini / ordini.length : 0;
  const guadagnoTot=ordini.reduce((s,o)=>s+(orderPaidStatus(o)?orderMargin(o,db):0),0);
  const sameMonth=o=>{ const d=new Date((o.data||'')+'T12:00:00'); return !isNaN(d) && d.getMonth()===curMonth && d.getFullYear()===curYear; };
  const guadagnoMese=ordini.filter(sameMonth).reduce((s,o)=>s+(orderPaidStatus(o)?orderMargin(o,db):0),0);
  const incMese=ordini.filter(sameMonth).reduce((s,o)=>s+orderIncassato(o),0);
  const incTot=ordini.reduce((s,o)=>s+orderIncassato(o),0);
  const daIncassare=Math.max(0, totaleOrdini-incTot);

  document.getElementById('c_open_orders').textContent=inCorso;
  document.getElementById('c_profit_month').textContent=money(guadagnoMese);
  document.getElementById('c_avg_order').textContent=money(mediaOrdini);
  document.getElementById('c_profit_total').textContent=money(guadagnoTot);
  document.getElementById('c_inc_month').textContent=money(incMese);
  document.getElementById('c_due_total').textContent=money(daIncassare);

  const months=[];
  for(let i=5;i>=0;i--){
    const d=new Date(curYear, curMonth-i, 1);
    const label=d.toLocaleDateString('it-IT',{month:'short'}).replace('.','');
    const value=ordini.filter(o=>{ const od=new Date((o.data||'')+'T12:00:00'); return !isNaN(od) && od.getMonth()===d.getMonth() && od.getFullYear()===d.getFullYear(); }).reduce((s,o)=>s+orderIncassato(o),0);
    months.push({label:label.charAt(0).toUpperCase()+label.slice(1), value, month:d.getMonth(), year:d.getFullYear()});
  }
  const max=Math.max(1,...months.map(m=>m.value));
  document.getElementById('homeSpark').innerHTML=months.map((m,idx)=>`<div class="sparkCol"><div class="sparkBarWrap"><button class="sparkBarBtn" type="button" data-action="openMonthSales" data-month="${m.month}" data-year="${m.year}" data-label="${esc(m.label)}" title="Apri vendite di ${esc(m.label)}"><div class="sparkBar ${idx===months.length-1?'soft':''}" style="height:${Math.max(12,Math.round((m.value/max)*100))}%" title="${esc(m.label)}: ${money(m.value)}"></div></button></div><div class="sparkLbl">${esc(m.label)}</div></div>`).join('');

  const prevMonth=months.length>1 ? months[months.length-2].value : 0;
  const mood=dashboardMood(incMese, prevMonth, inCorso, ordini.length);
  document.getElementById('homeMood').textContent=mood.title;
  document.getElementById('homeMoodSub').textContent=mood.sub;

  const last=ordini.slice().sort((a,b)=>(b._ts||0)-(a._ts||0))[0];
  const exp=db.articoli.filter(promoValid).sort((a,b)=>String(a.scadenzaPromo).localeCompare(String(b.scadenzaPromo)))[0];
  const lines=[];
  lines.push(last?`Ultimo ordine: ${last.stato} • ${last.data||''}`:'Ultimo ordine: nessuno');
  lines.push(exp?`Promo attiva: ${exp.brand||''} ${exp.modello||''}`:'Promo attiva: nessuna');
  lines.push(`Ordini aperti: ${inCorso} • Incassato mese ${money(incMese)}`);

  const list=document.getElementById('dashList');
  list.innerHTML=lines.map((t,i)=>{
    const target=(i===1)?'articoli':'ordini';
    return `<div class="row" data-go="${target}" style="grid-template-columns:1fr"><div class="main"><div class="t">${esc(t)}</div></div></div>`;
  }).join('');
  renderShipAlerts();
}

function normalizeCategoryName(v){
  return String(v||'').trim().replace(/\s+/g,' ').toLowerCase();
}
function articleCategoryOptions(db){
  const saved=Array.isArray(db?.categorie)?db.categorie:[];
  const found=(db?.articoli||[]).map(a=>String(a?.categoria||'').trim()).filter(Boolean);
  const out=[];
  const seen=new Set();
  for(const name of [...saved, ...found]){
    const clean=String(name||'').trim().replace(/\s+/g,' ');
    const key=normalizeCategoryName(clean);
    if(!clean || seen.has(key)) continue;
    seen.add(key);
    out.push(clean);
  }
  return out.sort((a,b)=>a.localeCompare(b,'it',{sensitivity:'base'}));
}
function renderCategorySettings(){
  const db=loadDB();
  const box=document.getElementById('catList');
  const hint=document.getElementById('catHint');
  if(!box) return;
  const cats=articleCategoryOptions(db);
  const savedSet=new Set((Array.isArray(db?.categorie)?db.categorie:[]).map(normalizeCategoryName));
  box.innerHTML=cats.length?cats.map(c=>`<div class="row" style="grid-template-columns:1fr auto auto;gap:8px"><div class="main"><div class="t">${esc(c)}</div><div class="small">${savedSet.has(normalizeCategoryName(c))?'Categoria salvata nelle impostazioni':'Categoria rilevata da articoli già esistenti'}</div></div><div><button class="btn smallish" type="button" data-action="renameCategory" data-name="${esc(c)}">Modifica</button></div><div><button class="btn danger smallish" type="button" data-action="deleteCategory" data-name="${esc(c)}">Elimina</button></div></div>`).join(''):'<div class="small">Nessuna categoria salvata.</div>';
  if(hint) hint.textContent='Puoi aggiungere, rinominare o eliminare le categorie. Se elimini una categoria, viene tolta anche dagli articoli che la usavano e gli articoli restano in Senza categoria.';
}
function addCategory(){
  const input=document.getElementById('catName');
  const nome=String(input?.value||'').trim().replace(/\s+/g,' ');
  if(!nome){ toast('Scrivi il nome categoria'); return; }
  const db=loadDB();
  const key=normalizeCategoryName(nome);
  const exists=(db.categorie||[]).some(c=>normalizeCategoryName(c)===key) || (db.articoli||[]).some(a=>normalizeCategoryName(a?.categoria)===key);
  if(exists){ toast('Categoria già presente'); return; }
  const next=[...new Set([...(db.categorie||[]), nome])].sort((a,b)=>a.localeCompare(b,'it',{sensitivity:'base'}));
  db.categorie=next;
  if(!saveDB(db)) return;
  if(input) input.value='';
  renderCategorySettings();
  renderBrandSettings();
  refreshArticleCategorySelects();
  refreshArticleBrandSelects();
  toast('Categoria salvata');
}
function renameCategory(oldName){
  const cleanOld=String(oldName||'').trim().replace(/\s+/g,' ');
  if(!cleanOld) return;
  const nuovo=window.prompt('Nuovo nome categoria', cleanOld);
  if(nuovo===null) return;
  const cleanNew=String(nuovo||'').trim().replace(/\s+/g,' ');
  if(!cleanNew){ toast('Nome categoria vuoto'); return; }
  const oldKey=normalizeCategoryName(cleanOld);
  const newKey=normalizeCategoryName(cleanNew);
  const db=loadDB();
  if(oldKey!==newKey){
    const exists=(db.categorie||[]).some(c=>normalizeCategoryName(c)===newKey) || (db.articoli||[]).some(a=>normalizeCategoryName(a?.categoria)===newKey);
    if(exists){ toast('Esiste già una categoria con questo nome'); return; }
  }
  db.categorie=(db.categorie||[]).map(c=>normalizeCategoryName(c)===oldKey ? cleanNew : c);
  if(!(db.categorie||[]).some(c=>normalizeCategoryName(c)===newKey)) db.categorie.push(cleanNew);
  db.categorie=[...new Set((db.categorie||[]).map(c=>String(c||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'it',{sensitivity:'base'}));
  db.articoli=(db.articoli||[]).map(a=> normalizeCategoryName(a?.categoria)===oldKey ? {...a, categoria: cleanNew, _ts: Date.now()} : a);
  if(artBrowseState.categoria && normalizeCategoryName(artBrowseState.categoria)===oldKey){
    setArtBrowse(artBrowseState.level, cleanNew, artBrowseState.brand||'', false);
  }
  if(!saveDB(db)) return;
  renderCategorySettings();
  refreshArticleCategorySelects(cleanNew);
  renderArt();
  toast('Categoria aggiornata');
}
function deleteCategory(nome){
  const clean=String(nome||'').trim().replace(/\s+/g,' ');
  if(!clean) return;
  askConfirm(`Elimino la categoria "${clean}"? Gli articoli restano salvati ma finiscono in "Senza categoria".`,()=>{
    const db=loadDB();
    const key=normalizeCategoryName(clean);
    db.categorie=(db.categorie||[]).filter(c=>normalizeCategoryName(c)!==key);
    db.articoli=(db.articoli||[]).map(a=>{
      if(normalizeCategoryName(a?.categoria)!==key) return a;
      return {...a, categoria:'', _ts: Date.now()};
    });
    if(!saveDB(db)) return;
    if(artBrowseState.categoria && normalizeCategoryName(artBrowseState.categoria)===key){
      setArtBrowse('categorie','','',false);
    }
    renderCategorySettings();
    refreshArticleCategorySelects();
    renderArt();
    toast('Categoria eliminata');
  },'Elimina categoria');
}
function refreshArticleCategorySelects(selectedEdit=''){
  const db=loadDB();
  const options=articleCategoryOptions(db);
  const qSel=document.getElementById('qArtCat');
  const editSel=document.getElementById('a_cat');
  if(qSel){
    const prev=String(qSel.value||'').trim();
    qSel.innerHTML='<option value="">Tutte le categorie</option>'+options.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');
    qSel.value=options.includes(prev)?prev:'';
  }
  if(editSel){
    const wanted=String(selectedEdit||editSel.value||'').trim();
    editSel.innerHTML='<option value="">Seleziona categoria</option>'+options.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');
    if(wanted && !options.includes(wanted)) editSel.innerHTML += `<option value="${esc(wanted)}">${esc(wanted)}</option>`;
    editSel.value=wanted||'';
  }
}

const DEFAULT_BRANDS=['Louis Vuitton','Gucci','Chanel','Dior','Alexander McQueen','Balenciaga','Versace'];
function normalizeBrandName(v){
  return String(v||'').trim().replace(/\s+/g,' ').toLowerCase();
}
function articleBrandOptions(db){
  const seen=new Set();
  const out=[];
  const push=(v)=>{
    const clean=String(v||'').trim().replace(/\s+/g,' ');
    if(!clean || /^senza\s+brand$/i.test(clean)) return;
    const key=normalizeBrandName(clean);
    if(!key || seen.has(key)) return;
    seen.add(key);
    out.push(clean);
  };
  DEFAULT_BRANDS.forEach(push);
  (Array.isArray(db?.brands)?db.brands:[]).forEach(push);
  (Array.isArray(db?.articoli)?db.articoli:[]).forEach(a=>push(a?.brand));
  return out.sort((a,b)=>a.localeCompare(b,'it',{sensitivity:'base'}));
}
function renderBrandSettings(){
  const db=loadDB();
  const box=document.getElementById('brandList');
  const hint=document.getElementById('brandHint');
  if(!box) return;
  const brands=articleBrandOptions(db);
  const savedSet=new Set((Array.isArray(db?.brands)?db.brands:[]).map(normalizeBrandName));
  box.innerHTML=brands.length?brands.map(b=>`<div class="row" style="grid-template-columns:1fr auto auto;gap:8px"><div class="main"><div class="t">${esc(b)}</div><div class="small">${savedSet.has(normalizeBrandName(b))?'Brand salvato nelle impostazioni':'Brand rilevato da articoli già esistenti'}</div></div><div><button class="btn smallish" type="button" data-action="renameBrand" data-name="${esc(b)}">Modifica</button></div><div><button class="btn danger smallish" type="button" data-action="deleteBrand" data-name="${esc(b)}">Elimina</button></div></div>`).join(''):'<div class="small">Nessun brand salvato.</div>';
  if(hint) hint.textContent='Puoi aggiungere, rinominare o eliminare i brand. Se elimini un brand, gli articoli restano ma finiscono in Senza brand.';
}
function refreshArticleBrandSelects(selected=''){
  const sel=document.getElementById('a_brand');
  if(!sel) return;
  const options=articleBrandOptions(loadDB());
  const wanted=String(selected||getArticleBrandValue()||'').trim();
  sel.innerHTML='<option value="">Seleziona brand</option>' + options.map(b=>`<option value="${esc(b)}">${esc(b)}</option>`).join('') + '<option value="__ALTRO__">Altro</option>';
  if(wanted && options.includes(wanted)){
    sel.value=wanted;
  }else if(wanted){
    sel.value='__ALTRO__';
  }else{
    sel.value='';
  }
  handleBrandSelectionChange();
}
function addBrand(){
  const input=document.getElementById('brandName');
  const nome=String(input?.value||'').trim().replace(/\s+/g,' ');
  if(!nome){ toast('Scrivi il nome brand'); return; }
  const db=loadDB();
  const key=normalizeBrandName(nome);
  const exists=articleBrandOptions(db).some(b=>normalizeBrandName(b)===key);
  if(exists){ toast('Brand già presente'); return; }
  db.brands=[...(Array.isArray(db.brands)?db.brands:[]), nome].sort((a,b)=>a.localeCompare(b,'it',{sensitivity:'base'}));
  if(!saveDB(db)) return;
  if(input) input.value='';
  renderBrandSettings();
  refreshArticleBrandSelects(nome);
  toast('Brand salvato');
}
function renameBrand(oldName){
  const cleanOld=String(oldName||'').trim().replace(/\s+/g,' ');
  if(!cleanOld) return;
  const nuovo=window.prompt('Nuovo nome brand', cleanOld);
  if(nuovo===null) return;
  const cleanNew=String(nuovo||'').trim().replace(/\s+/g,' ');
  if(!cleanNew){ toast('Nome brand vuoto'); return; }
  const oldKey=normalizeBrandName(cleanOld);
  const newKey=normalizeBrandName(cleanNew);
  const db=loadDB();
  if(oldKey!==newKey && articleBrandOptions(db).some(b=>normalizeBrandName(b)===newKey)){
    toast('Esiste già un brand con questo nome'); return;
  }
  db.brands=(Array.isArray(db.brands)?db.brands:[]).map(b=>normalizeBrandName(b)===oldKey ? cleanNew : b);
  if(!(Array.isArray(db.brands)?db.brands:[]).some(b=>normalizeBrandName(b)===newKey)) db.brands.push(cleanNew);
  db.brands=[...new Set((db.brands||[]).map(b=>String(b||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'it',{sensitivity:'base'}));
  db.articoli=(db.articoli||[]).map(a=> normalizeBrandName(a?.brand)===oldKey ? {...a, brand: cleanNew, _ts: Date.now()} : a);
  if(artBrowseState.brand && normalizeBrandName(artBrowseState.brand)===oldKey){
    setArtBrowse(artBrowseState.level, artBrowseState.categoria||'', cleanNew, false);
  }
  if(!saveDB(db)) return;
  renderBrandSettings();
  refreshArticleBrandSelects(cleanNew);
  renderArt();
  toast('Brand aggiornato');
}
function deleteBrand(nome){
  const clean=String(nome||'').trim().replace(/\s+/g,' ');
  if(!clean) return;
  askConfirm(`Elimino il brand "${clean}"? Gli articoli restano salvati ma finiscono in "Senza brand".`,()=>{
    const db=loadDB();
    const key=normalizeBrandName(clean);
    db.brands=(db.brands||[]).filter(b=>normalizeBrandName(b)!==key);
    db.articoli=(db.articoli||[]).map(a=> normalizeBrandName(a?.brand)===key ? {...a, brand:'', _ts: Date.now()} : a);
    if(artBrowseState.brand && normalizeBrandName(artBrowseState.brand)===key){
      setArtBrowse('brands', artBrowseState.categoria||'', '', false);
    }
    if(!saveDB(db)) return;
    renderBrandSettings();
    refreshArticleBrandSelects();
    renderArt();
    toast('Brand eliminato');
  },'Elimina brand');
}
function getBrandPresetList(){
  return articleBrandOptions(loadDB());
}


const ART_ICONS={
  'borse':'data:image/jpeg;base64,/9j/4AAQSkZJRgABAgEASABIAAD/2wDFAAQFBQkGCQkJCQkKCAkICgsLCgoLCwwKCwoLCgwMDAwNDQwMDAwMDw4PDAwNDw8PDw0OERERDhEQEBETERMREQ0BBAYGCgkKCwoKCwsMDAwLDxASEhAPEhAREREQEh4iHBERHCIeF2oaExpqFxofDw8fGioRHxEqPC4uPA8PDw8PdAIEBAQIBggHCAgHCAYIBggICAcHCAgJBwcHBwcJCgkICAgICQoJCAgGCAgJCQkKCgkJCggJCAoKCgoKDhAODg53/8IAEQgC4ALgAwEiAAIRAQMRAv/EAPQAAQAABwEBAAAAAAAAAAAAAAABAgQFBgcIAwkBAQACAwEBAAAAAAAAAAAAAAADBAECBQYHEAAABgIBAgYDAQEBAQAAAAABAgMEBQYABxEIEBITFRcwQBQWIFBgcIARAAEEAgICAwEBAQEAAAAAAAIAAQMEERIQEwUgFBUwQFBgcBIAAQIDBAcEBwYFAwIGAwAAAQACAxESBCExURATICJBYXEjMlKBFCRCU3KRoTAzQGKCsQVDUJLBYKLRY/AVVGRzgIOQsvETAAEEAAYBBQABBQEAAwAAAAEAEBEhIDAxQVFxYUBQgZGhsWBwwdHw8RKA4f/aAAgBAQAAAADvuIAAAAAAAAAAAAAAIwAAAAAAAAAAAAAAAjAAAAAAAAAAAAAAACMAAAAAAAAAAAAAAAIwAAAAAAIpcC5+1Hrigjfdj7f6BywigAAAAAIwAAAAAAKbmDjyTdW28yrZrfgWp9LZF2P0X6IQAAAAARjKAAAAABDQHBW0up8loMfstNU3q+VtVhXJGNfQnbsIAAAAAIxlAAAAAEyh+fWtu3L9rnWescJtNN63LNdq7Hzu+a/4a6m7TmAAAAARjKAAAAAJrB8yNsdP4FpHRuEX/Ibj7eVDZMYyDeG9M9uXFVd9G6gAAAACMZQAAAABZvlx0fuzTfO2nM4zHHrJQ+fpX3u/2bXWb9P7XvnLOPfST1AAAABGMoAACBEAeHzA3dvLQ/MeHbOwny31uHO6y1YHpfRlZn+M4t1nuzIuR8h78AAAABGMoAACBEAcSa9660hyfZb/AEfdfSdUiFv5g4Zul/1h17vC88EdqdHAAAABGMoAACBEA1v8zvolrvkbA/Xob6B3IALX8+Ofs+1f2ruC0cFfWy8gAAACMZQAACEQCHy56Yzjlbmi89idtAAJeGeQ87xzuLNucrh3iAAAAIxlAAAAA0pwp31o7it1P3xGIACHz453k3X1K+e/1wvYAAABGMoABAiAB8xOlsu4853299XfcAgIil+TFXrvvXYfLWzOywAAACMZQACBEAGLfKj6R6h4kwz7BbIgAQEQ1R8pcm3X1NjvE/1ziAAAAjGUAAgRAByPqbrDmziTrz6KwgAQEQfNbWln7yyD5+/UjNpQAAAIxlAAAAB8yOmcp475j+ymw4QAAA1b8rabu3aHJ+7utJQAAAIxlAAAACT5BfR7DuKfb6xgAACHyEtPRHTGn9efReUAAACMZQAAECIMe+Uv0e1rw71z2jAEAiAHB/KO3+wbVxV9aYAgIgAEYygAAIEQal4H7y1jwd9RdtwQAIgBzx83Nkds1vz1+wwEBEAAjGUAABBEDnflnszV/B/2QucEAEQAYr8bthd13b50fYOsBAiAAIxlAAAADmTQPW2rOIPsnPAAAAUvxUzHvO+/O760X0AAACMZQACBEAOZNDdY6s4i+yU0AAgIgS/GO6983756/VnIwACAiCMZQACBEAOZ+fusdYcJ/XjKwAQEQMd+N2Td+ZB89fqvkgABARBGMoABAiAHzOuWcYTzzn31dqAAgIgfMfUnt2ZT8kdE97gAEBEEYygAAADFvlpJ11jHKmc9l9FgAAGu/lt71XQewOMK76uX4AAAEYygAAADQ/Duey5Hq6GdfRWAAADlHhvNMlyzFvDHu1eiQAAARjKAAAAOeOXZdh7P5W2fq/6iQAAAcV8abtu+8Y8o5lv/AKnQAAAEYygAAADQvJu6ua4borOf/q1UgAAOLuHek90cweW3bhsvqWMIAAAEYygAAAFF86bH1dmvl7VXzMz/AOhedAAAfP3jb6iZZReOH6xxr6EVcoAAAjGUAAAA43tegOwqfxln4t7G1D9EAAAaq4osnS9fPN7aE98l7lAAACMZQAAAD56bJ4E2lT0tJT4h3zpX6YJgABx14cBbSn9Papw3rjQ/1RAAACMZQAAQjb6CWNwmfPzZ/LfdVZX3Tm/nTp3R30XhEAXOpijDiy7fO/6G7hpvHSHMvTOlPqgIpghAAIxlAAGF86aG13hlujPdfemx76F/Ou7xecKfv/gusuVymiTRQlrPeJ5YD3t88LzW1dLSUHb3G9xR9Ljmexdpbh2tUkoAjGUABqzhXS+f+Vgp/SMbvkOE4l31wPm8fSS9a67g4g23ku07nTej08K30pan28qett3JHXHz+zG/5fi9mtHWvHuWTekJcyp8Cxi69L9k7BlAEYygApuEuQL1kmcUMvr6SJKak1l3n867pJTyKX6FcL3m457kFqv/AKW/yu1VZbnW0tludr5671+ddTGeaEncvG2y889vaeSlxjAIV+F9Xd4XFGAIxlACzfMjVV325jGvb5s+0XWGDnnjHb/HXY9+mmjztcePPfbOxqb0wzHSOVX+Wkw6kl8da/RjkXrXI00ug8x4fyDZdbj2PT+l/wAy9sHstFd/qRmkYQCMZQBb/lhjl0yrV2TJ/HJrfbUZpLbD17tyWEXNnGNXc8/vm49T435oRvOXZJguJ+SOvc+yLsHJBz1ybje6No1Fn1r5oeFoyK869zHDvq9msIBGMoBJ80NI5bV2fKLvUYnSPaEtdccej5am+kuac9XXe3KvJ96y+uhm+Fl/orbH2z3XELxlVs13iGOfTrLOdvbojmXkf02Pdc117Jf6vG6Vk+t85w/M8f8ArJdQRjKAchcFZDn+L5XtPRGW59pWlsWU5JrfMKi2UVh6lp9waV2RpfRVh6hsODwmh65owcjJlm8uW9w+fNGx+iLLt/VOQak5sz7I6KHntOTA9oadpvO7UGUa9bx+jwIxlAYb8fbnujVF+z/BMvxa4WfJ8F6ktvPNDsq1YLtrFt14FZtn6W8te5Ht/WHoya726W6Y/YY+W19a5rgGyOees9B9Naps+2sH0FDfGAyXbO8KpJ/TD17o8f6Q5ttv013vN5wnjGUB84efsxpKvy2ViVr9M+0T0vyztbHrJnN6xvC+kMTueAVG2vHE9AbK2rp2aN/u0bdesTt8vntfDrHdc/5h6+sFFhvttPx0jhe9dfS5hivvVU3ridL5ZD4Ue+ufcg+t+nuK+k+pE0oGC/IS7bt1DkULxtDUWU0OvJMu19dNm2eh8cF62s/UFJUemicI5e6BteMVlIjsGkwiZ70143Tp3Y2sNP8AXee7Yoqn05pwbWmR0M/tvvR9HuTQlHa5Zr3ZOx+OLb9EOcdkbZ6MTSgcAcr3HY0ntYPL2u9tpa+hznBrJ0Pz1eY6x7Kve7ooYFpflPMrzT9Fc6VEay84zGp3Loz2hdbZY8P6w3nlw57xvk3amT3PAr1k9vxKip7xiUvlJtDJ9PYl9IOWfpXc00oKb4zVu5NabX9LNhsIS+uV656b5SuPcHz/AM4znR3U+2s9nLZzdyFmmxt0Wy7aXxpCbOdnW6OoLQlsFj6R6guU0sdUa7416kzSlt2oJZYS3a6YbZrdSTd4cQY12v79yk0oNHfK+99KaE2F7YuhcLYl9Mlzjp7m7QF58cB6Y6auyaEvLvLd3yb26F57khCEJsk3Loa3ekfHHpt19dzzJcb0Xxdt3PrhrjzlUVfkFZhmOUntafoT8+o5N9bL8TSg+fvK3t0Tqep9POE+TWe0S+uI7z6y4AzDI8Fw/c3X88Jk/J+mrBks15sm3KjVdzy3EscyvF5vLaOrsdyPYPZUsyHjzLyfn9fWW3z8sowyvp77iXjG3UHcXGN+2R9N4E0oPkFUemUY2ml9tm6o2Xhdo9KT27G5dyG34PdMw7OkhMcmYvYael9Hn0Xrue04VMm8t2ad2LpDY967MlmI8paQnrjzyLDr1TSU01wxC6Y11fofcPP32SmJpQsHxb2XsXXlVF75liV6tF4s1vhV7y1tjstg2VP2ZLCZDlu36O3HgXil2rn+hKe1zRqNka2yfBpdqePYyI5OwmosFJU5Tq7KpaqyeFfjeQWKTdVm2Rxz9n8gJpQ0x8tcn6K5ry3wnkl2bgOfa0ljH03XkPMFXb962DsYQjz9hei79PNFk209aYRVSJffduidraE6NsHYSKEOU6XTF0QrblhmeYPUT3zG7VcKHY2ROd/p3vYmlDkrhLK+k+UtiY1f7JHzz7C6eF+8rZuXd3z82ZhXResOybt6QoMK5Vzjm/PF3tPhvi2629fTHr1Z4s/wfCuode9o+sZZqDjzINAbAtvguNbjslNcaDamr6+35Pl+E627q65JpQ4B5dqOx+WfS/bU05SR9PGOUZF4YjuPe3HGP2C17coNxZPDFtN5Lzrn/t69I8zZxkVPNb9d5NtrQ8s/rTW227R9Ohb0x7nm989Z5tOy4vTwqKbwySoxqF5t9Lec71ZjnVPdRNKHzN0/S9p8bbYz6g99X2OZNld8nwTPertCchZzVa32RkVVkuLWTS2b33Lt02i9aQxKMzZmzLHW6ItySvyjn7cs2b3zWvhpHMdvXdimMPOGxcox+m19Khd801nat3fRgmlD5Q4jb+1eMcjqdwaT9pLh408L76YVt3pbVXIOV2/adp1tt29aeybCbrWvHpTmmpjUUyW47m0J7+UIT0uwrRgO3ZdY3rX+SXLNLHaVbc7BLXZ3rL0v3pYrtl+saPYH0/RjKIfG++W/sHi3Jo19BVbn15ktBriMbRuLZehcKuFHsm47L5/xLpXBdb7FybUnjebRHyzPxxSaW72v23Xg+a6rxrPfbP8AmuToLG9N7Tw70ll2RfdWb30Rb6rx23hFuzWwXukxe3/WpGMol+LW4Nddj8bX2efx2rbNeXDaGtbdKsuT4rktu8s1rdzoR0rru4bNqtUxjNsnH6v3wCKXcNu1hlGy9AbHu+yyg1dpzdWO4+9to63udLk2BMzoLTJU5DXYVk2DfXMmlFv+Km0cL7a5EzSxSU+fYHsXBfa645HKaPEqW73rGs3y3dMnjDVmitw6m2fraeOw8TuNmuN0wmPlsrW+09UbR1TsS67OQpdd6FzXJ8RV+U4XfabLtdwz/Xl59rHmdy1xf8e+uZNKLH8Vugtb9nckXGmj47UptYX3aenaeHnkF1w252Wl2BubekUdTcnybmt2q5kMgy7wwy3QNpX7Qu0Mv5+3JnW4PeNBrLjzp7SFJN5bzsGqOkNG2n3ynKtYUexqb1x++YH9bCaUY78X9qUHYfEOUq+g99s4jf8AEsZvlokheZrC8Ns7i21CE/L+r8jvepZNgYDMyL1xqEcpxaXZVHcdZ0W+8x3LGNs1Ly3kdjyK+YFNmfriVB6bp0bs+Fo86yptWG3z6sk0oxr4xbJxrunhnJbzsDVUybzj77TxLEoS3m0w8ds7L3eNQ8q+E82U7q0Vj0z18ma7G0pQRQkvG38q3UWnTvJmSbFy+noNTQlZvtawXHR1LCk2D7a7oc2+pRNKMZ+Mu0sR7q4Y29l1JW62s0qs29S3nD9aTwpszyyp25s9BqHlfymyLZFypdV2KWMu0c/tPvpS1wXHY2RZRugpNZ8VZLXZzkGq7dGSPnW7t0JGMvjseXALfsj6dE0oxj4y7NxfuvhjLb9srT9G8oe0m0cNsaM3nT2zfO3doISc66DyvFY+e6tJ7Ct2IRyyltu4dE+8K6gU+/NjbQgptbcU5DLXXfHZpcpxOMMhsEIwpdk+OCWvcX0jJpRi/wAZdoWPt7hPLI5NjENqUF4wzFq+hTXWvxumtu8tp7eQhpjQ/jTWZGW/bDw3ILRgk9woIe+yNdU9PvW4dEln0rzbtizYVNNG7Vk+LxhLl1Za5L/4YjjW9/okTSjGPjR01pjtzia7otmX/R2Ubh0TS+fr55/a8coaTdW0twIQ0xzzQ7KwmxSpOgbPqnIsNJLhuXRO6NVWffGc7fgtOuePsj2LqwyDOdW7Fxmw09xz/XVvvuVUPlrforv4mlGMfHTZuHdzcY5lZqbx2LrvZeBVl5xLzueZWW25xrq0by29sdCXnrS8crsOOQQzHaWpcWgmq89we/45meD7pznbsq3a35Hr8917Csyie3VMMeostw661+K7IpMGtnTvdZNKMa+Om1cG7l4Yzui8ZdvWXXF629pyg88pjba6T1w7eG6M9Qk0ZpS33LEvWMZM92bqvCb9YYw89y6m3BpTy3peehJVr1Vx9ta96ujGGXUOSa7iu+YYDQ5PfqSi1X2X2gTSjHvi/wBH6z7P4suU8IXDd2rM3seuJ4QjtfDZMdo9t7b2+hJpnl/O8A9ZNja6yLfWEY5c9W+mVYehs3W3l5b82Vsks2oeYswxz02hqqeGc4TCTM8GzWNm97/5a8xXurrkmlFl+KuxqTtrhbKLjeMXjC5UPk2pr+2K3MMBmumVbn3IS6a5flVWXbY1Pi3hLClueeZhqbHZoJL7tvPdrIWvWnGuR3jPMiwzBafy9KrK7zhuMxnpNnU+tMa786sJpRa/ijsGx94cJZrnV417ZJplfse5U+AY5D28sovtZtXcUUuhucowvee5bjOAY9BHYOY+tBqm3wXHYF5vPQhbdY8a5Lcs3zTX2E08nhkWVrDh0EmzaTXWKfQ7p0mlFH8Vsysvd/C+6cl9qHWFDCM2WbLxjBLLPCOa3G87j2HOk0Hztd7RHz3jo31hVVFthd9k6em8vTy9abfmy9lI2/V3Ht8lbN13sjD8b8K+w7H1v619NDZnjrfEfpT0KTSjy+LWW433fwjl9+y7WkazKrZjHvnOHbfwbDZM8xSm2ZtHc8yGnueZtsajx+ZHzzCOGzy1VLXbt19neqMb31s7Y8Vh1JzFsbBJku0MdoqWrw+ge18t/lstrvB/qFvAmlEPjXfKLtPhTJZqmju+6NE7LteuKikyvKai2UGI0m5tobmmS6b5dqLvlOqJo0mXyUVywWNTU7atWs8xznR3Q176AjC0a+4p2pQ4nST1GxqjXqw0lPl1ovdm2RJbtO/VjbpNKHyDzfVnb3DNf6VHhtHGbbJn2vqWSn3DbdXpI7S3JvSZLojmPMME2BruW1ZL5pPOpxr1qs5xTPNc51rzpXN9yxhbNbcm0FXU4wk2jSY9jFZQXaju+NXHZvtrTDPrxsUmlD5Qa9t3ePEOT2OSfMsSzDA8no6GhhmlfbceU+0so6hujz5357tG2MYxHyh4wyrxx+3Sy+2d3vW2eeOCdL7C22hbdXcP7fxuxW738ss8PSy+FEm8LxQbK9rDqP7P5OTSh8x9XWbqnki6yywzS565v+U6xjUTbFr8HmsFNtnLOkcoS6f5fno8Vn9aJFJ5p/L2qsrpKrFabpe+9DxlsOleVb9aqb08KvZVi1/kGL+0lwppWeXHWFn+2VYTSh8/+Qrx09ydVVPt4UmRVrHZr3jmY5xiUvljF1z7Pd8Zcl05yZa/Lyp9la79afy8Khdsl174TedXWUfUewdwGM81cy1tZ65Ri17lpqm00OY4jJ4Rqdl1OurD9ragmlDkPgLz7O46rrrecG9J56P19tlYLbpoR97pkGTZ5vDM0mhuW7PG6Zjb/DF7T6xkzas8vTDKelpbhm2y90bZMG0LzJd8huUtHYfOmpMlyuz3PBPGa8ZjXavl+zsSaUNO/JW4dkch7J9J/bWVOjd9sWi8YdgHn4++e+uV5vty7qTR/P8AZfeX2zbBrP6zx8vW93/DYyRjNNvDON8TQxDUnKtX63264/j72qaPJ8zwak9ZJczvmqc8+tomlCh+K0vYfIdddLliEZIKeG1cKtvijL55BsjYmdFJrbRPvbvCN7xjN7LYZL7bfGvovZlONy+G87vtNJj9j5arI+uQ4nLPU26uqchsV787pY71kOtejvoeJpQfNXnrrTl2h9ail8PLIcY9/SrtHrXXiz2+T03bsbNYKTX2h7bNQy+MldXLfGk9fGFRk1ivdl8t8ZHsSPjhNNypltkop/H298goqbznvGR4PLfrhk2oPpT0SJpQaq+P3anOFl8PGr9rvY79j3lU+MPSuq7LLLtjY+xSg1dpNNLaaNDYEMYp7f61VTcfCby86LeNz27DywGHKV+yLDqH3q8nxvILPb5rxYb7S1OS5Pg/2A9xNKCHDfMvhjtt9am+edFHwk86etull9bzbqPZGwdhlqwrSNFfKGkihkHtj1s9/VLUZFiOaY/aNu3HcEPPCPDnyWsmpo5bit4s9/sXldvK2zX+1+f083BATSgS818tWSEsvnJ4IIxhLCWSEJZIRlk8PCMZYIyxRiQlTQiTyRjGM3p7ez0jNFNP6+k3rVVtTsLrzOgTSgIIoEYRIREIgQRgBAAiEIgiAgIwIowATSgAAAAAAAAAAAAAATSgAAAAAAAAAAAAAATSgAAAAAAAAAAAAAATSgAAAAAAAAAAAAABFGAAAAIgAAAAAAAAAAAAAAAAAAAAAAAAAD//2gAIAQIQAAAAAAAAAAAAAAAAAAAAAADTnUsS3ruwAAAAAGvF4dqfMFCT0nUAAAAADTybtZyxijwe/wChyAAAAAx5GXuTzZw0p1vK+j7+QAAAAOLxPV2cgUuf5b3VwAAAAGvhfU9HYAo+ak9eAAAADmea9tsAI+T5H6LuAAAAHl9PWYACt4L2vRAAAADxHY74AI/D9z0AAAAAeD9D2wAY8bd9MAAAAMeD9D28gBjyM/qAAAABDxLXSlACtyZOzsAAAAUuTjsW8gDm8zfsWgAAACh5jPY7W4BjhcW16C7kAAADXj1N7m/TAOdDQzc7IAAA11aqfQxHRvaA12o9bVzunhnYAAxFBpHtrPWt42o5qZxjGEk3TjzWnq41tWJtgA1qxxwQ2W2nldex6Oly7llztOjI5fDern43Qs6pLU4AqwctPYxqueSv6ej5FjelLPjn57HHr1vUwRRRzz7T2pAEVetQlls0L9aSrNX6fJ6VWnvbk5+b9di7Xn528lzSeS1FMCrUrR7Tz5iw8jU6Pq6sU+mzTDoef89t7KenjeaSXObHG9CGlKlHO12pW9bPho7XtY+TYtZ5+vUxY85wcet6PG6M0cHQlisZshWqxYr62JuValz4nEvt4sV6ti5iuu+b470Xfr413xmXG3RyFGoxBiWapLYo+Rxn2uZXn+vPrT3uea5TuegxBjeSKXOnX2GKFKHFyOOHeHp68Sj1e3HQ3p2W1nSbncGT0NujZ12izvmXoSjHOrwRW9UM/K77EU+KnPuz7c7F/G8mFipRtxbVrOyXoTjTlRy686fFok25Eu1mh0taq5jlSXdK8tuvPz5JLVCXWboXRFzIZVKbS1Ckn8nW6nb5/Ugq73ccyaxR4tj0ENqjnF2hZ0mv3hHy4muddq9vWR5Ct2PQRVLe+9PFhvxuBY9bFzurtrQsTYn6NgRc+tX06GulO7vnTydbr+j158s+1HPQa8fz1j1kla9FtXsYhs9GYQc2GbHNm3tRwXNPJ1ev247UXKvXcVdLvJ83a9TDcxS3vUd9bfTmEPLrTbc+fNuniXPla/Y7WtrPB6lhS0vcjztr1MF3SrNaqbxWurKI+XVkzHrLrNUtvJVez6GHn2Nd9M3o9+JwLnqtaHQ3VJ9tLnQkGvOo1c9PNGl1N4dvKV+1346dvbNXFzXficGz6ranYsaV7mYLXQ3GvMrTa1FpUkn38dX7HeqdBWWoufvb4/Bt+oTw17NvXSGfqbDXn07mkG2LNLN2PynO7Poal9DmzijmfhcGz6na0pXNtUMvUyFKrZ1hS4p7WMea5HZ9LmGfdpnbTbz3nbvrpY9oJ0yGToAr0dJLajFbsV4vPUOx6BVnnxSzezpwuBe9PmrasRULcsMnRwEfLsb76tJddq3C1udeVHrJlG35XNn7W8m0W2sG2JruQxzrmkKbaPXePi6XOniTNOzvrHjehz5unLLppiTGY7MuQM4zkGMMgZwMZzjIxgAAAAAAAAAAAAAAAAAAAAAAAB//2gAIAQMQAAAAAAAAAAAAAAAAAAAAAADe3Z3irVdQAAAAANur2M6JN6fGoAAAADOAb+kt1NcZ2TWuDxgAAADbGBn09rk0aOMrHYm6vnOOAAAA2xgdb0HA5WoHY6PV8ZUAAAGc6g39dy+LFsZzjGe52qPlgAABs1B0vS+MjDOcYWO92PCxgAAAzgegv+RwZYB0/XeO54zgAADbGD1cPmmWWMBY9lwOIZzjAAAM4HseZwWRgG/seZ54ywAANmoZ9pyOCDOcYN/X0fNgNmoAZYCfv1uNGGTB0ulX4uoGWAAAXb+edTADsbzcauAAAAXu7jl8rABt2L+nBrgAAANup046dCqAW+hdzyuWAAAN9s5xNFjeTXYwMT0s5s09saagAGZbMm7MDXOJrU2WGcxU6smW9nOteCtoAG17eaWWLMEXezz+VcuwxrCrrX6HS14eelBprrDUrgC1Zv50h312p97nz8fp6tto8Tbcy/tPx5ppMxRw6UYwEtu3Mhr9zg3YbEU/N6kG02IU+KVrSSrNmRHWzBDVmhDN6eznEdXObMfopqnnrUkUrOucUux1sedr284ii11hh7PngmvWpMaYiuVt4fU7QeXsXYoN5kOtfsdfTh87owaswaa6Q1guXJd9tdYOjBFj028flZ95ZYIcya1+x1ccbj2t9Wseus3FB0rMmd8aRzaQW/QbPNa75u0o95dK3a6Ll8afLGuNdLfn8B1p5dottd9rHMl7Fvn8pZxLDnMOIuh1teTz7ke2mWrXlQjbrSzbQbY226fnpt5a8VizDrmfECPaTNOafQkiziPlwCXr7MWNcR5zBL3YYuZYr7TItbOsF63DzM6WdWm2M6c2kJOtJtpY0zHtHh35aXJsQJ0SVBf6kPFRWMbRTR5j5tIS9beTTOW0edHoJuVzZZYCXaJF0ulDxNp67aXTXaDl1hJ2Np8RaySxNcegm5vJknjjTq22vQ6kHExLptjEe01fl1xN2sarGNddtoXoJuXzpNNrcEeNlfodirw5od5tIpM7V+VXE/Xk0T6NJMx478nL58muLdeNNtVv9etxZqu0+IZNZIePCJuxu12202imj09HLyOVZswb6bax7RdHrV+JtPVxtLFiStyYxJ1p5dYMyz1cSx9+XlcvexXxtJtFvF0epBw9Z9I9sxJoORGJettjMuYU+InoZOZyrNZKjWdYej1a/D2gklhhTSR8aMSdCzBvNjFeyrzehn5fImr4k1jzaQdXr1uFpDtYg0STw8fUbdC1XzJjRY1im9DPy+JttrHmTXG2na6tbgQb4l10xi3X5AZu3dMwYsTVtZJvQS8zhbyRY1nxDnPZ6tXhQTRa7Sx62YOSCx162uNJNtCx6fflcPGcYwztnTv9Sr5+vhnOdk1Tmg36tXOcMbYzL6Dfn8cztrhnOnY6NbjwYzjbG2JKMAM5wGBnIagyMsGGRgAAAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABAgDj/mg/5wP+cD/nA/yOODDP7AmupqV6n3G+feb3nYdQkd1SQPUjDW7vx/xbl3cuoee2rD6hiNAR2pUqUWrjV3NHkNLTHT5I6xrG8aXvlNT/AAw/x+b/ALqn7jVdEQlMM5WmXFiVt37ina20wk9LKlXsWvrbo2obXoe0cH/BD/GfPtob8pmpK/UVJKXuT67yVuXvKl8/ei3hvd466x2wI64oO05C3a8s1D1Zv8in+AH+LPT2xNn691IAztnmrXKXgVWlATqJIn8M8SpUnWvlI6PvVduETam7xyz2PqDUW7Gzn74f4k1NbBvuudbrOp212C2qKR1a8xzLqWw91/dC3NK0tpIjt7DyFdr1/gbI2clV2jqvTG3UVvvB/hrr7h2VrLXjlxY7HZrjD142PrjE1iA6ZY3pjQ0J7GuunyU6YJ3ppkoljbmjqYq0JY6xZWT0FNta20Jtn7wf4fUHs7T1AOazz9vtUBXZayVWjUvp9bM+OP5ex116dbJT4uxyMe2XqdqZPFM2rRtJbK+6H+FsS50qAYNrZNXax1iCnrJqzQcdGfHJxW0tBQtgdtY99XJ9FedimLyFl/uB/giO77prany8jabDEMLDO6W0mAfKYu6dIQE3MR1Cs8K+OnuOq9NF6+4H+DuO4adrCmW+SuMzIO9B6k4+cQ33qWsz1widaWaLdvG8olBy32w/weoS06zrkw/uU5FG1Dr1Bv8ARdNdsUSGdwchBv1ibvgOma1fbD/AtczQWKeXR3fZFsz13TR+ntCkwzq8x2rpuPXsEZqmcKP2g/wOpax6GhH5rXILr9NtMwfqdRVIiFdbS0Gq7DbEbR5n7Qf4HUdL64h5Be9P26Wvaz9XaNYpz6wt4B+uXesZ0zy/2g++c066j0rAttBxpCucfVENuQd3DWkgkbZsd0uyf2g+/ZHmqW/NsNs5bphr/wBfqir6iul3EWeZa6UkPtB9/br7Q7VbLSN/PqKM+vv+Hr6mlloQyxYpYB+yH3+oFbp9Rc5ZBsBIpr9e3MYMNRnhBWy4kYqfZD7/AFGm6fCO8n8TKmH13iahNXHhccBtIleP9kPv9RgdPuOxnMQEn2DZeyayGHxbNvZWftB9/qLHp+Muacx+6q9n+vYZ+wSGtsh8OG38rBvsh9/fV40GM1uNLaNka68t7dx9bet9lc1wm5t8XtzbmdP2yvsh961yOr2ledwtfnk3Vf2tGaBsn1diz9JSpUdKLVfWcrRSQ16Rr8p9gPvb1e6tR1zD0ym2fTkaRtA9Lcn9XqWkWZqc4pyENRH9St6GymvT/J/YD73UEGkFJWx6tlFCvHEew6fVvq9UwvVK5JbiyKerJ1WxbOW6bM44+sH3t8J9PylcbP64e36x17F1yhvW7v6nVMD9RqtfKjHXOUvkJV9/o9Noc/XD7r59sXcvT+hWNeiwLHfiNULTBuCUm4fT6lri8LTI30x1XWtXs+suoJrozbrZx9cPu9TVk1XBahkTTwz4zwzyM7eXZ0emaZ+ltO26Uo29JqMlfXPXvXy2Le0w5oXTjevrh93qoyNPVbCbcY7cNtg20R2ZLr6qU0L9Pqfd62LIvibbDbobeLuFPctwvehltXfYD6nOOJH9j/ZgsoSfqPqPVGsxDRkCTWxKCSoJQvUM2dutQ5peQ/af2n9q/av2r9q/av2r9q/av2r9qby35n5f5f5X5fVEvQ8HNN0M2px1AbTm4taMq/095rkeeeefph9Kfus91NzXUkvth4+CM9FLCNoYtdViZNqyyNYfr/oHoHoHob2K1Fj1meqN6GXV/taGq/ar2q9qfan2p9qfalHXH6F+hfo36KekzcdRMTTalUOLNIi7dwh09ZMLfsf7J+zBdUNnseoOK6oYfqbgNuoOflD6Fz2dcuoVpX2usXoqWoLZ+yfsP7LCXj3NG5T8yzyrPfWwmvV/WI9xYJLUWN3J56IsjC2o2014VugXRG6qX5xcG1yRv728HurS9jsZW8r7C2HL0cIxQr51MHtcTP8Aqk8+6eckVfUgkvUvUBdRak7VG9MPXYq01LqZq2wPjD5nLrZXUORmIxme0h2pNie7o7j94h257rH2UbYFnlWJYpcJc8t6l6iEi8d6lEqxwXcRc1XZ5VzPWdvaYOcdSspa425MZqYtS93hrieYmra3m7EelFKH5YPQf+ofnrvOnssiEXDFqZaMFB9uj6nU0o+1M6FCbSqDhjrrqJj5Ltx/QfLMzG0twsoOObkrUvtMYFpCMmcuzY4/cifxeLxXMNfSWz6FBazDVPtX7V+1e8qXUbSjnkwNQ9uiQ3t3MVD0z0z0z0yOoga8Csq65cwPpnpS0S8R1g82hr6s6u9pfaP2kHUW56Dqd66Xhaw31e41svrktf8AQE4ppYG2312EpVUpuTrWvdnVK3h2H+g+SRkdq7PjoeuVKe2G0gwEMHPDBHlx47GLkgzql22Tcasv53n+b5vUAqmcSxqKShbIida1HW47sZqPsztVe3rL95Vpr3YO4LTVFvM87zfN30snbiI1ScbWkU3N2WW7DhyvI1lLKxqT6Siqfcadbf7D4zn3jtSMYVOuW65M2MdCuIb9YdshFu4MbDGi20uryGKISJdfunTl/uutbl56gnTRIY6LhORKhYQDByux8uy7NnFok8FSNhTUZ/UpRAUDtqKu6cvtzwO6yH6gnTEixGhY5zbXwAY7OvqVRwgXBxxKO4mMscjHSUHrbYMTK/0Hx7+2XCMY+Nv08yZwEU6OQay4cprJgJ5JtQmulbLC1WSlY3HKtUrujJneMnSSbJr+rJuzhdWZs1+rb4MO441a2VpDNDFzg3apwMgsoekSFzg1hqNX0lMbykqMpsav6dldnptioNnzAQOYT1uv22bYyEiDpv4jFjkrEFMm5qKnYzp82T/QfFcrPJyMm7SCBYqiLsHEBW3aEIe3vq/p6skXljOtiBPMj2k0M7U6e2g2TakNVtn3S+KyuvybuZAxil275LtwjWELmodk4e2F3XSCOHFF+s/g6OmpXZCULp9vrq3bZrda2rar4vLaRUtTRlI3g3I5CsZe2uFpaLSmrGZVADw0kJZhjXVId1YI/TF97KHTUwPi6i7zDtdbQFwnOVARZqQDd9HsouJty9t22o3c3FW9tCbfaOINd/Im6fW9BhT1uYsEJM1PVO4EeoBs2dVmuzLUnblpYmkBIR0XHv4B1LgA4csSzeVhCRhK+6Yy560Or6j6fL2+HsFT1S5NupnCsL0bnKgL1GLkZmVZx9kN5SiKLkGUinW53fVSRU1Hbym2Ts98bpvffFe7KmebdiWusTJ8Q8qZRWKhYmWln7bXMHuZmlXSRGgG+33Tx1xMq6tJoRtijJJIc3cy2cSNHXgWOZEQZ9iGfvaw+VVLgmWbZCTB3CtYgo+3WCcG1ZqdoUTsEk/FtVPqGZwz2QdlKsiyd+TOEaBJPHZ/JIY+IppOpdnpyU/Cn21P2zToTZct0+Q/xdTFsh0YGJ3PJwDaZaqolxJUJ9w8ApIKg5vlmqykXHTrFWp5gjNKKm0qz/jYbKPyAcsnPJlSsElAHlg6tD7OWCNmjE1MJnrSyrsZIu4T0xH+N3oboRanAaihc0SjFy7uwpTj12CboXEQZPDE50tN9QsC/a15kihdAio/4XK9tmwNoaPgHCuJGfy/PdFZK12h3sGMJboWrmQrwZFQdqS2sfXzTtxkohqIrArMYJklFkVUg7DH9g7VyupQDJdSpzEf2HFhZo72PGI4PYM2qykQjzVyGUaMUJaHOXsbEm/6w7EkIuQqagNHW6I6GXVVf2fp+rPxbssMYlKqNwgEa8pY1e6EeAhnKqGpLtY4xqnvmwRLUqKiKBd8LwyH8GJqrJ5umJgBYFhkBain25IdhMzrhSWAuBhsHKUjuA5A/i0NtZgyBieqv7g7OtyUwmcHZqKWF62VmlUjn8uVbVo8Hk+hVyV+E+LqfnYhN6w3ku3IkdQ/GIN1pSWjxFMcsDaYkY1WyKjUKfIytgoTfbahCfwXGB9vMjkAcPKlypWzYLxlFjV6XLTVlDJKwB2HEEXiIjqJvazCH8LJ6UVl2rIUVZN/igqKybZn2WyQkTCmgoDpgvnT+8ctlInppf8Axc7cmEMoDTc70QAMEzVtEJmMyfOYoDY8TriOt3KTe72GXItmk2cyJ/62LnUGzqcY9jSm4EPE8T18jd7XIlAOOwGq9Odqz0GsTQrWNAf5LlLHarGPMOBnJjNyMQdMgEQWI1ZET8ajs2dNjvYTSKitfyBTfDYXrdy+f6FY2Zfu3XeKeiR0wjCEZv5PONWp6gT3gyrBZV9IG6e2lPw39b6T3elVmCDt0uGDnGvpUiFfZzMjgYOM0nqQy7Vgq7VT6em+uAwP5sinUE1rpHyGM2kpHefKwca7kG5hb4guqtG18xXsZ08Od0MnTiRNXXvw7mla6yWHRaLJYWxTc54a3apVqrKnHsUddDr1HbsNUZUoWJLQSOlSD/AiGb4bWFenToB3HKi2u6KBilOjggJWbuuyrsky9ll9Dp6UL/W6Et/toZ52MVnJxzE5nj9RZ0YU4dYEztk3Hk6QW34FqeWRLRkj8PU08reT0lrxOoM7BLCL6K7GJHg6dD2gmcsyoQajRsKT9lBxV8l9QZqGxITBTeESrvJW22CfsKtXT5MIxfjMtRoYLpOy1bhrDNGNJRfZNVOPevZwNPjpKZTW457On2yLLtlzWxio1whnEbIKQZQLipHiKGIjIxkTWl2umy9QpJd3aE+mV/8AD1RycK2sORxKZOpps4yZQGPKfCqFzhrWGEe9j6I11PIy6W24djbXzCFsBkEpmHsBJNSRmplFtOWpdZs3McEF26aUNbzbN9xPcSSvaQQbC3NDJAOEXAJFpWrW5goq7x1sC1GtctbXEo7kH7+GiYBlMRDltwYFHQlSJX0rQmoiUSzLl2UNTH6h8DLITpaW+HqXXjyWAXoVwIGcCfYx61kmZHkBwp29sZST19RnuvlHoTrOtnGQlXcfXK/sp3S4bYU/e4epWvYyDJggIVt0Ekg0UkLK44DsOVuY9XhmbyXlVuw4xdzZoxlCXx1Wa5fbDaWMDZ9gs0Eix9nMo4mpWxAA9jBBOjumaDuVMbsGanDf3acHpgefDvt8zSn8m8r58ZnmXaRB7JRqzbnmBd2B0weXAsnKyrmukOR0XVaxYPlhPtqnYrfreEnMROBhwoKyKZQAQYM1C4YsIpbXKaXAn8ZVMchqQs9QoS2KxDOn2S5axgG4tyAFZeTbouHO0jTVVUpixSlqWIVMqVfUryiOpSb9wTSJem1z2D+hzZLhq0tcfYcr49nDsMYsWEM+ttfsE/WwzwgEsyqUsxj9k2VmgUHmaxJruNdNbNq9hT61WqlDuDltL2nqpDhpcADFlW5ZVMp8MD+UAWbZhUlrwxbzsC5zU4axRnoCWpjaPYVnWklAg9q5RASgY9Xrdtmmc0qzkY8wOnLdCPjp9/FyLlDUiO/BjHVkhtGLfAYbULZvblLLkCkQ3Yw1sHdwQJDPIyzzDTOAFNo/2lXUJGDIZ4XX+aoNnAiUKNkpgng7Zdm/dBKLhbjI0qUkawYexxpqMtdESQNg/NVHU6lBnOxSyR9WIQSjC2WNn2bt7DZHsjNVglktKmDlUQd2IpXjVKY1Ibf+R71SR0p8MiqVSaRnkLNlSmGzVUmK5YSmyrST1aJQtRu0RDSEqSIkY2PnXRXoa/W0/CjXBrwwIQdJkJxKblhVK2JgYUW9keV2tyEk4YV6Us3HCuTaYjX7Z51DbL5qk2vUPHzy9Pq53E4waWw3aNWtcN4JixoV24I4OQBCjCSM/JZpsu/cLjVtpT4Z4zEVWFvbWUKixVf84YK46f1wAg2rOPdOA7CRpLz0FHsJNISuyU93o/8AgBqVVsWKp1aIv8kAdhCBsV5ykPZWX4wMEKHKT1cRVo7W3yi4aZi9X0oIsI/8CRR187hAKd+7DDFOWrzl7YJnj05uT5XaVF67gJVJAqTDUWb+GtJWF1o1P4LKMaDV3dHVjyulLg47Z41dMp9xTY1hMzxSwkUql4RLFPWaRQIk8zW8PqaH47FzVKjxBOsyN2Ocwmq5TYOQC8/3TTsEJnEVfnKSl1cunWaHDVhsDtKttX1upvJWbyssbix5KZpdv3OQkxxrlkaEWjLHLwzSBeyulQ33icvJudAp/BacisKE+FlLAKIqxSVmRKfkSgcSGFJrWmliZDgmMWVkM5eIa6HSZ+5cpMrYA8vhJJOoGw1T8Q4UTqYQK7D2lstHFPxxwYTwGiDaptPeZPqOUiMNkNUAiUG8lSvB3rbH8JkDhvIplXUX8Oki76wAfZ06k+C05CJuW09ljytqxVcRhWDo9dlY3u0WZzkk2/JnZkvbhQK44nFdVvNXTHcMo9LsHYMhZ1O/Fif3WdmB7iFbsnrcVHObNKve8e/cXPRBtUE7vVqDLw+DjR/WZy1yrqWAO5isl51wGAGDg5pLN8iGSA9NSXwWrIg66s9liytA3XjpSXVUkgwTed5wCclSUsiglDsYmLIHHVhdXJ9xzVchYjSVfzgcPPkBvQ39PAeY+qS9ciHNueES7FZdnQaHS15Tu7tGkVaGSVKUzF5YJQOxjNa8Q3Bgfy45yGGJzpLN74GSedMKPwWvIvE0bI1sOVo/IDJzeBkTSn1njyztbxk9MJA4hmtgEQOZ2trJrqKJ7iOvrGWOjJeahueORCtymxoit12QqFeVABK5fcYyZnmH0eAOg0TmkV+82XTBa3Kwc9Za6BsDBGEhXlgsUMBuwni6/KSDGXfx+ks3ipIN5gelpP4LXkMmVrbRsGVaMKfw5zSo17ZEgrbllJPmmHzkcmWVax40UXfJa3W08/8A4oEJJSasU8unoB0+xyVl1RoWXcWxTuZSMiIZNTHgSES4NohTVtg7zDnWtmr7Bq4hpsSdkIFpdyRjG7KQyzUciGclOyTkpgltKjvUjQLIz6WEvgtWVnJN9YBncpUus0cNMUyWW8uoRz9GFPcgwcYxTKRnJwE5CWkotyXVKutlu5g1ZCyUOpZltfqT51O9JkrfJ05A62B2YOpF56AlNo11kMw70QlrGqd5TNdM6rL+CuRZ1MZv3MolQEbVHUdRZ4+DKpi2Q6tiX40rm8cI2szTpYT+C0BWMexViLN5VcRFZYcEK1j+mECEioWtSrzszshYFIsvO/qnrLsuqWFBgO581jY/zW8LZ7AAdzZQGNpjrAABNQ4ZzyJKldpNrYLRw4zR46Qed5dtqyAixqLS0TAF7CFYs9jYTssBcDIV0/hJVuCZGemD70Fq+si3S6h8FkCIOwkrw3msqcoUvIDkZJt5NzTa7X7HailIXsmq7k6kjZbDw+NQCaf/AIMOuJWxg4nSBhzkrRDMKzAwLSLcUeOqCzlshZYbsJY9dRbHGaGPr2V7zo6gf1l+6sQAinY4Io8GLXnplc8E9EmCNm5WMawz+S0rm8ccuLAPTIn8E4WNxI9okprKyORrWxxQZx4CSi6oFyoxso07Rz6xoFDhm3qK2mz9xDXMHYcMHDZgFDI4PRVR/O/M/LVMwiq/VrA2dVgvbnOT1zRCes4LvMO9b2SKziNhW1FXenoDhoOcY1YsqzJgvXVMSXVecaUzegojPj00l+CWBqTzZ3JcK0LRjXIixNXMAU+c4wjm9DVfv6rK1wMMVVbGNTcV2gL6gX57HLquu2LBzwxM8nsBONNfJieEOwhEXRpZmrJa8ykj3jpFxcdKhoxv3lD66PE9o6YQvCqTi9ruxHF1oe1Ft34a1ncL5wbNJDvTtPZ04ofA+K6A2TgyY1gY22JSrdNxbn73uU7a4QrmUtsjPl7gZldX9k1hH67gu5x1NNWEvoqocjhbAUAA2R7aVYCPMI9uUgA8isAedjrNEL68tnPaRaa9q0I2AcKaWsMe0DXs1C8nA8EiWffruUTeSYT5pLN5YGTw6AS+BYJ1NYJrJLK4pldc3F0ACLBgFJkKqRTKzNnXjoazNfEc7aoyLIjyhJ6ZQ7mHXtkWkRs0a5n4PPGAcqHbtkG4Dgg5dZHx7SAcXhjk3Bus0Whr+o97AXUi1YmJSKKbjDFoshcmbOvyNfcv1RO58LR1+SJDZpU+7FHic7mj0/gMF6STJbjP8rinj8bh6LmGbDNrPKnZbMuk/O4NI1az30lXj5kz3AI/zXzzTr3ubNeRVkVUaxlqkpkjkVgOL+JeWe0wNkm5k86E4WV/MrLuSvpX0DaHM6o60gOlFO8y8oVji8gp+QREwpFOwmLPJVgjUssubDKiVrHecs6AdOButJszn09Pk+HbaCz60KOVK81KqkAnMo3kzTzOGZvISxPksFRTGyIx7aVkrGm7cq05zqeVAewhrKsWoF7lwkgnhxMyZLqwjcz5ySPVmSOPIFKUUF5FWn8+tOju9HLansneWzX40+VcPY9tKPRUByo+hZ2dfx7pB4oYEFYfwOHJGypNPl3GXmbNrdH4d+Nl8kXZsrL46qpvyRXm2SbGMtpzVtGTcic70JGtyVommzgFPE9NTEtbN4xbsoGpXVnw68CnY5UMOAKqnYO5h5BPpGwFeHAseDCtSUymRxAp2A5i6OJq+B7yjehV1lkI2lJTwHTLhlICTm8ljEAyCiyMooqmxeSSBNTMtvEVVkzVVv8AD1JsWIz0Yyi4ZE7Tj8sXsCs/jUloY0hYhdlOBhUgEnLCYeRDF08cqVQusS1o3Yw6/tcw/CXf2Ay5XPkCYoGI0QeF58YEcN26pkWtj85eyHMq40oGjEO9iR1gpAoyUvz5SrBIAOk6FRwZNIGp2oY2XQaeIU9ZRW1WfmpkZB8PVHHx6cy0jncckVNErhwMiZ01m3Cx5FVyQ7CO4ZxKjgsaEXKKAogjUVNeuawPYc17FWjDCJhMOHSRA4mA5xEAAYk80Q6INTKhKEkQXVd6PX1VY+9pcUySZABSlbEljgQiys6m8B9IP0lpVcHpnRyHbJJanNttoB48Gxfh6momMGSSh1o/DGgQsT4JAVvxzpmDyPw4/H7kVfxxMQPG1jDMqdmvi1ceeTDq2vW4vlZHMzx6coaPk2v5RV/MMMUgdZk6O2ckwzxTIuO40+91eTve3lLXjs5ZRZI1RU1eWTHFBTdRbU0OmopGHUUdeKNYawU2+qA0tAA+HcUSyyQc18kaMMzdN0DKOHIAfzPOh1Wzh4kc80p5QmMqmRCzPnVMR1+0jJD17111N6vslmw7YuGL56q6jzx+Lwij5Rci1pdyq6IZQhSEw6ah9Wp6mIWxfsP7HcZmrJMW34jSQLPlBWwOHJHJHqpARZTT9yo4AoEMfnWpttkE2ko74n7WZYTBamZo3KaGCeSEqbcSmS8kxgcRky/VFYB8IODKg3ZOam5oTzOOHamt5KdTfNBwREFpNTGziQVB8o9ZzTyVRkH8kDoVk8Ih5YkWLrMNZJiAgbLCzq0bGNTMwUTkpSSFwMgDgjQmJuSmdvBUZsHcmxM+i9aZtpB6j0xwfx9SFVXe0oWhVFUHa7wy4vgcODqpppguQ5W53BMjceKfkdqarST93Y6+SmFkVHLIyIomQ/HZKTqcOlJO3CpGI5+R5nEXDLAqyxfNWq0OfHBw43VWorMnjNy8jvKOkUpViIC4dJKYUvMSgs8FRKQTiNel2qWdNoOsfHtGnukKCpKIOz/j8EVMozRbHlIA8YKA4YgoJoSDZjHmOVRYlczXH8SBNVx84qvHLqJxarDy8MLOUaP4zHzsRIILJKmW9aRjwkCmcJazHWDY2cmG+P6kLQWKiYLs/ARVMrcyrVBqs080FmrkG8XHGPGmoObcNrmnNm/yb01BUb9cZyQMdskskyTB3KFZKy6TJzHBh3KDZvO8pAeRVTchAutdvvVfVfVZaW1jKyaH5bmvi48YG8XignNkcCwKzBACiAJpKtGhxSi3b5cKA71U9GT9TNJXJ5U5CvguWNK/DAU9UMk1lU0i4s685g9IwOJTRy1Vs4k1jrv5TBfNDSXTf7BDoIdB+wnsKbRXsd7Hexvsb7Hexw6N9jvZH2S9kfZMdJ+zHs37N+zY6d9njal9rPa4dYe13td7Xe2Htj7Y+2Ptj7Y+2PtiOsfbAdYF1gbWPth7Xe1xdXF1Z7We1ntYGqg1UXUZdP8As2Glw0qGkw0j7I+x4aODRQaGDQnsGXQJenwOnMvTdCdL9TpH+jxxxxxxxxxxxxxxxx/9IcZxxxxxxxxxxxxxxxxxxxxxxx/5D//aAAgBAhEBAgD/ALBzkvv5L7EfIhcZ/wDFd57xGFT6/wCuOgUMVqvc/wAMitW4KjAurp12mpONO83+C6u2qlTAx+hAUckUwUbX+BfnqQCGPeSOxEL1pf7ieaSpE35GPkIfFz/3XpaoC35GNmOIgL+3yZ+PH9HGyNI/7fIF44f0JeQHxZ/23F479XXkl4n+11bXjv28kvE/2yFKEKB/zI7AVkP9llSyV5YP0mUs8Mlf+y0/yJLVGYS/F3vyQ2PkVv6yUcf131sdWn+Vopqv1v15N/M5b79u9N+zsJ6aeb5Pyfk/J+T8n5TWLT79nZZ423Yv3d93JZz1iqq001ro4fi/D+H8L4PwvhBTsDjr67KNdm+4y9jF+buRLckI4QKGJ5/kePljCVyGMdncxjbIvaivSfK+VCFh+yJZ4yB/kbopCGN9NiESEgqqhESaXRGcchMwnIq5+TGKOxDCxn1yzbRyYF0L/gbokB4hWjVuJkZiASrZSimQokJqqjOIZJISLjGocgQ8PL7EpDY+rQX2Zw4mVk9qJRrrKUXIQE5I5Hi6oxupkxVykYZ5I9QbdMwrev7E5KcQjQkQkp7cHBqTiu8SkE4xYCIjijhTOS8hw6qvZBogBOzIOCWIofWQs8G6Yge5GahGVy4jeJFJiYGlWFIYKV/Jc0ildhd2TPgSUiI/Y0PDp+GQvdUaBTk/MKKNmwgWSYkKmXkefH8kCFYHiZEh9XToEcoy4YTMJLyoSRMUU1H4sFMQMjmeQYMFJFM7AxKzUKtHVggkMZmLGzSPxKhUfq/EKkiji27nZgsNTEk5LRSSGJRBE75lhirpjBdpAAKQBiTy4612SuLxepoFBxjUxh4JBFsSlf5QFOo1q5uQmydsGNd5EFjvQEpWxGsaqRlW9ZEDwJmJBIo+HEZMKxL3V5JUHBCgBmJDJI9dWJe+CfaFZmW8C23Ur5repoWqqSQJCj6yKOVi1RvY4rFJGjmCQwZTTxzkHUxWuK6iUhtLGfWROQt1TszResiZVlIEca3IAhEWcmNT8VmM3YoUMhSSQww5YtbSdV1AWwwsxmiiW9hCovWVRlXfmQISZEWQKZWOK6nQliUNxbCM8i9lOqyiRJkUiE2RLWZMovWVA9fkJXULomQKdTcV1OgBnd8gmc2IUA2k6rKLlwQAtlMSj9ZEI1kZC5w9LIJXbRGrHFdSMRHM0jVxiOaOfEY72uKqiRE8oG4kXatJ2FB6kmVZSKNCsSgIgnaRlNxWRkpIgjJ8yxRw7NJra4gUCdii3ZzXUwqygQ+pISqogEDN2F+oR7I0ascQKRAOuCYVq7aSBArQqsokKZpY9oxw/FhCh9SWtbgmBaxLE7R8G1sFXRoedWHVxRKMbXFZRIeRTca4sMPuTV06ZuohwJyoEyJXOKyIdXJa4MwJw68WuKjRBjYkMeNuJ1H7m0CchLiUxIeJBVkeivGiHrEE6KIIm4xbDpqRQowcABSBoLZmUfuSrrQRQuTDHzI0nAJ0ywbcYTllTcQqJMtU75diHEyh93UUWqdarVx01MZIOgY3HGuNRDVxxhmlj6IYox60TdeuMamEYfvnP5Z/DP8A4t//2gAIAQMRAQIA/wCwGOOgPjfri8edNx/xQGHx0dVy+a3kGudU1Gen/Zj2jjqUZZCdfYN5Lv6YbksF6h/U3D+ojSpWbBlPff0htQ2wlZeRpf1v6+MgkklnOT2zTt15ZI7sH90YVofI2pDxy3D8M9eWjL5et/Q/t42JnmP1bh+a01aawEw/0Y9PGB5IvTGPaOUH8mHpjH8LcP6UA80fGOX9oCov5oOW4f8Ahws+lMfOPxnOcrHoC8W/m/TOecfs/qyqLznu3D+gLxa83/bXjjOcZo/VuH9Ioap2wMf66KlQje/NlAiERtf2UBKGOHyEbj+ItQUkXXa/rFo538399Y8hZH8a4U7/AN19sRfy4aLp6PjtFOHx/jBDZBqP1/1/1/1/wPgfXvRgDrav8esuvp6SD92YIhEW002NSLu7iMkFxvIfY/Z/Z/Y/Y/YlfjIJBneeB4V16PG9cq5h+YiEQh1gndaSiZDU+D5GAShcSNa6i5k7EMZ0IXo/AlKqOhNoifSaD8om16xRs5tDHITOMlqKXyJiurOWFx2Qxq3F417NilYsKIGIAUiy4hJKH4RiLCxNmy9eUvJE7qFBF1nASDgX4NCiZlcXXKEVeyMadPxK3EoOyCv6shjiHXbYwYZBdnUCrx6XRnW8ceBLZgMGJ5CVJtNbbRE8YybG+rIlq0N/2hFRPzlhgqSJ2hQMrI2FG4yEsCgkklZzQLx6dYtjVNzcuHT8EJK3Z9aw6rOMOMo1TjawUAhxI04iLKMup1lDFIMC8bzcGAWWMp1jDNFD7RDImZDw6kXj1IpVWZuCU8YG3MnApkagbx/N9g5w/DjmJq5l7CpEAmLp0zSBQbyMUiilhtM89mWcBGLDzoIjAUaAqloJJJrE4oo8LXTiJhU/qLAplGZyLXMhVCuIFGGrTEoY2IZSNkzBIcrJ2kQwRlJMYAuzOjFtjSHiz6wolLy7i5p1Gdm1rCoY28fYCBz4EcOxcZB52qqamVc0bKN3TkTbYhcXu+sKxNwycGUjM6IEDwFtZeFGyYmI3TNoLWHqjm28il4jWpp2aNQsLXfWHidABgB9rCUeH4BV+LbQuupwF8gBRsWTCDiypkwPEQIWxtvVWbXrCmVhBKUi1CQzTraNQcWFGzIZUQgEZyysnYirrFhT8ObcOt1rU4s+tdsTi3IvKLJmdGoFBxZUSdsChAn4ANTasnVlSpndCKfgWZ6zkrPrWWLHGDBS8C+HUChTqyq6IkXBrOwupHrJ1ZeVOKEnRksKtxP6wOx2ELEhkaUkUbF2KNoeLahIE0OHsbBEcTM6Ia/FlTIV1mDEzPHneq8ilf0iaN51GpOQMpOAJlDxZUQIZSIWZBIZsnEigZWWscNLrjPblVEbS+sKxZQm6ERIl2ORAZxKDi0okR7LbLuz7gdhVyVp5nJ9opXRJ0LqmjUvrE7HaWQIlsazCRkoVDxZUaLnbKFbCpSrcWVZTu7islxnakpHMvQXje5z2bkWsbm7qFRcWEBbY4Z2Ykx9irLNp7BZwLbLHFJS+zKErqZiHiMXEnQPGouLKZC7E78MZHxmqsWVZQluZM7EnWKise8D30xbJ0L7811FxMm9McYYcEqidW3t8bJuHfZnrK2XsJWbfa0nb29vZ2dnZDLHe+wms9nZux77btJvu5wWfnW7dmVpNmPs3337I7E0v54WuuuvtrprjGvGPTVa684/HOc5znOc5znOc5znOc5znOc5znOc5zn/AKL/2gAIAQECAz8C/wDk1Bgd+IAoTe41z/oop7jGt63q1O9uXQK1+8d/aFa/eO/tCtLMSHdQn+1CB6FQH98GH1wUKN3Htd5/6QDbyZBQoN0PtT9FabYZAmXhb/yo0W87vXFN9olygs9gKGPZb8kzIJmQUN3shQXex8kPYcR1Vos94v5txVosxk7fGTsVBtFzuzdkf+VP/RkKy3DffkFaP4i6V5HhGAXGKf0hMgi4Bqa1eSHFwUPxKH4lD8SBweiswmuUOP3mgp0O+GahkVHsJpN4HsO/woVsG6ZO4tOP+iQwEuMgOKMXs4E2t8XE9E+0b0TdafmUyAJNFIQGCa3EzTjgKUPaiJmRK/Kj4QvypuRCyfJPGMnJj/ylEYXoOxUO0C8efFRbE6psyBg4cFrJQ41x4P4ean/oZsBpe8yAUS3uob3ODc+qEOTn7z8uAQYg3H5IuxNLUB3RPmosfM/sj7RAUIYklQhwULwqEeChnjJeF01Fg5rxia8Dp8k2JjulU9E2KFTN8IdWowJQ4syzPi1BwmLwf9CNgtL3mQaon8RiUt7vst/yULOL73nE5KnBcG/NCH+ZyfaD/wByTWY7xR+EJjcXTTMkPCvyoeFMPJNODkeqZE/KU+DeL+YXCJ81L8zVO8Kvqq5xIYk/iM0bOdVFO5/+p/4U7/8AQVN54I22Jq2fdg3fmOa1Ame+ceSlcqt1uHEqW6zzKqvd/wD1CGL90LwDzVotfda537KK77xwZ0vUEd5znfRWYez9VZvD9VZncHDzUI917m/VRmdwh/0Kj2XvNc3rgvEPNTwMwhEvbcck+zGXDJBwqYeoVeGKq6qfasF/tBS7CIfgJ4cv9BU9gw3nvnLkpdq7E91Uqe63zK9hnmVxKEO5t5/ZRrc7dvHiPdCgwJF/au54INwEvsGvucAVCi3w+zd9FGsJ3hLnwQfcbihFuOPAp9kf/wB3oRRU3HiFVfxVX+V6O7WM7rj8ivS4dLvvGY8+f+gBY4TnnH2RmU62xqnX3zcVQP2VNwxKoFLcTiqt52CnusRiyiR7m8G8T1TYYk0UgfaNiilwDgUYM4kG9vh4jouDkIgpPkU6yv8A+7wg8B7cCuIQitLTg5P/AIbaPhP9zUIzQ9uDh/Xzao1De6wyHMrUMA48VT5KgF5xOCMZ9/mVVuMwColFjC/2W5fgJzjQR8TP8heyVrm/mC1L5HunHkpdDo1rKx3mfssYDurf+P696NAcR3nXN81rYlZwb+6pCmafmta+QwFwWqbQMT3lPt4o+Af5/BUdvDF3tjLmuHEL2xxxWsbSe81VBT80bBaJj2TUOiEVjXj2hP8Aruuj6sYQ7vMrUw2jzKlM5KhpPFyp3ssEbbFm7uNvdz5KkSHD8EHAg3go2GLd3HXt/wCEIzJZo2eL0MisDwdoqYInFuKrY6EfYw6H+uamE9/haSjabRU6++pyk1XBuaqfT4UXkNF5cZBCyQmsGPE5n8ILXBc32he3qjBfI5yKwfmtZDlxYphaxrm+II2S0tnnQf65RCEMfzD9At1z/EZaN5x8KqJOa1jzGcLmXN6/htVE1rcImPxLXwi3iFq4svFcuGjVR5j2rx5LXQYbs2j+t12inwN+pWrhsHJYqUN3NTkBibkLNBYzIX9fw3pMB7eMpjqFREkeNxWqi+c1MNdmNE2sf4SqoBb4Hf1v0i1n80T9lIKTSrmtWvtDcmbx/Eej2l451DzVQY/MKqEPyq5VwH8l2j25tH9aohvOTStZaAfNXK4KcUDIKTHxfEZDoPxH3cX9JVcD4CrnhXKprxmFqrU3maf61RZop/Ku1JyCuV4U4zlq7NCGbZ/P8RrLM78t6myIFvuHJXaNVaxyi/1qVlfzkvvCsFvKqO4ZuAVLWjID8RXCiNzaVIuHJdr5LHRTaT8Q/dTA6f1n1b9QW7E6rBb6nav/ALB+JmD0VER/Iu/ddssdErQfJThs+Ef1n1b9QW5E6rBb69aH/uj8VKPF+MrtwsdHrB8l2bPhH9Z9WPULdidVgt5UWgu8LwUy0sD2GY/ENs7C95kAtfFe8DvOmu3arzo9YPkuzZ8I/rJtMXUt7sP6lSEXkUxhpa0xCMk2I7eBh9VVHcPEU7+Hx5Hu4OH+VUJjj+HNpi6pvdYZdXIQBQO+e8VKO1Q7POsyUCIZTl1U7Q7oEQfR4h+Cf7f1jVwnuyaVrYpcb7ifmn1RIMP+Y7HIKFZGXyGZKs1quqbPgRijZoza8J95AhsUdFrrOAcYe7+G1ECI/IXdVNzojvZv816RFqPAzRhWk0iZ4BDvx995zwChRhKkciOCMO0hjr5Ox5L0a0B7brw5a1jX+IT/AKvTZYkuNyNEUjFejMiR4gk7mj/EnGJGdu8GqD/KuKMWqzRe8O4VE9HiNeO7gpRIjOBbP8NTZw3xuVNncfEVqbO9/FCzQzaYl7nd1R/4gK3xKBwAUexbzHl1OIXpkNseGN9tzgEXQoT3CRwKL7M2fskj+r+qv8l2caWIT49je52IdIpurb0TW8Zkqu2Mp4YqIY0YO7jm3Ki1U8iPl+G7OF8X+F6uz4lqbOzdrrdJU6gYNmnAbuCuNWSMCHHLc7k51khl/eJC9W/Uf6vOyxF96OSs72RITL5zmo9hJoFbFaIlzYckYPaP75Ub0ovPcK1VtvuAe5B2Bn+F7OF8f+F2LOqiw4Vn1YmD3rpr0uHT7QvCiWXcitNyfaNyG07yg2aGIcc3xD9VKzsAwqC9W/Uf6sGAuJkAn22qDCZNmfEqb4rTxaodmnTx4oZpuabmmjiq7W5k5VPx6q0/wh4M6mf7Sm2uGHt8xkfwjIlMJpm5rt7knBoBBGS7GH8IXNB+Mig3AAIWggnFqps7OTgodnbqol1/e4XoOvF4P9VLIbYY9s39AhBs7ne04TJVMd/OejkuS5LkqbWXcwvS4Dmuv3ZhFsR8LMT+X4P0WA5/HAdShHLo8W8A/MoRIjAMApMb02a4TPiUO0WUOYJPa3FEzgOOHd/4/qu/C+E/4UrG/wCBGzuqF6d4QomQUX8qjZhRvEPknxe0dx48FOF+heuO6P8A3/ByhMGblTYwi55PNRMgomQUTwhP8I+ad4B80bSAKZSU4JClbh8b/wCnNbiQFD8bfmofjb81D8bfmm+IfNNzHzTcx81N8KV9x/wvU3/CoUaKRFlKm6asXhh/NWPwQ/orGPYhfRWUcIX0UIQBRROsYSQ9CA41Lsh8CDLY6oy737qF7xvzUL3jfmoXvG/NQveN+ahe8b81C9435qF7xvzUL3jfmoXvG/NQveN+ahe8b81C9435prsHA+aGYQzCGYQzCGYQohfEvUx0WPUqzxbOxz2NLjOc1ZPdtVk921WT3bfmrNAgOcxoDhhemeiOiS36pTXZOXr4+N39KhWfvvDVCb920v8Aoo7+7Sz6lWp/813ko8TFzz1Kic0/JPUZ2FR81H/N/coouv8AmnCVU16m/wCFF+Cfknp+SfknZJzRM4Lsv0IviOA8RUTIKK7BoUfwBR/ArR4FaPArR4FaPdq0e7Vo8CtHu1aPdq1NwaR0crXk7+5WvJ39yteTv7la8nf3K15O/uUVvfn5ma9THRTJ6lRBcC4eclGHF/8AcVHx3/7iozvH/cVEONR6lPaJXhq7J3miIzy2YNRwUfxxf7io/ji/3FR/eRf7irSP5kT5q1N/mvVpb7QPUKIO9DDuhkoTu+1zPqrPH7sQdDcgcDP8dBsnfdf4Rio0a5nZN+qjWi+RPMoN+8f5KBC7t6ahkV+Qo+By/KUIZnSUzwlCczNCJKS9Tf8ACg2c03NNzTc03NMcDvKbZLsv0KmM6d15TPEoYHeUOXfChnB81C94FCHtqFjXcoZweoQ9sKG2U3yngobpkPnLFQT7YUJhk50ioUqqt3NQn3B01B8ahDF+KgyO+E2IG0ma9UHwrePmgOKaeKZqqar01kzO9NzQLcV2TvNSjv8AiKbmm5hNzCbmE3MKFEEnSmoVM2yQcCZykndVHs3de5v7JzboravzDFQrV3HA8uP4oNEzcApzZA/v/wCE+MZmZniSocH8xVptF0MEBEXx44b5qwQeLopVnZ3bP80OFnane4an+5an+4aj/wCXav8A07UP/Lhawjc1a9Tf8CAxE0zwJngTfCm+FDJA8F2X6E3WuqwmVZ+asxAxVjDKDV1VhgGYqmv4eTPeVhjyqnu5BWFrCyRkeSsEE1Cc1/D3GZBvVhiyqnu4Kww2loFzsbl/D2GYBuVgjGpwJKsJZq5bo4SVhg3tEl/D5zpKsMaUx3cF/D2tIkb1C/lr1QfCrz1Tck3JN8Kb4UzwpssF2LvNDXPnhUVZib3KxH2x81Y/H9VZPH9VZPH9VZzhE+qHsxVaGd11QUWF32FNcmxL8E+zuuPmERJke8eP/lNiCbTMH8O2C0vcZAJ9rJa0yhZZ9VSKn/JRLUaITVZrBfGdrYnhUaNuwxqmckXXvdNMCh8JKfdAQAvlNMlsjdl5pr4Yae69sl6G8AGYcoLmNNDbwoPgaoPgaoPgaoPgamQIbS0AXoQLKXnKQU/PQIihc1CnRR5qFzTYfNNyTck3JNyVd+ATBfiFBijdEkOCDcQm5JuSbloDoLBwLZI2R053PNyguhsJYJkKB4AoPgCg+Bqg+AKHZ4Qc1sjNBlnqwABmq3uOZWtNyvvNyhkdmZlFvCabzQ5ojB7h5q0Q8Ik+qeLosOoKyWzunVPUeyXjfZyQiqq9qiWF2beLUy1MqYeoy/CiGC5xkAnW18hdDGAz5psAVvx4BOtprcaIQxKEMamyikcX8SuLrzs4q/arEk6y7rhNqbaaC3hiuyZ0RR0Fdk34kXACdw4aJlSwuTxxV3OSep47Lmc0YhlKSEJpkE44CSLsdi9ej7ju7+ybHEOl1Ul2UP4QiiiiuxHxJ+q1Qubx5qSMIYTCETdlimWcLwhTv2Wu4SKj2TjWzIqDbr4fZRfDwKfZ3UxBIhNtIuud+6iWCJMeYzTLUwPZx+n4T0h2qZ3Gn+4oMFTkba6p5lCZif8AC9I7KFuwW/VBidE5BQ2d5yBva5FmOiRu2KjyCrFY6aQcVeVVBZ0QaJm4BCcocN0SXFMiml7dW7RdDbmVw0OAnK7Tuc9it1/dGKocR8ummkzUwBnpfF7oRGLwE9n5lMdFNXKcGH0QaJm4BTPZQjElxQc6mIzVlTXZsGZU1JXKhwKmAM79L38E/ki3HTNq4i4ptoGptNx9mIn2J9LsOBzQtLKgRUnWGJ+U3OCEVoc0zDvwWpbqWHfdjyCnenWuIIbf+wgJWWD3Gd4+IoMC1h5BUgy4Kd6k7khEEpzUtDnOpYJlWp/syUZ3ecAnWKJRVVcpmXBy1Rlw4afSDEGTZqqGWHFhRpYwe2VDgQg1ovQitLpSc1GNBaTiLl6XbGs4MxWqjvHPROGqDUMDsmIaW3laoCEOrjmvSGUe2zuqVxuOzrXTPdC1bTLgFXeb0TNp4K6oeaxWus0Y8Rgq4MuLCjSyH4zeocGHTSmxYbzKRbeEYkET9m5el2hsJvsC9UuIyKrIGa1Zp2KRU685IiTRcjDvmq+hVJlpmUIvDDimxx6NaP8A635FRLDEodhw5hawVtxGK1TtS87ru7yP4EWaG6IeATrS8udi4qgSC/8ADrNP+dH+gUhPidGqhCWLkc0IgmSpEjJSeJKhxT4zNa91IOC9HtEppx4r8y7VhXo8cU8ZFV3RG3Kq9hqCxU3RCvRLW8juTvXpMJsSHeWXjmmSk80u4rX9lB3quKH8Ns4bjEPDmU+DHY5/81Ux5+IK6aNNxkjFguni3YMqonZsQhXQmXZnin2x4kJGSdZXm4FyhxvvG0nxBOF43257GogiWLk7xYqtlVUkc0XNe033KU1KzuOc16NFJPccZFekww5l5beE0CmLNrgvSeyhAmrim/w2AG4xDw5qcWJV33BauPEH5kQ4HIqZY7Maa3hUmTROSMd2CMIyPFOHFEkHRLmm3zunonfxCH8Vs5hP+/hd05owXFjuFyodU3A/RelwhPvsudpkp/aax+qb3YePVUia9JjTPch3lelxyfZbcOmnXQhm1OGPBOGBkqzjetVeVMz5oCzsbD7zhLonQojdZjimZzQyTrbEa1oVNoYMmhCGJxPJqJ/KMlcVKHEKbaotoqEwVabD912kPJQ4n3lnIdyThdZ4EifaKcXa20Gp2SofAfk5T1T8wiQnRW3IQIVOew9uO+MimR/uzSfCU6xlpa68p1qeZu3kyz981u4NTn8hkNj0iFTxansBJwCc0SDjIoxMDghZ4bsyrlq7CT+UpsezEPGJVqsHc7WGoUX7yzmrkn4WeBT+ZEu1loNbslqreOAe1U2k8wq3NHAlXtblp3/JUuIK1ZmtaeiLzgrwJ4aZd4TC4wz5LyRskZsT59FUG2mHx7y1rJL0SOJ91267QyxN8Tz3Wq1W0GI95YzJF0AzM5PIH2fo0J78hd1RjRKncTMqQXoNj/6kf9ld1UtGrPIoRBdxTm8Jqnecp3BTWstDGngZr1ojkEE0cFOOeina+kkXmZ0XKiyOPIrdiOzOgHgFLDROBPwla2xw35SVypa6dy1p5DQZVcNMrxcV6TD/AOpD+q1TXReJuaqrzidJEuegwTPgcU20NIBxURt1M+a1Am43la24d0aNXYB0Cps7dDT7IUsBLRTHs7+a3obswgykqsl2eiSoIKbFE5AqTyPkpkSxQhi9TvOiejiLk51x+egWqzuguvpuRgRHwz7JUjPNNFj1rzewUnmU63xTHi4TuCohulwElq7M2ftmr5/Zzc2COG87/C+q9IjMZzWsjiGO7DEtF6loIwT80XYnQ53Jam1tBzVNoa7xBEKQUg+ItZaXnnsaqwdWqmB1OzXAiDktbYCMh+2gnjpAZTy2KHA/Pog50m9xuGmtwGaBZ8OmSf4ii7Ez0TcFTZobc5KUGH8Oz2bHeFy1lnhvyksNFTjyUpHPQ6Fh8kyL323psPuNvzKLrzedO5OenmjmtTaJcHrVxWxR7WKqZ1wRiOEOcgShAhgDgjaIsOCPaN6ENrWjBol9lSCckbTGe/xO+gVyvixj7AWtiviHiVO4G9BneN6b12ZLMLfbFHAr06zNiNvc29GmmWCi2twEpDNCxWcgey1VEu0NInOZyW8AqLIxuclTAYOWzU1w5KcGNDyJUnEK9Mcd4yTBwCfrJS3E3iAmMO4Z7LX3l36UwezgjEqBbIfuoZ4SQhmQM9mqKwcwvuWqTWjIDZqs71rbB0boY4A4nJBgJaL1WBWL1DlfunZJuCPEoOBbNHgiMdOrex2RWvstQxEipgLVvnkUHQw/gAjFe+0v43M+z1Nmfm64eav6IgL0X+HnOJ/lSarzzV4GWwXNLstippC1DtU/uuUOyR2vlNsXhkhK5UsbDHtYqlqJ4FEcCFXFaOYV0Fikxo5bVFojszVEZ4/MVfoOZW7PknHElHwlHI7HknVNm4yUmm+SecXbVVoZ1VVpgt2qoTx+VayyPblNSmrlvXnoiJSMiicTPYPBUYLkg0TR4XIzmTpuXpFi/QpTGS4p9qos7eJv6IQGNY3Bo+zm6HDyBcVdciXNbmVRDgwlIKSnfpqMgtWQ0d0Yqg/lOGxxyTI9ngvfwKBaJYSTrVaXcZGXyUXJObVOVDP3TouOHAKu0M6qu0wm5S29Vbz+YLV2k879g006CTQ7yT23ew5Pf3RNRfAi2YIFLMUY3AAaK2hvz2GtGqOLsTkUWzBxGiq0jkq7e0ZS2pg9FIx4fMqiK8fmKuUjNawz0yVEPhXjJHjpm1SRcUBcPmnNRlgq7OW5TVEaI38xVbHflQbHI8TPtNdaYh50/JUNWttLeSrtIHhGyX4KHCnvbxWKZqw1xmpd3eGmYWss8ZngNSqgM6LVW1wwmf3RLpAypWqhth8XXuVyqjzyWst45bertcJ2a34bswmxWyLpZJ0PHDPYlfkvSIPknEm+4J1Ra0yAWphNZ7US92zwF5VG87vSuGSJJPGa1rGu9qXzUsblOK45BV/xB3Lb1dtiN8SotL+d6u2RCFb+97LVW6t/DFe0O6diryQAJC5Ld3lLAr7wc1RaonNUw5Zham0Qzk+Xz+zohvdk0qbqsb5qrgpxHOyVdpiHnsAG8TQjfdmn8qd4ShDa5rmzKecAhAvcd7IKvlpnFfDOD2laoxIU50lURWRQtc+Z6lax5d8lcVvRHZBay3POW3LUuycq4MJ6MQXCaFnuJrPh4KozlLYkSz5IQA4+a10SZw7xWseXfLYaTvGQWqE4IBHixKcfaM1DMMuLt9HMq41L7wqq2RT129Vb2HxKUZpzC1zd5sh4kAbjMaKjKckIAwmT7WSI4zWraDVUXcE7Bt/JAcnZaZA3J7uQUwTUuGKClEeFTagfFJUifJUvJ81XDY7No+y1dmi8xL5qryWKphPd1VT4jvzFGU+Gz7L/ACKpcQVqWAcVPYlagpWqOtZDdmLwg2G7xG7QWtvumpQ4rlVHiu6/vtzgdCtbYhyCc1paLp7VUQckTDPJamDP2ov7aPrsOh3tMlDjewA9Y9U2HDbu7zgriVKE8qqPFdt0xYD+aqbCeiWATuHDYczmMkwhzwPJYAYkrVihn6nL56biFzU+K1fNVX3qUZ3RdtCPJSaBmrwq7LD5XfZSgNGbgpTKnDOaosZPIov8yqjSO627RSAc9gRRN2MP6qsz01HkFQ7kV60Oi7WO7no1EZzeHBFxmRuNvJWtv4cAvVnZ3oQIkQOxKadgDEoNGQzTrcaGd3iUyzwCyfDYNNfDTQ2o4uQNTXtNPRa12BDRc0SRiuya29xWtd+Vtw0GHKfHTK8YhCJ2vAd4c1WZlXL1c+abDiRA64lT2Q3FemPYyHfScUNQBO8ELdVakZaTDM+HFUAxM+7pJcFSZIsMwmuvkEJoG91wU8DcpRndFvwSqpdFgpwXt8L/AN/st6EzqVct1U2P9CLIZaOPHQahNpkptPFO8J2nO5LUzJNy1siCqbV0BVUSNwvU2q5sQcMU97KZ3KoKJYzyyzUG3Xg0RFFsl0QVNzQiCbHJ2admmwhU4qJbjfuwlDsYohibk6O6biqRonK44rdlK6lHIrViVAKd4Aj4Aj7sJ72lsg2egl7ZgyU2FEYg6SARwOioJ9kPI4hQ7XvwjS9RLOaY39yJEwQ4LkuSpEyaQoluNLN1nEqFYGyF70+0mbkZSaFQN669FzphFuIlpJAGWnfwRqF01JSXJF2j1h3RXwdG6vvh8P2XrA5MRkFcFKyfoW6mtxEuabmiwlxdcmjig83CWyRiJrXTmLlqQJC5TtU8wtXa4jfEriq2OHJYhZpr2nonubrGcMsV7EXeGa/mWd0uSpNMYUnNMhjd33HABOinWx/kvYhfNGrex0wx3hemZhOrJLtxM4kKG47g2YYulSc003VCadDqrdO9MGJBTS7cEhsU4iahxmHMBRGjWM4ZJkcURh5qJZ96Cam+FNi3HccmwBfeeAT7Ua4u6zJCH2cH5qskuv0AYiSEcYoQ7lXdK7ZhjkeabwlNFk6ym9dn1h3RfdaNwrtYgzbP7Ku0u5CWi4dV6p+hbuikgrdPPYefZKLcQRpk7qpulktVGY5aiNDjDA4qbbvaVLXHksTouKlCcUy3AuAocCo1idy+hUG2iTxJyg2TfP1T7W6hk6ckxsQh172/ILt3qWmUkKZ8JbFbg0YlSJGWkMe0oUHnt3FTY7qmRpuhG8YhRLIaXC7IqDbRU2531UOzb7zVLNPtJohg0/upPdU3ALef1OmVyqdpe/Bqi5ItuIlopcFu9dE8E48k5EYr1h3RfdaN0qVo6s+yqtET41O4KmnqvVT8C3dJcAMtBiGQTIQ/cpzu7cFrN12KHeZ8tioJtqhUPxFxVADeAVXZN/UpCWi4rsXIsa6eaDxIiYUr4fyUaKZOnIZpkDDHNFsd5zQFpfMTTeMPdTIgqZci0yOI0GijTJGztq/mRMOQWsGtH69gvlPhoLzIJkITdeRij7LBJQ7S2cpHijBOYPFXFdm/zUq/iTY4k4eaiWY1MwzCjWw7xMgm2djqe9LFOex9V6Fbp5lSvbsz3neQRhgBt005l9RQjNExitW6nRV5KoyCDLlfIIgyU127+i+6TYgkRgqASMFK1Quc/wBvspx3/wDuO/dCFxxU6eq9VPwI0TldsiFDqPFBwIljoDHTKa8ylIqhx2HB1cLEYpz20hsnZrekb6sUYXNv7aLivV4nmtx3XZOviL1h+hkNoBmg5rYg2C65omocHeiu3vChEiTBmJJjC+oyBQdvQTUPCpctgQmF7uKbEaWyN/HRqJ3TqTbVDdmFcVKG/wA0YodPgdjdd0W49Se74ir7xcqX9dNRAzK1e43gnRZA3ngnQhM8U8ccOCrax+nvOyTjhcjEPNGGU5Tjv6L7pULWMdmvWoPU/t9jJruhVUSebkC5Sp6r1U/AixmYyQi3gU/spaezh5aGtbfigXGWCm8SW/pa/F36U5u792FUVqzKfmnM/NyUNwmezdkriqbNEKL4RPNOTk5ORixntI7i9YiKEYQAlPQW2e/jsNc2mWp5hPbwrGYvXo75vZ5LWPcWtTu8TqhnxTXimmr8xx2JwYcsBjoYyGWkX6CK34CXzVzvNdk+fNNAdSZgnY3XdEXQ3zW8/qUXmQW8OQ0yc3qnB1UpgoiRwyTogAKe6V2PFUNa3TOG7RQUH4aO2f0X3WjdceS9ag9T+32O4/4St4IRb+KppXqp+BN1dTj5InkMtitkjfJNaC4aA50imwsFUSdjg/eb9UxrKmKtwGabAJp3v8KauKoscUrsP1HZbCjRHB1RdwyXrMXQ1zQ4tvWDNl0A3d3JaymKMDctVXEOGHmnRjN2HAbIvhnyTGNcWtv0V1TEwtWynNXLWQYg4ma1TDWL5puSbkhkmta4ywChxITixtOK33fEqb8FW4nYrEj3gjc7JVXC8rVsFRwWtdPhw0EAHgVIkZprlJxV6AXbxF90pqlh5r1qF5/t9j2b/hK3gqSqqOq9V/Qt3SWSnx0FhmE2JdhPgj7JEk2BeTeq7hho1k1Iy0y3T3StXMnHAabitbZIjeqMKDI57PrFo6prrVFDlDF7olyDRKGFPR2dXHYnOGe6/wChVMoQwZjzOmd2a1Uueki54q5qzOvmRyTWCmE1F5mb1cV2T/NRJRNZPvXT2KmOGYKdAgvD8b01johImajJGJyGit/RSIOel7bjvKWEMAp0TvHy0VOAzQ1Z5aA7G4qu8YqV5VOGK7SIr4KawSai4ElTtLOh+x7KJ8JW8NHd6r1Y/AtzRU4Kbemwczpc7Bqk3CSJeZCa8tOsp/KNJkbuC9Ti+a9X8zswnxYtDZOHeOa9Zi6ScBNRMldTxlgojRhsT0TwvTg8EtuVTDK9Obi07Ty0mVylCieadH1lXB2xJjuhTokF9Rnir3/EdAdeT5JsKbgELQ0FzZJuINKlsQz3jfkm5BPJdWN3gmSvlJNnu4I5o56N+Ir4Oi4r1kfCfseyifCVN7RmqTeu71Xqx+BbqDhM3prb5Xha6Yc25MyQYbjPYAN4mmnAyWtlS6UkG3EphulM7MPo7mhq3XjBUWSIZTlwWtgzppvwGy6BFiuJBD8F6zF0mFwmmc5podrL5yTBmtacJbLG3ES5phuDsVqQ6brlDaMZoPMwJbFBnKaaWnhcuyieah9pq596+exJrjjcmRYTixtAvuV7/iOgswKc995RYAWlOfidrebeUKDtb0Rb0LRulesfo+x7KJ8JUnNU8V3eq9WPwLdRbgU4uEyt08E48dvdlkqn7U1IEG9D0WJVhxTBB7PCey50aPMkyK9Ziqhgd8+WwNXV5aHOEw8J0MTLh00viCYknQu9JUOBW4eewaa+Gm4qcKIF6KHiqqoz2JgjMIWaG8B1U5lbz+O8URiJaKCCtYbsBsThF/HLlsVtAy2t6It6Fo3Su2f8H2PZRPhK3gpoCnOa9WPwLd01gD56OAxQxf8AJMbcxgMlCtA7sijB5t0FmGxU7k28qqUQYO03EKqyRAMTNOhQJOEjPZEWJFAYGlvHNV2yLPBt6m81d19xRgmXDgdnVP5FTAiBNi+1IqHDxiLVMfE8mrO/QXSnw0mI6luJ+ia06r2MD1zRhmk+Wi4rsonmiRGn4tjcf8JR1D5zxKMMxJeIrWbr5FUbzcNnXO/KMSu0mO626XJUbw7jvpszvctXcAqrjoviLfgqnoVuldpE+EfY9lE+EqbmoMuV7eq9WPwKbJjHZxeUwzFWgNdM4JsaYBmqHEbE7hitRDa3i/FB04Zwdh1RYS04hSQIKlZIhGN6L4E3GZmdljIsUtfVUbxktXaY/O5OaASDSeKY9tLmGSq+7NYy4hS2NdCpPRUVErXRDzMgpUwxgwfXZdF7uGagwAQHio4lYqFFY1peKgMU6HjeMwripQonmhGEQhobJ2xSxxyCNogucQAb8EXuiSE94rVnmFrZtcpaeMQ0N+pUOGKWsMk4guDd1NDAwsmAmvvhH9JxRbiJaK3BNZdiqzMKSmr4i3oSa5gBKLW8lfF8vseyifCV2jU5xXdXqx+BUNwmmRO6aTkUW46ZQWS446GEb15QDnSwW+2Wa7TS5+AuzUOz4do/NG0Fu7ejAe2oYKFarjuO4FFneE+a3SgLK+rC+aYYPZiTZ7LoUWNUJTNy1tpjcJXp72CH7IRF7ngNVF0ISHi4lTxv2KIkuDlq2HncpVRDgwfVVX57FBmW1L0kdm6iXsYKJhQUxsIso3s1EPsIWbvmo+Dgq5mVPJThRPNGztfMg1O2BQ6eEr1DbCdqjNpmjDdElxcUXkotm43KegsMximx/vN13ByicCJZp8NphJ7wCCJFMg93ff4skX3uM9G8eivKAdehdo+8W9CRRay/jwX33UfY9lE+ErtGog9V3eq9WPwLduE0Gc3fsi7HSI0MtPBBgJquGgRDTgmwb8Tmq3k6XNEjvNyQiXwv7CnQSHFspI2hwu6BO9rcA4lUCll4zK3StZZXtwqWohBs6uey+LEjBxnSblTbIk8HXLtKMv2RimQ7jfrtVPq4NWshmV54LVsZC44u0aqUzMnhls+w/wAiiCRxmjCY2G3vSv5LzVxXYxPNFzIkzPe2KmOGYKdAguDxI3q9/wARRJnwV1I2TBMjez9lS+68PwVDWwm8BvbFLuqa4qR0SV8VXwlQ0EqoXrcin832PZv+EreCr6qRb1Xqx+BUwyBieOyYRmE2O2WfBRG4CoZrU7zyJqrdZ5nZLTMXFelQT42Kp4JwZeUY7vy8Bo3SibHEljevVxPPZhxHxaW0me9zXrMVDV/9TAnlsdnP2sdESLe0LUtlxVoYTItvUZxmZTK1E4kQjdwHNVkuOJVRAzWrlLDYa5usd3of1U7zx0XFdlEUOIH6ttN9+x2b5eEpz4DqiTKeKpdEunvFONw3Ry0TMs0Ay72dgSNX8u9qnfnondmqQCOGOjg75qq8I8VLBXxFvQlUrl2L/j+x3H/CVvBSNyqpnmvVj8C3dFRAVBuw2H+IouxM9O7PxKhxGnVuq+aEISb/ADb/AC0zbE5BSsMWS9XHXZbDiRi1wcHH5L1mLpc/uiafdeE3ue1JROSfDumWp3iKd4ineIo8SSnxO6E9j5uwWtZJt6iN4bTy0mUhJdlE802E19L65u2KGOOQWvhONIbjgt5/xHQ6JhhmpEGrBNjVMBvRlc6ZRZc4S2HPwCc1wNyrBAKI56COKOej7xb0LRguwPxn7Hdd0Kk/R3eq9W/Qt1OfgE5hvRe3dvT28NkxDIIcSU2zUtvM0HkmeKdD5jTPHhoe/HdC1MOJfOYVNiiGU8VOAOF52XQYkaoSqNy9Zi6XQsMEPCZpoOs9qSbkU6LjcNmm5wu5JsXdE702zNOMkwYXrWGcpbGrM5TQLHTuuXYRfNEMiT8WwKXTwleoWqdqpht+K3n/ABHQ6HgUXSFKbDm4C9HgJIuvN+mSo6IHAYoQpu+ayGz94r4WjBSs3Vx+xuPRSiH4jo7vVerfoW6hg4STYu6Cm2Zt6aOarM5S2Xt5rWNBKLHESFydExN2y4d7eWtY8SlILWWR7ZymtRCDaqr8dl8R8YOM6XXL1mIongKliJaezq5bFbg3NatxblpoeCpNlnsHI6biqYMQ5L0lrjTTI7FbXDMI2aE4HmiTE5OOxVD5lBxkTLmsnrVe1VpieFEOvukt0c1Tounp+8V8LRgvVWfZSjO+M6MOq9W/QrtFL1cBpdE7oT8wFEZz00Ag+SqdM53qDFE2hQ2XAScNNQnWFQZVVKlr+YU7FElzRFnE8zstivigMokb+a1dqilRMavJNtDN4LUnNp2jAZV7cTDkFr2/nZ9RsF2OgxDIJkETxlxTvZAATLS29t6ME5t4FXHopwXjNejNcKqpmex2b/hKJgOqnO/FGEXy8RmqhWzzGzi35Kl8/EqxMO8lQJkhFjGgEzKnzRKDcVXcFw4KWj7xb0JSPVYKVlhdPsqbQ/41MoboGa9W/Qt3TPHQHm/AJsNtwwVd5KlNrrwmO3gCD0QOiXBBrpeJYOkoMUcxioDJgAzWrhhnF950bpVNjieaL4EzfedmGx8Uw31TN4yUrTFRlORkjDEgEI0I5jYGahMveZnIJsUgtQhOmZqFEvG6U0JqbmghChlx4oPaRTjo1U92c0LRDMm3hXFdjE804ti1T73HYoY52QXpEEukG44K9/xFCGJFCJvMuOSzuXNFUOBVbL2qllUlrX9SqnH5BOT+ScckWic79DXDno+8X3SrYFJ169Vg/D9lK1ROoTWADMKcpL1f9CJbNTUtIgwxdvFPOPFOdgFThiiTS6+ak4jYMZkqruafZwS2ScX1ObPiUYjiZIq4qVkiJmpAGy6DFjVe0bl6zFW5TJHJauEZ8dIKYBIs81xbIhGDeQjFMw1Oyl1TWiVAcc03iExSRMNh4BBNayktUuSpDnTEpK4qUGIeqMdr5yEnbAodVhK9Q9S7VTpvxQhmJPMrFF1/dU7seadkjkuSa5spqTZNd5J0NrnSxwRy0A8VLC9OKAbzRickG3cU7tJL7q/RvKVnhfCPspWp/MBFkuIVQ816v+hFoTH8ij1XLRU0EYpydDbKmaDs5qTpm6Sm52gjguSGCkJAosZzfpuKnZX+alC81No2HGJHmTcV6zF0SaJqq4YDZ1ZmEXtDpBU72ACrPGS5InihoPdUmnd0VDuzTQKQFcpwYnmmwmvk6qZ2KmuGEwvR4LmzDscFe7qVJt6qww0PRUkwYtQe4UqUm5KeiXBAZp7u6Ls14iuDVzVVd6A1ckGtGZU3KmEwflH2UrQD4mIOAvVInzXY4nuqYN8lkijkgobrjcmSMn/VOHEIk3jzCDRKRPkhlJDNFFUiZC1srgqnchcqjfgFfdgrl6pEXY+a3djXvi7obSfmqbTF4pmNF6c7kpaDKfDYOE8URdMXJyK5KWIIQz0EXOvChZLg25T0dhE80QyJ8WxOG/4SqbO4OuN6BqmZCZVVwwGkhS0CEMQoXenfkgZlBjZtO8U7NPCdyTsJyCE7ygmnig8vvKDBDkiV2g+IK4dPst6E7kQgeXNODRfUJp4g932VisjJP6otxCGSaoXGHNQT7JCA7m6n5zTuMlWDNvRSTDjETJSrUMe2VB8ZTWilnHEoBTa85KVkeqoQV2xDY+KWPqmb+S9ZibHNbsuWzyR0byuvvTSuaIXJDQL1KDEPVGO15MhJ3DYLYTyMQEYsFxdeb1j1Q0EmSmOiChj2EPAhkuQVRwkr7k+V8tHLQEFvPUtXonFb8Tf3Vw+yqgtf4HfuuCIEuCnBb8Kx6rzRqRl3V+VflQyUuKJRRyRkEajdNA8NIUk9+ARZDfNeqvQ1QkrjsOgvjVCU3Xc16xE0h2JTBwV8paAz2tJ0MTG9VX3k13CSAux0kpvtFBoNyphPnheoVDtVnfsUQXnkpwCZSxWPXQDiUAZgrWTAWRUsdirFAcEXnBNPCWmampPiKYh6Ko8Mf9QfZ62zRByn8lNTb0XYt+FXu6lMPVS7sponvBQ9gKHPeTOBCeSJYLoof6uWjmgijKRC1jHclVZXhFsIA3INQQQkeie90Sp05FTjxFz081dgjmuScnI5o5oozxUhcVntSC7J61AfPiU1NTUx0JwOEk0Qd28XqqfVDNUc1XdTJNh4Fc1ViSuaCmiE7jeFdupxxOxzW+6SuZfO9XLWWqHym77OppGYWpiuafZMldNdi3or3ZzKn1V96lKkonHRzXNdF5oZISF6vPFDQEFPivzINY5vFU2V5CL4QJ2JAnJCJWaab1OO8c0OHs47G7z0MeJd0preN+jkmAd1A8kJppwQ00ik4u2Oyf5o0OnnsVscBxCMOBI43oun1UsUAgJIEaZ8FMEyw2LuuhvFAd0IRPZVHRdo5SDOqDWT4lTiPf4RL7TVxRE4RB9Qg6FzC7JvRdo8c1STNFVaQocqZ4aCEeIQyRzRy0ATcpFckckRNAWZ88ENWKbhsXGeCZvFnEqUeIVK/NSXNc1zXNBpvvTDe0IlGauplLQEFyXJE3lGc0XCqWmUJ6MZrp8DsShOkp2e/Ioics1ULypcJo5I8Sm9Vk1OKpMuHFU7BJuC/MFineyp95ylEdJbrON6wC1NnBOMTeP2npcFzeOLeqImDcRiuyai2O8SnNCayXlpbIlSPdRxwmiiNPNEo3NKDhKd403L1R67EbE2u6Isa6ealGiIgA5ouxTXYYqXBDJDJDJNLcEGNU3TRcUM0NE+SDOfNOU21TT8JqpSXZPUmu437BZCK7DyKx6oDFazBHiU3qsgiVRlPQwtvdepc0FyT5XC5OKae8V4VSc1OK5CTBzRtkYN4Yu6KkADh9rVOPCHxt/yEYG64Tb+ya6I2IwoRDMqWBWaDjcZJsPHeKa7hJSFVQ6Jx9pMdi6SDfbnoKn7QCbD7omc0Yh4BUG+9MPsy5rmhJAWV4negIImQm+IJviCb4gm0O3hghq953Hiq4sS9F0hNU4vUu7dsgTVwUmzqx4IIaQpKG7jI6GXElTwuCuQEGJfmgGGZlem+IJviCb4gmGE6Zmm6iUxgmzNSE1vBCooaGuEhuKSpBGamms4zKno4TxX5ggFzTGzJN6EFznG/JRLfEuE3HhkhYmSxee8ft4VpNTezdywVob3aX/RWrwD+5WrwD+5WrwD+5Wrwf7lavB/uVq939Vavd/VWr3f1Vq919VavdfVWr3f1Vq939Vavd/VWr3f1Vq939VavdfVWr3f1Vq919VavdfVWr3R+atXuj81avdn5q1e7PzVq92fmrT7tytI/lOVo909Wj3T1aPdPVo909Wj3TlaPdOVo905Wj3TlaPdOVo905Wj3TlH905R/dOUf3TlH905R/dOVo905Wj3TlaPdOVo925Wj3TlaPduVo925Wj3blaPdvVo929Wj3b1aPdvVo909Wn3TlafdOVp90VafdlWn3Z+atXuz81avdfVWr3f1Vq939Vavd/VWr3f1Vq939VavB/uVq8H+5WrwD+5Wnwt/uVpyb/crR+T5o/zInk0KHZRKG2XPif/AMRn/9oACAECEwM/Av6xGAe0zhPs85Me3So9ulQp9gk+21nUr9vr1159+vv26/7N16yQ8Zkvp7EEEEEEEEPYaztPb9HkettBRmwt1XrbQe/Z9XtrzKzpOfXodH09ZrnVgr0WuRTa4NMF47zK9BXopeMmsmvZaya9lpVkVl36qlWRWXbV6ismvQx6SsmvZayawRk16isms2vUVk1m16ismsu2rOvKr01e3VnX7BWdf/0j/9oACAEDEwM/Av7Phx7TClAIIIFcLlT7JChRZU4YUr/4qfY4y4aPbJHt0K/Yaz79dpn16/TPr26vYJ9+v+ioKDTmQwUz7CUUUeEUUUUcOvrLztcXlefWRnxPqTgppzI9XaGCvbdcF5eudA9Lpna5c+h09ZWRpkW2mDXLrNrIv268isM+ovJvHCnAM+Mq8m/Zb9uvJv26/Zbyb9lvJv2W8m/Zbyb9lv26/wCxV5M5YQzhlwp/t5//xAAtEAACAQMDAwMEAwEBAQEAAAAAAREhMUFRYXEQgZGhsfAgwdHhMEDxUGCAkP/aAAgBAQADPyH/AOmYPGcyy9m9Plnqo+wtdp+58x7C/I9D2k/Y+2j3GpM9avJCbpok/wDkEwkZbgkVDlOnuOIWtKvRUdZvVIX8eix36mM7BfwI/VRcb2MZeBmOlSGRuGWBM2m9NO5G6fLR8WCSU5Tyv/GJbFr1nuzIKlHkJiR8asiLF5LFWPEBLLuJfpmNs8mLTGGwK7hZom8ouzK1vpFHIsi0HZr/AOJXRaW1EiZlg/lQMUzk1NFFHl8ssu5lGiLcmrEyPRCW5hovRar5MuKxZ9jMB2uU33Co0CghQb0SwkTKbjkKRVmw35CSVVP/AMMuK8t/gjLTunfcIHkQUasuq6BTYVOZqGexQN+V6K600DSltg8HIqUcVQ1TkKjHeBrKHcj3hiic3Q23L7qGtyITXd8wJMSEpqz/APCLwtLbE0OqPkV9hBwQ/AQkjuZV13nQOdfbRmv2Fbj4EWPAZBsJZ2YKLQZC4hjxdFL63Bs0ATjtfmNVWaz0FUiWHQWgW7LryJ1lwm7kSpHKdn/4JI2QklvRIrFwlXxLQS0Jrq9iEsO7HJkIFXzdB30PyLRoZZFELcMp+tvOxVT6VfwX55+wz33Gr5HtR0erH5E7T/DYZG81eVhOnaCSdqJt3wZNcn+3RBSTQmCMYEHGS3ncmqN/lL9v/BRdMUMMdxQnQaLUhCu7jduhBe15CY7aLBr4FMeSh8Niw3sPZC4UuiUfwJgujUkvHK98EV6YWr9zyHqKskmL9KJshASwolxJMcNTdJQqhRjYx/4BWKEahYYlTlJwJFIhQg0/Vla1pok1yaBWlZ4IQ319V2bCa9kko/kZuyTUlQrq8X3H230bT9HXQGBqLQmCWcq8MXdcm4OyUGu//fu6NeVizir7iRt2GxBBptS5aClTLISl7/U9/wCeTMrqzruEaOHoKhsvUdrbCaiUdCn6u4mZyvz/AN5MI5qaJ7Ey5y6uUMsgR2qHeO6MjfQlhQkq7/cvb+kpwndGzafuTVsbohqz4GV7R3WDnQpJ1Swxej3WVV4oNCUjy/7sbZstSUbWO4yGgOH13FNr2Ny6ny6sBIRCSEtF/SScCGtUy53HCQYfD1En9wQk0WCURSw8CUVefkx/3E7/ABCErhubpQhyIkt7hfwCN2LiydYu/wCpCchogxTiA8NFiyQypdSOxExN7ME1Cb8LdPUn/t55W8jIZVYHCLLQnBQbfJlTLh5P+tGiPGT8ktZImoqnJViKjdSUOYJS5qOf+3ErlKUafoNtk+WRPREzLjzSk5Yk4Hua/wDWoc+8iHaJQbkkYRRKsRKIRVgfDJu7kuH/ANqE3oNm9Hs8ex2lByiNVUqlK/wf2IqiacYgtJm/aCU4InJdiJ15G6/7W5j0JKrq/ch9ylqz4BJPKs58M/2FSvL7lUQ6+iTp6kqbijV139fx/wBrXppdyRNJKTgISBRA3NX9imUt0vY3FSc41Lcq90yfoetPv/2oGpCuhBQU8H+4jQltEl6f2PmODmC8UIda9KqO6/QS9U9v+zUHhdEtsiE6L+xD1ZehCeF6iF4ZUWO7f1JHwj/s1B4HRV/clnhZXo8XvPmY/wC13hdFZOWacIQNy7p6P+xEz1JKhirMHgfU8fvJ+ZT/ALMhrRC+dCqpBPgzVEKEd44SES7Knknbm9E07dgkMlJKez/r33Tl8qCVdaehOENB0cMYyZWWWLLO3SEFNX1CtCd1yav+H/YiqNxcwYSYe5zR6e4EpO0cti57MJGTOY2sGiEXNT1kkkulrCt6f1qxDb3KIvZI5vVUb66k/YfzbpboWtcwwUp2Kbdhyt1VZwHgAdr+gl1k+S/67t0F5CL21UJLgbTqQrhh1Ok4oWs1ZnIqqTLb0Fb0pV7DwC704/rbALxX7GuRjVqpwhE2yu8scafohjTWquZQ2ZuAOZlr1NGDwnT/AK/n9w03VLwNGXINExEO1E6MS4kKGU0CbplbpbBXZ8t/W8n3EK1FvqiapVllRSsCKaGVkXF2kc8Rx1ZeZm+T4tf+v4XuKXWhPAwYvDerJIa6ZKud0mH9xrq+iSxtTitKrQS20TbdkmIlCapz/V8z3FPcWJWgNFUdzYinwX8obu4+wjCUcewVqIOD4tf+suSctvCRUpvchZ2RbVF+qESVvarfQTDosTEPYtgmVjpWU6RhmcqZMi/qKr9QtREcinupRIo5i546LXnUnp0h76DQ1XhFbTdrcZEJiQlNWf8A1W5FYCClJZwmjWQ9zFozd0MuVvMRU4FqacpwN1onLw/6cVj6IirFNJ91sTqVmOUJWHRTZi0YtxLUSVQtUlDLymVahM7pZ/6r5uRTfEECsjQf8h+6bA34xQSKbscRCY+RR/T0f2yQspsaXMPHZipKzuftn7PTswMqTzc26SOqUO1f+d6iM/QH6wf8Q/VH6Y/TCZZaNzkfLoTmWSNCkT8T8i/l6A2VGJ8pR2KsqNM3PMHyFhZbhWH6M/Rn6M/Rn6M/Rn6M/Rn6M/Rn6M/RlZFsh+4j9xH7iP2EfuIaJp1ex55X5KlXqF1xv0n7B8j7jLspKV2OzJYJY4PVPh4f/KVO1TUps9bfUmSp+Gx9pJewyXO4NjyNbyaY7jWpCxP8koiXL8j5NWt5dE6ts+XQ1kH+ho9TQ8mh5NIgkS1KOQjJeXkQkSBvyGn5Ro+UaPk0fJoeTQ8mj5RoeUaHlFBFpB7M/Z/k/Z/k/Z/k/Z/kT8v8kPak9x5Y0VX8hTBonQufA3I1Q1/YMhNn8MlHgNZIbCaTx0T4RibQ74Z817nzHv0h+TM+4VFw/jcCO9fcF5Nl9pSQfK8MqoTZz/eTcxqMNeyxV+4yovP+SolbClBtbsW3sNZnYePCfrMefGxhmzsI5qjtUNjdA+fQqkSaZpmmaY5cGrCiOalHITTQvdx8BqVRXsbj4Q2iF/IXUU60IUIZwPhDbshzTU1dSJZCZsikCXlgaknN2RCqsMRXrWwHVa8IXHyLTQlZLuNBa1IhrrsRzhKain3DpiJVEoagGclCLmpGSN9MmHb7xo/QkmCARZKQjWjECm8mD7hs7SnPgKUPw8mhUvMzo7f2mmpCW3gwd0/wEuZcpb6DyOWXk5Hqpl5UZvsF+T2Mfj2Pn/Bl8exl8OxN/l2HNOJdiySn4oTk0jBDQNA0xMKBCbMK1Zf3xtIspazqReq8HIxOZRVN0JCtubMpVKFIqCjk6pKlpZtNwPzLS6O4pUZJFDoh7lqFRGaaVR0ZJRzDEmfFIObbNRMMe4NzZikdhBNQJbmt2mUeR5fsROpq9xDpmkaRoDslF4ZDA1q03kpOOSwBsA+AayDGB73mRNDQPX0FN05JU4Nak5ias2GbIEl1wE1bRqv9dEl5bYy2JKPfs2FYdBPEaqy5YrgeqTKbxKlxyPkO9W2MUqmRFQwkuELciS4k3t9NXT5FQJDmBTz21stBroLsfoH6B+gfoDjri4QyIbj6sqbynybEahKLsS0mJWNtYGhBuEfn6cBVEvWKqhcYrk4kVVJvRjoSmaPQgxCHXIF0PbkNpRbfP0myqE6MoqC7gGksY4kpliXcGSoJ1qKl9pmhHya17s93Bd10qKCzNFb0Cp5SqpwMmzymLW6EOstW3bcQmeRtH/VXBOW2Vmz+cMti7lF00RQdoj3CsrfeakUVPolaieP0RenT2A9yN203Q+ZTduO7iajUPU1Drhhd2sEQQ7DaWbGIy/ckaUmlWBvLS/ps0aMRdUYwVS6LBuGS0v6Ibcrlm6PUPkZNR3v8DUajUah19BDfpZXECzMHxbUNtJw2KI7jG7a7+n1QqEcaisoK5rtRmxLHrCZCGZQrDR9l+ZG9KSqy2U/6cVdEhuZnNYvsjKNB16tfaFgOCbRJUpyxNL5ZUS3GUGzsLqh0J316OYS5eekCmnK+wlIjJadbCRKCkE8NPVw2T5aRUEXHUU26b2Qrix6oerNldJIjjTt9CqYXUPG3fD6otLEk39INA1di42hWUJsc2AkqQzVkydtGnwJbY2JV2RZ5zhPHcSSqp2ZGfL4GkIdyKekpH0IKygtWJluCmkdb11SCa8dVFBZGGKGtJZfD1XZNUK0jTfYlOZFs9VwLclKa/pYA1r5yyU7KxZ2avCS7EUNq7hAXdkrf5iyUUQ6lW7smlxGo8ifYNmso1oztjGVzoWn5kYwDbWZFmU2tGNrXXdIIy7E5OHTYRtFNiAxVXF2QdWSqFWbjWBK6x+BD0ijgmo08kVO4vpURJ4QtNbgSSytqtBs0wXX0/wCwkpErSG7e2eZtwJYbxb9hN1Q15IhCAVaewrbhCJNpeMhJElK8XGFEpLdi7W1Ww6yTnsN8F4cEuqNA2ti3HSSBIVLbQTKq7Q2DOtU3MiSLo8Dc/bresrlCjAS6juXxKdBjnMayF+cCMh7raff+jt7LV4QzplPbRdkQ3mbDpq8rQoOx5Rcm8koKXgzsoGplcpc2JLqEyNKyacT0ry3kuJmJ8mISIXIkqNSIOM3To0UbY4GPIl2GivN2bQlWAqMKUUXgSpDZocCepKgEY01brvU4y/A4m4cC7aE6lOq2B5fAqMsrwgRMG8C1wEbQJh2P7wudYV+iVf3K5Z5Cns1Yi1BJSZVrGYGnBSTZDkJ7qDvDswq0Hp9mULooLcTMD3oZMlqQpnIb2YrepsLetRadg1Cp1g6VZtwbF4q9hSHQPV0YIHdCezGFBpJSS5GGwUwTuaP2U+btk9rkVCstxVMRro+qucCqTlbfyRuyb8V2Ki59vKhF6biHSgkE4sCm6FkJiMyRUNrkUnS/Y24g6PBF9JPDPMMTMYsVsJ+FNzUUe8ijquwUVwqEFzPsVKTXFR7luax2Gt521akr3CpaEsmnUgaKLsdkekiKmhIdXIK9z1ZC60G16/g7j/YJopqUsZTOpW04suSlOnSXWUKqh1NiAVk1HFGAS4U7kytTm6d49QnRPDymU9grwiqtk0iTM3SSlryKVpKesPc2oQTMKY+cAkpj1rWtA6Vqxw/A1NpxYiMmSy2UkEo9ZNxOMnerL3HKaVWC1lMb2EgUhR7lRn3HJQ3y2fkmupVaNzu9EVPppXChaKjF7qoVp/Gnrhu5Nb1GGS5vckjNEWaeVN+hrcLNOj1L2wzKiDonoHKhotC7plkGhWlI7E2ScHZGtsUxJwvuKl5+4ZdLdtulfJiZaSz07zuwrSXHSkulmpP+BKEx4SWdvfpZc+rZMgsyJ2uLQLaT3GzfNx9Us1Cs6QVbAVCizumO7FBNSV7YkqHqFEiBqrycmvS4zsK04dIjMGzn68EvjA3nAmmo3h0ZsrrwLcyN5TwoNOuRLui2rJu88EqXTYVENbiWSKsjV8BtNO5Vkjr0wZaUiJafdgUsMZTRLuV04ilktkJShQOWNq538ZNKeZgQg7qr+FcxdQ3KvZUHCEO5NdKrNdC+Pp+QOjbPJoVwUm1Rk5JKJouxnEvb1pG5tP3CF6z+nlDM83CE0MabRp0tu4NI/E9H1aPWNzXFqKKN3fqtTDKtGhPR1Jw+mqM5FSDq17m+E9CPs9vpcHGyCr9wlCiE1eMoTZ6H0ZLyncX3cjWwMlDLueoqFWSMT0nQaDGl3CY7mOLHJFbNQyo6mn+lOUkIqm19ufQsUE7fxJhZG32GDNG1BEcEaW2H6ifbjU8iVpJhCXILEvpt5V0JfYIo8HoKkyvyRA0nQJD52UJFpHV1ZL3bb89HXWIKMo/04pO9Pp3RyYwTbG16kHsstRCSiJGWauPRNalisrT6b6fYQtKnYx0e0UhEPkKE/oqb57x3WvwfOUfTFylPgr3avQoMrmXYICo0jI3k7NDAURaq1+h8M6vQaHLsIEKDKWKNyNhZTRAuY/cgVKU/cczA0JRyIYHe9xBXPiy/45uD2g3JCpySbUtxDuKLNgnkXfQgW+im/KHOaU2T/Y8q5XUeUIkUk1KgkVXngQLUsM4RVfYwN9Wl6kI5NuX6Z7knk2bMVHRbRaSZqZ9hFUuS/uwJdC467N9hqqndVD3AqS1QVGJSZ1pOF1hnaI90Qlsl9O9MT90UkmjGlhtcDbpzlBEyTBcOXSeko8htLVyNwoVyNKqwRBqo2SPkU3ZooXll6HKexYKkX20ykUULJfxwtuQWQ6Elsf7qIvZtcEC2JSrok2u+rVefoi6Ke+RzXqtz0npRLRhptNabWqGtUEcCJKyLYaK7kN4LkV43QKxG0n4PjkshJaJfTYh2RTYpERDw6pluj6evRWFp3iEkZKVnkRMNGt5KUNt2qzoX0boko6PTrtetkqt0SMep8CiFxQ6d4f1xQNWJTaRs/uFJEl0OR46QQ5wKGYeaCE3PrEvJd4RCXfYZa1FeU08jsmNyobB7g3VhIyRNLlP+SKqlEIIuOZWcmkqX0theXhC0atV9DlV1Hkz2HJt7p26SorlYBczECYykHXkocZZDHQxwrfkja16fXp8URiRkHazwNhJwWqgnrJJdpFNmpbNDJMqTWrFc0IcZbNUN6PpbcDZZKo5xsowZpe8jsig5JJdEJmp+n19+I5hJ3LLfR3Lwhq11ZXKVcNCrndvbrKJVdLmURWuvQnBOCqotCnKIWqfJI93SPSF+Ghk/xbxPCK6ps28sgqEdvG3Q+hJw9BCW5tnuO4qC6szoJTlTsy4MPvDeWlojpcVuIama2Q+Kd0QWvbNCmOCI4idoGTk/r+U1IDEeqEE5/Rci6r5ISQTwvokOQrUVe4eqG3ZGlW4L6EE5mUJbAVbXsMl94/YuQWGiHbDn001Kjtj+tg0i9T5vAktSFsHlvXSKCeWXDEWDM7y6ia5pLCqKIXLq4kIpUnzaXqL9ITSDVpGCYhnFI+MQS6A1lKpeZk3gen8U7XX0E3S2xCaKJG4yN09wWjVn6Oz1HR16C9eeZHl68DaXVv6PLPjyREpT4hGr/gQiiUabo5x+xyXufXE8rN4r0GrqvJ3bz9LhUjLGacJpfBumEY7DUNppWb/QyoaYYlylTxdlZqGmldx7C0X3G2HJyb9jkn7v6+NejPCeUNDfQMmu9RgW14CaYnxJEm5G5OhDi7ZY4pV9IbrQUxQThRgSxKkK5LoUaz7kQWiSHaorHLn4fxfByHAcEFrkbw4lSTdZ7IatBbtdG/5bdZEHZHswNj5tx1v7hKlqInkDe+r1JS3oyQuc8HYlpVBZ7DbBHGghKK4Uia4mmTLAnnrbBhqhdiPOurkZanFLLZd9V3nTuNqsnYdV6E0zlFRKNQohejqgoosFulJ4z0Q+Hx1bqhYZXOEciD8UtEQ4lrsMCS4nlitc/SuWSSIFdNLIZ+wEVck3oiZrrrCXWaoTKHOnSekvgQLI3urCPeTF1DEakC3SPUUkwQh2H4Jtohcb4fd/FwF9kperI5Hl+wmFL8kh2VSbUKkOLKIVTQJ6NTDvfp3ES6fUSVgY4Sq4IcKrREmxNwp4C7JhRFC02KWr3ayCOEWc/cdOxroVw2yu3SbI8JZZKmp0WpBGjpu2Ts5+UFAiB4BpWBJ/gIh9hkdHy7/RPUBS9oiiqQSulrJZy1aLi5SWsdUF6i6TIYTTd490IpasK87iSmtEEmBk1OhbVkFaZXJcd5nck1PRcD2AbYSD6KNDYd1YLb0jcywyhtAwO5NFyoPKPkuvt0jkdKi6PM3p/FKdD1YheYl+bFJTkCxK5JetjQVnsSk7tfoiquUgJUiTAkJhMyiShNamjxCf5YjYY6JJSKVVUFSOdcHBSHBTVcom5Xg6MdCdNDKgtQPJIKXT2SIp7Q+wzKWTm54XR/at2IK2Ro2VFoIrMsLV4f0rluVZKCQqQSITonCFUzS5O+gE0wPYmIsMMq5Job+4gCbLB/gbNuZUMe4dKkxk2xWSUwVVtBEKpSH2G8NszctCsKSoNCMmSTHTmhCAR9CIE1GZrCmRejETmNp2+jyCpoiUYuRpXwp/FwgKFXHQVfNiFJFCWYk7CU69yx9FJSdhSWGFTcMyqS4iS2mFOBPbJiZ8vpHAbU2ylvJVnyZSFA299mViYs/sIiliS752EViB5RUE9EzaNE8Bmu/V/wCQBsLtHjpIyKkwIt8COkGz8E9PAJJ1UpISkehJNTX5Jkw4qJyi41jx4IAaFflsO56UqzPlZ6pm9JqStWVOkF2a1ErF9xkp9yRNMVOWp0dCSy5ATKZRSDyD1lETxlPWXr/FO3LwN0jFSNUyhHyWKerA6W9PLnoWUtKWDnKKw7F+4g7iv9CeLqqLqVBnkSxtphSTlnUhQvPTxE901UYCdhjael9a4EoOR5jgTCTlmxuiLBhETsO4TuyXCapoxhcdCLCb9YGCQaNMuyLDWSeqUs6V1y36D1KSzJWvW7HqLTUmRnoh4j5NBpNNVF4sZImDeFzuL7gdEuxcsu+SQSTYycveIXNukdIIxhVpnoh0GapujLRLfQbmth7dHCcIQ0XmIgq5Y3KiBBm2mWuuhG0PWxBeULoZeCg0X5P+LlkRN6WJNM0HyaCqsp3J+hyn7iZUkiSlm+CBNpIui9SFh1+iMN2SKx1GIuN7kZSrYSeIdC4ba239JFubnlEJpmrxgqjF3t9DZD7WHJN4JVLkUnSxGCiSs8kyNx5LglDTbR0+ilWogUkoKWbjMFmcJohExoztJolaSGqJUFHTwJWSQ05XnA5molskNTHuCphakk0WSeuzA3UMpV6DoklXIrG1owRY9iBZx9UpbIMxYKfkKTfAlW5WhJFe8vVW0JN0RHwcv4ZGntEeqfljKU0R4B8mhEVyrWJmCk1eOlCxZcoPKClWRrcdBq4Oux6etequEj2qWkrvuRJNJvI75sFQqNVTsIVk8RscijCTc1I2Gk0imKUSrspaMsGrkSGdaUn1jcvIzr1nM5EiZKuVSdYdYSsRpHh4CKSLmdaMbVTAmWTHi8izSpIKWC6AlhXDl2Q+hpiunNENnwsiKM12KXUnBhbnTBTHkzIzhaZGIoLsJCX46w1dyegnt5GK5K7JLtxXvPYejHw8v4Y+RTpqU4zJK9TxPY046ayjwJ9CitRC8bjHSNSmsCG0jVm+On0Ki9zAQmuqklLlXgRczYVdxqLQps1a8/VEPqWHmFAlELbkwcv6ZDS1/wARK7KJbCS0qG4l3oV9LLJseUQch4KCgXSidRRoTpSWCvgWjBeBr1DxwINA0hummtrUh/uW55fuJbESN5t0jop6MGo6UpVLWm5QiSyLQhUlxU6HhRZJ3gNlqGQEoSKOR9FUnhK94mcqVAldFETsN/V/D8/HTbotlCVloK/ixTz18A6ZWvUXKpKsTqt2BDTbjx/eQT0L3G5rrrVWs7Ma0nk7nqRY8TK9EsJxzN0r9LfI9x0wnZ6MfBa41NJITwhtLct3ILW/sT1WwK9w0hq6jZJdoKqqrtn0hynDVmJp3xUbc7oWxWWMPkzxFu8h8I3B9DV3WXLFlDNouMkj1Bf4F0vWrEppY+jVU4ayKgSbl2tB80PAgWCYgWjQiGnDQhLmYZSxfcN5VSwpKtslbY9QTRLgqJTwcJn8Pw8dOGyvAfJoRZNSUJJ2E59on0kSyO5N68kFwY68k1HDU1GqNS36SXFFDqlREhqOgbSW3rc/Smlkag8wujYY2w0OETYUka/CHG5rYxZrD6Q01dWGzbct3fRtCNth20g1klOCsgifpTIQySldMLnmZLj6GyqNReBk500lnzM9EqfsEtpSssjQVUTHTlFrYbNXj6GzJi1inHawkRUJIqJ0zYSzIa7PresUPETte9/D8PA0Fw4BXgPk0ItkmHBDIwC2EdCEU7kL8P6EnB0F0dlhrclYyQIppZE9y+hrcSjBBZEzhlVkS1RZLB9LSjMLrk83VrhEd9SKojYG5yVLYrS2wpksc5f0rUv6htY0wTHtnNcEjtlC+mv0RwRwyfl5UFM7T4EXoNuT6E4UEza1IljR7j5mel6QwqSViKFbF6jT6nUgnUqXig2qtv6v1/t08BL7N7/w/DwNpUaG8tLK8R8mh6y/IqcmyNEsC4b/AELomLeYTIxT6GqOnRXX1GyQijHXq9gombnvefpRLGQngjmHd27NDt1tsbqKN+iTOVZYGncd3VCldlNRabVuycs5eH3FFtgjrLClxPXxM3xtDYJgsfQnzhMUiCLUIbhT0HJcOiE78CR1ED1jKCer7m36zZSNYZPR9f7dPAS7SHr/AA/Dx0Xbgu5gPg0PV0yrof8AuOjbSJYStPoQ2C5MamHdIqKpnToxvJQ/oqPVOBbDPZ9KxFBKxcDrygQhWGn0vgkNCmMh+w2q2wYSwS93E11xjpE9lrBpSj4Lr6C0FVk4tlldcum/cbqzZ6ueiUalvVLeNmplFU3yyN9xqungPP7Cct13+ifkUPIgoevuEoGOzg9QWn0tSWpihEJpfB5k1XqrkT1ghaTshUaSVEVYoyOchzsp+xKeHpVdP4T4eCFqIo5HE0lRY+DQntHYn6FHYN4QpVUMhEshEK3QjaXT6GyRLWRzM/2GfYIUZ9RCrbGWw3yEoYuxen9KTcwckRMX5CPmUCzhFE5W5UyA2hqHo+soTqjSka3LS4Q4lQk+qW7fQlcfRGT0SIGJ8pTk69xUiEaGW2hWRPEStGxLBE4zv9DV3a12EqUHYmWie4xyxsDjFVUJNaN9NFLZ6KKxzE5e43Tm6kIZD3PIaacDoc+j6QsKrGZF4QtUJqVYqlRQ8p4H9hMlSmw3nBlfb+H8PHRarROx60fBoPGN1KkjfINhI6UGtQnGg24MdZwJnlXQaztGhXwuru4ayLPUwXAkUFtAwero1EVE3ChAwlUyINBykrQ1Qs2Oaj+iZJtrND4GlOR2GJqSglRBLeRcpMDaWk8/R8BJT3pdxPoFuw2b3eX9ChC6MSF4CfcRuq9Bw0eQlQ9cmRcKpyKEtFhC1aC2QGo0+jc/sJZmK3khU/cMcRLdSHwSoSb1fRKFJqQpNBt3QzqPXE6Gk2mxVGZ4HRSZW4Dqh07NA6l5c9EamJySV5njf2NDcoq1xv2fT+H4eOi6kpkQ02e58Gg3BjSVWtvAZLS+ta/UhtZosZqpJZ1KUyScWWD0vrAk2jsoIknW4h4ps5JCDsD1XO+wJqpL1fBHAVCo1OhSdbo+ij4ITI9iEjkP3GpbNLfnJJooLh9UmBHcaKQOU3Iy47LVwhuiEJafQzZ6jdWrUC31ocyxgTHIXbcnds8B82hMUHvX6Grukibg2vJ8zIzgV9SJEt32I+hZjZgS6jvbG1RWbnBHWHSgkW+4o1ZClaCt0I3GeJivhqiHJU2yNZ7V/D8zBBqMOi6HpmPg0Gp1Kjz9Hky1HJJRhsOjQEZUgdW0QkweQgmYrF+qD4ckTejWBUFUh52XoeE4OD1UvoidkN4+G4eYZaVdZgUtCBQRAh5bMJ3vketJ5huw257jkcipKDDqBs9hobsVNh8/RjVEehjd3mnp4BJzqk3PA6iJ1uf0PUUI4JGGTUKYus5F0NAd2QZNAi7voxot1e43bXaX0kkuwhBJMdoPI+5KaUhSVTPKeqS2SKOSN5v4Z+RTpVKGNVSyVPg0PV03wiaQ1O/XSnAlivfVMyrR2NHTp1ak/ZMnUurtoI6J97Y3mh1qTyvovwWQoV23PN1ZEj0Hk6DTglUtESatmCthYwfvn75++N6ozYcuiFFKCvJLC8+BMua2O0dHDWHfp3ZS4yuJqdE3IjZHOmNvoaOre/BXymjVh8TPRtMZMXq2kRSlGLRaA6oL6GRMOUkiJL1F0fAw6MtsNduleZHdKFP4n/OwQLRsqegVfFj1HuQy1URR6CySUi5c1qvpyAW8YiGVTYeXTFfv9JHGUwhbLpU7i42KZpgiqx5E8lC19EprVFIEranm64Da6I2G8DqJyFUTKkFkkWX0tFTsh2IuPpqVLFsOWmxfQ4CchZJm1CYM/aQxqu/0I5ZV+waPIkrpPiZ6ado7DIVXEibal7j221HyyfXRI6Yq8jkmSLjWonFuyXLu/orzPW66mr9f4Z53sQtEeGVPQKvmx6iFg0JnJauQGbTdy1OwsGxfQ1VOGKhxzIGm36C3oGYnQvoaqroopBCXRCn1U66CSIsnC1foo+GM2txio2tKXJcDpdz6qUrQ7nr1a7Kuy1JTg9V10h0Zy/VI/SZrTnp4mZSTZBJPULP0bjoc6bbZRoMEpUjz1hp6ORUKUGhOBYnKijI4jTpNh7SFkkmqUJkpdXhDalqGPY6+v6LG42/4aPhkf4yWKcRV82I7+kGE6F7VuerLm+DLbNlWI7E9FQUVGTTlwJh74Gt5rs11cSPOxSJuRUZ0NG7QVQnaf0ROwuTRMjR5i3I7teglImzH2Q9OjiJpp1gkKUNQM87NXWnWBtMKF0X770Q+yklWHfBIuPNSSji6IFwPON6NeSlpdGPobhmaEXHzNLcGdUwHmoo+j7JPWSJXao2iSRIT6CShYVxSVfhDZt1MoJNbvBXqeomCfH3LH0h8hKW2TiSUVPK/iQt3uWraiLSO5V82Eu7q3lpYkVdr1hidQoNm0297DVhotliYfvgzU6agqzaVEbiiQsNlWmyMbre5FU7SiDwDcV1QINl9NNBzQUjUXuwjrWuRo1BW16bk4g2WZWsIlyiiIFaSIagbO91UYyGahsDUj85mPLJWMpZuMwRg2sfgQG6WGfJoMmauPoNVVvdRt3KGrD4mRuVyzvoGqI23HgLeGNQqoeQunoNjwV5HXtI+ESlZeBG2OlfDcAgSrC+vR2uKkarkRuyoxoVyI4f8Ube8j4uAUtkkv82GUUpOpYPd0egsSMVNQaCJkWo3c4yKVVCKw+mwrxVCFVroOugSZg4EtCY622SHxA62hAxUWXSlzOv0XHiKGNk5mp5DtoKErrGs+nosmZkIe4b/ACIYps2H+0RkiLI7WAfD2GtAlokxCU3EhtiuD4KocG7FAmhG5kvJtEhmkkqU+jcvsPvgSOqp94q1Um6FI2iyQg5roMgldjLldM+IIxChh7xNXAwOuK6yXiKlukfRJNSlTetWGsJTWSskdzCbY4TeMkXT+K5R9CZMiuQVmgl/mw1GtUVW95COLNRiVcT4oaM3wjyIMbhGdkVdpZORNJ0bH0CeRNs2lgSap3Jbf2F18RBmNRnmombdaPgTOWZweQQ4TzgneuPosiJyy8N6OwhbyWCbairuNza0EaC4iNckWbQlcNMWY1FFxNpquyOU36FXBAtIhue21jb6K/VqXZDfTJTYfGyKVVGrHTQpoakZsyciWmucpCDOhNDoteR21J6LKpESyIKpybdJrQJ5so3gg1XzJCRF4OY2L2P4toH4cEOkxVEUImArVzbNLCQdwSC5kS/gPegidMrOYkShuKIZAkPQNSb1DXYNaIuUzOC6GJGoTVlilETShEtilF6BtuCYNz1Po+hEmRNr3E5qp2FcAo2i1Mbx0hjyzclZWqxSweo2mkbvPgUaiYhXThioCnMp0HEMBtLcsSTWx8WhJJqu/wBDUV3B4K4Ra7jX/IRSyLW/RvJccDuYpVqlZashu+5DJHLNyVZSEyL3r0q43X0JLatGTYaQTNCWjiRYsVc5kqvsifi1PG9v4uf9yKUtssBs8UITJWvsSuToP2DHcJINh8mfoJpxYxuA+VtlYVDPlUbENYPIQpqIaEJwbHEQYtcn7RNW1yiwJ5hQkrcnRFyvnrcwS7XoeX6JvcKWC6mdx46T1G0rgpbUamCBKzoySRcNsLUhBN0NokKljFh9FFmYY6NQLGajSzRiUhVJnLA25kPptWKZFZhzNIaDaSrJSSK0NiQtIL4Zp8lmglqmW5EoyRNVCOBfxbEfYJy5ug+LgqsxUcC1jDIG6puh5CZfR0LLQmhXDF+1GBrNwXoMWGRdDCFShqxNS2hV7VkTE+glNaoz8m0E85v0bQW2pQ8xTqLAm7QhmWwsSx6dDMXL3GSlPAg2maI9+GwYSErKTCkOwTpIijNSVcCTG03ctfoaDASxJqhFeY4KxqQkjQMiSuPRjeKH0i1TeGTcqL1PUoYViuK9cScGzHhBnDFjFhkopob96L/jadS1F6jgyg7sfJofEyKv+BY25qbFlDJpuBJ0bgWrF0XDGVkMosxiWZHTngFuhINhvgVpzbDNIaGmSDSVbmBIyl0EuevQUcoJCWhOC+iv0GolmiH2XHVaDSXJoSGyusJZl8NEEyPJiwLkd0oHmpI2VJRrI1q1Oo6NZrHo5VNDM3DU7i7oTITUfAb2DuxLbNxYYTSwJWDbCvXcst8k1L3BJ2/JdRIkgSrJDd/KyNS/YEdhtPSfxzeZeUO8n+oTgoT8thuOyl3OGQqZuVQjITzPQRkQpNg9RGEEu6KSMIrJtDNMWpokQwgNhibbIbZDUwxiy61+jbDIBGujJuAdfRLEHRxJQgVFnQW7NxAc3qPooEGhCGE7DXIpChPBjJuUZb09gqFd9/od1UB5cIhQuzGJmkMackSJkSwkLbsj/AcJgNWqtCb0ZDlYE6b3CLmb7DIooouD1J1hi06NCiCQqii0NDWvLr/JCq2b0/UQHR3ofNoJSoc4eg1vIStGSl+CMC0HwNm1d9BO0Fto1AiajXItgl5CasSkJKnIokpmq6WtAU0qqqQWa5Q7kqOn0LbK8Cp1tVJwawmN8lciU2T+hoqtoZKqT+xFCUIkWNhwTeeWJXFNJNjGgxUKiHkuL0WvXpRkzSWOIqhT6GzJPYczNu4zdmHEnwXKAbSWJQl56JqVpIsHkSjDsJ3Is5XSYhxrYao1PRIadiJQ3cVcziw0tJkkVScwpZEof2Hb0/kWHqTYQiQ0mjRPCJFRIjp02Y1V+xN6hWuLKJFS1ZDU0jl2Yjo4LGr16TJGKQkhQsfkYo2JEqTLQ3ZeRyk9U8r+iHqxEomk7oxGpENMIo16BPDqRqGsaxFlMRYy/A6SVdyMOUjKRiLQTRPIsKfgPkbKMY1IWUh3qd0QdZoeNk+YP6LVZp56T1B0ipMkI2rImrH7R34HUu4NtuZ1IDOeBa01RuNGJ++LrJp6ENpaasqtyOUJnVQVHFpui/kVAJEl2/ldUN2M/c1MoO4nlKrsSBLoW7UUByL3YVhd7Ygou8qU3RoZG9LFgUsmA62oiTlhJmXVi03R0NV0G1oRq4IAlNMi1Jy6Nn7h+4fuFLJKIZZE53VJyS8zqTNKtsYDWwqKOuWbi2FsLYakqGJqTT4K6DtT79C6C2FqjUYNNZRUsLF6kcHLQqYe+KQiaJtUTsR5LJwfun7p+8IE00SdZESE5UbqaXLJItNCakGAzCELVMoRvcnedyjJ69CUSu4uqPwnQTTRC1RCdBBN18gy6EypJRRC6bOwVTaRJZN9EK6jrvThfzSNOnu7nKG2XP7HxPsfE+x8D7Gj8cGj8cHw/j+Jsltt6h1fE1PA1PD6gLmb94+w/wCi/q/J/iG+gBPw/nqT8P5/gNttKfWlht/J+T5vyfN+T5vyfJ+T/D+T9xH7qP3z9Z0TUGqdXpfw/g+H8Gj8cGj8cHwPsPi+NhvyvwNdJ5/YoaUs1HlkeavcP/8AIz//2gAIAQITAz8h/rEF4bwi9ojRFC/CBEIH2SFoGilAIooorlToimx9jkwNFuVxjhBCSmvYYEKTlwUlD2EgZcLdbevhJObPRR69YGfBU+2tlXrrKs61r66yrOv10ITpKjOEygJgetpECfKJBzoE8okSq9ZSg+ETwFOqnLgBbESprQKnrJEW+2ZRio9UDUggpWqHK5LkuS5LkFyC5BcgtO8GnfsCjgCHCC8IcLwv1g07bwV4K79QRPDyVDFFyi8gQoDoFwij6InAOcFwjqFI+Gt5wcKFIUjooAJ3QIAcqAVtCPooVqQUVt4akPAoLpAyAqyA0UMIM7lDtAK/hW15AzIV/DWzTtW7dSjDCnBTt9OnlHFSszd+ERoNVDLCtrWqlofdS9FUD12Uq1GKw0Y7x6dq/EN+HtX2HpVjWOs1eO8hRUg1Ya8aGr5wNelQyVjHar5ww1vhbKFr5XDAava4Y4ZWpEIlkDIsqGSDQg1qQR4UPK8KGlowbsFeGWhgVaAayoZaVOjyob+VaLkHGSVw2vahSVq84Jayoqw1hbKMWnat21NJwS8UoaAe2tUXhi0LdXVFWGm/SjAAucGnat26VDTkUe2sKj2oaXtS1lQxVmKHas9tWAZCj21qj214LwKGKm/TklcYtO1Z7asFZFHtrVHvDDS6hirC2Zvhr5V4146PbWqPanFDqCrDTowRhr5VnAhpyKPbWte1CuVOCXUMkUcZVDtWcCWhRhDUeJa1R7a1GNQxU6WM0iFLQUW07Vu8CDjkrhqPbqPeUoZFZd4E44ej21qj2pyKWmRWGGlQ3856j26j3k0tMimLnAVXypYjAjIr5Ry1LTI1y7asymvKpUMgjGUXMoox84TjMIozgOKVH9vP/9oACAEDEwM/If6wJRPhh5XlEefZ5XKjwgQQ4P0iQLR7JKjtDuj4BgXUalFIE3HsUr5FaRqvIRwigqUfIKCix7DuoSos6lTkTRU42KkKXr5UfCuOFOV3BSOlIn18meFAUknLko7KQoPrq7UFm6eFIUeuUlDN1Ugr9dXRaZ7T11DpaZ7T1slULhU3UGM0xwiYuVHrLPSlrzJlStlb1loHlRsVemaOkFZ9YAeFwQ4VfGYJocLh6gKKKKIUlFFEKSuC4Li1wXBcFxXBQCpRRwD6OG7XeAXtEIoo8oooryjypwNV8OeQvDR6WYU8LyoYJwB4JCmV5C6UgYYoy4UqMHB7UKdZUAOWrKlHKJNbLUHZX284diozZVKAKBSey1npHyRREE/+KCVWRLSa2CKPS0VZEsSJ4yJOCVTRDqDVjS8KSpLtfBypKr5zf1D6UlQq7L0cCcdrXt/xlaFT6xaqh5x0X/T0q6OC8Vqnv4ypPHWQ0+VBNeQVglrKo+is5Fq/eOl+MdhbqValuPtTQwjDE+VFKVC5+lJnItrxaZCwrNMojyF5XQNDTkcL4XyWjBDS6yrw2tFZ4xmvSkBSlW044eUCoFaPGL8FWVeGwtMKcWqoN/DRgjBLX8NRVjHLfhWVeGw14Zw6qg1tOGcFKx01Kx1ipQ34VntXhtaYkYZJVNeCcdLRqVjrJta9q8NrTAjHqqa/jBGRY6alY6yfwte1eG1Ywpxaqmv4WmClOKx01Kx1lNVeG1OW1VNfwcELxjv4alY6UtGCHWVeG1o4YwrKpr+My/hqVh5xrKvDa0y2qpr+GrAHh9OmpWMpZV4tFeVqqDX8ZmjUr+MpZyLyJbVUGvOpXk2rOReVqqDXmW1K8m1rkWMMYqDWesy/hqV5SzkCHhBw4QeGq5ISb2wDlDnGJ12XJAjVBxhCFlL+3n//2gAIAQEAAz8Q/wDplVNpLV0F1rEbOyJ1Kr+WFDc2OPdK9g/SDF1GWKgoHzSwAWemvSL/APkHUMlpIu7G7SM4tK1DABSFircUT2BFB3VYscXoTN8L0EQje0kr3lhFvHwN6zfyCX2CBfmM0GCbyBBKsTJT7r/ximqcZXaXBr4TvvheZgLaaEvJlp6xgRq3HTRkeDVLMeXBeOwSy8iUkKVzG1K2VeUilxsKGAVQAJOTNIfscf8AiXl01SC3Yy1h/wCVtRla0P8AXUzgj17glpVMicfW/MQe59b/AAepI0/LP2BZQ9aFNT+qWG7CNjbin1IfUqLSY32l90Wqauoi50I8A6AgxISmnKaej/8ADOUxjOyZbPb3N/w4IhdHxNRKeNWQtufEl3VizZIa6Nkq20XF0D79032wv2PXYrhsEhZBAqnEiJalbUjXsZcMzEgoMMUp8ossoh9MzegoeBtKHZp/+EaFraLYWrZAvi/h3dFTMPRyL2HwhBW4mruVzq8DXdiaH7YeLKjz26Ce4fR/il/GQaNwIr6smq+FETkmwQCndQoeyXMBCnrKRaBZlBSX2SByPR7NgiS6aKpp5/8ABKw8YoqhtiT0v/QAcRlMrJSJnyiwQZ2I2mKrKdkBTCFUL53HAQe6FLdig8BSstehjJDr2mif2RuE8ChQqEBMveLFpV9el5CSj9DlC2tAp1LW4sVpUKTm6GLv/BBnCM1YCE3gyLngQgf8i4psegcVuz3YrSILxHziQpCicoRTVtkkXZfwNsO6Seot2esE7o1qV/8AG1Gr2WIfEqIjTaL3zfTE9MNxuBuI0Q1qa9ZfuKLJL55XP/gO5AmE4uxjVfZMY6DaCRJZ9IP1IKKtBg33le2jaDD7AwWyITJ6fyKUDSZK8l7JfeyNiztsq5KRquHQjpxRSeQt9lMjk3QpbJNeFiH4gCMPEtn/AHoroT96Vm07NiL01nS/A7oU43ZKJ7iwXzJmFoSxr5WRSe6AekoVFj+ZI01Kd0JO09+SaHFu6y0ISKPi6EqcnOGSOc2GTK8EHrLmIWWfTLj/AL1ODe1DsVHLGmXeEaDYYlziD1TwNPOC7DqJnb+hNHYu2X4IC4t1ARLaeQbNUjQTpsQlKK5LVHBL6kE6T0bKrs/+64A0E5XgoI/NqCdujI5HJVGK51VMuRVoe4PyikLEKJChJf0kxbPqVQNDsJdPcVd6r2IFsPYPdO4IyJQa7knlF5nuSrtXc0f9w0IgOaBVgwPU5FMqTYmFWkSSmIVoOWinUI1bo7/1HhIHl2nkTTdlAbEVEEDq7nNJr1mJSUSW8HwKSmwhKs6/9tvkfLjIqEQSGuyVJR1voVYlCxQtSdvi39bZ1bfiBVB6xWG2ejxHdIo0M9Whqfc9AiCh+v8A23ty0+7CjqjENU9jY15H1HgREbDadBLef6yW1z4xgSpHaRae436V5SNakgnQ/jgzuNpnyZL/ALWwG/B80P8AgJ6Vlp2Ru6fJvBt2FX8ci/Mj+tNHk/OXR6rpxKpz6GTNUKFLX3hi3Kmv/a/zeYdOneOchBATYML4Fod39hbBt6h9g1QFVwTucejE8r9mfkDJ/wDaNN7koM3GjuM4A7P8JnxQEOf7Dd+4++jODZG4PU4AlWi9DQDyVOv/AGfiSydGX0IWUdEHfIIaEghaQi/sJwpid5wNpre9jeBepVNyHckyx7dT5T/stbnvlb4wWbHACDtepHAv7H+rTIdBtuHI6d6umFsrv2X/AGex7p8fBXgeFEfKqUXC/sUfBEX+0PqXLXJAv5eP/ZS+BU+Tgl8DxoSJKS1hkUg0rwjD/sKnLM86JbssAVXLT26gy1z0sm1X8f8A7MwOS7i2a74RFQzRNZGURMUGMAQU+P8AcJEbG1iJX9eS0Z3Lt0O0NUBJJuPGf4YbVIqA53NZwxyKEBtrXH/sGzSc5I9TJx2azZ93AwKYP3RXGdagB7cQnUgAoWFg51CpOVf9ZHwc3xKsVW2ZDID9Yz03kb0PJFiTfpQByIdhYYegI24M2ZVwf9d40uwNUy7WgZgY5CUHURAnFexvUc+tiypNGWT9CTUd8C39bUOW6b5/RYJvs6PyFYntWdB5qOy5lj8Mx8CgEHu5vZ/2aKvnBwSCUmsD8hgyCrBnMV5hD70TQKx6tL/X/wBwjdxImYWeZPEjufBFyHoipO9LsRK5egKtwIgS3/X3DmGysCsN3yitBqPbqLx/ZvsNkdev7nBxeoIq+CAZ22Enp/Wj+DyVgu4PYVQllwNif0M92RHdzAfDoUWIgh47KEf9YmiQ2hISzaMj8JB680rhIU0+sBCHTwjAcJGoV5EfSNaTGo284z44JXP6i0Pr2oq7sFVZc7syUa8yBaT0g2Hy71SmVg1ZGZ+x+AgKMbjytaORPQNpQ7NP/qsM1Fzi8wRVkGweBPWWmelUG/ocYNL+KNRQ1Ab7nr09Rf05LWOPJaFvthBXaTgCXR/oLonSpkKHKl12KDL3EGcLq/pTt/1luwDUHabFrxzBZfIYzh2Va3MrlrHwkc+st7EH+nD3AdsmuGJ/WpaWCyJHYfqD9CJk7D7SLrlqUk1WifrAv+covdlC3+dufDe4yE1v5XG+B6nzHufMe4vIlODwul3dPDn0zfMvXqK5Gr3Fcev0oZm9YD4H3Pgfc+B9z4H3Pgfc+B9z4H3Pgfc+B9z4H3Pgfc+B9xe7DH3Pivc+K9z4r3Pmvc+K9xNom5PwcM+dkW5XU4c/Jh/i9xxKzsScEncyYehwfLVdF/x+QwnoOY4vVDcC4UAoSipCQLzO8YCOj7pjjAR+zgO3VL946WQo++9PRC9Ef7uoJ+8YyC/TpiJTkBcOca5LXiHynufGe5+mP0x+i/J+i6c+Q9z5L3FcBD9QKrLarTUr4VmfLwJqT9wI/wAQcTLCnpMQpO5jAE2zA/DZ3aLpM1K7xewr1S2X4PqWV/JcZKpFTNzWFVfxEPS5S1NEMTImUJ6f3mYIftsrdyo5+TWLsT90Pjn3RLRrsH459JRme/oJR0a5AciYk6JRWVdZ6HSNIUnL94/eEXRpm4/YtOuTTMwINEqRNrGMgSSXA5poauIFGpUqlqS1RDnQ+RS1wctjznDKkxRqlmiGwiVSxKTcYd4Q6tsegg3SdRME2MpkVR5DhXKTTF+Ahiy8ENjNqLkChj5mw3ZZLqg/JgtL+tBnUm9TbNHwblAEn6mm/MftIy/dHY+FJNdgEbXIEqiHAgD1Hn0IW0KTuOngpSZYi5bv7TGobQkV6kKTV76fuGK8PUgf6I1aOlH3CiKewBMfg0J8Mlj8oYLsP9AyQfo0L/z7CvifkdCVcP0zqj64rbzENP0QxWx0VsDUiW059yD+c7YYd4hpqC4LvW1ciyCjjGsaW3YirJjCgOydv/KFvQejL2FYSeNkuhO7QclH9YQXFIKDLveUhKjNnuMQT8x+4fuH7H0IkJ1YqS+IevU1vgvqfYET2Vo+7UKMBcBlDwEsR7gKP7NsOB6NZUD4lxDultI/H9d63bN9yQQR2FpbuuxDEbCgoo184CdEADkHvuIon9gic4kUcdWEQdIWEUMMjBNlTQ26MjKoBspBpWCKRPeEsTrkvpzMhWTsioKGzzTb3zPJInRSbJiCWsJ8gLcZIaU2NikVmrQf6GmaZpiUwA2W7QV1iFJ50Da46TTKJZhwKKLMZqncjE1nhO4PYPldofpn65+kP+MRu2wG6gzuF+XcxaDpSJtWkEtxE6RhhEE2miupIx+S1K7P4ZHUgKHFi+xddj7R7E/7AqxJb5OZpPeccrBbEaVTjH9V3ENoSSJg8pP+3ZCNYiZXwEHFJz4txSrnku3bIQJFhdYcptMSDdD7lNUhXpHRvCS0fRNsd23GkkNe8Gy8yyqgeBv1mqahrmoNOmkrSPMCSFg2lTFlRZoUlcJTFSh4lYbD1AmklWg4y7L+l1XxqCKjVyVCk2JEpSq3DDjs/RFxUhNJSAJSHKig8DE1TVNXyavkhNIfqAI4JYzcQSuBZ8i6Nq+wuAauSXZ6BUm6/onR7Mg42cXhIES1DBGcxtH3RgyLAoxGgX04HsxDI5/ppWxIS27JIa5RHNATDtSCkM6ElTkHCWBx/eGffR8DdzrAXeV618lGtMOiRV0G680vokq0UNr/ACghYThaLMnpRQm4uWDYEh0L0FpCaJJIgpuT4Q+26m9JwTVVRTaAPSHFRHFY7l4gksHL0O/0J9Sn2U2Gar0l1aH12aoMGqpo06mVeyEacQn3nJHZ9Wuh6EbnIgJZp+EJzLNCSQ1zQ4ND5DsSggyBKLNPKFMexCiClARwmyOHwytNEtF0W7ZCZfEi5ocNIyXug7mdC+ATpipGu7W6CtmvssB2+6IJkvuCtUw/C19Qqja9Kf8ASsqR8xodN1CvW0C0k92hJdfINR+6G5cYMEkjbbKlCOerU08DV2IzVaFRilbBCWzGN6D0Ioyng0MeTCxqdnR9PBD9KYjMFuQeRZHYvzuk3ainZPDAuehSvQ8EdyLJeeQ2qqWB1KuRIEnjf0sm3Erysqo3vxgkskinp4Z7rpJNXWKdJJJK79CClkGCtC6gX0JrDyEFwmYW1sfuC9leqFZgS5SZeAjqtjDI8g1VJQFbOBMK0iMNkf7OYKkSGE/d0O6tCG+OS/IuFkuaSmgikPCAQdVNUuZhi7VCdJU9ElajghcEejN/hoYAwSpkniErUsPhUrq6/oC/o2yknPNjO5NTdt+gMCYpcWwgiSrVl3rkqLoXYNbnMnKJNGJKwr2Um6OBLAn6nCG5aoTcXxFDnLpcjgLTOwr2jJP7DijudCS/5QJGgYplARQL55cbvJ9ieCpYQ0Aklkrtl92ObBaX8EjUkjMqVfrxEWYsE05QI/aVko46NwkpbolqyZXDbr0zIdcjyqQpLlqHgBEejzO5PSExqlgtG5UgjU3MjUCsnqDHikgHWuROIsUWpGri8CDfPhyGPvNmoUQPO9K8i1PsRdnZGdF3JfAh3ccU9TESPlyaYAJEqP0dXj28QmoJULStBkiaSSwFrK4qoYUKJLA1JFOBsy9RC60LyI6TAJNLw8GFrMr0Iw4NgVb10HsMuKpyw19xY07Z7q6olCatwvURCdZsmvK/k2dPODCtXsfhBWofyBnyJJJWSglke+yBRJaXqRKEoeQpPKUg0xJe3tJSZAfsPmVRzhSe3jM8kW0fuBmXEJYVbl8iON908npyVy/oH3rBCoMs7jB8y7AhL/bRL8nmiRuJfgOOgSJ3PQqQASi5dtxls0/IEC26Nbbia94ATM/8lGKiMoELA+IxMegQ1wR0kRO3U1DB11PgXoMjpUk4uA8liWtkvQje2YRgVmJ50iSj7rQ2G6xh9gqPQS9SBACiUWChiRbNRCQ/5jnqqiJUJRaauU2Lo51JmBR7iLkdBEIVgEJW4TVQfIvvUXRRnGQ8uJV9RYwVWuSlR7+xTMCVsH8Cr29mEiSqSU9UzFhyK/CyVlsx+BHkEQZ4cFxLr/Gr1Rdko76MSorGSrupCjWfsNmyh3dGp0D3C+WFwMPAuSo0XlyOwSv3x2FeU/QqZzS8VnHwBbgviFkh/wDUPiBSMAodkWEUO8M+9wHfXSrvdWh6Skhs3J+kMVwa+RqoZQRlDHH98a9Hrao5dXgZlN5/A2GT5NjZ6gyHQelnsukVGGuevT3aFGuRECdorMUaLf8AU26ECkSt/RYNlIO/yqNcaDpZatRUINiQy2hi5geQ+qnIyQ8Bskq2hIaXDdMa8h5VeV0QqisiArSL43KKVpLgrpZXsKjwMa0SV2Kta0G0vXwywPAK1oiz4tW8SRcFKY9D9Jc3kWHZG6ISPUMBUcRwuAXTTnP8Z0H4vBnqVbO/gQ1Rd9IwxaW1ehUSxB2vbd4PXxEjZLsxVHsPBlkaKSukpCqir2H7uDRNNCZeVCHXJ7NxWJFT0QnUo1CsD1f1D6dZicpH5hwioncm0KywkhOCwS5LFXb5yEk03cVeSemCF9QBC2gt1kvszwhCSqH0gSXT6MlaycCqKHIyUbpKVobW/KLoZKTFXz9Jr5NbScuWyDrrMS4huwgtWicCeTVJFhShJ2u4lzci0TyyywiHcbwiytkxEehZsKOYS2LpNiplyWfpIAQzGPjYqXgCfUW0XcBRpLH7kzs0PlSoSMJzZI/ibccNJJ7kg4BOcRYElFAdrA9STVHoZPIsEu2UbjLNcEzSJxp9CEeCaogT3GQ0Go93MCq7dKoFkLsAzyz2hh/kda90PPSYKOq3YRAk1RbiCz9A4r5fSn/+UzSK8jd09GYg3RFd4HcMFXNHI9iQVtk7EQ5bg+n25HJcjOQeJZWTAXD4UgZWxNY2+iX6OlONfG5ty9H0tQpSUftoNOzFbUTIIXKALo1QzOoIaz2EzTQOmrf6KoAQDB1E6CqS2Jxa3yUYHd3E+6odfz4V3oKdLGwbNShLQpiXmImIt2GWoPA9v44hxvrI+yNNI7jKbacxwzIrUI7YFxycPoRzm8krpDoUzbUu4zXMZn9hDAkMoU5Q5CRRmAILSa1UxErdWNCeQNhfcRqQqcQfKcfTBrQ15QvyBpML7ghhIlQEauainqNQzhQuQuE9WoidUN0l36vHAZjamrQ9QRPRpJMsH2B8Kg89JZE5Ibwi5Lk2yXhM0UyHovT6ck4PMFzQkkbuXhj1zGUDnt1qaAhoK7jVpILhIgVV30H5wCkjeBVpqeoy2jYIDeE54IV7GUHYFT9nhybtXk19iY+GUSQvX8CQvahLMKr5b/jkmUO58m8QxmzQFiWWTTgBsyIaqVhjri4+qzl9fUbPfptzEE8F6CFIqko6NVNTK2sXiy2DHkmawKyBoytr1nA0SNvpTJ2ojaAhgygOVA2oen015dGL4Kqm2VgcEptV0qdD5RoRGxAMRCrrDKLWMJA0yxDawyALnyJyik6bmjWGyLY9xwUNI2lurbqGkrtsWP0KkHuWGQpJItCb7ivj6dnnoaO7pJM0/TE8I7+ZLdhQtHSE3KjvQtzsiduADSssaSSOkXTkT91Cgzk5RW7YE2l6pBhZsiRNRddIXDfnvuWWFa8HypVP44uShovRuCk4dEhD17kMdYFZmr7gwgE9bY108it5KZW+4hNVmrDDTbRqOiZVoKgvmfAnYxWjFDLi3UJvW4j3ofcTmiZOEZ4qr+n3MX+AIG4bmhZLnMFBp0MoVjnq3SiTsRlSnsQ02RLRCG4y9z6UmUhKT8EakHRrj3Ha6rYUFLVCtU3J0RNGfNJMh7QX+mpiESyhdqChqkrOn0aVYSyyyj2ADuir+iXkDTtXo4FkUMCOBCEaaC3q+4nHQhVeTOP6xGY0KSKt3oVKAdQTw1K7/wAWK9bTXS2TGRlwSSsGV9ko+iIXecSKBFVCUsTVfckaK1DBFmhEzmFAsnLk79JSao+QN+5LrNEozN3fRPJvvMeacKkiVuNkBhHo6FXz9VDiTYuy69htnL+4GPiPyJEu8419GDv/ACL/AJ32DCXewjfvHSX0XYNc6J0YN9tDD9RkpZFI+WpkozrvI7Hwn0N+7+mqPnDIeB9VjKB30Dboy6ekxESL0rbxYH9gLY1oAtxPQknJUuRybDqvb8I0MgSVMRjkrhOz1lJy1NCqUf3BaMfyE2sheUMCUxsgEqc1js/iUpD5gUpS+yG8ZNXN9A23+wSbq01mT1qmm0WS6JSH6iSuzk09FovvGU5DD75t9KHqc1Gic5HrAALOLge0T21Ew+AQZ2sVOfrFlbXdwKsluYRGlAiW5uGu/pkjRzF6EEi30uSJTca/wJEsBdxA1C4dUySsjV2mj8xfJDkBw0UgqtxOozfPT/gFz24kPKg7MCRpTomq1KMtouwjvb1MdTMfCh8vgQakm8qCQSSBtRahmeiKk7NKyJmZLTQgmfJFReuGP4V+hA/8cDhIbjFGzviP4lKVptbh92QJCrQz0C2yYt3JcsbEKSFa4ZBxxdX3LZopSeGHBBph1T+gIHgeyNlfvRMalK+IjcN6Ak6BAiCq7h5xNzrRnqHYCC89Swj7jGJbQjE1GElW2oKVM9A6Jlw9pKOkCMJaERVb8GSNeCkgVoqpbCtGaAF2NhWA9hI60B3AbKaFqKUeQ6JVboi0EnLTq/pEo9mURLEn6mMSbHLghWvJsaLABKTWnP0SN36VQj2AItvlS5IHXQqr3wO9GOslw4wcViSjnPPQS/hB+YSRt+YoFkiarKYxbTdIJAtZvwIBJZQbO/ufAyHfEoU0yoVodP4iZ1O7We46yAo6kUvgwjZ72hDOFvoquWRQRbB7VC4m0DMC2NXTo10SjElhNSKDdEpaIUet+4Td2nkpOKhDfuXsj81IZ5Ia1V+w9SjJkriRWylwaXzxMMpxjFkXuglFRWYEzFwyb4cq+iPllPco5LCpEWu7cIKLhCuHSihyRDZa61EErRer1uCBbxg2DaR8ng/VX4KN2VrBBKbaJNsV7fHQKM8drkENRlBNukEGzrECsrxyZ6mlKDOKMjgCI9rZ8iBJKQYPcMoqz2GIa8BmMwCOvVUWHRBBlorvIouDkXOB3OYCKPv0oxrd7yKaFqUnoOpydgQTSgKc7qqDadtqrMjEDmo0rRRIiegJ+Gh4ENzwmjJeL/HnCKiUHg9Fcwjt1I7VilG4xSFwmR2KikYwo+X0N0yEqmLSSrIpgmkk2K+SrCKu6irVNyhy/lQigt4UOBa6pB3oOI7WOdRC69ASvh7BEj4j5CMsuYFM1xwPnbRdTRVbk6im0BKoVNyZuHBUFPF0xLsKkaafpfRImoq905I2WFCEU01hOyXbIYYzr6Fwx/Ew8VoYZmZdgkvbcn3dFUG0h0z2SZhRyYV2vbkbWupxrJinfMhoiGsUwQauLWqKPZrcdLNl1ZZ1lClGR5cCWjUQuVIAKGa7CW2ldbTrfoXnf2PAh4kKjjuf8TZl0LOLDwvcjhdTQdFYfXR8pEsdJoqtFVlVxPYsZrAnbotoe4pE5yju5HfYeJCiIhw1KRsw39DAT+rNDuJmPSiRENcdhqB8NCgv2OQW+eDxFGU/UHQIk1PUfkk6lKHkVjNjBXnXEjX5T4EspqzryJW6V/ljZBBQ266FcpKgHYk0YLe2LsEhXOCbN7hUWejo+kc0Rqoh2g7V4QkTq3OS3P7wCHx4OAnAfFWDbMlLYPnZE1INJgz/ACg6KplZwyohPZkNiDZ2YhYR0kqbBhIZM2hU9wJoBrZ9hIVW3ES0lIgBf4ul/Flvc4JhuElZFcje4Oyhqj1kNaECGfgQoZVUH2I7etUtpEiokpxaQB/Dgle/Srep94yUMXiGCshUUBS0ixic2XAkwQomdzyCLq1KSqRDkcvgRIxvg/INcSSEnqm+EE/LxPXpo0rIrwoF21qLLKLL7okaTTLVGnVTPxq9C3UxHzkpkxehUkq3ScjmoQozGX01TPG5m1sGuBaDYSi2LalBIM+KTPLPKE+LuKMkUtLNO8RRtmWwkZSj/eCRKg20BpdIW9S9RVaFLOqhq63JSqPUSErbEiYvgzYDLo2FXNVkkDCVF0VYrIldYSV+QOePRFeu7bHWFvjJqzB1RFphFWhH1CoIQBjYU5aSg9ccb+EQnw+lpKypERA/cPBD8SE9LEs4fWE3oMKT99giu5ORFEHRJYwSzOhZlhTqIe5Dv1gupSNNykmn41gp2XB1q8BUKqUecdvDfkemSSpCdNnW1y+GV3nFBvAqSgfcILUbrAu09FHLEI1f9tEE4JoYgoSaiuJJ91BnBjdEusJjmWuvGiKTK/QSvGGim4tSl6UEK6m6tB17sOx8+JE6pgR0mjq107MoqdlAtZSF2L1GKPDkdxBSVNPItE3v10mQKNEftiMRGx3E7ck0E1exAi0oPq7BXgbbL1S1IaS3YQ1Qqw5IMuN3Pl+0dBDdhMSb5/iu32eGJyoPYp59j5GTwQjBKAW0FcVVait0qHLwOolRWbDovhLoQcAV0c7aBNows9VwlanV5LYzBRKa51ck0dKU0uJ5QiuWz/IjzylSObBjUC6u4mHnotfs0A8kPbvAkIIElCPWRHHkTUPIkFF0lMUO2uxINRr7xQta+e0DSpoJvApPcJxSW1GTgwAkRRudfAI52bbliKNE4GQru4JLoygU6qp6itqw4/CQP2lzgLrdwV4Ly0Z8jIeyqSiiIUHCusvZIM1Fkk2ZKpZsFURweuTfoFAOeaXz9GJFHR0QJClM6CNmEhCq3YaRYrPL9hEPVDHSrn+KaXp78dG809RCgKN0D0h9+hMqjUdE6Bdzt0lMcU9F1Q+AlMEJqXkYfkFoIukpZfyaH4nVOudbPyIt3vujpruJoxQlRdXUyalf6Ut6sjVqToyGkAa+S/0OTeKLn0KTotx+157mhUPZxt9E3qTg5Wqo1HeXxMek9ocidkcfTD+VhoCM/OhCVk0FJLYegiOzMIXo/QQUemlQweqyCaBBKqKxAbcf3ZS5w3ESPBv4HqNoahrDG1SjVU90JoIw2x1Q09E16A5gzCFkVLZ3fsO3UnbpkMArSTyN/CKSKyx7EpSTlEMxUzsiSPN9pRLTgsSRF80Qfwx8Ssn56jB5BeJIaPDFR6ilOlBiM9CrIuLCDLaRSLsO0ntIJHFY9kJgr1eeg2G4XHISsNh9JoyLtjLtGVjZPAvNam95FpLQ+Ng00jHSz1Sxv6PZ+xLVBJjCSQltxWyKDCNhp56WZCRwY41owT6sb/QKCZyfuJfWriCCRtrQ/RaHn5RdM0IWl2thqdSoKMIpr6npDS4PJHwhzBVtp8/H0egtRQWVUSsNsKC8dFDb7xAshSjqzTZCRqatEwYD0pVl72lEpPBLBLpA5uhTJKhHiOzNWGUD6AUHpdzQQ1xJiGqyR2wUTtd5Q8cSW8uBoysWP4ir4GfQmand9wpbAqjAqChaG4x9h0UXBCafVQSaIXM33SJNCWL1iBZa3ZIjiwZK0KDuQ9TYAWJ6Yyx213kDCpkh64vNP0Klg3CwSFsLoi4MJPkxWNs6wIkZFWFFRLqlxJVunfUGuloNltGhhqtl3021CSSEyrsigdQqhEEKriYFZ0WnRLWuLkbR9DdB3Ai5SH6miaih/QzW1MrppoFlPXIPl59ILXVfdFRt/oCLC1AglsqhhaZ4lWf0XycII2gzjU1juQOzBN1H7FFByJ8gyEV9kfLqijgjnHJH8L4GZowIj0Hxs9AdK4JTT7Io1a7jlUXhI/hd0QGmmfoQHWFEjWYYMQRGIJ1D6LBRcfRUXYMdU7CtCcJCJSLsDiVsHf6PUZZOoHPR79PgBkMqHBLmzM8Dldgp7CE9Kij6DQ1Kd/cQg6hXCrMccgksKyPIaT1fQ0PYATrwbbAmocS1/wAFfo2BHJKqPvqi58vMkdOy48Ew5KwYlzuD1l1Ng4RH0J865FkyrKlBLYosa4FO+tsjpJuVuPueH3Ci4XRTdf8Aw/gZjKwPUmRh8DPQvUKgKxtURI1SdFRWD0seddSBbvsM4mOmEZkcVCHdSVS3VykKnTy6LdjYJLD6Jw0LodhjjNKd0ri5Husr9Hs/YloFbJ6PfL37g+tWy6a7DPRPeYlFhv7kN8bqcBGleQno4cs9osUXtgUcoXYCcra6iRU6vOefdUNhfWkSZ7l4f0S4g0Jq4yK4KuDbcU5nqsibVHjTDBCnOesG3g9SiaXfAkTXTyONEint6u44IVLV2FLY9D7nj9wouEQb4Mf8P5GfSbCzk8CIu6bRV6VT0NQyGSnuWPHodJQGiQiqRP3A3S883AgQt+Qh1bvHMkeOI2KturcueRxXpgtuZJdx+kTS6bhkcrtrcUwAwUzLRv6ITeibHRLd9zMaM1DkluKol41+0VOvVxVwx4JIpuauyydkV0bWYmKntBq/1oTjJWnsG3tNsqfJJMhEdVdmVeRihrlYDlnDjjp5/SDCHjm3Fd/oaSmXBF7jSGX9y8lc8VE/PCFarxSusFMvZQGTuMHjTLLV9I1ufcYtSPaw4Fpsx5LEmdi+4tQDyIUtJt2sRwk6cef4fkZjS7CGR0qeWynBB3dKnDb3JC6oEXpeAEpnVtIoHSG/UblzLFXVpy0Y29vE+iwKoqarb5Czt2As5FH4GhFEi7XOGV0UjBG0GSj+i82hz4LPwPI6YLUUz1aigsl8AtUuZh5d7i6yLOCrJp9mOOhJ7B34TwyWJ1P0K6giN2mvuMk1IowK5PkajV0VQWGeTAt9BMLWZv0xH3Alt9EAudrShQCK0GRDIaZUvYlhiFBtbIwcT16OUmWCVWxx8vKIcqw1kg7EIUVELT6BmZ1QJkkVLoNYIJOkp4BlHDJKZVME6I2gjfT7lYzLGR1gSLTrOTt70/h+Bmep9yyoCTYcycv7xJUKDHcO46SbYrExv0qMrIQtAuHBS2C6VuWZe1bhKHrLKLYlcnzS6CQooa8kxd+sKI0D9hhFJWBJ46LMDUajJzX6IJqmvQi+ex2W59AgRLIKdh1XgjwGkbC3jApp26a/0OS6Ilfd+RdFhVNd730KKHiJCkqAsBvHuLk9i3IkCrcBNe0OFJ9tomN9YRlUDw2v0KyaqSuoVK2IO1AbAEiu5KCsVwd2b/Po4rBCUPwH+iCqNVI7OCllFruLp05kN32+Ccdd46VMt7io/lBB5KkldZMCDV6D7QqCeyiC14YlVFP4VZ+BWKv8uRiSJjdXUnh0p6YlsC47bfDUkb2OkiCk9sGqJmSXsKQeycSiSWgGu5IQTmwmxUpTccF1dUTIcGNpslgcTLRcxbQpvqFklUvhUP8A7xhD39LzkkiOwVx9FRXTR4JhhRyFGpRpG49R0dgwQYofsT9UuphNGxRQwutBaEfJhEtFWhGrZutuKyf0Vg4LJRruZq+faTDTLsIPRQC9xyybmobZ541HcpUrtRX6INaYerRGiJYD5+ZFWoErBP8ATOIQfrfpNGNgtZS5Z4Fg2/uUUShF5FUJR1ntxUF3Z3iwYXQKqrQVkpK58zc+BoVaWJ1z8CcN/wAJPw6xvq6sIoKJUaifqulRAb2ERW7XfSeiv2RDTcEhja6LRVGPql2uRhzlTQbEB0lCYYXV47VM7PYbmkD+sRQzNrbAyOTGsll9I5IoAvTrZcu/0QbUfhDJyZhFJJEkhygRC06QkZy+RotDLH2FUulhrWYpZoyzy/YnRXhdKrnpwHXJcMF4GzQLhZE67mk33dZ2as9Bj1lir483TzxM0W4VLMPEVL/QspreE6COEzD8q9nAMQVbbku2NVYJ3EhCF31E+lGOvTtr0F093ujswJGHa5EBJQNfJjabbMQVhMTcTVCidCWH5tiB4SS0KYk/4/4YGvuyO77sqDWV0eudK9bpTZTV4FgxtE6w5Zvq0C4TS3GTyTEiBMWb2ET9kfWwicJ3Qn5Z6oVC6IafVGMk7hvty37v0JqVm08E109xL6EnXUw5ZWCwXTklSL7Ih1KbSWGP2Gewe/WYFsdGNFBrX6QSz2iwnzqWdyKZ15yyZTTa5Oj6Ig3hYcdHKSTZZId5gwbMCbSgkYgeVv6COSDTs4WZhQByi58fPpGgNkhX0ROxQfbKJSUr8jrmE/oq9y8LuTCNUsFXlG0Wao4XGm0wXRY60mhfhHSyNvsLtUUdWV9fc/hlWvvR5BD1ZRK/0+DUkb1htRrVRGP7AmmdNEbzlWCfomaTZdkIrO7VEWkKCkR010wJ8bRokhGo52PUvAbTJaHWdxcEKOOVQYAdEJBnAr9G9C8ond7orc/QHupt3yRJsCXcXoruoI3Kk23GrADfu/okSCwkxTgdrmzZQkY82mXLE8Gdh3sM+hHYf2EQRaLD44CLRVGfop6i1jUaMAA+Hn0ZkOt4RYa2CNK0hNVZVY2zlPq1UPxFRncUQvctkwutdBe5+0CZ8s6whDn5sFOyPUfAz/hQtV+o/wB6ATRwynwV6a1JXVAqyNErQRjiYQjc41uKvxKiL+D+h6aVlFEKsw9nJkRVXm5IlcEhRTqxMionoxOKJySYgQSFnYIsPQJ9EatDwNBBJhDMMtRCDEPkWwktF00/BGInSluW7tL7kdEHX7wDrS7UM9UzoxM2ZcJtULbXqyLvRVY1U1Ek4Rvsjp8bBQLC1hCTNtoz9FXSqbxKJf6WUG/pFiono1N1J2Fk8PYRcQ2/bAkTkrO4kdLKbKHSVUN7iOYaoMWKVWVUWhWbLdiEoxoIka3HShUfVKdiqcnzU3/DK9fYNmO7GVPlPSO63RPvJPcyUtsl0i5EauunkZ+9wLmuvWWVTV08dHLBHubCg6YZrKQLPJhJkcjPSLQQYh/oKyOtlPQStneBWNvRkKFYZVlKd/og2hvwNHfLE7ifrG4MQ07rRZoIttHVPUSh/wCGPpcpudEkdEnNt2MUXD5exe0e5TKeAy7adPQawftHRN17RLfNV7caE3VKwbsMRqSj+ETPgYMaUrgmNTH0epUEYFQSbvcK1KtZJMX0BZZg7lddUkMlvaeNBRE+wTknO98g3y1lTKsCyxYbuG7saohYE7m/kVZOeCbSxfuGzxFGcksElJESxm7adLuD+GU+GfCZLiR6sUYYkerpDM6xajVnVFtCOxcJ1wkhBhRxA+j6kEw0m8QSSWPQaKTPcPwgYFTNzWmCChshICoaD5IShWHlDHgzPlO/0KHNoc8QOg45IwJhGE9sYEI25heHIVpFCVHYWV7svQwmMWONIUo7a4IpI0hLNezQFhkND9JOm06hTN/qpCG4Cs0xQUmVuVBO5ImHkhFO0x0rqga4CvSfoVKTascIpiAsJG4lO1vFpYEqk+4dJHNAYC3Vsz1QVqFd08FeJGl7FM0JpqIEpXTjYo6bRw8joZZK63mCETFbitqjcYvwMuQmZtkxLBOpOslmmGcp/n+L5IrJ9RSqx81R36JmUQSSozKw2VTThlkTp4nLMhdSw2+iXIim1IiVAOBJlGxtPRrUPVnJ5poIkCt0hjMK0q+mzCL3sL2iE1Jt86I3RU8v0SktKa8oWxTsDkSGcu/giybuRQd8xigyhoKiZ3Z2CRXdArBGmfeVYaVh1N9Ac6LkP8wdZvY1IT0s0H0IXXIyjPYNg5qlR8TUaS/pEOOUDV9FIbtd6Kx0JhE0VeQmpIHBDdQWhDmPNkgt3sIcDsLt5gN3cBDT8uKe8ciaAopKWb8UDKG0r1oLQSUweBunMYgPfR5JNYGmkzEMRG8yMT9l/F81UDJCCMkSbVC0FFWgSel5ZllYRigtqRnAVSFim8qKhfYV0KBSHcM01XCLDhE8qBmDTLrtalzxklbcO4KvFrUYSVunliviCo3yVydgeOrcF5RzBNJaryx0cNZ9yIE7qFgkOkbDZHQwgVEHAkeUAvYVnkOFtIGsos0gbx8qC2eg95fB9/ShLxM2OKdBW3FSh0JKLyjMJ7iKOXsJg4QN6UEv0SgKK3HCuygvT5E/Oq6SA3aiVJHaglSE+4Rndo1E+aI/BsM0BQOaWSq4MlUzkuDgEwIgXKwlceywklFVXQt3vJAgytUNUQQhrwPUaFy2yao5/h/GoygTFpRsKSFSvLAjET5idhuK8lpORmxTXuXSggcuJIVQO1NVI1KNAryT0PQjMHLRlRbqrIjAkthEyW2cQhWhyHn0o3EmoqHtBp390ng+sJvQ34QpQ/STiQo5A4QaSLhVukUIZsaHkaVKqBFSC70CcimyoPkbUBLs5oxtRna4W2ISNl2ZJNos0RwTNH8AnO408y7HKZbE8BYGOr6KnqEy3Ic0SVH1C9oY90KWokTEoyUKTfK24x1VoRJqJV3ILUSgUkzPiQPErLNDVvcFoq7UGSEQiXBeArf+i5JyKX9F5gmwkk5CGnZBD19mQr4w/iaxH/zwIAQROFfVMqTMkPAlxMElW+GgtJCNCaDXO4pET74xzqECGHUHZepeECuLFkY1mIYg867SaKMDPSgzB39ACoCYE70RoKpHGqKfVSVoc8QVGZ9MNZoLkbs0o1JpXGB5UWHY1ahOBIneENUgvYQn+mlwaAGZFsDfNOhdtecia/ujM+SNMdDVNVIjKuJ2QmIuEPoYMjyJwZqjUXf2Rgh7Gt3I4jIgoaNAglvVwWWd2JRKUGjNDeEQUVaEilqaJtJXSB1VNQrxQ5poPDAtkYcN5KNhjN6ocJ4HpSeBC0V6L+L/AAd+8tFuxVNJbjEd0fcao1u5EZu4WRpTvRmeC4NXEsqG1xdgUJ8xkzHAm8QgGl6IoSh8iDYgRRQWHoIIBoD16Lszz5yeQQhSFWJd0UBPw2VoUbgpXZsSI6BaoYWmgsBLEwxVKzOhRor8BrAa0Tah4lwswMp1/QNNLmEshQrAUNezgdhtTQKUvZGO+pHbONGT9HBfCBJKHDf9Bby2UdmiuMNiRVPm2PATA4RFY1IVC3LBIcBCigaSi2ZK+EygdAOmqm8PGnDLlBXDyOYcaiWQVSATNydHQQPsJqhWRoB/jedkQv4qKANw8GOw/wA3CXcBCIT8wbleVA6CnfgIp7y4k1HcrjKnBK0M7ylqhc+BWcjGhI2Shq24FQuECJY7Cek1wyjutAo7FQ+wkopqnIhbOH4TUCbNmlmljV9QbwKWbRmweql2JZfcnZ62ZeCs2KJtZFTKZmXqMAYgzCssmrqqDe+QykKkkNh+gy9xyaEYG8nUgsBUnhq0nyGhErSRNB9Uang1vAhxjISF/P5FQ2tPkxncnclUU08C25yGtN4Jl9y+8NDbttRF7RB/iGQ4a60EKHeSqhKUTRFmm4s57Fks9ACLAQY0rBK3EF3WdtP40oSma5ELeOXVQxFEqdyLuGj01DS1UEkRFVZ6oenabBQedyF/c2exCX1nFBlRy3JekPSE3XEys45o6DO4K640HsjFim8GDyFhmVNdOXFSGj1fRBKZUcLqJU7eyp3CjGxwbSJwHhBoC6IFEq4rWyBfcgj8Ahq8JtKsJCMc6iBLkpNpinS9EVo/IgpRAhyojqIJVpoN5lAJhdCufXqlch2YsKlh0pm5YwFZt8M0JgCyBFHPSmpvBvhrRdgrqBUJtMjveoW4jQTJRl0IVw1C3oX24YmmDAKm55JTTtwTS91F/J86CG4jA6VEyd0ySAW27bMdJIVhy0hFk0DtTYjS7MMUhBPgIVJ+8uBsqjRnrIkUsQnQtMhrNjke8sJSEUeA8iiPw2Br/QrLD+KpTGRkGgUsQSzkc0lI3XqRFBP9zV8ldjTsJ7CUC9ymi38Bv3Yuhsa7GHpEBQqkOsJieqK/BOF4HMOkXPGNDf0yFs56JYp1SxJBSVHcibHWJeR6wVSyl7S4TQitLvGUA0KodjeB44kcXpuKZq6+xRWdz3g6oiqqboiwOJg8cDdz/GBsrEsoXVfA6uYEsgHvQtg9v5CCq3QV15sNdZBaNo8MJc8JPQqR8ImonMTXemJU04ljwLEU+UYT1BVJFI5hAiorjQZqcnIdyaYtg9I050Qi8mFw53J/YOdUQ4L0JrK2PqcbAl4PcOCRElqSMUjNgVB07y/uONZKiggN+AaeFYsHKVTFS4ISK9AO+L2GItho+BS4ywVH5msJIjOmg9JJyCKmKR5F94wQKpRfZEqVlEdXgQabgydVAmepKflqQW1oOFepDQXRO0O4jeyS+WUS1UODu6srCiDBhm1BKFsnErkqZZaBjcDY8TQnEIqSdBtWg5glEcxGpWbULQsoZaJIX8rsBPWH+QJpP4kYAf8AcS+bE57ZQYWskBh2H2uhaArg0bABCRaKJVGciB6jXZlmfclDo1lmopHZLb4K6MwmVuQKWzCHXXk6kHN7h2sCdRrDQD9cfrj9cJJniVJjB6Z0ENUmSVIaF8qJWCdN1U1Hzkaid0fLNQ1DWGVCcwI9TVQIcpMZtPuWOn0RkjE+4URCoOuhDwTaSiDpDuU1CyV+RcK2pEPpqmFMswD9L+T9b+TBPZ1UZjhYJOwvJayWRVesF7V1EAjngNkq14wOaZEh1xcKgeSNMhQSY7XRJnzFJJSSXkMJM3kuIowNHBmY8P3H2CE76FOx4PbeBfzQh1TwMHZlC98Cn+oUuaYXAv8AF+D/ADfg/wAH4P8AB+D/AC/g1vngb9X4P8f4Nf44P1HRnw3sfDewijsxP1f0v/8A/eyjoE+B9y8zx+T/AAfk/wA/5P11+T9ND/D+T/D+ehf4fyfqfs/V/Z+p+z9X9n+f8jfL7lj49x/wr8mb/nJ8v5P0v2KrXzk0vzn6EAGzC32AxHwHv0t+l6c/Sn6HpnyPsa3j+Bv1jS+i4TnvIYKYfeAE9CIcKwvS9ufUf/yM/9oACAECEwM/EP6wA1K3J6Z4cT7NCDGTDlEJsezKAkqSGosno8LAonspScYBR0Lt9jRU1KuW2TuF3I+wTAnNiShLl6+bzTMZchpEfKkevF5t+4INPr+2fr1z71bP6+tguUXCM6xakQet/TIkPbITdFChgGjKhgQIQLY9YFLsMKgRloEcqCFke3pxyhyguSBwQJ+kKcC4Vwrhbf8A6mX/AOhSoIIOBBD0fheB9rr7X/S0oEHAUEOCuBXIuBQ5LkQ5KEBBBVhKjnOhuWnEna7dTuuSDdwuVza0SEvLtdsSnmoeiI00Vu1FtAKkzQSzEk+DTAtClAQ0UhQESY0IsL0RwE2tACJgoHAWhXK0DVciidfQDRkocAH3IXiXAdVLCcFYAG0SYisKIJSrV4gMZMrcIoFhjSzFQHlosrAlAtCAKCGqnVQHxai1a1BkNOUNLbl4Uq1TANRAlfEFJFoF6DCCygGamlR1L4D/ABMaFoY7K8BtkfqHJ0wxYX4LbQDG2liYloWway+q9vBC0yK+VTPPyUhrn4VPTgSGWq4GQPJY+G/gvoyEqAHlDdAh3LCQxo2TdlibsdGiJCENgaoHXVS30LJNGBQC0IlypDQrUvfQqxWv0oSt0NTAfLPIJIK1CCCeTgCgwgkKVuGQuS1Llvhg4GdGzAeKw0VJdCJyocls2ha92oJdlFWrDAIkyVClQFKOjJDBZUh0YlGyGigtJDRR8eQlqfm1Fm1EyWIsItSCkeVJTyFfwrOHtkKixsVMB4RINk2WJSFS1FDSVJQEknWNWVsQUi1OASHqDgZVUj+XLrRDspUICgbQ0KBQQBhFn9y1U4ozKhMMQjZbwvKj4l9arDZv2t1NqEOUCp1UNKhxL3uK+VB+ECrYlAIahDUsCrl1VgC6DDakEOVf4X1KsScF4DCaLQt2pyCfYwSS2eFNBcKX9WcFo7R3R1MSpr9hfQqw2b9tTNSmWcvRLdsZcSP5w3KpppQp0UYfUmluWkVFqT7C+jEklC/bJQJlTqyVK2aifcwl2GgrrRAYBtQw0CGhUhQhMO6qmsuAFaDbfC+hVhp+5tMSi5aNPuYy7CCCWgg1KVVIDXVAIt0JlFlqyBXwQaN1b27C+pVhs36QSEUGEHuDU4hs3GEJKLQjIWVa3W0wKR0tBht2MZRb94OVq276dqx8tbsL+FLHJRgVcKXi1lEqGgxcoJ/LCXYe8EBgWh3IOLj0FZuGAX2KiS+UURxIacTfBJMEAVr2pYhpRl7qshSTglRg/lXb95lu3a5N8kIXJ2RRRcKKmpcVTDCijgFFFFSdrgUFgVSKLii5CFD+3n//2gAIAQMTAz8Q/rDQBK1kG5LA2L5aEaiPZiUDdb/Rf82t2Sh2PwGijTsLTj4U7StnshOAJJX+7heclrFWsZYNcCNkf5CBI3XwexEgBqVD7PCAahbeULEnstCgidbwaRW2k7o3/YQmFyv5HsMme2im3FXu2OFvyP8ALRneBDuC6z6+QHKoNgXVllB8CqTyB7Al/Mrzhy4So+FkHhSD192s2QXNQHkevIzo0cs4A+vGnOkfby69a3oi1rQ7eVuQ5zZt8oIzAb7oomCdVKPWaiTjSAogZi2Poo9aD8wtUIN8vAoypK5tHYlA58n1lJHaLHRA3NzKI3KDlbq0JktGgl9OWy4M4ognl1wZMItGz5VyLnXOudcqFYB1COECuCI29BKlk7/QX/Av+Bd/S011UEWHhEr6rdZyX/kvD6Rbj6XL8R/8M2cohEIlo3KDgvBeRk6UjmJMKAp0aFTBpdrUP9F4fS3ZW63hA7QuEfCC8IaRC0Q07KQqVpwp/wBC8/ReUhA6rghwgVDA62vjmgBcqFsLJRJJINQxIRtagI1I+kJkSurt9LRUIeLO+AASdUPCgqQtgIRwlaKRsTqUmf8AkKpRFMHCjASydzoF+qHQC4BSVKsYs4QuArTBMbQvgSQPKi+4p4vVfraLduy8oS1AETqi7anlR84UfNjAamloeQxACt2OIVmAgwAO0XwviCCv4X2tEhSCSFBwIRZBPK+kg1JEqlGqCl5UKEcoQMSSt1A6wiYP/pFZtJzxSIcL6agBp6GRapFIfZ5HBWHMlAVKcVHwo8CP4MVEvkY/kCEeSV+LT2VBpJfbCpoIQl9qJ/Glc/XLfkr7l/uSifGRM9KTxkbDw8rlqKvokTm1R8qvgS9FftUH+ZWz7lS+AKPJ/t7PzBUd+R9goDyWOgX0SekXlVC+orTjTIA6ECEITRXlTRVuna1K2VSgNUCvKUSfCI0aVOWgRPChwG6Ggyv9UDBLSx/sibktIf5aG/K18FWwyR2z8LZy1L4KQ7NFAXwBXorjxuj/ANpY6FVskw3K1bwqKI/wXBQ9X0EZk6nAKKV5YVTpfbiUUGC+oNKhCu0GlKqNA3/XlCVwgo/0uGy/ygE8PGlndDpwBG/KjVfqkB4XjKHW13V9HATEyt1LQoUgj78Y/TrW+BNPHwR+JFXrupV8oB2/3vgTa3NqZPUvoQpgaNQw0DAFtwq9lPevpitO1/FSoKhinGC+j35NKB9sryUQoY6qCO2ihFGRcXaTuqUHVvK+jp+TGlFafgYDwzh4XwP8qjcNjar5KhUi2VstmhWCvo17hTvMrBUMVfoq8UkVfZSfTWgPJXKixu00tuHUb9G4aQK3+VXb7nbZSoBX/DRrsJDfC40GqnRgG/RXilWLdKVBW6nwtBw3Cjtcq0o3yl0q/WCsqWAAKV/ktBtAB5LQp003X00t+VffEgFIL8KWhpKhELd9HlfaJUDtTsAhk+GKhiQVRl3io3ZClQPLp+C+xWw0V9l+EMADZDiV4YNRKnpVG47rVfJRCq1KlQr1UqWqFRll9SIVIupS34K+9Ww0UHsyGAFoHZQ0hDnVvwqN+1N9HAFWwKUAgKNWunZrr6ngrU4fyW7YYIUnsvzg4xfhfQ37Wv5KgYA0NOqlX0a6rlH2lSThhadhfnAFLAbobm/DkatjS/zinBKsdBrqnTUoyLZxaKvTDlwUHCvovoaTrQHMn4MZ0qdZMCoOPa+nEnBZX0N9jDOL+QvwfTrHToxsIXPUuSCDByg4OUBKEKrjRkEhRBBDliCDlBBDlDlDkIZI4FVCZRHVDlBgQQQ5XJEtKkPP9vP/2Q==','borsa':'data:image/jpeg;base64,/9j/4AAQSkZJRgABAgEASABIAAD/2wDFAAQFBQkGCQkJCQkKCAkICgsLCgoLCwwKCwoLCgwMDAwNDQwMDAwMDw4PDAwNDw8PDw0OERERDhEQEBETERMREQ0BBAYGCgkKCwoKCwsMDAwLDxASEhAPEhAREREQEh4iHBERHCIeF2oaExpqFxofDw8fGioRHxEqPC4uPA8PDw8PdAIEBAQIBggHCAgHCAYIBggICAcHCAgJBwcHBwcJCgkICAgICQoJCAgGCAgJCQkKCgkJCggJCAoKCgoKDhAODg53/8IAEQgC4ALgAwEiAAIRAQMRAv/EAPQAAQAABwEBAAAAAAAAAAAAAAABAgQFBgcIAwkBAQACAwEBAAAAAAAAAAAAAAADBAECBQYHEAAABgIBAgYDAQEBAQAAAAABAgMEBQYABxEIEBITFRcwQBQWIFBgcIARAAEEAgICAwEBAQEAAAAAAAIAAQMEERIQEwUgFBUwQFBgcBIAAQIDBAcEBwYFAwIGAwAAAQACAxESBCExURATICJBYXEjMlKBFCRCU3KRoTAzQGKCsQVDUJLBYKLRY/AVVGRzgIOQsvETAAEEAAYBBQABBQEAAwAAAAEAEBEhIDAxQVFxYUBQgZGhsWBwwdHw8RKA4f/aAAgBAQAAAADvuIAAAAAAAAAAAAAAIwAAAAAAAAAAAAAAAjAAAAAAAAAAAAAAACMAAAAAAAAAAAAAAAIwAAAAAAIpcC5+1Hrigjfdj7f6BywigAAAAAIwAAAAAAKbmDjyTdW28yrZrfgWp9LZF2P0X6IQAAAAARjKAAAAABDQHBW0up8loMfstNU3q+VtVhXJGNfQnbsIAAAAAIxlAAAAAEyh+fWtu3L9rnWescJtNN63LNdq7Hzu+a/4a6m7TmAAAAARjKAAAAAJrB8yNsdP4FpHRuEX/Ibj7eVDZMYyDeG9M9uXFVd9G6gAAAACMZQAAAABZvlx0fuzTfO2nM4zHHrJQ+fpX3u/2bXWb9P7XvnLOPfST1AAAABGMoAACBEAeHzA3dvLQ/MeHbOwny31uHO6y1YHpfRlZn+M4t1nuzIuR8h78AAAABGMoAACBEAcSa9660hyfZb/AEfdfSdUiFv5g4Zul/1h17vC88EdqdHAAAABGMoAACBEA1v8zvolrvkbA/Xob6B3IALX8+Ofs+1f2ruC0cFfWy8gAAACMZQAACEQCHy56Yzjlbmi89idtAAJeGeQ87xzuLNucrh3iAAAAIxlAAAAA0pwp31o7it1P3xGIACHz453k3X1K+e/1wvYAAABGMoABAiAB8xOlsu4853299XfcAgIil+TFXrvvXYfLWzOywAAACMZQACBEAGLfKj6R6h4kwz7BbIgAQEQ1R8pcm3X1NjvE/1ziAAAAjGUAAgRAByPqbrDmziTrz6KwgAQEQfNbWln7yyD5+/UjNpQAAAIxlAAAAB8yOmcp475j+ymw4QAAA1b8rabu3aHJ+7utJQAAAIxlAAAACT5BfR7DuKfb6xgAACHyEtPRHTGn9efReUAAACMZQAAECIMe+Uv0e1rw71z2jAEAiAHB/KO3+wbVxV9aYAgIgAEYygAAIEQal4H7y1jwd9RdtwQAIgBzx83Nkds1vz1+wwEBEAAjGUAABBEDnflnszV/B/2QucEAEQAYr8bthd13b50fYOsBAiAAIxlAAAADmTQPW2rOIPsnPAAAAUvxUzHvO+/O760X0AAACMZQACBEAOZNDdY6s4i+yU0AAgIgS/GO6983756/VnIwACAiCMZQACBEAOZ+fusdYcJ/XjKwAQEQMd+N2Td+ZB89fqvkgABARBGMoABAiAHzOuWcYTzzn31dqAAgIgfMfUnt2ZT8kdE97gAEBEEYygAAADFvlpJ11jHKmc9l9FgAAGu/lt71XQewOMK76uX4AAAEYygAAADQ/Duey5Hq6GdfRWAAADlHhvNMlyzFvDHu1eiQAAARjKAAAAOeOXZdh7P5W2fq/6iQAAAcV8abtu+8Y8o5lv/AKnQAAAEYygAAADQvJu6ua4borOf/q1UgAAOLuHek90cweW3bhsvqWMIAAAEYygAAAFF86bH1dmvl7VXzMz/AOhedAAAfP3jb6iZZReOH6xxr6EVcoAAAjGUAAAA43tegOwqfxln4t7G1D9EAAAaq4osnS9fPN7aE98l7lAAACMZQAAAD56bJ4E2lT0tJT4h3zpX6YJgABx14cBbSn9Papw3rjQ/1RAAACMZQAAQjb6CWNwmfPzZ/LfdVZX3Tm/nTp3R30XhEAXOpijDiy7fO/6G7hpvHSHMvTOlPqgIpghAAIxlAAGF86aG13hlujPdfemx76F/Ou7xecKfv/gusuVymiTRQlrPeJ5YD3t88LzW1dLSUHb3G9xR9Ljmexdpbh2tUkoAjGUABqzhXS+f+Vgp/SMbvkOE4l31wPm8fSS9a67g4g23ku07nTej08K30pan28qett3JHXHz+zG/5fi9mtHWvHuWTekJcyp8Cxi69L9k7BlAEYygApuEuQL1kmcUMvr6SJKak1l3n867pJTyKX6FcL3m457kFqv/AKW/yu1VZbnW0tludr5671+ddTGeaEncvG2y889vaeSlxjAIV+F9Xd4XFGAIxlACzfMjVV325jGvb5s+0XWGDnnjHb/HXY9+mmjztcePPfbOxqb0wzHSOVX+Wkw6kl8da/RjkXrXI00ug8x4fyDZdbj2PT+l/wAy9sHstFd/qRmkYQCMZQBb/lhjl0yrV2TJ/HJrfbUZpLbD17tyWEXNnGNXc8/vm49T435oRvOXZJguJ+SOvc+yLsHJBz1ybje6No1Fn1r5oeFoyK869zHDvq9msIBGMoBJ80NI5bV2fKLvUYnSPaEtdccej5am+kuac9XXe3KvJ96y+uhm+Fl/orbH2z3XELxlVs13iGOfTrLOdvbojmXkf02Pdc117Jf6vG6Vk+t85w/M8f8ArJdQRjKAchcFZDn+L5XtPRGW59pWlsWU5JrfMKi2UVh6lp9waV2RpfRVh6hsODwmh65owcjJlm8uW9w+fNGx+iLLt/VOQak5sz7I6KHntOTA9oadpvO7UGUa9bx+jwIxlAYb8fbnujVF+z/BMvxa4WfJ8F6ktvPNDsq1YLtrFt14FZtn6W8te5Ht/WHoya726W6Y/YY+W19a5rgGyOees9B9Naps+2sH0FDfGAyXbO8KpJ/TD17o8f6Q5ttv013vN5wnjGUB84efsxpKvy2ViVr9M+0T0vyztbHrJnN6xvC+kMTueAVG2vHE9AbK2rp2aN/u0bdesTt8vntfDrHdc/5h6+sFFhvttPx0jhe9dfS5hivvVU3ridL5ZD4Ue+ufcg+t+nuK+k+pE0oGC/IS7bt1DkULxtDUWU0OvJMu19dNm2eh8cF62s/UFJUemicI5e6BteMVlIjsGkwiZ70143Tp3Y2sNP8AXee7Yoqn05pwbWmR0M/tvvR9HuTQlHa5Zr3ZOx+OLb9EOcdkbZ6MTSgcAcr3HY0ntYPL2u9tpa+hznBrJ0Pz1eY6x7Kve7ooYFpflPMrzT9Fc6VEay84zGp3Loz2hdbZY8P6w3nlw57xvk3amT3PAr1k9vxKip7xiUvlJtDJ9PYl9IOWfpXc00oKb4zVu5NabX9LNhsIS+uV656b5SuPcHz/AM4znR3U+2s9nLZzdyFmmxt0Wy7aXxpCbOdnW6OoLQlsFj6R6guU0sdUa7416kzSlt2oJZYS3a6YbZrdSTd4cQY12v79yk0oNHfK+99KaE2F7YuhcLYl9Mlzjp7m7QF58cB6Y6auyaEvLvLd3yb26F57khCEJsk3Loa3ekfHHpt19dzzJcb0Xxdt3PrhrjzlUVfkFZhmOUntafoT8+o5N9bL8TSg+fvK3t0Tqep9POE+TWe0S+uI7z6y4AzDI8Fw/c3X88Jk/J+mrBks15sm3KjVdzy3EscyvF5vLaOrsdyPYPZUsyHjzLyfn9fWW3z8sowyvp77iXjG3UHcXGN+2R9N4E0oPkFUemUY2ml9tm6o2Xhdo9KT27G5dyG34PdMw7OkhMcmYvYael9Hn0Xrue04VMm8t2ad2LpDY967MlmI8paQnrjzyLDr1TSU01wxC6Y11fofcPP32SmJpQsHxb2XsXXlVF75liV6tF4s1vhV7y1tjstg2VP2ZLCZDlu36O3HgXil2rn+hKe1zRqNka2yfBpdqePYyI5OwmosFJU5Tq7KpaqyeFfjeQWKTdVm2Rxz9n8gJpQ0x8tcn6K5ry3wnkl2bgOfa0ljH03XkPMFXb962DsYQjz9hei79PNFk209aYRVSJffduidraE6NsHYSKEOU6XTF0QrblhmeYPUT3zG7VcKHY2ROd/p3vYmlDkrhLK+k+UtiY1f7JHzz7C6eF+8rZuXd3z82ZhXResOybt6QoMK5Vzjm/PF3tPhvi2629fTHr1Z4s/wfCuode9o+sZZqDjzINAbAtvguNbjslNcaDamr6+35Pl+E627q65JpQ4B5dqOx+WfS/bU05SR9PGOUZF4YjuPe3HGP2C17coNxZPDFtN5Lzrn/t69I8zZxkVPNb9d5NtrQ8s/rTW227R9Ohb0x7nm989Z5tOy4vTwqKbwySoxqF5t9Lec71ZjnVPdRNKHzN0/S9p8bbYz6g99X2OZNld8nwTPertCchZzVa32RkVVkuLWTS2b33Lt02i9aQxKMzZmzLHW6ItySvyjn7cs2b3zWvhpHMdvXdimMPOGxcox+m19Khd801nat3fRgmlD5Q4jb+1eMcjqdwaT9pLh408L76YVt3pbVXIOV2/adp1tt29aeybCbrWvHpTmmpjUUyW47m0J7+UIT0uwrRgO3ZdY3rX+SXLNLHaVbc7BLXZ3rL0v3pYrtl+saPYH0/RjKIfG++W/sHi3Jo19BVbn15ktBriMbRuLZehcKuFHsm47L5/xLpXBdb7FybUnjebRHyzPxxSaW72v23Xg+a6rxrPfbP8AmuToLG9N7Tw70ll2RfdWb30Rb6rx23hFuzWwXukxe3/WpGMol+LW4Nddj8bX2efx2rbNeXDaGtbdKsuT4rktu8s1rdzoR0rru4bNqtUxjNsnH6v3wCKXcNu1hlGy9AbHu+yyg1dpzdWO4+9to63udLk2BMzoLTJU5DXYVk2DfXMmlFv+Km0cL7a5EzSxSU+fYHsXBfa645HKaPEqW73rGs3y3dMnjDVmitw6m2fraeOw8TuNmuN0wmPlsrW+09UbR1TsS67OQpdd6FzXJ8RV+U4XfabLtdwz/Xl59rHmdy1xf8e+uZNKLH8Vugtb9nckXGmj47UptYX3aenaeHnkF1w252Wl2BubekUdTcnybmt2q5kMgy7wwy3QNpX7Qu0Mv5+3JnW4PeNBrLjzp7SFJN5bzsGqOkNG2n3ynKtYUexqb1x++YH9bCaUY78X9qUHYfEOUq+g99s4jf8AEsZvlokheZrC8Ns7i21CE/L+r8jvepZNgYDMyL1xqEcpxaXZVHcdZ0W+8x3LGNs1Ly3kdjyK+YFNmfriVB6bp0bs+Fo86yptWG3z6sk0oxr4xbJxrunhnJbzsDVUybzj77TxLEoS3m0w8ds7L3eNQ8q+E82U7q0Vj0z18ma7G0pQRQkvG38q3UWnTvJmSbFy+noNTQlZvtawXHR1LCk2D7a7oc2+pRNKMZ+Mu0sR7q4Y29l1JW62s0qs29S3nD9aTwpszyyp25s9BqHlfymyLZFypdV2KWMu0c/tPvpS1wXHY2RZRugpNZ8VZLXZzkGq7dGSPnW7t0JGMvjseXALfsj6dE0oxj4y7NxfuvhjLb9srT9G8oe0m0cNsaM3nT2zfO3doISc66DyvFY+e6tJ7Ct2IRyyltu4dE+8K6gU+/NjbQgptbcU5DLXXfHZpcpxOMMhsEIwpdk+OCWvcX0jJpRi/wAZdoWPt7hPLI5NjENqUF4wzFq+hTXWvxumtu8tp7eQhpjQ/jTWZGW/bDw3ILRgk9woIe+yNdU9PvW4dEln0rzbtizYVNNG7Vk+LxhLl1Za5L/4YjjW9/okTSjGPjR01pjtzia7otmX/R2Ubh0TS+fr55/a8coaTdW0twIQ0xzzQ7KwmxSpOgbPqnIsNJLhuXRO6NVWffGc7fgtOuePsj2LqwyDOdW7Fxmw09xz/XVvvuVUPlrforv4mlGMfHTZuHdzcY5lZqbx2LrvZeBVl5xLzueZWW25xrq0by29sdCXnrS8crsOOQQzHaWpcWgmq89we/45meD7pznbsq3a35Hr8917Csyie3VMMeostw661+K7IpMGtnTvdZNKMa+Om1cG7l4Yzui8ZdvWXXF629pyg88pjba6T1w7eG6M9Qk0ZpS33LEvWMZM92bqvCb9YYw89y6m3BpTy3peehJVr1Vx9ta96ujGGXUOSa7iu+YYDQ5PfqSi1X2X2gTSjHvi/wBH6z7P4suU8IXDd2rM3seuJ4QjtfDZMdo9t7b2+hJpnl/O8A9ZNja6yLfWEY5c9W+mVYehs3W3l5b82Vsks2oeYswxz02hqqeGc4TCTM8GzWNm97/5a8xXurrkmlFl+KuxqTtrhbKLjeMXjC5UPk2pr+2K3MMBmumVbn3IS6a5flVWXbY1Pi3hLClueeZhqbHZoJL7tvPdrIWvWnGuR3jPMiwzBafy9KrK7zhuMxnpNnU+tMa786sJpRa/ijsGx94cJZrnV417ZJplfse5U+AY5D28sovtZtXcUUuhucowvee5bjOAY9BHYOY+tBqm3wXHYF5vPQhbdY8a5Lcs3zTX2E08nhkWVrDh0EmzaTXWKfQ7p0mlFH8Vsysvd/C+6cl9qHWFDCM2WbLxjBLLPCOa3G87j2HOk0Hztd7RHz3jo31hVVFthd9k6em8vTy9abfmy9lI2/V3Ht8lbN13sjD8b8K+w7H1v619NDZnjrfEfpT0KTSjy+LWW433fwjl9+y7WkazKrZjHvnOHbfwbDZM8xSm2ZtHc8yGnueZtsajx+ZHzzCOGzy1VLXbt19neqMb31s7Y8Vh1JzFsbBJku0MdoqWrw+ge18t/lstrvB/qFvAmlEPjXfKLtPhTJZqmju+6NE7LteuKikyvKai2UGI0m5tobmmS6b5dqLvlOqJo0mXyUVywWNTU7atWs8xznR3Q176AjC0a+4p2pQ4nST1GxqjXqw0lPl1ovdm2RJbtO/VjbpNKHyDzfVnb3DNf6VHhtHGbbJn2vqWSn3DbdXpI7S3JvSZLojmPMME2BruW1ZL5pPOpxr1qs5xTPNc51rzpXN9yxhbNbcm0FXU4wk2jSY9jFZQXaju+NXHZvtrTDPrxsUmlD5Qa9t3ePEOT2OSfMsSzDA8no6GhhmlfbceU+0so6hujz5357tG2MYxHyh4wyrxx+3Sy+2d3vW2eeOCdL7C22hbdXcP7fxuxW738ss8PSy+FEm8LxQbK9rDqP7P5OTSh8x9XWbqnki6yywzS565v+U6xjUTbFr8HmsFNtnLOkcoS6f5fno8Vn9aJFJ5p/L2qsrpKrFabpe+9DxlsOleVb9aqb08KvZVi1/kGL+0lwppWeXHWFn+2VYTSh8/+Qrx09ydVVPt4UmRVrHZr3jmY5xiUvljF1z7Pd8Zcl05yZa/Lyp9la79afy8Khdsl174TedXWUfUewdwGM81cy1tZ65Ri17lpqm00OY4jJ4Rqdl1OurD9ragmlDkPgLz7O46rrrecG9J56P19tlYLbpoR97pkGTZ5vDM0mhuW7PG6Zjb/DF7T6xkzas8vTDKelpbhm2y90bZMG0LzJd8huUtHYfOmpMlyuz3PBPGa8ZjXavl+zsSaUNO/JW4dkch7J9J/bWVOjd9sWi8YdgHn4++e+uV5vty7qTR/P8AZfeX2zbBrP6zx8vW93/DYyRjNNvDON8TQxDUnKtX63264/j72qaPJ8zwak9ZJczvmqc8+tomlCh+K0vYfIdddLliEZIKeG1cKtvijL55BsjYmdFJrbRPvbvCN7xjN7LYZL7bfGvovZlONy+G87vtNJj9j5arI+uQ4nLPU26uqchsV787pY71kOtejvoeJpQfNXnrrTl2h9ail8PLIcY9/SrtHrXXiz2+T03bsbNYKTX2h7bNQy+MldXLfGk9fGFRk1ivdl8t8ZHsSPjhNNypltkop/H298goqbznvGR4PLfrhk2oPpT0SJpQaq+P3anOFl8PGr9rvY79j3lU+MPSuq7LLLtjY+xSg1dpNNLaaNDYEMYp7f61VTcfCby86LeNz27DywGHKV+yLDqH3q8nxvILPb5rxYb7S1OS5Pg/2A9xNKCHDfMvhjtt9am+edFHwk86etull9bzbqPZGwdhlqwrSNFfKGkihkHtj1s9/VLUZFiOaY/aNu3HcEPPCPDnyWsmpo5bit4s9/sXldvK2zX+1+f083BATSgS818tWSEsvnJ4IIxhLCWSEJZIRlk8PCMZYIyxRiQlTQiTyRjGM3p7ez0jNFNP6+k3rVVtTsLrzOgTSgIIoEYRIREIgQRgBAAiEIgiAgIwIowATSgAAAAAAAAAAAAAATSgAAAAAAAAAAAAAATSgAAAAAAAAAAAAAATSgAAAAAAAAAAAAABFGAAAAIgAAAAAAAAAAAAAAAAAAAAAAAAAD//2gAIAQIQAAAAAAAAAAAAAAAAAAAAAADTnUsS3ruwAAAAAGvF4dqfMFCT0nUAAAAADTybtZyxijwe/wChyAAAAAx5GXuTzZw0p1vK+j7+QAAAAOLxPV2cgUuf5b3VwAAAAGvhfU9HYAo+ak9eAAAADmea9tsAI+T5H6LuAAAAHl9PWYACt4L2vRAAAADxHY74AI/D9z0AAAAAeD9D2wAY8bd9MAAAAMeD9D28gBjyM/qAAAABDxLXSlACtyZOzsAAAAUuTjsW8gDm8zfsWgAAACh5jPY7W4BjhcW16C7kAAADXj1N7m/TAOdDQzc7IAAA11aqfQxHRvaA12o9bVzunhnYAAxFBpHtrPWt42o5qZxjGEk3TjzWnq41tWJtgA1qxxwQ2W2nldex6Oly7llztOjI5fDern43Qs6pLU4AqwctPYxqueSv6ej5FjelLPjn57HHr1vUwRRRzz7T2pAEVetQlls0L9aSrNX6fJ6VWnvbk5+b9di7Xn528lzSeS1FMCrUrR7Tz5iw8jU6Pq6sU+mzTDoef89t7KenjeaSXObHG9CGlKlHO12pW9bPho7XtY+TYtZ5+vUxY85wcet6PG6M0cHQlisZshWqxYr62JuValz4nEvt4sV6ti5iuu+b470Xfr413xmXG3RyFGoxBiWapLYo+Rxn2uZXn+vPrT3uea5TuegxBjeSKXOnX2GKFKHFyOOHeHp68Sj1e3HQ3p2W1nSbncGT0NujZ12izvmXoSjHOrwRW9UM/K77EU+KnPuz7c7F/G8mFipRtxbVrOyXoTjTlRy686fFok25Eu1mh0taq5jlSXdK8tuvPz5JLVCXWboXRFzIZVKbS1Ckn8nW6nb5/Ugq73ccyaxR4tj0ENqjnF2hZ0mv3hHy4muddq9vWR5Ct2PQRVLe+9PFhvxuBY9bFzurtrQsTYn6NgRc+tX06GulO7vnTydbr+j158s+1HPQa8fz1j1kla9FtXsYhs9GYQc2GbHNm3tRwXNPJ1ev247UXKvXcVdLvJ83a9TDcxS3vUd9bfTmEPLrTbc+fNuniXPla/Y7WtrPB6lhS0vcjztr1MF3SrNaqbxWurKI+XVkzHrLrNUtvJVez6GHn2Nd9M3o9+JwLnqtaHQ3VJ9tLnQkGvOo1c9PNGl1N4dvKV+1346dvbNXFzXficGz6ranYsaV7mYLXQ3GvMrTa1FpUkn38dX7HeqdBWWoufvb4/Bt+oTw17NvXSGfqbDXn07mkG2LNLN2PynO7Poal9DmzijmfhcGz6na0pXNtUMvUyFKrZ1hS4p7WMea5HZ9LmGfdpnbTbz3nbvrpY9oJ0yGToAr0dJLajFbsV4vPUOx6BVnnxSzezpwuBe9PmrasRULcsMnRwEfLsb76tJddq3C1udeVHrJlG35XNn7W8m0W2sG2JruQxzrmkKbaPXePi6XOniTNOzvrHjehz5unLLppiTGY7MuQM4zkGMMgZwMZzjIxgAAAAAAAAAAAAAAAAAAAAAAAB//2gAIAQMQAAAAAAAAAAAAAAAAAAAAAADe3Z3irVdQAAAAANur2M6JN6fGoAAAADOAb+kt1NcZ2TWuDxgAAADbGBn09rk0aOMrHYm6vnOOAAAA2xgdb0HA5WoHY6PV8ZUAAAGc6g39dy+LFsZzjGe52qPlgAABs1B0vS+MjDOcYWO92PCxgAAAzgegv+RwZYB0/XeO54zgAADbGD1cPmmWWMBY9lwOIZzjAAAM4HseZwWRgG/seZ54ywAANmoZ9pyOCDOcYN/X0fNgNmoAZYCfv1uNGGTB0ulX4uoGWAAAXb+edTADsbzcauAAAAXu7jl8rABt2L+nBrgAAANup046dCqAW+hdzyuWAAAN9s5xNFjeTXYwMT0s5s09saagAGZbMm7MDXOJrU2WGcxU6smW9nOteCtoAG17eaWWLMEXezz+VcuwxrCrrX6HS14eelBprrDUrgC1Zv50h312p97nz8fp6tto8Tbcy/tPx5ppMxRw6UYwEtu3Mhr9zg3YbEU/N6kG02IU+KVrSSrNmRHWzBDVmhDN6eznEdXObMfopqnnrUkUrOucUux1sedr284ii11hh7PngmvWpMaYiuVt4fU7QeXsXYoN5kOtfsdfTh87owaswaa6Q1guXJd9tdYOjBFj028flZ95ZYIcya1+x1ccbj2t9Wseus3FB0rMmd8aRzaQW/QbPNa75u0o95dK3a6Ll8afLGuNdLfn8B1p5dottd9rHMl7Fvn8pZxLDnMOIuh1teTz7ke2mWrXlQjbrSzbQbY226fnpt5a8VizDrmfECPaTNOafQkiziPlwCXr7MWNcR5zBL3YYuZYr7TItbOsF63DzM6WdWm2M6c2kJOtJtpY0zHtHh35aXJsQJ0SVBf6kPFRWMbRTR5j5tIS9beTTOW0edHoJuVzZZYCXaJF0ulDxNp67aXTXaDl1hJ2Np8RaySxNcegm5vJknjjTq22vQ6kHExLptjEe01fl1xN2sarGNddtoXoJuXzpNNrcEeNlfodirw5od5tIpM7V+VXE/Xk0T6NJMx478nL58muLdeNNtVv9etxZqu0+IZNZIePCJuxu12202imj09HLyOVZswb6bax7RdHrV+JtPVxtLFiStyYxJ1p5dYMyz1cSx9+XlcvexXxtJtFvF0epBw9Z9I9sxJoORGJettjMuYU+InoZOZyrNZKjWdYej1a/D2gklhhTSR8aMSdCzBvNjFeyrzehn5fImr4k1jzaQdXr1uFpDtYg0STw8fUbdC1XzJjRY1im9DPy+JttrHmTXG2na6tbgQb4l10xi3X5AZu3dMwYsTVtZJvQS8zhbyRY1nxDnPZ6tXhQTRa7Sx62YOSCx162uNJNtCx6fflcPGcYwztnTv9Sr5+vhnOdk1Tmg36tXOcMbYzL6Dfn8cztrhnOnY6NbjwYzjbG2JKMAM5wGBnIagyMsGGRgAAAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABAgDj/mg/5wP+cD/nA/yOODDP7AmupqV6n3G+feb3nYdQkd1SQPUjDW7vx/xbl3cuoee2rD6hiNAR2pUqUWrjV3NHkNLTHT5I6xrG8aXvlNT/AAw/x+b/ALqn7jVdEQlMM5WmXFiVt37ina20wk9LKlXsWvrbo2obXoe0cH/BD/GfPtob8pmpK/UVJKXuT67yVuXvKl8/ei3hvd466x2wI64oO05C3a8s1D1Zv8in+AH+LPT2xNn691IAztnmrXKXgVWlATqJIn8M8SpUnWvlI6PvVduETam7xyz2PqDUW7Gzn74f4k1NbBvuudbrOp212C2qKR1a8xzLqWw91/dC3NK0tpIjt7DyFdr1/gbI2clV2jqvTG3UVvvB/hrr7h2VrLXjlxY7HZrjD142PrjE1iA6ZY3pjQ0J7GuunyU6YJ3ppkoljbmjqYq0JY6xZWT0FNta20Jtn7wf4fUHs7T1AOazz9vtUBXZayVWjUvp9bM+OP5ex116dbJT4uxyMe2XqdqZPFM2rRtJbK+6H+FsS50qAYNrZNXax1iCnrJqzQcdGfHJxW0tBQtgdtY99XJ9FedimLyFl/uB/giO77prany8jabDEMLDO6W0mAfKYu6dIQE3MR1Cs8K+OnuOq9NF6+4H+DuO4adrCmW+SuMzIO9B6k4+cQ33qWsz1widaWaLdvG8olBy32w/weoS06zrkw/uU5FG1Dr1Bv8ARdNdsUSGdwchBv1ibvgOma1fbD/AtczQWKeXR3fZFsz13TR+ntCkwzq8x2rpuPXsEZqmcKP2g/wOpax6GhH5rXILr9NtMwfqdRVIiFdbS0Gq7DbEbR5n7Qf4HUdL64h5Be9P26Wvaz9XaNYpz6wt4B+uXesZ0zy/2g++c066j0rAttBxpCucfVENuQd3DWkgkbZsd0uyf2g+/ZHmqW/NsNs5bphr/wBfqir6iul3EWeZa6UkPtB9/br7Q7VbLSN/PqKM+vv+Hr6mlloQyxYpYB+yH3+oFbp9Rc5ZBsBIpr9e3MYMNRnhBWy4kYqfZD7/AFGm6fCO8n8TKmH13iahNXHhccBtIleP9kPv9RgdPuOxnMQEn2DZeyayGHxbNvZWftB9/qLHp+Muacx+6q9n+vYZ+wSGtsh8OG38rBvsh9/fV40GM1uNLaNka68t7dx9bet9lc1wm5t8XtzbmdP2yvsh961yOr2ledwtfnk3Vf2tGaBsn1diz9JSpUdKLVfWcrRSQ16Rr8p9gPvb1e6tR1zD0ym2fTkaRtA9Lcn9XqWkWZqc4pyENRH9St6GymvT/J/YD73UEGkFJWx6tlFCvHEew6fVvq9UwvVK5JbiyKerJ1WxbOW6bM44+sH3t8J9PylcbP64e36x17F1yhvW7v6nVMD9RqtfKjHXOUvkJV9/o9Noc/XD7r59sXcvT+hWNeiwLHfiNULTBuCUm4fT6lri8LTI30x1XWtXs+suoJrozbrZx9cPu9TVk1XBahkTTwz4zwzyM7eXZ0emaZ+ltO26Uo29JqMlfXPXvXy2Le0w5oXTjevrh93qoyNPVbCbcY7cNtg20R2ZLr6qU0L9Pqfd62LIvibbDbobeLuFPctwvehltXfYD6nOOJH9j/ZgsoSfqPqPVGsxDRkCTWxKCSoJQvUM2dutQ5peQ/af2n9q/av2r9q/av2r9q/av2r9qby35n5f5f5X5fVEvQ8HNN0M2px1AbTm4taMq/095rkeeeefph9Kfus91NzXUkvth4+CM9FLCNoYtdViZNqyyNYfr/oHoHoHob2K1Fj1meqN6GXV/taGq/ar2q9qfan2p9qfalHXH6F+hfo36KekzcdRMTTalUOLNIi7dwh09ZMLfsf7J+zBdUNnseoOK6oYfqbgNuoOflD6Fz2dcuoVpX2usXoqWoLZ+yfsP7LCXj3NG5T8yzyrPfWwmvV/WI9xYJLUWN3J56IsjC2o2014VugXRG6qX5xcG1yRv728HurS9jsZW8r7C2HL0cIxQr51MHtcTP8Aqk8+6eckVfUgkvUvUBdRak7VG9MPXYq01LqZq2wPjD5nLrZXUORmIxme0h2pNie7o7j94h257rH2UbYFnlWJYpcJc8t6l6iEi8d6lEqxwXcRc1XZ5VzPWdvaYOcdSspa425MZqYtS93hrieYmra3m7EelFKH5YPQf+ofnrvOnssiEXDFqZaMFB9uj6nU0o+1M6FCbSqDhjrrqJj5Ltx/QfLMzG0twsoOObkrUvtMYFpCMmcuzY4/cifxeLxXMNfSWz6FBazDVPtX7V+1e8qXUbSjnkwNQ9uiQ3t3MVD0z0z0z0yOoga8Csq65cwPpnpS0S8R1g82hr6s6u9pfaP2kHUW56Dqd66Xhaw31e41svrktf8AQE4ppYG2312EpVUpuTrWvdnVK3h2H+g+SRkdq7PjoeuVKe2G0gwEMHPDBHlx47GLkgzql22Tcasv53n+b5vUAqmcSxqKShbIida1HW47sZqPsztVe3rL95Vpr3YO4LTVFvM87zfN30snbiI1ScbWkU3N2WW7DhyvI1lLKxqT6Siqfcadbf7D4zn3jtSMYVOuW65M2MdCuIb9YdshFu4MbDGi20uryGKISJdfunTl/uutbl56gnTRIY6LhORKhYQDByux8uy7NnFok8FSNhTUZ/UpRAUDtqKu6cvtzwO6yH6gnTEixGhY5zbXwAY7OvqVRwgXBxxKO4mMscjHSUHrbYMTK/0Hx7+2XCMY+Nv08yZwEU6OQay4cprJgJ5JtQmulbLC1WSlY3HKtUrujJneMnSSbJr+rJuzhdWZs1+rb4MO441a2VpDNDFzg3apwMgsoekSFzg1hqNX0lMbykqMpsav6dldnptioNnzAQOYT1uv22bYyEiDpv4jFjkrEFMm5qKnYzp82T/QfFcrPJyMm7SCBYqiLsHEBW3aEIe3vq/p6skXljOtiBPMj2k0M7U6e2g2TakNVtn3S+KyuvybuZAxil275LtwjWELmodk4e2F3XSCOHFF+s/g6OmpXZCULp9vrq3bZrda2rar4vLaRUtTRlI3g3I5CsZe2uFpaLSmrGZVADw0kJZhjXVId1YI/TF97KHTUwPi6i7zDtdbQFwnOVARZqQDd9HsouJty9t22o3c3FW9tCbfaOINd/Im6fW9BhT1uYsEJM1PVO4EeoBs2dVmuzLUnblpYmkBIR0XHv4B1LgA4csSzeVhCRhK+6Yy560Or6j6fL2+HsFT1S5NupnCsL0bnKgL1GLkZmVZx9kN5SiKLkGUinW53fVSRU1Hbym2Ts98bpvffFe7KmebdiWusTJ8Q8qZRWKhYmWln7bXMHuZmlXSRGgG+33Tx1xMq6tJoRtijJJIc3cy2cSNHXgWOZEQZ9iGfvaw+VVLgmWbZCTB3CtYgo+3WCcG1ZqdoUTsEk/FtVPqGZwz2QdlKsiyd+TOEaBJPHZ/JIY+IppOpdnpyU/Cn21P2zToTZct0+Q/xdTFsh0YGJ3PJwDaZaqolxJUJ9w8ApIKg5vlmqykXHTrFWp5gjNKKm0qz/jYbKPyAcsnPJlSsElAHlg6tD7OWCNmjE1MJnrSyrsZIu4T0xH+N3oboRanAaihc0SjFy7uwpTj12CboXEQZPDE50tN9QsC/a15kihdAio/4XK9tmwNoaPgHCuJGfy/PdFZK12h3sGMJboWrmQrwZFQdqS2sfXzTtxkohqIrArMYJklFkVUg7DH9g7VyupQDJdSpzEf2HFhZo72PGI4PYM2qykQjzVyGUaMUJaHOXsbEm/6w7EkIuQqagNHW6I6GXVVf2fp+rPxbssMYlKqNwgEa8pY1e6EeAhnKqGpLtY4xqnvmwRLUqKiKBd8LwyH8GJqrJ5umJgBYFhkBain25IdhMzrhSWAuBhsHKUjuA5A/i0NtZgyBieqv7g7OtyUwmcHZqKWF62VmlUjn8uVbVo8Hk+hVyV+E+LqfnYhN6w3ku3IkdQ/GIN1pSWjxFMcsDaYkY1WyKjUKfIytgoTfbahCfwXGB9vMjkAcPKlypWzYLxlFjV6XLTVlDJKwB2HEEXiIjqJvazCH8LJ6UVl2rIUVZN/igqKybZn2WyQkTCmgoDpgvnT+8ctlInppf8Axc7cmEMoDTc70QAMEzVtEJmMyfOYoDY8TriOt3KTe72GXItmk2cyJ/62LnUGzqcY9jSm4EPE8T18jd7XIlAOOwGq9Odqz0GsTQrWNAf5LlLHarGPMOBnJjNyMQdMgEQWI1ZET8ajs2dNjvYTSKitfyBTfDYXrdy+f6FY2Zfu3XeKeiR0wjCEZv5PONWp6gT3gyrBZV9IG6e2lPw39b6T3elVmCDt0uGDnGvpUiFfZzMjgYOM0nqQy7Vgq7VT6em+uAwP5sinUE1rpHyGM2kpHefKwca7kG5hb4guqtG18xXsZ08Od0MnTiRNXXvw7mla6yWHRaLJYWxTc54a3apVqrKnHsUddDr1HbsNUZUoWJLQSOlSD/AiGb4bWFenToB3HKi2u6KBilOjggJWbuuyrsky9ll9Dp6UL/W6Et/toZ52MVnJxzE5nj9RZ0YU4dYEztk3Hk6QW34FqeWRLRkj8PU08reT0lrxOoM7BLCL6K7GJHg6dD2gmcsyoQajRsKT9lBxV8l9QZqGxITBTeESrvJW22CfsKtXT5MIxfjMtRoYLpOy1bhrDNGNJRfZNVOPevZwNPjpKZTW457On2yLLtlzWxio1whnEbIKQZQLipHiKGIjIxkTWl2umy9QpJd3aE+mV/8AD1RycK2sORxKZOpps4yZQGPKfCqFzhrWGEe9j6I11PIy6W24djbXzCFsBkEpmHsBJNSRmplFtOWpdZs3McEF26aUNbzbN9xPcSSvaQQbC3NDJAOEXAJFpWrW5goq7x1sC1GtctbXEo7kH7+GiYBlMRDltwYFHQlSJX0rQmoiUSzLl2UNTH6h8DLITpaW+HqXXjyWAXoVwIGcCfYx61kmZHkBwp29sZST19RnuvlHoTrOtnGQlXcfXK/sp3S4bYU/e4epWvYyDJggIVt0Ekg0UkLK44DsOVuY9XhmbyXlVuw4xdzZoxlCXx1Wa5fbDaWMDZ9gs0Eix9nMo4mpWxAA9jBBOjumaDuVMbsGanDf3acHpgefDvt8zSn8m8r58ZnmXaRB7JRqzbnmBd2B0weXAsnKyrmukOR0XVaxYPlhPtqnYrfreEnMROBhwoKyKZQAQYM1C4YsIpbXKaXAn8ZVMchqQs9QoS2KxDOn2S5axgG4tyAFZeTbouHO0jTVVUpixSlqWIVMqVfUryiOpSb9wTSJem1z2D+hzZLhq0tcfYcr49nDsMYsWEM+ttfsE/WwzwgEsyqUsxj9k2VmgUHmaxJruNdNbNq9hT61WqlDuDltL2nqpDhpcADFlW5ZVMp8MD+UAWbZhUlrwxbzsC5zU4axRnoCWpjaPYVnWklAg9q5RASgY9Xrdtmmc0qzkY8wOnLdCPjp9/FyLlDUiO/BjHVkhtGLfAYbULZvblLLkCkQ3Yw1sHdwQJDPIyzzDTOAFNo/2lXUJGDIZ4XX+aoNnAiUKNkpgng7Zdm/dBKLhbjI0qUkawYexxpqMtdESQNg/NVHU6lBnOxSyR9WIQSjC2WNn2bt7DZHsjNVglktKmDlUQd2IpXjVKY1Ibf+R71SR0p8MiqVSaRnkLNlSmGzVUmK5YSmyrST1aJQtRu0RDSEqSIkY2PnXRXoa/W0/CjXBrwwIQdJkJxKblhVK2JgYUW9keV2tyEk4YV6Us3HCuTaYjX7Z51DbL5qk2vUPHzy9Pq53E4waWw3aNWtcN4JixoV24I4OQBCjCSM/JZpsu/cLjVtpT4Z4zEVWFvbWUKixVf84YK46f1wAg2rOPdOA7CRpLz0FHsJNISuyU93o/8AgBqVVsWKp1aIv8kAdhCBsV5ykPZWX4wMEKHKT1cRVo7W3yi4aZi9X0oIsI/8CRR187hAKd+7DDFOWrzl7YJnj05uT5XaVF67gJVJAqTDUWb+GtJWF1o1P4LKMaDV3dHVjyulLg47Z41dMp9xTY1hMzxSwkUql4RLFPWaRQIk8zW8PqaH47FzVKjxBOsyN2Ocwmq5TYOQC8/3TTsEJnEVfnKSl1cunWaHDVhsDtKttX1upvJWbyssbix5KZpdv3OQkxxrlkaEWjLHLwzSBeyulQ33icvJudAp/BacisKE+FlLAKIqxSVmRKfkSgcSGFJrWmliZDgmMWVkM5eIa6HSZ+5cpMrYA8vhJJOoGw1T8Q4UTqYQK7D2lstHFPxxwYTwGiDaptPeZPqOUiMNkNUAiUG8lSvB3rbH8JkDhvIplXUX8Oki76wAfZ06k+C05CJuW09ljytqxVcRhWDo9dlY3u0WZzkk2/JnZkvbhQK44nFdVvNXTHcMo9LsHYMhZ1O/Fif3WdmB7iFbsnrcVHObNKve8e/cXPRBtUE7vVqDLw+DjR/WZy1yrqWAO5isl51wGAGDg5pLN8iGSA9NSXwWrIg66s9liytA3XjpSXVUkgwTed5wCclSUsiglDsYmLIHHVhdXJ9xzVchYjSVfzgcPPkBvQ39PAeY+qS9ciHNueES7FZdnQaHS15Tu7tGkVaGSVKUzF5YJQOxjNa8Q3Bgfy45yGGJzpLN74GSedMKPwWvIvE0bI1sOVo/IDJzeBkTSn1njyztbxk9MJA4hmtgEQOZ2trJrqKJ7iOvrGWOjJeahueORCtymxoit12QqFeVABK5fcYyZnmH0eAOg0TmkV+82XTBa3Kwc9Za6BsDBGEhXlgsUMBuwni6/KSDGXfx+ks3ipIN5gelpP4LXkMmVrbRsGVaMKfw5zSo17ZEgrbllJPmmHzkcmWVax40UXfJa3W08/8A4oEJJSasU8unoB0+xyVl1RoWXcWxTuZSMiIZNTHgSES4NohTVtg7zDnWtmr7Bq4hpsSdkIFpdyRjG7KQyzUciGclOyTkpgltKjvUjQLIz6WEvgtWVnJN9YBncpUus0cNMUyWW8uoRz9GFPcgwcYxTKRnJwE5CWkotyXVKutlu5g1ZCyUOpZltfqT51O9JkrfJ05A62B2YOpF56AlNo11kMw70QlrGqd5TNdM6rL+CuRZ1MZv3MolQEbVHUdRZ4+DKpi2Q6tiX40rm8cI2szTpYT+C0BWMexViLN5VcRFZYcEK1j+mECEioWtSrzszshYFIsvO/qnrLsuqWFBgO581jY/zW8LZ7AAdzZQGNpjrAABNQ4ZzyJKldpNrYLRw4zR46Qed5dtqyAixqLS0TAF7CFYs9jYTssBcDIV0/hJVuCZGemD70Fq+si3S6h8FkCIOwkrw3msqcoUvIDkZJt5NzTa7X7HailIXsmq7k6kjZbDw+NQCaf/AIMOuJWxg4nSBhzkrRDMKzAwLSLcUeOqCzlshZYbsJY9dRbHGaGPr2V7zo6gf1l+6sQAinY4Io8GLXnplc8E9EmCNm5WMawz+S0rm8ccuLAPTIn8E4WNxI9okprKyORrWxxQZx4CSi6oFyoxso07Rz6xoFDhm3qK2mz9xDXMHYcMHDZgFDI4PRVR/O/M/LVMwiq/VrA2dVgvbnOT1zRCes4LvMO9b2SKziNhW1FXenoDhoOcY1YsqzJgvXVMSXVecaUzegojPj00l+CWBqTzZ3JcK0LRjXIixNXMAU+c4wjm9DVfv6rK1wMMVVbGNTcV2gL6gX57HLquu2LBzwxM8nsBONNfJieEOwhEXRpZmrJa8ykj3jpFxcdKhoxv3lD66PE9o6YQvCqTi9ruxHF1oe1Ft34a1ncL5wbNJDvTtPZ04ofA+K6A2TgyY1gY22JSrdNxbn73uU7a4QrmUtsjPl7gZldX9k1hH67gu5x1NNWEvoqocjhbAUAA2R7aVYCPMI9uUgA8isAedjrNEL68tnPaRaa9q0I2AcKaWsMe0DXs1C8nA8EiWffruUTeSYT5pLN5YGTw6AS+BYJ1NYJrJLK4pldc3F0ACLBgFJkKqRTKzNnXjoazNfEc7aoyLIjyhJ6ZQ7mHXtkWkRs0a5n4PPGAcqHbtkG4Dgg5dZHx7SAcXhjk3Bus0Whr+o97AXUi1YmJSKKbjDFoshcmbOvyNfcv1RO58LR1+SJDZpU+7FHic7mj0/gMF6STJbjP8rinj8bh6LmGbDNrPKnZbMuk/O4NI1az30lXj5kz3AI/zXzzTr3ubNeRVkVUaxlqkpkjkVgOL+JeWe0wNkm5k86E4WV/MrLuSvpX0DaHM6o60gOlFO8y8oVji8gp+QREwpFOwmLPJVgjUssubDKiVrHecs6AdOButJszn09Pk+HbaCz60KOVK81KqkAnMo3kzTzOGZvISxPksFRTGyIx7aVkrGm7cq05zqeVAewhrKsWoF7lwkgnhxMyZLqwjcz5ySPVmSOPIFKUUF5FWn8+tOju9HLansneWzX40+VcPY9tKPRUByo+hZ2dfx7pB4oYEFYfwOHJGypNPl3GXmbNrdH4d+Nl8kXZsrL46qpvyRXm2SbGMtpzVtGTcic70JGtyVommzgFPE9NTEtbN4xbsoGpXVnw68CnY5UMOAKqnYO5h5BPpGwFeHAseDCtSUymRxAp2A5i6OJq+B7yjehV1lkI2lJTwHTLhlICTm8ljEAyCiyMooqmxeSSBNTMtvEVVkzVVv8AD1JsWIz0Yyi4ZE7Tj8sXsCs/jUloY0hYhdlOBhUgEnLCYeRDF08cqVQusS1o3Yw6/tcw/CXf2Ay5XPkCYoGI0QeF58YEcN26pkWtj85eyHMq40oGjEO9iR1gpAoyUvz5SrBIAOk6FRwZNIGp2oY2XQaeIU9ZRW1WfmpkZB8PVHHx6cy0jncckVNErhwMiZ01m3Cx5FVyQ7CO4ZxKjgsaEXKKAogjUVNeuawPYc17FWjDCJhMOHSRA4mA5xEAAYk80Q6INTKhKEkQXVd6PX1VY+9pcUySZABSlbEljgQiys6m8B9IP0lpVcHpnRyHbJJanNttoB48Gxfh6momMGSSh1o/DGgQsT4JAVvxzpmDyPw4/H7kVfxxMQPG1jDMqdmvi1ceeTDq2vW4vlZHMzx6coaPk2v5RV/MMMUgdZk6O2ckwzxTIuO40+91eTve3lLXjs5ZRZI1RU1eWTHFBTdRbU0OmopGHUUdeKNYawU2+qA0tAA+HcUSyyQc18kaMMzdN0DKOHIAfzPOh1Wzh4kc80p5QmMqmRCzPnVMR1+0jJD17111N6vslmw7YuGL56q6jzx+Lwij5Rci1pdyq6IZQhSEw6ah9Wp6mIWxfsP7HcZmrJMW34jSQLPlBWwOHJHJHqpARZTT9yo4AoEMfnWpttkE2ko74n7WZYTBamZo3KaGCeSEqbcSmS8kxgcRky/VFYB8IODKg3ZOam5oTzOOHamt5KdTfNBwREFpNTGziQVB8o9ZzTyVRkH8kDoVk8Ih5YkWLrMNZJiAgbLCzq0bGNTMwUTkpSSFwMgDgjQmJuSmdvBUZsHcmxM+i9aZtpB6j0xwfx9SFVXe0oWhVFUHa7wy4vgcODqpppguQ5W53BMjceKfkdqarST93Y6+SmFkVHLIyIomQ/HZKTqcOlJO3CpGI5+R5nEXDLAqyxfNWq0OfHBw43VWorMnjNy8jvKOkUpViIC4dJKYUvMSgs8FRKQTiNel2qWdNoOsfHtGnukKCpKIOz/j8EVMozRbHlIA8YKA4YgoJoSDZjHmOVRYlczXH8SBNVx84qvHLqJxarDy8MLOUaP4zHzsRIILJKmW9aRjwkCmcJazHWDY2cmG+P6kLQWKiYLs/ARVMrcyrVBqs080FmrkG8XHGPGmoObcNrmnNm/yb01BUb9cZyQMdskskyTB3KFZKy6TJzHBh3KDZvO8pAeRVTchAutdvvVfVfVZaW1jKyaH5bmvi48YG8XignNkcCwKzBACiAJpKtGhxSi3b5cKA71U9GT9TNJXJ5U5CvguWNK/DAU9UMk1lU0i4s685g9IwOJTRy1Vs4k1jrv5TBfNDSXTf7BDoIdB+wnsKbRXsd7Hexvsb7Hexw6N9jvZH2S9kfZMdJ+zHs37N+zY6d9njal9rPa4dYe13td7Xe2Htj7Y+2Ptj7Y+2PtiOsfbAdYF1gbWPth7Xe1xdXF1Z7We1ntYGqg1UXUZdP8As2Glw0qGkw0j7I+x4aODRQaGDQnsGXQJenwOnMvTdCdL9TpH+jxxxxxxxxxxxxxxxx/9IcZxxxxxxxxxxxxxxxxxxxxxxx/5D//aAAgBAhEBAgD/ALBzkvv5L7EfIhcZ/wDFd57xGFT6/wCuOgUMVqvc/wAMitW4KjAurp12mpONO83+C6u2qlTAx+hAUckUwUbX+BfnqQCGPeSOxEL1pf7ieaSpE35GPkIfFz/3XpaoC35GNmOIgL+3yZ+PH9HGyNI/7fIF44f0JeQHxZ/23F479XXkl4n+11bXjv28kvE/2yFKEKB/zI7AVkP9llSyV5YP0mUs8Mlf+y0/yJLVGYS/F3vyQ2PkVv6yUcf131sdWn+Vopqv1v15N/M5b79u9N+zsJ6aeb5Pyfk/J+T8n5TWLT79nZZ423Yv3d93JZz1iqq001ro4fi/D+H8L4PwvhBTsDjr67KNdm+4y9jF+buRLckI4QKGJ5/kePljCVyGMdncxjbIvaivSfK+VCFh+yJZ4yB/kbopCGN9NiESEgqqhESaXRGcchMwnIq5+TGKOxDCxn1yzbRyYF0L/gbokB4hWjVuJkZiASrZSimQokJqqjOIZJISLjGocgQ8PL7EpDY+rQX2Zw4mVk9qJRrrKUXIQE5I5Hi6oxupkxVykYZ5I9QbdMwrev7E5KcQjQkQkp7cHBqTiu8SkE4xYCIjijhTOS8hw6qvZBogBOzIOCWIofWQs8G6Yge5GahGVy4jeJFJiYGlWFIYKV/Jc0ildhd2TPgSUiI/Y0PDp+GQvdUaBTk/MKKNmwgWSYkKmXkefH8kCFYHiZEh9XToEcoy4YTMJLyoSRMUU1H4sFMQMjmeQYMFJFM7AxKzUKtHVggkMZmLGzSPxKhUfq/EKkiji27nZgsNTEk5LRSSGJRBE75lhirpjBdpAAKQBiTy4612SuLxepoFBxjUxh4JBFsSlf5QFOo1q5uQmydsGNd5EFjvQEpWxGsaqRlW9ZEDwJmJBIo+HEZMKxL3V5JUHBCgBmJDJI9dWJe+CfaFZmW8C23Ur5repoWqqSQJCj6yKOVi1RvY4rFJGjmCQwZTTxzkHUxWuK6iUhtLGfWROQt1TszResiZVlIEca3IAhEWcmNT8VmM3YoUMhSSQww5YtbSdV1AWwwsxmiiW9hCovWVRlXfmQISZEWQKZWOK6nQliUNxbCM8i9lOqyiRJkUiE2RLWZMovWVA9fkJXULomQKdTcV1OgBnd8gmc2IUA2k6rKLlwQAtlMSj9ZEI1kZC5w9LIJXbRGrHFdSMRHM0jVxiOaOfEY72uKqiRE8oG4kXatJ2FB6kmVZSKNCsSgIgnaRlNxWRkpIgjJ8yxRw7NJra4gUCdii3ZzXUwqygQ+pISqogEDN2F+oR7I0ascQKRAOuCYVq7aSBArQqsokKZpY9oxw/FhCh9SWtbgmBaxLE7R8G1sFXRoedWHVxRKMbXFZRIeRTca4sMPuTV06ZuohwJyoEyJXOKyIdXJa4MwJw68WuKjRBjYkMeNuJ1H7m0CchLiUxIeJBVkeivGiHrEE6KIIm4xbDpqRQowcABSBoLZmUfuSrrQRQuTDHzI0nAJ0ywbcYTllTcQqJMtU75diHEyh93UUWqdarVx01MZIOgY3HGuNRDVxxhmlj6IYox60TdeuMamEYfvnP5Z/DP8A4t//2gAIAQMRAQIA/wCwGOOgPjfri8edNx/xQGHx0dVy+a3kGudU1Gen/Zj2jjqUZZCdfYN5Lv6YbksF6h/U3D+ojSpWbBlPff0htQ2wlZeRpf1v6+MgkklnOT2zTt15ZI7sH90YVofI2pDxy3D8M9eWjL5et/Q/t42JnmP1bh+a01aawEw/0Y9PGB5IvTGPaOUH8mHpjH8LcP6UA80fGOX9oCov5oOW4f8Ahws+lMfOPxnOcrHoC8W/m/TOecfs/qyqLznu3D+gLxa83/bXjjOcZo/VuH9Ioap2wMf66KlQje/NlAiERtf2UBKGOHyEbj+ItQUkXXa/rFo538399Y8hZH8a4U7/AN19sRfy4aLp6PjtFOHx/jBDZBqP1/1/1/1/wPgfXvRgDrav8esuvp6SD92YIhEW002NSLu7iMkFxvIfY/Z/Z/Y/Y/YlfjIJBneeB4V16PG9cq5h+YiEQh1gndaSiZDU+D5GAShcSNa6i5k7EMZ0IXo/AlKqOhNoifSaD8om16xRs5tDHITOMlqKXyJiurOWFx2Qxq3F417NilYsKIGIAUiy4hJKH4RiLCxNmy9eUvJE7qFBF1nASDgX4NCiZlcXXKEVeyMadPxK3EoOyCv6shjiHXbYwYZBdnUCrx6XRnW8ceBLZgMGJ5CVJtNbbRE8YybG+rIlq0N/2hFRPzlhgqSJ2hQMrI2FG4yEsCgkklZzQLx6dYtjVNzcuHT8EJK3Z9aw6rOMOMo1TjawUAhxI04iLKMup1lDFIMC8bzcGAWWMp1jDNFD7RDImZDw6kXj1IpVWZuCU8YG3MnApkagbx/N9g5w/DjmJq5l7CpEAmLp0zSBQbyMUiilhtM89mWcBGLDzoIjAUaAqloJJJrE4oo8LXTiJhU/qLAplGZyLXMhVCuIFGGrTEoY2IZSNkzBIcrJ2kQwRlJMYAuzOjFtjSHiz6wolLy7i5p1Gdm1rCoY28fYCBz4EcOxcZB52qqamVc0bKN3TkTbYhcXu+sKxNwycGUjM6IEDwFtZeFGyYmI3TNoLWHqjm28il4jWpp2aNQsLXfWHidABgB9rCUeH4BV+LbQuupwF8gBRsWTCDiypkwPEQIWxtvVWbXrCmVhBKUi1CQzTraNQcWFGzIZUQgEZyysnYirrFhT8ObcOt1rU4s+tdsTi3IvKLJmdGoFBxZUSdsChAn4ANTasnVlSpndCKfgWZ6zkrPrWWLHGDBS8C+HUChTqyq6IkXBrOwupHrJ1ZeVOKEnRksKtxP6wOx2ELEhkaUkUbF2KNoeLahIE0OHsbBEcTM6Ia/FlTIV1mDEzPHneq8ilf0iaN51GpOQMpOAJlDxZUQIZSIWZBIZsnEigZWWscNLrjPblVEbS+sKxZQm6ERIl2ORAZxKDi0okR7LbLuz7gdhVyVp5nJ9opXRJ0LqmjUvrE7HaWQIlsazCRkoVDxZUaLnbKFbCpSrcWVZTu7islxnakpHMvQXje5z2bkWsbm7qFRcWEBbY4Z2Ykx9irLNp7BZwLbLHFJS+zKErqZiHiMXEnQPGouLKZC7E78MZHxmqsWVZQluZM7EnWKise8D30xbJ0L7811FxMm9McYYcEqidW3t8bJuHfZnrK2XsJWbfa0nb29vZ2dnZDLHe+wms9nZux77btJvu5wWfnW7dmVpNmPs3337I7E0v54WuuuvtrprjGvGPTVa684/HOc5znOc5znOc5znOc5znOc5znOc5zn/AKL/2gAIAQECAz8C/wDk1Bgd+IAoTe41z/oop7jGt63q1O9uXQK1+8d/aFa/eO/tCtLMSHdQn+1CB6FQH98GH1wUKN3Htd5/6QDbyZBQoN0PtT9FabYZAmXhb/yo0W87vXFN9olygs9gKGPZb8kzIJmQUN3shQXex8kPYcR1Vos94v5txVosxk7fGTsVBtFzuzdkf+VP/RkKy3DffkFaP4i6V5HhGAXGKf0hMgi4Bqa1eSHFwUPxKH4lD8SBweiswmuUOP3mgp0O+GahkVHsJpN4HsO/woVsG6ZO4tOP+iQwEuMgOKMXs4E2t8XE9E+0b0TdafmUyAJNFIQGCa3EzTjgKUPaiJmRK/Kj4QvypuRCyfJPGMnJj/ylEYXoOxUO0C8efFRbE6psyBg4cFrJQ41x4P4ean/oZsBpe8yAUS3uob3ODc+qEOTn7z8uAQYg3H5IuxNLUB3RPmosfM/sj7RAUIYklQhwULwqEeChnjJeF01Fg5rxia8Dp8k2JjulU9E2KFTN8IdWowJQ4syzPi1BwmLwf9CNgtL3mQaon8RiUt7vst/yULOL73nE5KnBcG/NCH+ZyfaD/wByTWY7xR+EJjcXTTMkPCvyoeFMPJNODkeqZE/KU+DeL+YXCJ81L8zVO8Kvqq5xIYk/iM0bOdVFO5/+p/4U7/8AQVN54I22Jq2fdg3fmOa1Ame+ceSlcqt1uHEqW6zzKqvd/wD1CGL90LwDzVotfda537KK77xwZ0vUEd5znfRWYez9VZvD9VZncHDzUI917m/VRmdwh/0Kj2XvNc3rgvEPNTwMwhEvbcck+zGXDJBwqYeoVeGKq6qfasF/tBS7CIfgJ4cv9BU9gw3nvnLkpdq7E91Uqe63zK9hnmVxKEO5t5/ZRrc7dvHiPdCgwJF/au54INwEvsGvucAVCi3w+zd9FGsJ3hLnwQfcbihFuOPAp9kf/wB3oRRU3HiFVfxVX+V6O7WM7rj8ivS4dLvvGY8+f+gBY4TnnH2RmU62xqnX3zcVQP2VNwxKoFLcTiqt52CnusRiyiR7m8G8T1TYYk0UgfaNiilwDgUYM4kG9vh4jouDkIgpPkU6yv8A+7wg8B7cCuIQitLTg5P/AIbaPhP9zUIzQ9uDh/Xzao1De6wyHMrUMA48VT5KgF5xOCMZ9/mVVuMwColFjC/2W5fgJzjQR8TP8heyVrm/mC1L5HunHkpdDo1rKx3mfssYDurf+P696NAcR3nXN81rYlZwb+6pCmafmta+QwFwWqbQMT3lPt4o+Af5/BUdvDF3tjLmuHEL2xxxWsbSe81VBT80bBaJj2TUOiEVjXj2hP8Aruuj6sYQ7vMrUw2jzKlM5KhpPFyp3ssEbbFm7uNvdz5KkSHD8EHAg3go2GLd3HXt/wCEIzJZo2eL0MisDwdoqYInFuKrY6EfYw6H+uamE9/haSjabRU6++pyk1XBuaqfT4UXkNF5cZBCyQmsGPE5n8ILXBc32he3qjBfI5yKwfmtZDlxYphaxrm+II2S0tnnQf65RCEMfzD9At1z/EZaN5x8KqJOa1jzGcLmXN6/htVE1rcImPxLXwi3iFq4svFcuGjVR5j2rx5LXQYbs2j+t12inwN+pWrhsHJYqUN3NTkBibkLNBYzIX9fw3pMB7eMpjqFREkeNxWqi+c1MNdmNE2sf4SqoBb4Hf1v0i1n80T9lIKTSrmtWvtDcmbx/Eej2l451DzVQY/MKqEPyq5VwH8l2j25tH9aohvOTStZaAfNXK4KcUDIKTHxfEZDoPxH3cX9JVcD4CrnhXKprxmFqrU3maf61RZop/Ku1JyCuV4U4zlq7NCGbZ/P8RrLM78t6myIFvuHJXaNVaxyi/1qVlfzkvvCsFvKqO4ZuAVLWjID8RXCiNzaVIuHJdr5LHRTaT8Q/dTA6f1n1b9QW7E6rBb6nav/ALB+JmD0VER/Iu/ddssdErQfJThs+Ef1n1b9QW5E6rBb69aH/uj8VKPF+MrtwsdHrB8l2bPhH9Z9WPULdidVgt5UWgu8LwUy0sD2GY/ENs7C95kAtfFe8DvOmu3arzo9YPkuzZ8I/rJtMXUt7sP6lSEXkUxhpa0xCMk2I7eBh9VVHcPEU7+Hx5Hu4OH+VUJjj+HNpi6pvdYZdXIQBQO+e8VKO1Q7POsyUCIZTl1U7Q7oEQfR4h+Cf7f1jVwnuyaVrYpcb7ifmn1RIMP+Y7HIKFZGXyGZKs1quqbPgRijZoza8J95AhsUdFrrOAcYe7+G1ECI/IXdVNzojvZv816RFqPAzRhWk0iZ4BDvx995zwChRhKkciOCMO0hjr5Ox5L0a0B7brw5a1jX+IT/AKvTZYkuNyNEUjFejMiR4gk7mj/EnGJGdu8GqD/KuKMWqzRe8O4VE9HiNeO7gpRIjOBbP8NTZw3xuVNncfEVqbO9/FCzQzaYl7nd1R/4gK3xKBwAUexbzHl1OIXpkNseGN9tzgEXQoT3CRwKL7M2fskj+r+qv8l2caWIT49je52IdIpurb0TW8Zkqu2Mp4YqIY0YO7jm3Ki1U8iPl+G7OF8X+F6uz4lqbOzdrrdJU6gYNmnAbuCuNWSMCHHLc7k51khl/eJC9W/Uf6vOyxF96OSs72RITL5zmo9hJoFbFaIlzYckYPaP75Ub0ovPcK1VtvuAe5B2Bn+F7OF8f+F2LOqiw4Vn1YmD3rpr0uHT7QvCiWXcitNyfaNyG07yg2aGIcc3xD9VKzsAwqC9W/Uf6sGAuJkAn22qDCZNmfEqb4rTxaodmnTx4oZpuabmmjiq7W5k5VPx6q0/wh4M6mf7Sm2uGHt8xkfwjIlMJpm5rt7knBoBBGS7GH8IXNB+Mig3AAIWggnFqps7OTgodnbqol1/e4XoOvF4P9VLIbYY9s39AhBs7ne04TJVMd/OejkuS5LkqbWXcwvS4Dmuv3ZhFsR8LMT+X4P0WA5/HAdShHLo8W8A/MoRIjAMApMb02a4TPiUO0WUOYJPa3FEzgOOHd/4/qu/C+E/4UrG/wCBGzuqF6d4QomQUX8qjZhRvEPknxe0dx48FOF+heuO6P8A3/ByhMGblTYwi55PNRMgomQUTwhP8I+ad4B80bSAKZSU4JClbh8b/wCnNbiQFD8bfmofjb81D8bfmm+IfNNzHzTcx81N8KV9x/wvU3/CoUaKRFlKm6asXhh/NWPwQ/orGPYhfRWUcIX0UIQBRROsYSQ9CA41Lsh8CDLY6oy737qF7xvzUL3jfmoXvG/NQveN+ahe8b81C9435qF7xvzUL3jfmoXvG/NQveN+ahe8b81C9435prsHA+aGYQzCGYQzCGYQohfEvUx0WPUqzxbOxz2NLjOc1ZPdtVk921WT3bfmrNAgOcxoDhhemeiOiS36pTXZOXr4+N39KhWfvvDVCb920v8Aoo7+7Sz6lWp/813ko8TFzz1Kic0/JPUZ2FR81H/N/coouv8AmnCVU16m/wCFF+Cfknp+SfknZJzRM4Lsv0IviOA8RUTIKK7BoUfwBR/ArR4FaPArR4FaPdq0e7Vo8CtHu1aPdq1NwaR0crXk7+5WvJ39yteTv7la8nf3K15O/uUVvfn5ma9THRTJ6lRBcC4eclGHF/8AcVHx3/7iozvH/cVEONR6lPaJXhq7J3miIzy2YNRwUfxxf7io/ji/3FR/eRf7irSP5kT5q1N/mvVpb7QPUKIO9DDuhkoTu+1zPqrPH7sQdDcgcDP8dBsnfdf4Rio0a5nZN+qjWi+RPMoN+8f5KBC7t6ahkV+Qo+By/KUIZnSUzwlCczNCJKS9Tf8ACg2c03NNzTc03NMcDvKbZLsv0KmM6d15TPEoYHeUOXfChnB81C94FCHtqFjXcoZweoQ9sKG2U3yngobpkPnLFQT7YUJhk50ioUqqt3NQn3B01B8ahDF+KgyO+E2IG0ma9UHwrePmgOKaeKZqqar01kzO9NzQLcV2TvNSjv8AiKbmm5hNzCbmE3MKFEEnSmoVM2yQcCZykndVHs3de5v7JzboravzDFQrV3HA8uP4oNEzcApzZA/v/wCE+MZmZniSocH8xVptF0MEBEXx44b5qwQeLopVnZ3bP80OFnane4an+5an+4aj/wCXav8A07UP/Lhawjc1a9Tf8CAxE0zwJngTfCm+FDJA8F2X6E3WuqwmVZ+asxAxVjDKDV1VhgGYqmv4eTPeVhjyqnu5BWFrCyRkeSsEE1Cc1/D3GZBvVhiyqnu4Kww2loFzsbl/D2GYBuVgjGpwJKsJZq5bo4SVhg3tEl/D5zpKsMaUx3cF/D2tIkb1C/lr1QfCrz1Tck3JN8Kb4UzwpssF2LvNDXPnhUVZib3KxH2x81Y/H9VZPH9VZPH9VZzhE+qHsxVaGd11QUWF32FNcmxL8E+zuuPmERJke8eP/lNiCbTMH8O2C0vcZAJ9rJa0yhZZ9VSKn/JRLUaITVZrBfGdrYnhUaNuwxqmckXXvdNMCh8JKfdAQAvlNMlsjdl5pr4Yae69sl6G8AGYcoLmNNDbwoPgaoPgaoPgaoPgamQIbS0AXoQLKXnKQU/PQIihc1CnRR5qFzTYfNNyTck3JNyVd+ATBfiFBijdEkOCDcQm5JuSbloDoLBwLZI2R053PNyguhsJYJkKB4AoPgCg+Bqg+AKHZ4Qc1sjNBlnqwABmq3uOZWtNyvvNyhkdmZlFvCabzQ5ojB7h5q0Q8Ik+qeLosOoKyWzunVPUeyXjfZyQiqq9qiWF2beLUy1MqYeoy/CiGC5xkAnW18hdDGAz5psAVvx4BOtprcaIQxKEMamyikcX8SuLrzs4q/arEk6y7rhNqbaaC3hiuyZ0RR0Fdk34kXACdw4aJlSwuTxxV3OSep47Lmc0YhlKSEJpkE44CSLsdi9ej7ju7+ybHEOl1Ul2UP4QiiiiuxHxJ+q1Qubx5qSMIYTCETdlimWcLwhTv2Wu4SKj2TjWzIqDbr4fZRfDwKfZ3UxBIhNtIuud+6iWCJMeYzTLUwPZx+n4T0h2qZ3Gn+4oMFTkba6p5lCZif8AC9I7KFuwW/VBidE5BQ2d5yBva5FmOiRu2KjyCrFY6aQcVeVVBZ0QaJm4BCcocN0SXFMiml7dW7RdDbmVw0OAnK7Tuc9it1/dGKocR8ummkzUwBnpfF7oRGLwE9n5lMdFNXKcGH0QaJm4BTPZQjElxQc6mIzVlTXZsGZU1JXKhwKmAM79L38E/ki3HTNq4i4ptoGptNx9mIn2J9LsOBzQtLKgRUnWGJ+U3OCEVoc0zDvwWpbqWHfdjyCnenWuIIbf+wgJWWD3Gd4+IoMC1h5BUgy4Kd6k7khEEpzUtDnOpYJlWp/syUZ3ecAnWKJRVVcpmXBy1Rlw4afSDEGTZqqGWHFhRpYwe2VDgQg1ovQitLpSc1GNBaTiLl6XbGs4MxWqjvHPROGqDUMDsmIaW3laoCEOrjmvSGUe2zuqVxuOzrXTPdC1bTLgFXeb0TNp4K6oeaxWus0Y8Rgq4MuLCjSyH4zeocGHTSmxYbzKRbeEYkET9m5el2hsJvsC9UuIyKrIGa1Zp2KRU685IiTRcjDvmq+hVJlpmUIvDDimxx6NaP8A635FRLDEodhw5hawVtxGK1TtS87ru7yP4EWaG6IeATrS8udi4qgSC/8ADrNP+dH+gUhPidGqhCWLkc0IgmSpEjJSeJKhxT4zNa91IOC9HtEppx4r8y7VhXo8cU8ZFV3RG3Kq9hqCxU3RCvRLW8juTvXpMJsSHeWXjmmSk80u4rX9lB3quKH8Ns4bjEPDmU+DHY5/81Ux5+IK6aNNxkjFguni3YMqonZsQhXQmXZnin2x4kJGSdZXm4FyhxvvG0nxBOF43257GogiWLk7xYqtlVUkc0XNe033KU1KzuOc16NFJPccZFekww5l5beE0CmLNrgvSeyhAmrim/w2AG4xDw5qcWJV33BauPEH5kQ4HIqZY7Maa3hUmTROSMd2CMIyPFOHFEkHRLmm3zunonfxCH8Vs5hP+/hd05owXFjuFyodU3A/RelwhPvsudpkp/aax+qb3YePVUia9JjTPch3lelxyfZbcOmnXQhm1OGPBOGBkqzjetVeVMz5oCzsbD7zhLonQojdZjimZzQyTrbEa1oVNoYMmhCGJxPJqJ/KMlcVKHEKbaotoqEwVabD912kPJQ4n3lnIdyThdZ4EifaKcXa20Gp2SofAfk5T1T8wiQnRW3IQIVOew9uO+MimR/uzSfCU6xlpa68p1qeZu3kyz981u4NTn8hkNj0iFTxansBJwCc0SDjIoxMDghZ4bsyrlq7CT+UpsezEPGJVqsHc7WGoUX7yzmrkn4WeBT+ZEu1loNbslqreOAe1U2k8wq3NHAlXtblp3/JUuIK1ZmtaeiLzgrwJ4aZd4TC4wz5LyRskZsT59FUG2mHx7y1rJL0SOJ91267QyxN8Tz3Wq1W0GI95YzJF0AzM5PIH2fo0J78hd1RjRKncTMqQXoNj/6kf9ld1UtGrPIoRBdxTm8Jqnecp3BTWstDGngZr1ojkEE0cFOOeina+kkXmZ0XKiyOPIrdiOzOgHgFLDROBPwla2xw35SVypa6dy1p5DQZVcNMrxcV6TD/AOpD+q1TXReJuaqrzidJEuegwTPgcU20NIBxURt1M+a1Am43la24d0aNXYB0Cps7dDT7IUsBLRTHs7+a3obswgykqsl2eiSoIKbFE5AqTyPkpkSxQhi9TvOiejiLk51x+egWqzuguvpuRgRHwz7JUjPNNFj1rzewUnmU63xTHi4TuCohulwElq7M2ftmr5/Zzc2COG87/C+q9IjMZzWsjiGO7DEtF6loIwT80XYnQ53Jam1tBzVNoa7xBEKQUg+ItZaXnnsaqwdWqmB1OzXAiDktbYCMh+2gnjpAZTy2KHA/Pog50m9xuGmtwGaBZ8OmSf4ii7Ez0TcFTZobc5KUGH8Oz2bHeFy1lnhvyksNFTjyUpHPQ6Fh8kyL323psPuNvzKLrzedO5OenmjmtTaJcHrVxWxR7WKqZ1wRiOEOcgShAhgDgjaIsOCPaN6ENrWjBol9lSCckbTGe/xO+gVyvixj7AWtiviHiVO4G9BneN6b12ZLMLfbFHAr06zNiNvc29GmmWCi2twEpDNCxWcgey1VEu0NInOZyW8AqLIxuclTAYOWzU1w5KcGNDyJUnEK9Mcd4yTBwCfrJS3E3iAmMO4Z7LX3l36UwezgjEqBbIfuoZ4SQhmQM9mqKwcwvuWqTWjIDZqs71rbB0boY4A4nJBgJaL1WBWL1DlfunZJuCPEoOBbNHgiMdOrex2RWvstQxEipgLVvnkUHQw/gAjFe+0v43M+z1Nmfm64eav6IgL0X+HnOJ/lSarzzV4GWwXNLstippC1DtU/uuUOyR2vlNsXhkhK5UsbDHtYqlqJ4FEcCFXFaOYV0Fikxo5bVFojszVEZ4/MVfoOZW7PknHElHwlHI7HknVNm4yUmm+SecXbVVoZ1VVpgt2qoTx+VayyPblNSmrlvXnoiJSMiicTPYPBUYLkg0TR4XIzmTpuXpFi/QpTGS4p9qos7eJv6IQGNY3Bo+zm6HDyBcVdciXNbmVRDgwlIKSnfpqMgtWQ0d0Yqg/lOGxxyTI9ngvfwKBaJYSTrVaXcZGXyUXJObVOVDP3TouOHAKu0M6qu0wm5S29Vbz+YLV2k879g006CTQ7yT23ew5Pf3RNRfAi2YIFLMUY3AAaK2hvz2GtGqOLsTkUWzBxGiq0jkq7e0ZS2pg9FIx4fMqiK8fmKuUjNawz0yVEPhXjJHjpm1SRcUBcPmnNRlgq7OW5TVEaI38xVbHflQbHI8TPtNdaYh50/JUNWttLeSrtIHhGyX4KHCnvbxWKZqw1xmpd3eGmYWss8ZngNSqgM6LVW1wwmf3RLpAypWqhth8XXuVyqjzyWst45bertcJ2a34bswmxWyLpZJ0PHDPYlfkvSIPknEm+4J1Ra0yAWphNZ7US92zwF5VG87vSuGSJJPGa1rGu9qXzUsblOK45BV/xB3Lb1dtiN8SotL+d6u2RCFb+97LVW6t/DFe0O6diryQAJC5Ld3lLAr7wc1RaonNUw5Zham0Qzk+Xz+zohvdk0qbqsb5qrgpxHOyVdpiHnsAG8TQjfdmn8qd4ShDa5rmzKecAhAvcd7IKvlpnFfDOD2laoxIU50lURWRQtc+Z6lax5d8lcVvRHZBay3POW3LUuycq4MJ6MQXCaFnuJrPh4KozlLYkSz5IQA4+a10SZw7xWseXfLYaTvGQWqE4IBHixKcfaM1DMMuLt9HMq41L7wqq2RT129Vb2HxKUZpzC1zd5sh4kAbjMaKjKckIAwmT7WSI4zWraDVUXcE7Bt/JAcnZaZA3J7uQUwTUuGKClEeFTagfFJUifJUvJ81XDY7No+y1dmi8xL5qryWKphPd1VT4jvzFGU+Gz7L/ACKpcQVqWAcVPYlagpWqOtZDdmLwg2G7xG7QWtvumpQ4rlVHiu6/vtzgdCtbYhyCc1paLp7VUQckTDPJamDP2ov7aPrsOh3tMlDjewA9Y9U2HDbu7zgriVKE8qqPFdt0xYD+aqbCeiWATuHDYczmMkwhzwPJYAYkrVihn6nL56biFzU+K1fNVX3qUZ3RdtCPJSaBmrwq7LD5XfZSgNGbgpTKnDOaosZPIov8yqjSO627RSAc9gRRN2MP6qsz01HkFQ7kV60Oi7WO7no1EZzeHBFxmRuNvJWtv4cAvVnZ3oQIkQOxKadgDEoNGQzTrcaGd3iUyzwCyfDYNNfDTQ2o4uQNTXtNPRa12BDRc0SRiuya29xWtd+Vtw0GHKfHTK8YhCJ2vAd4c1WZlXL1c+abDiRA64lT2Q3FemPYyHfScUNQBO8ELdVakZaTDM+HFUAxM+7pJcFSZIsMwmuvkEJoG91wU8DcpRndFvwSqpdFgpwXt8L/AN/st6EzqVct1U2P9CLIZaOPHQahNpkptPFO8J2nO5LUzJNy1siCqbV0BVUSNwvU2q5sQcMU97KZ3KoKJYzyyzUG3Xg0RFFsl0QVNzQiCbHJ2admmwhU4qJbjfuwlDsYohibk6O6biqRonK44rdlK6lHIrViVAKd4Aj4Aj7sJ72lsg2egl7ZgyU2FEYg6SARwOioJ9kPI4hQ7XvwjS9RLOaY39yJEwQ4LkuSpEyaQoluNLN1nEqFYGyF70+0mbkZSaFQN669FzphFuIlpJAGWnfwRqF01JSXJF2j1h3RXwdG6vvh8P2XrA5MRkFcFKyfoW6mtxEuabmiwlxdcmjig83CWyRiJrXTmLlqQJC5TtU8wtXa4jfEriq2OHJYhZpr2nonubrGcMsV7EXeGa/mWd0uSpNMYUnNMhjd33HABOinWx/kvYhfNGrex0wx3hemZhOrJLtxM4kKG47g2YYulSc003VCadDqrdO9MGJBTS7cEhsU4iahxmHMBRGjWM4ZJkcURh5qJZ96Cam+FNi3HccmwBfeeAT7Ua4u6zJCH2cH5qskuv0AYiSEcYoQ7lXdK7ZhjkeabwlNFk6ym9dn1h3RfdaNwrtYgzbP7Ku0u5CWi4dV6p+hbuikgrdPPYefZKLcQRpk7qpulktVGY5aiNDjDA4qbbvaVLXHksTouKlCcUy3AuAocCo1idy+hUG2iTxJyg2TfP1T7W6hk6ckxsQh172/ILt3qWmUkKZ8JbFbg0YlSJGWkMe0oUHnt3FTY7qmRpuhG8YhRLIaXC7IqDbRU2531UOzb7zVLNPtJohg0/upPdU3ALef1OmVyqdpe/Bqi5ItuIlopcFu9dE8E48k5EYr1h3RfdaN0qVo6s+yqtET41O4KmnqvVT8C3dJcAMtBiGQTIQ/cpzu7cFrN12KHeZ8tioJtqhUPxFxVADeAVXZN/UpCWi4rsXIsa6eaDxIiYUr4fyUaKZOnIZpkDDHNFsd5zQFpfMTTeMPdTIgqZci0yOI0GijTJGztq/mRMOQWsGtH69gvlPhoLzIJkITdeRij7LBJQ7S2cpHijBOYPFXFdm/zUq/iTY4k4eaiWY1MwzCjWw7xMgm2djqe9LFOex9V6Fbp5lSvbsz3neQRhgBt005l9RQjNExitW6nRV5KoyCDLlfIIgyU127+i+6TYgkRgqASMFK1Quc/wBvspx3/wDuO/dCFxxU6eq9VPwI0TldsiFDqPFBwIljoDHTKa8ylIqhx2HB1cLEYpz20hsnZrekb6sUYXNv7aLivV4nmtx3XZOviL1h+hkNoBmg5rYg2C65omocHeiu3vChEiTBmJJjC+oyBQdvQTUPCpctgQmF7uKbEaWyN/HRqJ3TqTbVDdmFcVKG/wA0YodPgdjdd0W49Se74ir7xcqX9dNRAzK1e43gnRZA3ngnQhM8U8ccOCrax+nvOyTjhcjEPNGGU5Tjv6L7pULWMdmvWoPU/t9jJruhVUSebkC5Sp6r1U/AixmYyQi3gU/spaezh5aGtbfigXGWCm8SW/pa/F36U5u792FUVqzKfmnM/NyUNwmezdkriqbNEKL4RPNOTk5ORixntI7i9YiKEYQAlPQW2e/jsNc2mWp5hPbwrGYvXo75vZ5LWPcWtTu8TqhnxTXimmr8xx2JwYcsBjoYyGWkX6CK34CXzVzvNdk+fNNAdSZgnY3XdEXQ3zW8/qUXmQW8OQ0yc3qnB1UpgoiRwyTogAKe6V2PFUNa3TOG7RQUH4aO2f0X3WjdceS9ag9T+32O4/4St4IRb+KppXqp+BN1dTj5InkMtitkjfJNaC4aA50imwsFUSdjg/eb9UxrKmKtwGabAJp3v8KauKoscUrsP1HZbCjRHB1RdwyXrMXQ1zQ4tvWDNl0A3d3JaymKMDctVXEOGHmnRjN2HAbIvhnyTGNcWtv0V1TEwtWynNXLWQYg4ma1TDWL5puSbkhkmta4ywChxITixtOK33fEqb8FW4nYrEj3gjc7JVXC8rVsFRwWtdPhw0EAHgVIkZprlJxV6AXbxF90pqlh5r1qF5/t9j2b/hK3gqSqqOq9V/Qt3SWSnx0FhmE2JdhPgj7JEk2BeTeq7hho1k1Iy0y3T3StXMnHAabitbZIjeqMKDI57PrFo6prrVFDlDF7olyDRKGFPR2dXHYnOGe6/wChVMoQwZjzOmd2a1Uueki54q5qzOvmRyTWCmE1F5mb1cV2T/NRJRNZPvXT2KmOGYKdAgvD8b01johImajJGJyGit/RSIOel7bjvKWEMAp0TvHy0VOAzQ1Z5aA7G4qu8YqV5VOGK7SIr4KawSai4ElTtLOh+x7KJ8JW8NHd6r1Y/AtzRU4Kbemwczpc7Bqk3CSJeZCa8tOsp/KNJkbuC9Ti+a9X8zswnxYtDZOHeOa9Zi6ScBNRMldTxlgojRhsT0TwvTg8EtuVTDK9Obi07Ty0mVylCieadH1lXB2xJjuhTokF9Rnir3/EdAdeT5JsKbgELQ0FzZJuINKlsQz3jfkm5BPJdWN3gmSvlJNnu4I5o56N+Ir4Oi4r1kfCfseyifCVN7RmqTeu71Xqx+BbqDhM3prb5Xha6Yc25MyQYbjPYAN4mmnAyWtlS6UkG3EphulM7MPo7mhq3XjBUWSIZTlwWtgzppvwGy6BFiuJBD8F6zF0mFwmmc5podrL5yTBmtacJbLG3ES5phuDsVqQ6brlDaMZoPMwJbFBnKaaWnhcuyieah9pq596+exJrjjcmRYTixtAvuV7/iOgswKc995RYAWlOfidrebeUKDtb0Rb0LRulesfo+x7KJ8JUnNU8V3eq9WPwLdRbgU4uEyt08E48dvdlkqn7U1IEG9D0WJVhxTBB7PCey50aPMkyK9Ziqhgd8+WwNXV5aHOEw8J0MTLh00viCYknQu9JUOBW4eewaa+Gm4qcKIF6KHiqqoz2JgjMIWaG8B1U5lbz+O8URiJaKCCtYbsBsThF/HLlsVtAy2t6It6Fo3Su2f8H2PZRPhK3gpoCnOa9WPwLd01gD56OAxQxf8AJMbcxgMlCtA7sijB5t0FmGxU7k28qqUQYO03EKqyRAMTNOhQJOEjPZEWJFAYGlvHNV2yLPBt6m81d19xRgmXDgdnVP5FTAiBNi+1IqHDxiLVMfE8mrO/QXSnw0mI6luJ+ia06r2MD1zRhmk+Wi4rsonmiRGn4tjcf8JR1D5zxKMMxJeIrWbr5FUbzcNnXO/KMSu0mO626XJUbw7jvpszvctXcAqrjoviLfgqnoVuldpE+EfY9lE+EqbmoMuV7eq9WPwKbJjHZxeUwzFWgNdM4JsaYBmqHEbE7hitRDa3i/FB04Zwdh1RYS04hSQIKlZIhGN6L4E3GZmdljIsUtfVUbxktXaY/O5OaASDSeKY9tLmGSq+7NYy4hS2NdCpPRUVErXRDzMgpUwxgwfXZdF7uGagwAQHio4lYqFFY1peKgMU6HjeMwripQonmhGEQhobJ2xSxxyCNogucQAb8EXuiSE94rVnmFrZtcpaeMQ0N+pUOGKWsMk4guDd1NDAwsmAmvvhH9JxRbiJaK3BNZdiqzMKSmr4i3oSa5gBKLW8lfF8vseyifCV2jU5xXdXqx+BUNwmmRO6aTkUW46ZQWS446GEb15QDnSwW+2Wa7TS5+AuzUOz4do/NG0Fu7ejAe2oYKFarjuO4FFneE+a3SgLK+rC+aYYPZiTZ7LoUWNUJTNy1tpjcJXp72CH7IRF7ngNVF0ISHi4lTxv2KIkuDlq2HncpVRDgwfVVX57FBmW1L0kdm6iXsYKJhQUxsIso3s1EPsIWbvmo+Dgq5mVPJThRPNGztfMg1O2BQ6eEr1DbCdqjNpmjDdElxcUXkotm43KegsMximx/vN13ByicCJZp8NphJ7wCCJFMg93ff4skX3uM9G8eivKAdehdo+8W9CRRay/jwX33UfY9lE+ErtGog9V3eq9WPwLduE0Gc3fsi7HSI0MtPBBgJquGgRDTgmwb8Tmq3k6XNEjvNyQiXwv7CnQSHFspI2hwu6BO9rcA4lUCll4zK3StZZXtwqWohBs6uey+LEjBxnSblTbIk8HXLtKMv2RimQ7jfrtVPq4NWshmV54LVsZC44u0aqUzMnhls+w/wAiiCRxmjCY2G3vSv5LzVxXYxPNFzIkzPe2KmOGYKdAguDxI3q9/wARRJnwV1I2TBMjez9lS+68PwVDWwm8BvbFLuqa4qR0SV8VXwlQ0EqoXrcin832PZv+EreCr6qRb1Xqx+BUwyBieOyYRmE2O2WfBRG4CoZrU7zyJqrdZ5nZLTMXFelQT42Kp4JwZeUY7vy8Bo3SibHEljevVxPPZhxHxaW0me9zXrMVDV/9TAnlsdnP2sdESLe0LUtlxVoYTItvUZxmZTK1E4kQjdwHNVkuOJVRAzWrlLDYa5usd3of1U7zx0XFdlEUOIH6ttN9+x2b5eEpz4DqiTKeKpdEunvFONw3Ry0TMs0Ay72dgSNX8u9qnfnondmqQCOGOjg75qq8I8VLBXxFvQlUrl2L/j+x3H/CVvBSNyqpnmvVj8C3dFRAVBuw2H+IouxM9O7PxKhxGnVuq+aEISb/ADb/AC0zbE5BSsMWS9XHXZbDiRi1wcHH5L1mLpc/uiafdeE3ue1JROSfDumWp3iKd4ineIo8SSnxO6E9j5uwWtZJt6iN4bTy0mUhJdlE802E19L65u2KGOOQWvhONIbjgt5/xHQ6JhhmpEGrBNjVMBvRlc6ZRZc4S2HPwCc1wNyrBAKI56COKOej7xb0LRguwPxn7Hdd0Kk/R3eq9W/Qt1OfgE5hvRe3dvT28NkxDIIcSU2zUtvM0HkmeKdD5jTPHhoe/HdC1MOJfOYVNiiGU8VOAOF52XQYkaoSqNy9Zi6XQsMEPCZpoOs9qSbkU6LjcNmm5wu5JsXdE702zNOMkwYXrWGcpbGrM5TQLHTuuXYRfNEMiT8WwKXTwleoWqdqpht+K3n/ABHQ6HgUXSFKbDm4C9HgJIuvN+mSo6IHAYoQpu+ayGz94r4WjBSs3Vx+xuPRSiH4jo7vVerfoW6hg4STYu6Cm2Zt6aOarM5S2Xt5rWNBKLHESFydExN2y4d7eWtY8SlILWWR7ZymtRCDaqr8dl8R8YOM6XXL1mIongKliJaezq5bFbg3NatxblpoeCpNlnsHI6biqYMQ5L0lrjTTI7FbXDMI2aE4HmiTE5OOxVD5lBxkTLmsnrVe1VpieFEOvukt0c1Tounp+8V8LRgvVWfZSjO+M6MOq9W/QrtFL1cBpdE7oT8wFEZz00Ag+SqdM53qDFE2hQ2XAScNNQnWFQZVVKlr+YU7FElzRFnE8zstivigMokb+a1dqilRMavJNtDN4LUnNp2jAZV7cTDkFr2/nZ9RsF2OgxDIJkETxlxTvZAATLS29t6ME5t4FXHopwXjNejNcKqpmex2b/hKJgOqnO/FGEXy8RmqhWzzGzi35Kl8/EqxMO8lQJkhFjGgEzKnzRKDcVXcFw4KWj7xb0JSPVYKVlhdPsqbQ/41MoboGa9W/Qt3TPHQHm/AJsNtwwVd5KlNrrwmO3gCD0QOiXBBrpeJYOkoMUcxioDJgAzWrhhnF950bpVNjieaL4EzfedmGx8Uw31TN4yUrTFRlORkjDEgEI0I5jYGahMveZnIJsUgtQhOmZqFEvG6U0JqbmghChlx4oPaRTjo1U92c0LRDMm3hXFdjE804ti1T73HYoY52QXpEEukG44K9/xFCGJFCJvMuOSzuXNFUOBVbL2qllUlrX9SqnH5BOT+ScckWic79DXDno+8X3SrYFJ169Vg/D9lK1ROoTWADMKcpL1f9CJbNTUtIgwxdvFPOPFOdgFThiiTS6+ak4jYMZkqruafZwS2ScX1ObPiUYjiZIq4qVkiJmpAGy6DFjVe0bl6zFW5TJHJauEZ8dIKYBIs81xbIhGDeQjFMw1Oyl1TWiVAcc03iExSRMNh4BBNayktUuSpDnTEpK4qUGIeqMdr5yEnbAodVhK9Q9S7VTpvxQhmJPMrFF1/dU7seadkjkuSa5spqTZNd5J0NrnSxwRy0A8VLC9OKAbzRickG3cU7tJL7q/RvKVnhfCPspWp/MBFkuIVQ816v+hFoTH8ij1XLRU0EYpydDbKmaDs5qTpm6Sm52gjguSGCkJAosZzfpuKnZX+alC81No2HGJHmTcV6zF0SaJqq4YDZ1ZmEXtDpBU72ACrPGS5InihoPdUmnd0VDuzTQKQFcpwYnmmwmvk6qZ2KmuGEwvR4LmzDscFe7qVJt6qww0PRUkwYtQe4UqUm5KeiXBAZp7u6Ls14iuDVzVVd6A1ckGtGZU3KmEwflH2UrQD4mIOAvVInzXY4nuqYN8lkijkgobrjcmSMn/VOHEIk3jzCDRKRPkhlJDNFFUiZC1srgqnchcqjfgFfdgrl6pEXY+a3djXvi7obSfmqbTF4pmNF6c7kpaDKfDYOE8URdMXJyK5KWIIQz0EXOvChZLg25T0dhE80QyJ8WxOG/4SqbO4OuN6BqmZCZVVwwGkhS0CEMQoXenfkgZlBjZtO8U7NPCdyTsJyCE7ygmnig8vvKDBDkiV2g+IK4dPst6E7kQgeXNODRfUJp4g932VisjJP6otxCGSaoXGHNQT7JCA7m6n5zTuMlWDNvRSTDjETJSrUMe2VB8ZTWilnHEoBTa85KVkeqoQV2xDY+KWPqmb+S9ZibHNbsuWzyR0byuvvTSuaIXJDQL1KDEPVGO15MhJ3DYLYTyMQEYsFxdeb1j1Q0EmSmOiChj2EPAhkuQVRwkr7k+V8tHLQEFvPUtXonFb8Tf3Vw+yqgtf4HfuuCIEuCnBb8Kx6rzRqRl3V+VflQyUuKJRRyRkEajdNA8NIUk9+ARZDfNeqvQ1QkrjsOgvjVCU3Xc16xE0h2JTBwV8paAz2tJ0MTG9VX3k13CSAux0kpvtFBoNyphPnheoVDtVnfsUQXnkpwCZSxWPXQDiUAZgrWTAWRUsdirFAcEXnBNPCWmampPiKYh6Ko8Mf9QfZ62zRByn8lNTb0XYt+FXu6lMPVS7sponvBQ9gKHPeTOBCeSJYLoof6uWjmgijKRC1jHclVZXhFsIA3INQQQkeie90Sp05FTjxFz081dgjmuScnI5o5oozxUhcVntSC7J61AfPiU1NTUx0JwOEk0Qd28XqqfVDNUc1XdTJNh4Fc1ViSuaCmiE7jeFdupxxOxzW+6SuZfO9XLWWqHym77OppGYWpiuafZMldNdi3or3ZzKn1V96lKkonHRzXNdF5oZISF6vPFDQEFPivzINY5vFU2V5CL4QJ2JAnJCJWaab1OO8c0OHs47G7z0MeJd0preN+jkmAd1A8kJppwQ00ik4u2Oyf5o0OnnsVscBxCMOBI43oun1UsUAgJIEaZ8FMEyw2LuuhvFAd0IRPZVHRdo5SDOqDWT4lTiPf4RL7TVxRE4RB9Qg6FzC7JvRdo8c1STNFVaQocqZ4aCEeIQyRzRy0ATcpFckckRNAWZ88ENWKbhsXGeCZvFnEqUeIVK/NSXNc1zXNBpvvTDe0IlGauplLQEFyXJE3lGc0XCqWmUJ6MZrp8DsShOkp2e/Ioics1ULypcJo5I8Sm9Vk1OKpMuHFU7BJuC/MFineyp95ylEdJbrON6wC1NnBOMTeP2npcFzeOLeqImDcRiuyai2O8SnNCayXlpbIlSPdRxwmiiNPNEo3NKDhKd403L1R67EbE2u6Isa6ealGiIgA5ouxTXYYqXBDJDJDJNLcEGNU3TRcUM0NE+SDOfNOU21TT8JqpSXZPUmu437BZCK7DyKx6oDFazBHiU3qsgiVRlPQwtvdepc0FyT5XC5OKae8V4VSc1OK5CTBzRtkYN4Yu6KkADh9rVOPCHxt/yEYG64Tb+ya6I2IwoRDMqWBWaDjcZJsPHeKa7hJSFVQ6Jx9pMdi6SDfbnoKn7QCbD7omc0Yh4BUG+9MPsy5rmhJAWV4negIImQm+IJviCb4gm0O3hghq953Hiq4sS9F0hNU4vUu7dsgTVwUmzqx4IIaQpKG7jI6GXElTwuCuQEGJfmgGGZlem+IJviCb4gmGE6Zmm6iUxgmzNSE1vBCooaGuEhuKSpBGamms4zKno4TxX5ggFzTGzJN6EFznG/JRLfEuE3HhkhYmSxee8ft4VpNTezdywVob3aX/RWrwD+5WrwD+5WrwD+5Wrwf7lavB/uVq939Vavd/VWr3f1Vq919VavdfVWr3f1Vq939Vavd/VWr3f1Vq939VavdfVWr3f1Vq919VavdfVWr3R+atXuj81avdn5q1e7PzVq92fmrT7tytI/lOVo909Wj3T1aPdPVo909Wj3TlaPdOVo905Wj3TlaPdOVo905Wj3TlH905R/dOUf3TlH905R/dOVo905Wj3TlaPdOVo925Wj3TlaPduVo925Wj3blaPdvVo929Wj3b1aPdvVo909Wn3TlafdOVp90VafdlWn3Z+atXuz81avdfVWr3f1Vq939Vavd/VWr3f1Vq939VavB/uVq8H+5WrwD+5Wnwt/uVpyb/crR+T5o/zInk0KHZRKG2XPif/AMRn/9oACAECEwM/Av6xGAe0zhPs85Me3So9ulQp9gk+21nUr9vr1159+vv26/7N16yQ8Zkvp7EEEEEEEEPYaztPb9HkettBRmwt1XrbQe/Z9XtrzKzpOfXodH09ZrnVgr0WuRTa4NMF47zK9BXopeMmsmvZaya9lpVkVl36qlWRWXbV6ismvQx6SsmvZayawRk16isms2vUVk1m16ismsu2rOvKr01e3VnX7BWdf/0j/9oACAEDEwM/Av7Phx7TClAIIIFcLlT7JChRZU4YUr/4qfY4y4aPbJHt0K/Yaz79dpn16/TPr26vYJ9+v+ioKDTmQwUz7CUUUeEUUUUcOvrLztcXlefWRnxPqTgppzI9XaGCvbdcF5eudA9Lpna5c+h09ZWRpkW2mDXLrNrIv268isM+ovJvHCnAM+Mq8m/Zb9uvJv26/Zbyb9lvJv2W8m/Zbyb9lv26/wCxV5M5YQzhlwp/t5//xAAtEAACAQMDAwMEAwEBAQEAAAAAAREhMUFRYXEQgZGhsfAgwdHhMEDxUGCAkP/aAAgBAQADPyH/AOmYPGcyy9m9Plnqo+wtdp+58x7C/I9D2k/Y+2j3GpM9avJCbpok/wDkEwkZbgkVDlOnuOIWtKvRUdZvVIX8eix36mM7BfwI/VRcb2MZeBmOlSGRuGWBM2m9NO5G6fLR8WCSU5Tyv/GJbFr1nuzIKlHkJiR8asiLF5LFWPEBLLuJfpmNs8mLTGGwK7hZom8ouzK1vpFHIsi0HZr/AOJXRaW1EiZlg/lQMUzk1NFFHl8ssu5lGiLcmrEyPRCW5hovRar5MuKxZ9jMB2uU33Co0CghQb0SwkTKbjkKRVmw35CSVVP/AMMuK8t/gjLTunfcIHkQUasuq6BTYVOZqGexQN+V6K600DSltg8HIqUcVQ1TkKjHeBrKHcj3hiic3Q23L7qGtyITXd8wJMSEpqz/APCLwtLbE0OqPkV9hBwQ/AQkjuZV13nQOdfbRmv2Fbj4EWPAZBsJZ2YKLQZC4hjxdFL63Bs0ATjtfmNVWaz0FUiWHQWgW7LryJ1lwm7kSpHKdn/4JI2QklvRIrFwlXxLQS0Jrq9iEsO7HJkIFXzdB30PyLRoZZFELcMp+tvOxVT6VfwX55+wz33Gr5HtR0erH5E7T/DYZG81eVhOnaCSdqJt3wZNcn+3RBSTQmCMYEHGS3ncmqN/lL9v/BRdMUMMdxQnQaLUhCu7jduhBe15CY7aLBr4FMeSh8Niw3sPZC4UuiUfwJgujUkvHK98EV6YWr9zyHqKskmL9KJshASwolxJMcNTdJQqhRjYx/4BWKEahYYlTlJwJFIhQg0/Vla1pok1yaBWlZ4IQ319V2bCa9kko/kZuyTUlQrq8X3H230bT9HXQGBqLQmCWcq8MXdcm4OyUGu//fu6NeVizir7iRt2GxBBptS5aClTLISl7/U9/wCeTMrqzruEaOHoKhsvUdrbCaiUdCn6u4mZyvz/AN5MI5qaJ7Ey5y6uUMsgR2qHeO6MjfQlhQkq7/cvb+kpwndGzafuTVsbohqz4GV7R3WDnQpJ1Swxej3WVV4oNCUjy/7sbZstSUbWO4yGgOH13FNr2Ny6ny6sBIRCSEtF/SScCGtUy53HCQYfD1En9wQk0WCURSw8CUVefkx/3E7/ABCErhubpQhyIkt7hfwCN2LiydYu/wCpCchogxTiA8NFiyQypdSOxExN7ME1Cb8LdPUn/t55W8jIZVYHCLLQnBQbfJlTLh5P+tGiPGT8ktZImoqnJViKjdSUOYJS5qOf+3ErlKUafoNtk+WRPREzLjzSk5Yk4Hua/wDWoc+8iHaJQbkkYRRKsRKIRVgfDJu7kuH/ANqE3oNm9Hs8ex2lByiNVUqlK/wf2IqiacYgtJm/aCU4InJdiJ15G6/7W5j0JKrq/ch9ylqz4BJPKs58M/2FSvL7lUQ6+iTp6kqbijV139fx/wBrXppdyRNJKTgISBRA3NX9imUt0vY3FSc41Lcq90yfoetPv/2oGpCuhBQU8H+4jQltEl6f2PmODmC8UIda9KqO6/QS9U9v+zUHhdEtsiE6L+xD1ZehCeF6iF4ZUWO7f1JHwj/s1B4HRV/clnhZXo8XvPmY/wC13hdFZOWacIQNy7p6P+xEz1JKhirMHgfU8fvJ+ZT/ALMhrRC+dCqpBPgzVEKEd44SES7Knknbm9E07dgkMlJKez/r33Tl8qCVdaehOENB0cMYyZWWWLLO3SEFNX1CtCd1yav+H/YiqNxcwYSYe5zR6e4EpO0cti57MJGTOY2sGiEXNT1kkkulrCt6f1qxDb3KIvZI5vVUb66k/YfzbpboWtcwwUp2Kbdhyt1VZwHgAdr+gl1k+S/67t0F5CL21UJLgbTqQrhh1Ok4oWs1ZnIqqTLb0Fb0pV7DwC704/rbALxX7GuRjVqpwhE2yu8scafohjTWquZQ2ZuAOZlr1NGDwnT/AK/n9w03VLwNGXINExEO1E6MS4kKGU0CbplbpbBXZ8t/W8n3EK1FvqiapVllRSsCKaGVkXF2kc8Rx1ZeZm+T4tf+v4XuKXWhPAwYvDerJIa6ZKud0mH9xrq+iSxtTitKrQS20TbdkmIlCapz/V8z3FPcWJWgNFUdzYinwX8obu4+wjCUcewVqIOD4tf+suSctvCRUpvchZ2RbVF+qESVvarfQTDosTEPYtgmVjpWU6RhmcqZMi/qKr9QtREcinupRIo5i546LXnUnp0h76DQ1XhFbTdrcZEJiQlNWf8A1W5FYCClJZwmjWQ9zFozd0MuVvMRU4FqacpwN1onLw/6cVj6IirFNJ91sTqVmOUJWHRTZi0YtxLUSVQtUlDLymVahM7pZ/6r5uRTfEECsjQf8h+6bA34xQSKbscRCY+RR/T0f2yQspsaXMPHZipKzuftn7PTswMqTzc26SOqUO1f+d6iM/QH6wf8Q/VH6Y/TCZZaNzkfLoTmWSNCkT8T8i/l6A2VGJ8pR2KsqNM3PMHyFhZbhWH6M/Rn6M/Rn6M/Rn6M/Rn6M/Rn6M/RlZFsh+4j9xH7iP2EfuIaJp1ex55X5KlXqF1xv0n7B8j7jLspKV2OzJYJY4PVPh4f/KVO1TUps9bfUmSp+Gx9pJewyXO4NjyNbyaY7jWpCxP8koiXL8j5NWt5dE6ts+XQ1kH+ho9TQ8mh5NIgkS1KOQjJeXkQkSBvyGn5Ro+UaPk0fJoeTQ8mj5RoeUaHlFBFpB7M/Z/k/Z/k/Z/k/Z/kT8v8kPak9x5Y0VX8hTBonQufA3I1Q1/YMhNn8MlHgNZIbCaTx0T4RibQ74Z817nzHv0h+TM+4VFw/jcCO9fcF5Nl9pSQfK8MqoTZz/eTcxqMNeyxV+4yovP+SolbClBtbsW3sNZnYePCfrMefGxhmzsI5qjtUNjdA+fQqkSaZpmmaY5cGrCiOalHITTQvdx8BqVRXsbj4Q2iF/IXUU60IUIZwPhDbshzTU1dSJZCZsikCXlgaknN2RCqsMRXrWwHVa8IXHyLTQlZLuNBa1IhrrsRzhKain3DpiJVEoagGclCLmpGSN9MmHb7xo/QkmCARZKQjWjECm8mD7hs7SnPgKUPw8mhUvMzo7f2mmpCW3gwd0/wEuZcpb6DyOWXk5Hqpl5UZvsF+T2Mfj2Pn/Bl8exl8OxN/l2HNOJdiySn4oTk0jBDQNA0xMKBCbMK1Zf3xtIspazqReq8HIxOZRVN0JCtubMpVKFIqCjk6pKlpZtNwPzLS6O4pUZJFDoh7lqFRGaaVR0ZJRzDEmfFIObbNRMMe4NzZikdhBNQJbmt2mUeR5fsROpq9xDpmkaRoDslF4ZDA1q03kpOOSwBsA+AayDGB73mRNDQPX0FN05JU4Nak5ias2GbIEl1wE1bRqv9dEl5bYy2JKPfs2FYdBPEaqy5YrgeqTKbxKlxyPkO9W2MUqmRFQwkuELciS4k3t9NXT5FQJDmBTz21stBroLsfoH6B+gfoDjri4QyIbj6sqbynybEahKLsS0mJWNtYGhBuEfn6cBVEvWKqhcYrk4kVVJvRjoSmaPQgxCHXIF0PbkNpRbfP0myqE6MoqC7gGksY4kpliXcGSoJ1qKl9pmhHya17s93Bd10qKCzNFb0Cp5SqpwMmzymLW6EOstW3bcQmeRtH/VXBOW2Vmz+cMti7lF00RQdoj3CsrfeakUVPolaieP0RenT2A9yN203Q+ZTduO7iajUPU1Drhhd2sEQQ7DaWbGIy/ckaUmlWBvLS/ps0aMRdUYwVS6LBuGS0v6Ibcrlm6PUPkZNR3v8DUajUah19BDfpZXECzMHxbUNtJw2KI7jG7a7+n1QqEcaisoK5rtRmxLHrCZCGZQrDR9l+ZG9KSqy2U/6cVdEhuZnNYvsjKNB16tfaFgOCbRJUpyxNL5ZUS3GUGzsLqh0J316OYS5eekCmnK+wlIjJadbCRKCkE8NPVw2T5aRUEXHUU26b2Qrix6oerNldJIjjTt9CqYXUPG3fD6otLEk39INA1di42hWUJsc2AkqQzVkydtGnwJbY2JV2RZ5zhPHcSSqp2ZGfL4GkIdyKekpH0IKygtWJluCmkdb11SCa8dVFBZGGKGtJZfD1XZNUK0jTfYlOZFs9VwLclKa/pYA1r5yyU7KxZ2avCS7EUNq7hAXdkrf5iyUUQ6lW7smlxGo8ifYNmso1oztjGVzoWn5kYwDbWZFmU2tGNrXXdIIy7E5OHTYRtFNiAxVXF2QdWSqFWbjWBK6x+BD0ijgmo08kVO4vpURJ4QtNbgSSytqtBs0wXX0/wCwkpErSG7e2eZtwJYbxb9hN1Q15IhCAVaewrbhCJNpeMhJElK8XGFEpLdi7W1Ww6yTnsN8F4cEuqNA2ti3HSSBIVLbQTKq7Q2DOtU3MiSLo8Dc/bresrlCjAS6juXxKdBjnMayF+cCMh7raff+jt7LV4QzplPbRdkQ3mbDpq8rQoOx5Rcm8koKXgzsoGplcpc2JLqEyNKyacT0ry3kuJmJ8mISIXIkqNSIOM3To0UbY4GPIl2GivN2bQlWAqMKUUXgSpDZocCepKgEY01brvU4y/A4m4cC7aE6lOq2B5fAqMsrwgRMG8C1wEbQJh2P7wudYV+iVf3K5Z5Cns1Yi1BJSZVrGYGnBSTZDkJ7qDvDswq0Hp9mULooLcTMD3oZMlqQpnIb2YrepsLetRadg1Cp1g6VZtwbF4q9hSHQPV0YIHdCezGFBpJSS5GGwUwTuaP2U+btk9rkVCstxVMRro+qucCqTlbfyRuyb8V2Ki59vKhF6biHSgkE4sCm6FkJiMyRUNrkUnS/Y24g6PBF9JPDPMMTMYsVsJ+FNzUUe8ijquwUVwqEFzPsVKTXFR7luax2Gt521akr3CpaEsmnUgaKLsdkekiKmhIdXIK9z1ZC60G16/g7j/YJopqUsZTOpW04suSlOnSXWUKqh1NiAVk1HFGAS4U7kytTm6d49QnRPDymU9grwiqtk0iTM3SSlryKVpKesPc2oQTMKY+cAkpj1rWtA6Vqxw/A1NpxYiMmSy2UkEo9ZNxOMnerL3HKaVWC1lMb2EgUhR7lRn3HJQ3y2fkmupVaNzu9EVPppXChaKjF7qoVp/Gnrhu5Nb1GGS5vckjNEWaeVN+hrcLNOj1L2wzKiDonoHKhotC7plkGhWlI7E2ScHZGtsUxJwvuKl5+4ZdLdtulfJiZaSz07zuwrSXHSkulmpP+BKEx4SWdvfpZc+rZMgsyJ2uLQLaT3GzfNx9Us1Cs6QVbAVCizumO7FBNSV7YkqHqFEiBqrycmvS4zsK04dIjMGzn68EvjA3nAmmo3h0ZsrrwLcyN5TwoNOuRLui2rJu88EqXTYVENbiWSKsjV8BtNO5Vkjr0wZaUiJafdgUsMZTRLuV04ilktkJShQOWNq538ZNKeZgQg7qr+FcxdQ3KvZUHCEO5NdKrNdC+Pp+QOjbPJoVwUm1Rk5JKJouxnEvb1pG5tP3CF6z+nlDM83CE0MabRp0tu4NI/E9H1aPWNzXFqKKN3fqtTDKtGhPR1Jw+mqM5FSDq17m+E9CPs9vpcHGyCr9wlCiE1eMoTZ6H0ZLyncX3cjWwMlDLueoqFWSMT0nQaDGl3CY7mOLHJFbNQyo6mn+lOUkIqm19ufQsUE7fxJhZG32GDNG1BEcEaW2H6ifbjU8iVpJhCXILEvpt5V0JfYIo8HoKkyvyRA0nQJD52UJFpHV1ZL3bb89HXWIKMo/04pO9Pp3RyYwTbG16kHsstRCSiJGWauPRNalisrT6b6fYQtKnYx0e0UhEPkKE/oqb57x3WvwfOUfTFylPgr3avQoMrmXYICo0jI3k7NDAURaq1+h8M6vQaHLsIEKDKWKNyNhZTRAuY/cgVKU/cczA0JRyIYHe9xBXPiy/45uD2g3JCpySbUtxDuKLNgnkXfQgW+im/KHOaU2T/Y8q5XUeUIkUk1KgkVXngQLUsM4RVfYwN9Wl6kI5NuX6Z7knk2bMVHRbRaSZqZ9hFUuS/uwJdC467N9hqqndVD3AqS1QVGJSZ1pOF1hnaI90Qlsl9O9MT90UkmjGlhtcDbpzlBEyTBcOXSeko8htLVyNwoVyNKqwRBqo2SPkU3ZooXll6HKexYKkX20ykUULJfxwtuQWQ6Elsf7qIvZtcEC2JSrok2u+rVefoi6Ke+RzXqtz0npRLRhptNabWqGtUEcCJKyLYaK7kN4LkV43QKxG0n4PjkshJaJfTYh2RTYpERDw6pluj6evRWFp3iEkZKVnkRMNGt5KUNt2qzoX0boko6PTrtetkqt0SMep8CiFxQ6d4f1xQNWJTaRs/uFJEl0OR46QQ5wKGYeaCE3PrEvJd4RCXfYZa1FeU08jsmNyobB7g3VhIyRNLlP+SKqlEIIuOZWcmkqX0theXhC0atV9DlV1Hkz2HJt7p26SorlYBczECYykHXkocZZDHQxwrfkja16fXp8URiRkHazwNhJwWqgnrJJdpFNmpbNDJMqTWrFc0IcZbNUN6PpbcDZZKo5xsowZpe8jsig5JJdEJmp+n19+I5hJ3LLfR3Lwhq11ZXKVcNCrndvbrKJVdLmURWuvQnBOCqotCnKIWqfJI93SPSF+Ghk/xbxPCK6ps28sgqEdvG3Q+hJw9BCW5tnuO4qC6szoJTlTsy4MPvDeWlojpcVuIama2Q+Kd0QWvbNCmOCI4idoGTk/r+U1IDEeqEE5/Rci6r5ISQTwvokOQrUVe4eqG3ZGlW4L6EE5mUJbAVbXsMl94/YuQWGiHbDn001Kjtj+tg0i9T5vAktSFsHlvXSKCeWXDEWDM7y6ia5pLCqKIXLq4kIpUnzaXqL9ITSDVpGCYhnFI+MQS6A1lKpeZk3gen8U7XX0E3S2xCaKJG4yN09wWjVn6Oz1HR16C9eeZHl68DaXVv6PLPjyREpT4hGr/gQiiUabo5x+xyXufXE8rN4r0GrqvJ3bz9LhUjLGacJpfBumEY7DUNppWb/QyoaYYlylTxdlZqGmldx7C0X3G2HJyb9jkn7v6+NejPCeUNDfQMmu9RgW14CaYnxJEm5G5OhDi7ZY4pV9IbrQUxQThRgSxKkK5LoUaz7kQWiSHaorHLn4fxfByHAcEFrkbw4lSTdZ7IatBbtdG/5bdZEHZHswNj5tx1v7hKlqInkDe+r1JS3oyQuc8HYlpVBZ7DbBHGghKK4Uia4mmTLAnnrbBhqhdiPOurkZanFLLZd9V3nTuNqsnYdV6E0zlFRKNQohejqgoosFulJ4z0Q+Hx1bqhYZXOEciD8UtEQ4lrsMCS4nlitc/SuWSSIFdNLIZ+wEVck3oiZrrrCXWaoTKHOnSekvgQLI3urCPeTF1DEakC3SPUUkwQh2H4Jtohcb4fd/FwF9kperI5Hl+wmFL8kh2VSbUKkOLKIVTQJ6NTDvfp3ES6fUSVgY4Sq4IcKrREmxNwp4C7JhRFC02KWr3ayCOEWc/cdOxroVw2yu3SbI8JZZKmp0WpBGjpu2Ts5+UFAiB4BpWBJ/gIh9hkdHy7/RPUBS9oiiqQSulrJZy1aLi5SWsdUF6i6TIYTTd490IpasK87iSmtEEmBk1OhbVkFaZXJcd5nck1PRcD2AbYSD6KNDYd1YLb0jcywyhtAwO5NFyoPKPkuvt0jkdKi6PM3p/FKdD1YheYl+bFJTkCxK5JetjQVnsSk7tfoiquUgJUiTAkJhMyiShNamjxCf5YjYY6JJSKVVUFSOdcHBSHBTVcom5Xg6MdCdNDKgtQPJIKXT2SIp7Q+wzKWTm54XR/at2IK2Ro2VFoIrMsLV4f0rluVZKCQqQSITonCFUzS5O+gE0wPYmIsMMq5Job+4gCbLB/gbNuZUMe4dKkxk2xWSUwVVtBEKpSH2G8NszctCsKSoNCMmSTHTmhCAR9CIE1GZrCmRejETmNp2+jyCpoiUYuRpXwp/FwgKFXHQVfNiFJFCWYk7CU69yx9FJSdhSWGFTcMyqS4iS2mFOBPbJiZ8vpHAbU2ylvJVnyZSFA299mViYs/sIiliS752EViB5RUE9EzaNE8Bmu/V/wCQBsLtHjpIyKkwIt8COkGz8E9PAJJ1UpISkehJNTX5Jkw4qJyi41jx4IAaFflsO56UqzPlZ6pm9JqStWVOkF2a1ErF9xkp9yRNMVOWp0dCSy5ATKZRSDyD1lETxlPWXr/FO3LwN0jFSNUyhHyWKerA6W9PLnoWUtKWDnKKw7F+4g7iv9CeLqqLqVBnkSxtphSTlnUhQvPTxE901UYCdhjael9a4EoOR5jgTCTlmxuiLBhETsO4TuyXCapoxhcdCLCb9YGCQaNMuyLDWSeqUs6V1y36D1KSzJWvW7HqLTUmRnoh4j5NBpNNVF4sZImDeFzuL7gdEuxcsu+SQSTYycveIXNukdIIxhVpnoh0GapujLRLfQbmth7dHCcIQ0XmIgq5Y3KiBBm2mWuuhG0PWxBeULoZeCg0X5P+LlkRN6WJNM0HyaCqsp3J+hyn7iZUkiSlm+CBNpIui9SFh1+iMN2SKx1GIuN7kZSrYSeIdC4ba239JFubnlEJpmrxgqjF3t9DZD7WHJN4JVLkUnSxGCiSs8kyNx5LglDTbR0+ilWogUkoKWbjMFmcJohExoztJolaSGqJUFHTwJWSQ05XnA5molskNTHuCphakk0WSeuzA3UMpV6DoklXIrG1owRY9iBZx9UpbIMxYKfkKTfAlW5WhJFe8vVW0JN0RHwcv4ZGntEeqfljKU0R4B8mhEVyrWJmCk1eOlCxZcoPKClWRrcdBq4Oux6etequEj2qWkrvuRJNJvI75sFQqNVTsIVk8RscijCTc1I2Gk0imKUSrspaMsGrkSGdaUn1jcvIzr1nM5EiZKuVSdYdYSsRpHh4CKSLmdaMbVTAmWTHi8izSpIKWC6AlhXDl2Q+hpiunNENnwsiKM12KXUnBhbnTBTHkzIzhaZGIoLsJCX46w1dyegnt5GK5K7JLtxXvPYejHw8v4Y+RTpqU4zJK9TxPY046ayjwJ9CitRC8bjHSNSmsCG0jVm+On0Ki9zAQmuqklLlXgRczYVdxqLQps1a8/VEPqWHmFAlELbkwcv6ZDS1/wARK7KJbCS0qG4l3oV9LLJseUQch4KCgXSidRRoTpSWCvgWjBeBr1DxwINA0hummtrUh/uW55fuJbESN5t0jop6MGo6UpVLWm5QiSyLQhUlxU6HhRZJ3gNlqGQEoSKOR9FUnhK94mcqVAldFETsN/V/D8/HTbotlCVloK/ixTz18A6ZWvUXKpKsTqt2BDTbjx/eQT0L3G5rrrVWs7Ma0nk7nqRY8TK9EsJxzN0r9LfI9x0wnZ6MfBa41NJITwhtLct3ILW/sT1WwK9w0hq6jZJdoKqqrtn0hynDVmJp3xUbc7oWxWWMPkzxFu8h8I3B9DV3WXLFlDNouMkj1Bf4F0vWrEppY+jVU4ayKgSbl2tB80PAgWCYgWjQiGnDQhLmYZSxfcN5VSwpKtslbY9QTRLgqJTwcJn8Pw8dOGyvAfJoRZNSUJJ2E59on0kSyO5N68kFwY68k1HDU1GqNS36SXFFDqlREhqOgbSW3rc/Smlkag8wujYY2w0OETYUka/CHG5rYxZrD6Q01dWGzbct3fRtCNth20g1klOCsgifpTIQySldMLnmZLj6GyqNReBk500lnzM9EqfsEtpSssjQVUTHTlFrYbNXj6GzJi1inHawkRUJIqJ0zYSzIa7PresUPETte9/D8PA0Fw4BXgPk0ItkmHBDIwC2EdCEU7kL8P6EnB0F0dlhrclYyQIppZE9y+hrcSjBBZEzhlVkS1RZLB9LSjMLrk83VrhEd9SKojYG5yVLYrS2wpksc5f0rUv6htY0wTHtnNcEjtlC+mv0RwRwyfl5UFM7T4EXoNuT6E4UEza1IljR7j5mel6QwqSViKFbF6jT6nUgnUqXig2qtv6v1/t08BL7N7/w/DwNpUaG8tLK8R8mh6y/IqcmyNEsC4b/AELomLeYTIxT6GqOnRXX1GyQijHXq9gombnvefpRLGQngjmHd27NDt1tsbqKN+iTOVZYGncd3VCldlNRabVuycs5eH3FFtgjrLClxPXxM3xtDYJgsfQnzhMUiCLUIbhT0HJcOiE78CR1ED1jKCer7m36zZSNYZPR9f7dPAS7SHr/AA/Dx0Xbgu5gPg0PV0yrof8AuOjbSJYStPoQ2C5MamHdIqKpnToxvJQ/oqPVOBbDPZ9KxFBKxcDrygQhWGn0vgkNCmMh+w2q2wYSwS93E11xjpE9lrBpSj4Lr6C0FVk4tlldcum/cbqzZ6ueiUalvVLeNmplFU3yyN9xqungPP7Cct13+ifkUPIgoevuEoGOzg9QWn0tSWpihEJpfB5k1XqrkT1ghaTshUaSVEVYoyOchzsp+xKeHpVdP4T4eCFqIo5HE0lRY+DQntHYn6FHYN4QpVUMhEshEK3QjaXT6GyRLWRzM/2GfYIUZ9RCrbGWw3yEoYuxen9KTcwckRMX5CPmUCzhFE5W5UyA2hqHo+soTqjSka3LS4Q4lQk+qW7fQlcfRGT0SIGJ8pTk69xUiEaGW2hWRPEStGxLBE4zv9DV3a12EqUHYmWie4xyxsDjFVUJNaN9NFLZ6KKxzE5e43Tm6kIZD3PIaacDoc+j6QsKrGZF4QtUJqVYqlRQ8p4H9hMlSmw3nBlfb+H8PHRarROx60fBoPGN1KkjfINhI6UGtQnGg24MdZwJnlXQaztGhXwuru4ayLPUwXAkUFtAwero1EVE3ChAwlUyINBykrQ1Qs2Oaj+iZJtrND4GlOR2GJqSglRBLeRcpMDaWk8/R8BJT3pdxPoFuw2b3eX9ChC6MSF4CfcRuq9Bw0eQlQ9cmRcKpyKEtFhC1aC2QGo0+jc/sJZmK3khU/cMcRLdSHwSoSb1fRKFJqQpNBt3QzqPXE6Gk2mxVGZ4HRSZW4Dqh07NA6l5c9EamJySV5njf2NDcoq1xv2fT+H4eOi6kpkQ02e58Gg3BjSVWtvAZLS+ta/UhtZosZqpJZ1KUyScWWD0vrAk2jsoIknW4h4ps5JCDsD1XO+wJqpL1fBHAVCo1OhSdbo+ij4ITI9iEjkP3GpbNLfnJJooLh9UmBHcaKQOU3Iy47LVwhuiEJafQzZ6jdWrUC31ocyxgTHIXbcnds8B82hMUHvX6Grukibg2vJ8zIzgV9SJEt32I+hZjZgS6jvbG1RWbnBHWHSgkW+4o1ZClaCt0I3GeJivhqiHJU2yNZ7V/D8zBBqMOi6HpmPg0Gp1Kjz9Hky1HJJRhsOjQEZUgdW0QkweQgmYrF+qD4ckTejWBUFUh52XoeE4OD1UvoidkN4+G4eYZaVdZgUtCBQRAh5bMJ3vketJ5huw257jkcipKDDqBs9hobsVNh8/RjVEehjd3mnp4BJzqk3PA6iJ1uf0PUUI4JGGTUKYus5F0NAd2QZNAi7voxot1e43bXaX0kkuwhBJMdoPI+5KaUhSVTPKeqS2SKOSN5v4Z+RTpVKGNVSyVPg0PV03wiaQ1O/XSnAlivfVMyrR2NHTp1ak/ZMnUurtoI6J97Y3mh1qTyvovwWQoV23PN1ZEj0Hk6DTglUtESatmCthYwfvn75++N6ozYcuiFFKCvJLC8+BMua2O0dHDWHfp3ZS4yuJqdE3IjZHOmNvoaOre/BXymjVh8TPRtMZMXq2kRSlGLRaA6oL6GRMOUkiJL1F0fAw6MtsNduleZHdKFP4n/OwQLRsqegVfFj1HuQy1URR6CySUi5c1qvpyAW8YiGVTYeXTFfv9JHGUwhbLpU7i42KZpgiqx5E8lC19EprVFIEranm64Da6I2G8DqJyFUTKkFkkWX0tFTsh2IuPpqVLFsOWmxfQ4CchZJm1CYM/aQxqu/0I5ZV+waPIkrpPiZ6ado7DIVXEibal7j221HyyfXRI6Yq8jkmSLjWonFuyXLu/orzPW66mr9f4Z53sQtEeGVPQKvmx6iFg0JnJauQGbTdy1OwsGxfQ1VOGKhxzIGm36C3oGYnQvoaqroopBCXRCn1U66CSIsnC1foo+GM2txio2tKXJcDpdz6qUrQ7nr1a7Kuy1JTg9V10h0Zy/VI/SZrTnp4mZSTZBJPULP0bjoc6bbZRoMEpUjz1hp6ORUKUGhOBYnKijI4jTpNh7SFkkmqUJkpdXhDalqGPY6+v6LG42/4aPhkf4yWKcRV82I7+kGE6F7VuerLm+DLbNlWI7E9FQUVGTTlwJh74Gt5rs11cSPOxSJuRUZ0NG7QVQnaf0ROwuTRMjR5i3I7teglImzH2Q9OjiJpp1gkKUNQM87NXWnWBtMKF0X770Q+yklWHfBIuPNSSji6IFwPON6NeSlpdGPobhmaEXHzNLcGdUwHmoo+j7JPWSJXao2iSRIT6CShYVxSVfhDZt1MoJNbvBXqeomCfH3LH0h8hKW2TiSUVPK/iQt3uWraiLSO5V82Eu7q3lpYkVdr1hidQoNm0297DVhotliYfvgzU6agqzaVEbiiQsNlWmyMbre5FU7SiDwDcV1QINl9NNBzQUjUXuwjrWuRo1BW16bk4g2WZWsIlyiiIFaSIagbO91UYyGahsDUj85mPLJWMpZuMwRg2sfgQG6WGfJoMmauPoNVVvdRt3KGrD4mRuVyzvoGqI23HgLeGNQqoeQunoNjwV5HXtI+ESlZeBG2OlfDcAgSrC+vR2uKkarkRuyoxoVyI4f8Ube8j4uAUtkkv82GUUpOpYPd0egsSMVNQaCJkWo3c4yKVVCKw+mwrxVCFVroOugSZg4EtCY622SHxA62hAxUWXSlzOv0XHiKGNk5mp5DtoKErrGs+nosmZkIe4b/ACIYps2H+0RkiLI7WAfD2GtAlokxCU3EhtiuD4KocG7FAmhG5kvJtEhmkkqU+jcvsPvgSOqp94q1Um6FI2iyQg5roMgldjLldM+IIxChh7xNXAwOuK6yXiKlukfRJNSlTetWGsJTWSskdzCbY4TeMkXT+K5R9CZMiuQVmgl/mw1GtUVW95COLNRiVcT4oaM3wjyIMbhGdkVdpZORNJ0bH0CeRNs2lgSap3Jbf2F18RBmNRnmombdaPgTOWZweQQ4TzgneuPosiJyy8N6OwhbyWCbairuNza0EaC4iNckWbQlcNMWY1FFxNpquyOU36FXBAtIhue21jb6K/VqXZDfTJTYfGyKVVGrHTQpoakZsyciWmucpCDOhNDoteR21J6LKpESyIKpybdJrQJ5so3gg1XzJCRF4OY2L2P4toH4cEOkxVEUImArVzbNLCQdwSC5kS/gPegidMrOYkShuKIZAkPQNSb1DXYNaIuUzOC6GJGoTVlilETShEtilF6BtuCYNz1Po+hEmRNr3E5qp2FcAo2i1Mbx0hjyzclZWqxSweo2mkbvPgUaiYhXThioCnMp0HEMBtLcsSTWx8WhJJqu/wBDUV3B4K4Ra7jX/IRSyLW/RvJccDuYpVqlZashu+5DJHLNyVZSEyL3r0q43X0JLatGTYaQTNCWjiRYsVc5kqvsifi1PG9v4uf9yKUtssBs8UITJWvsSuToP2DHcJINh8mfoJpxYxuA+VtlYVDPlUbENYPIQpqIaEJwbHEQYtcn7RNW1yiwJ5hQkrcnRFyvnrcwS7XoeX6JvcKWC6mdx46T1G0rgpbUamCBKzoySRcNsLUhBN0NokKljFh9FFmYY6NQLGajSzRiUhVJnLA25kPptWKZFZhzNIaDaSrJSSK0NiQtIL4Zp8lmglqmW5EoyRNVCOBfxbEfYJy5ug+LgqsxUcC1jDIG6puh5CZfR0LLQmhXDF+1GBrNwXoMWGRdDCFShqxNS2hV7VkTE+glNaoz8m0E85v0bQW2pQ8xTqLAm7QhmWwsSx6dDMXL3GSlPAg2maI9+GwYSErKTCkOwTpIijNSVcCTG03ctfoaDASxJqhFeY4KxqQkjQMiSuPRjeKH0i1TeGTcqL1PUoYViuK9cScGzHhBnDFjFhkopob96L/jadS1F6jgyg7sfJofEyKv+BY25qbFlDJpuBJ0bgWrF0XDGVkMosxiWZHTngFuhINhvgVpzbDNIaGmSDSVbmBIyl0EuevQUcoJCWhOC+iv0GolmiH2XHVaDSXJoSGyusJZl8NEEyPJiwLkd0oHmpI2VJRrI1q1Oo6NZrHo5VNDM3DU7i7oTITUfAb2DuxLbNxYYTSwJWDbCvXcst8k1L3BJ2/JdRIkgSrJDd/KyNS/YEdhtPSfxzeZeUO8n+oTgoT8thuOyl3OGQqZuVQjITzPQRkQpNg9RGEEu6KSMIrJtDNMWpokQwgNhibbIbZDUwxiy61+jbDIBGujJuAdfRLEHRxJQgVFnQW7NxAc3qPooEGhCGE7DXIpChPBjJuUZb09gqFd9/od1UB5cIhQuzGJmkMackSJkSwkLbsj/AcJgNWqtCb0ZDlYE6b3CLmb7DIooouD1J1hi06NCiCQqii0NDWvLr/JCq2b0/UQHR3ofNoJSoc4eg1vIStGSl+CMC0HwNm1d9BO0Fto1AiajXItgl5CasSkJKnIokpmq6WtAU0qqqQWa5Q7kqOn0LbK8Cp1tVJwawmN8lciU2T+hoqtoZKqT+xFCUIkWNhwTeeWJXFNJNjGgxUKiHkuL0WvXpRkzSWOIqhT6GzJPYczNu4zdmHEnwXKAbSWJQl56JqVpIsHkSjDsJ3Is5XSYhxrYao1PRIadiJQ3cVcziw0tJkkVScwpZEof2Hb0/kWHqTYQiQ0mjRPCJFRIjp02Y1V+xN6hWuLKJFS1ZDU0jl2Yjo4LGr16TJGKQkhQsfkYo2JEqTLQ3ZeRyk9U8r+iHqxEomk7oxGpENMIo16BPDqRqGsaxFlMRYy/A6SVdyMOUjKRiLQTRPIsKfgPkbKMY1IWUh3qd0QdZoeNk+YP6LVZp56T1B0ipMkI2rImrH7R34HUu4NtuZ1IDOeBa01RuNGJ++LrJp6ENpaasqtyOUJnVQVHFpui/kVAJEl2/ldUN2M/c1MoO4nlKrsSBLoW7UUByL3YVhd7Ygou8qU3RoZG9LFgUsmA62oiTlhJmXVi03R0NV0G1oRq4IAlNMi1Jy6Nn7h+4fuFLJKIZZE53VJyS8zqTNKtsYDWwqKOuWbi2FsLYakqGJqTT4K6DtT79C6C2FqjUYNNZRUsLF6kcHLQqYe+KQiaJtUTsR5LJwfun7p+8IE00SdZESE5UbqaXLJItNCakGAzCELVMoRvcnedyjJ69CUSu4uqPwnQTTRC1RCdBBN18gy6EypJRRC6bOwVTaRJZN9EK6jrvThfzSNOnu7nKG2XP7HxPsfE+x8D7Gj8cGj8cHw/j+Jsltt6h1fE1PA1PD6gLmb94+w/wCi/q/J/iG+gBPw/nqT8P5/gNttKfWlht/J+T5vyfN+T5vyfJ+T/D+T9xH7qP3z9Z0TUGqdXpfw/g+H8Gj8cGj8cHwPsPi+NhvyvwNdJ5/YoaUs1HlkeavcP/8AIz//2gAIAQITAz8h/rEF4bwi9ojRFC/CBEIH2SFoGilAIooorlToimx9jkwNFuVxjhBCSmvYYEKTlwUlD2EgZcLdbevhJObPRR69YGfBU+2tlXrrKs61r66yrOv10ITpKjOEygJgetpECfKJBzoE8okSq9ZSg+ETwFOqnLgBbESprQKnrJEW+2ZRio9UDUggpWqHK5LkuS5LkFyC5BcgtO8GnfsCjgCHCC8IcLwv1g07bwV4K79QRPDyVDFFyi8gQoDoFwij6InAOcFwjqFI+Gt5wcKFIUjooAJ3QIAcqAVtCPooVqQUVt4akPAoLpAyAqyA0UMIM7lDtAK/hW15AzIV/DWzTtW7dSjDCnBTt9OnlHFSszd+ERoNVDLCtrWqlofdS9FUD12Uq1GKw0Y7x6dq/EN+HtX2HpVjWOs1eO8hRUg1Ya8aGr5wNelQyVjHar5ww1vhbKFr5XDAava4Y4ZWpEIlkDIsqGSDQg1qQR4UPK8KGlowbsFeGWhgVaAayoZaVOjyob+VaLkHGSVw2vahSVq84Jayoqw1hbKMWnat21NJwS8UoaAe2tUXhi0LdXVFWGm/SjAAucGnat26VDTkUe2sKj2oaXtS1lQxVmKHas9tWAZCj21qj214LwKGKm/TklcYtO1Z7asFZFHtrVHvDDS6hirC2Zvhr5V4146PbWqPanFDqCrDTowRhr5VnAhpyKPbWte1CuVOCXUMkUcZVDtWcCWhRhDUeJa1R7a1GNQxU6WM0iFLQUW07Vu8CDjkrhqPbqPeUoZFZd4E44ej21qj2pyKWmRWGGlQ3856j26j3k0tMimLnAVXypYjAjIr5Ry1LTI1y7asymvKpUMgjGUXMoox84TjMIozgOKVH9vP/9oACAEDEwM/If6wJRPhh5XlEefZ5XKjwgQQ4P0iQLR7JKjtDuj4BgXUalFIE3HsUr5FaRqvIRwigqUfIKCix7DuoSos6lTkTRU42KkKXr5UfCuOFOV3BSOlIn18meFAUknLko7KQoPrq7UFm6eFIUeuUlDN1Ugr9dXRaZ7T11DpaZ7T1slULhU3UGM0xwiYuVHrLPSlrzJlStlb1loHlRsVemaOkFZ9YAeFwQ4VfGYJocLh6gKKKKIUlFFEKSuC4Li1wXBcFxXBQCpRRwD6OG7XeAXtEIoo8oooryjypwNV8OeQvDR6WYU8LyoYJwB4JCmV5C6UgYYoy4UqMHB7UKdZUAOWrKlHKJNbLUHZX284diozZVKAKBSey1npHyRREE/+KCVWRLSa2CKPS0VZEsSJ4yJOCVTRDqDVjS8KSpLtfBypKr5zf1D6UlQq7L0cCcdrXt/xlaFT6xaqh5x0X/T0q6OC8Vqnv4ypPHWQ0+VBNeQVglrKo+is5Fq/eOl+MdhbqValuPtTQwjDE+VFKVC5+lJnItrxaZCwrNMojyF5XQNDTkcL4XyWjBDS6yrw2tFZ4xmvSkBSlW044eUCoFaPGL8FWVeGwtMKcWqoN/DRgjBLX8NRVjHLfhWVeGw14Zw6qg1tOGcFKx01Kx1ipQ34VntXhtaYkYZJVNeCcdLRqVjrJta9q8NrTAjHqqa/jBGRY6alY6yfwte1eG1Ywpxaqmv4WmClOKx01Kx1lNVeG1OW1VNfwcELxjv4alY6UtGCHWVeG1o4YwrKpr+My/hqVh5xrKvDa0y2qpr+GrAHh9OmpWMpZV4tFeVqqDX8ZmjUr+MpZyLyJbVUGvOpXk2rOReVqqDXmW1K8m1rkWMMYqDWesy/hqV5SzkCHhBw4QeGq5ISb2wDlDnGJ12XJAjVBxhCFlL+3n//2gAIAQEAAz8Q/wDplVNpLV0F1rEbOyJ1Kr+WFDc2OPdK9g/SDF1GWKgoHzSwAWemvSL/APkHUMlpIu7G7SM4tK1DABSFircUT2BFB3VYscXoTN8L0EQje0kr3lhFvHwN6zfyCX2CBfmM0GCbyBBKsTJT7r/ximqcZXaXBr4TvvheZgLaaEvJlp6xgRq3HTRkeDVLMeXBeOwSy8iUkKVzG1K2VeUilxsKGAVQAJOTNIfscf8AiXl01SC3Yy1h/wCVtRla0P8AXUzgj17glpVMicfW/MQe59b/AAepI0/LP2BZQ9aFNT+qWG7CNjbin1IfUqLSY32l90Wqauoi50I8A6AgxISmnKaej/8ADOUxjOyZbPb3N/w4IhdHxNRKeNWQtufEl3VizZIa6Nkq20XF0D79032wv2PXYrhsEhZBAqnEiJalbUjXsZcMzEgoMMUp8ossoh9MzegoeBtKHZp/+EaFraLYWrZAvi/h3dFTMPRyL2HwhBW4mruVzq8DXdiaH7YeLKjz26Ce4fR/il/GQaNwIr6smq+FETkmwQCndQoeyXMBCnrKRaBZlBSX2SByPR7NgiS6aKpp5/8ABKw8YoqhtiT0v/QAcRlMrJSJnyiwQZ2I2mKrKdkBTCFUL53HAQe6FLdig8BSstehjJDr2mif2RuE8ChQqEBMveLFpV9el5CSj9DlC2tAp1LW4sVpUKTm6GLv/BBnCM1YCE3gyLngQgf8i4psegcVuz3YrSILxHziQpCicoRTVtkkXZfwNsO6Seot2esE7o1qV/8AG1Gr2WIfEqIjTaL3zfTE9MNxuBuI0Q1qa9ZfuKLJL55XP/gO5AmE4uxjVfZMY6DaCRJZ9IP1IKKtBg33le2jaDD7AwWyITJ6fyKUDSZK8l7JfeyNiztsq5KRquHQjpxRSeQt9lMjk3QpbJNeFiH4gCMPEtn/AHoroT96Vm07NiL01nS/A7oU43ZKJ7iwXzJmFoSxr5WRSe6AekoVFj+ZI01Kd0JO09+SaHFu6y0ISKPi6EqcnOGSOc2GTK8EHrLmIWWfTLj/AL1ODe1DsVHLGmXeEaDYYlziD1TwNPOC7DqJnb+hNHYu2X4IC4t1ARLaeQbNUjQTpsQlKK5LVHBL6kE6T0bKrs/+64A0E5XgoI/NqCdujI5HJVGK51VMuRVoe4PyikLEKJChJf0kxbPqVQNDsJdPcVd6r2IFsPYPdO4IyJQa7knlF5nuSrtXc0f9w0IgOaBVgwPU5FMqTYmFWkSSmIVoOWinUI1bo7/1HhIHl2nkTTdlAbEVEEDq7nNJr1mJSUSW8HwKSmwhKs6/9tvkfLjIqEQSGuyVJR1voVYlCxQtSdvi39bZ1bfiBVB6xWG2ejxHdIo0M9Whqfc9AiCh+v8A23ty0+7CjqjENU9jY15H1HgREbDadBLef6yW1z4xgSpHaRae436V5SNakgnQ/jgzuNpnyZL/ALWwG/B80P8AgJ6Vlp2Ru6fJvBt2FX8ci/Mj+tNHk/OXR6rpxKpz6GTNUKFLX3hi3Kmv/a/zeYdOneOchBATYML4Fod39hbBt6h9g1QFVwTucejE8r9mfkDJ/wDaNN7koM3GjuM4A7P8JnxQEOf7Dd+4++jODZG4PU4AlWi9DQDyVOv/AGfiSydGX0IWUdEHfIIaEghaQi/sJwpid5wNpre9jeBepVNyHckyx7dT5T/stbnvlb4wWbHACDtepHAv7H+rTIdBtuHI6d6umFsrv2X/AGex7p8fBXgeFEfKqUXC/sUfBEX+0PqXLXJAv5eP/ZS+BU+Tgl8DxoSJKS1hkUg0rwjD/sKnLM86JbssAVXLT26gy1z0sm1X8f8A7MwOS7i2a74RFQzRNZGURMUGMAQU+P8AcJEbG1iJX9eS0Z3Lt0O0NUBJJuPGf4YbVIqA53NZwxyKEBtrXH/sGzSc5I9TJx2azZ93AwKYP3RXGdagB7cQnUgAoWFg51CpOVf9ZHwc3xKsVW2ZDID9Yz03kb0PJFiTfpQByIdhYYegI24M2ZVwf9d40uwNUy7WgZgY5CUHURAnFexvUc+tiypNGWT9CTUd8C39bUOW6b5/RYJvs6PyFYntWdB5qOy5lj8Mx8CgEHu5vZ/2aKvnBwSCUmsD8hgyCrBnMV5hD70TQKx6tL/X/wBwjdxImYWeZPEjufBFyHoipO9LsRK5egKtwIgS3/X3DmGysCsN3yitBqPbqLx/ZvsNkdev7nBxeoIq+CAZ22Enp/Wj+DyVgu4PYVQllwNif0M92RHdzAfDoUWIgh47KEf9YmiQ2hISzaMj8JB680rhIU0+sBCHTwjAcJGoV5EfSNaTGo284z44JXP6i0Pr2oq7sFVZc7syUa8yBaT0g2Hy71SmVg1ZGZ+x+AgKMbjytaORPQNpQ7NP/qsM1Fzi8wRVkGweBPWWmelUG/ocYNL+KNRQ1Ab7nr09Rf05LWOPJaFvthBXaTgCXR/oLonSpkKHKl12KDL3EGcLq/pTt/1luwDUHabFrxzBZfIYzh2Va3MrlrHwkc+st7EH+nD3AdsmuGJ/WpaWCyJHYfqD9CJk7D7SLrlqUk1WifrAv+covdlC3+dufDe4yE1v5XG+B6nzHufMe4vIlODwul3dPDn0zfMvXqK5Gr3Fcev0oZm9YD4H3Pgfc+B9z4H3Pgfc+B9z4H3Pgfc+B9z4H3Pgfc+B9xe7DH3Pivc+K9z4r3Pmvc+K9xNom5PwcM+dkW5XU4c/Jh/i9xxKzsScEncyYehwfLVdF/x+QwnoOY4vVDcC4UAoSipCQLzO8YCOj7pjjAR+zgO3VL946WQo++9PRC9Ef7uoJ+8YyC/TpiJTkBcOca5LXiHynufGe5+mP0x+i/J+i6c+Q9z5L3FcBD9QKrLarTUr4VmfLwJqT9wI/wAQcTLCnpMQpO5jAE2zA/DZ3aLpM1K7xewr1S2X4PqWV/JcZKpFTNzWFVfxEPS5S1NEMTImUJ6f3mYIftsrdyo5+TWLsT90Pjn3RLRrsH459JRme/oJR0a5AciYk6JRWVdZ6HSNIUnL94/eEXRpm4/YtOuTTMwINEqRNrGMgSSXA5poauIFGpUqlqS1RDnQ+RS1wctjznDKkxRqlmiGwiVSxKTcYd4Q6tsegg3SdRME2MpkVR5DhXKTTF+Ahiy8ENjNqLkChj5mw3ZZLqg/JgtL+tBnUm9TbNHwblAEn6mm/MftIy/dHY+FJNdgEbXIEqiHAgD1Hn0IW0KTuOngpSZYi5bv7TGobQkV6kKTV76fuGK8PUgf6I1aOlH3CiKewBMfg0J8Mlj8oYLsP9AyQfo0L/z7CvifkdCVcP0zqj64rbzENP0QxWx0VsDUiW059yD+c7YYd4hpqC4LvW1ciyCjjGsaW3YirJjCgOydv/KFvQejL2FYSeNkuhO7QclH9YQXFIKDLveUhKjNnuMQT8x+4fuH7H0IkJ1YqS+IevU1vgvqfYET2Vo+7UKMBcBlDwEsR7gKP7NsOB6NZUD4lxDultI/H9d63bN9yQQR2FpbuuxDEbCgoo184CdEADkHvuIon9gic4kUcdWEQdIWEUMMjBNlTQ26MjKoBspBpWCKRPeEsTrkvpzMhWTsioKGzzTb3zPJInRSbJiCWsJ8gLcZIaU2NikVmrQf6GmaZpiUwA2W7QV1iFJ50Da46TTKJZhwKKLMZqncjE1nhO4PYPldofpn65+kP+MRu2wG6gzuF+XcxaDpSJtWkEtxE6RhhEE2miupIx+S1K7P4ZHUgKHFi+xddj7R7E/7AqxJb5OZpPeccrBbEaVTjH9V3ENoSSJg8pP+3ZCNYiZXwEHFJz4txSrnku3bIQJFhdYcptMSDdD7lNUhXpHRvCS0fRNsd23GkkNe8Gy8yyqgeBv1mqahrmoNOmkrSPMCSFg2lTFlRZoUlcJTFSh4lYbD1AmklWg4y7L+l1XxqCKjVyVCk2JEpSq3DDjs/RFxUhNJSAJSHKig8DE1TVNXyavkhNIfqAI4JYzcQSuBZ8i6Nq+wuAauSXZ6BUm6/onR7Mg42cXhIES1DBGcxtH3RgyLAoxGgX04HsxDI5/ppWxIS27JIa5RHNATDtSCkM6ElTkHCWBx/eGffR8DdzrAXeV618lGtMOiRV0G680vokq0UNr/ACghYThaLMnpRQm4uWDYEh0L0FpCaJJIgpuT4Q+26m9JwTVVRTaAPSHFRHFY7l4gksHL0O/0J9Sn2U2Gar0l1aH12aoMGqpo06mVeyEacQn3nJHZ9Wuh6EbnIgJZp+EJzLNCSQ1zQ4ND5DsSggyBKLNPKFMexCiClARwmyOHwytNEtF0W7ZCZfEi5ocNIyXug7mdC+ATpipGu7W6CtmvssB2+6IJkvuCtUw/C19Qqja9Kf8ASsqR8xodN1CvW0C0k92hJdfINR+6G5cYMEkjbbKlCOerU08DV2IzVaFRilbBCWzGN6D0Ioyng0MeTCxqdnR9PBD9KYjMFuQeRZHYvzuk3ainZPDAuehSvQ8EdyLJeeQ2qqWB1KuRIEnjf0sm3Erysqo3vxgkskinp4Z7rpJNXWKdJJJK79CClkGCtC6gX0JrDyEFwmYW1sfuC9leqFZgS5SZeAjqtjDI8g1VJQFbOBMK0iMNkf7OYKkSGE/d0O6tCG+OS/IuFkuaSmgikPCAQdVNUuZhi7VCdJU9ElajghcEejN/hoYAwSpkniErUsPhUrq6/oC/o2yknPNjO5NTdt+gMCYpcWwgiSrVl3rkqLoXYNbnMnKJNGJKwr2Um6OBLAn6nCG5aoTcXxFDnLpcjgLTOwr2jJP7DijudCS/5QJGgYplARQL55cbvJ9ieCpYQ0Aklkrtl92ObBaX8EjUkjMqVfrxEWYsE05QI/aVko46NwkpbolqyZXDbr0zIdcjyqQpLlqHgBEejzO5PSExqlgtG5UgjU3MjUCsnqDHikgHWuROIsUWpGri8CDfPhyGPvNmoUQPO9K8i1PsRdnZGdF3JfAh3ccU9TESPlyaYAJEqP0dXj28QmoJULStBkiaSSwFrK4qoYUKJLA1JFOBsy9RC60LyI6TAJNLw8GFrMr0Iw4NgVb10HsMuKpyw19xY07Z7q6olCatwvURCdZsmvK/k2dPODCtXsfhBWofyBnyJJJWSglke+yBRJaXqRKEoeQpPKUg0xJe3tJSZAfsPmVRzhSe3jM8kW0fuBmXEJYVbl8iON908npyVy/oH3rBCoMs7jB8y7AhL/bRL8nmiRuJfgOOgSJ3PQqQASi5dtxls0/IEC26Nbbia94ATM/8lGKiMoELA+IxMegQ1wR0kRO3U1DB11PgXoMjpUk4uA8liWtkvQje2YRgVmJ50iSj7rQ2G6xh9gqPQS9SBACiUWChiRbNRCQ/5jnqqiJUJRaauU2Lo51JmBR7iLkdBEIVgEJW4TVQfIvvUXRRnGQ8uJV9RYwVWuSlR7+xTMCVsH8Cr29mEiSqSU9UzFhyK/CyVlsx+BHkEQZ4cFxLr/Gr1Rdko76MSorGSrupCjWfsNmyh3dGp0D3C+WFwMPAuSo0XlyOwSv3x2FeU/QqZzS8VnHwBbgviFkh/wDUPiBSMAodkWEUO8M+9wHfXSrvdWh6Skhs3J+kMVwa+RqoZQRlDHH98a9Hrao5dXgZlN5/A2GT5NjZ6gyHQelnsukVGGuevT3aFGuRECdorMUaLf8AU26ECkSt/RYNlIO/yqNcaDpZatRUINiQy2hi5geQ+qnIyQ8Bskq2hIaXDdMa8h5VeV0QqisiArSL43KKVpLgrpZXsKjwMa0SV2Kta0G0vXwywPAK1oiz4tW8SRcFKY9D9Jc3kWHZG6ISPUMBUcRwuAXTTnP8Z0H4vBnqVbO/gQ1Rd9IwxaW1ehUSxB2vbd4PXxEjZLsxVHsPBlkaKSukpCqir2H7uDRNNCZeVCHXJ7NxWJFT0QnUo1CsD1f1D6dZicpH5hwioncm0KywkhOCwS5LFXb5yEk03cVeSemCF9QBC2gt1kvszwhCSqH0gSXT6MlaycCqKHIyUbpKVobW/KLoZKTFXz9Jr5NbScuWyDrrMS4huwgtWicCeTVJFhShJ2u4lzci0TyyywiHcbwiytkxEehZsKOYS2LpNiplyWfpIAQzGPjYqXgCfUW0XcBRpLH7kzs0PlSoSMJzZI/ibccNJJ7kg4BOcRYElFAdrA9STVHoZPIsEu2UbjLNcEzSJxp9CEeCaogT3GQ0Go93MCq7dKoFkLsAzyz2hh/kda90PPSYKOq3YRAk1RbiCz9A4r5fSn/+UzSK8jd09GYg3RFd4HcMFXNHI9iQVtk7EQ5bg+n25HJcjOQeJZWTAXD4UgZWxNY2+iX6OlONfG5ty9H0tQpSUftoNOzFbUTIIXKALo1QzOoIaz2EzTQOmrf6KoAQDB1E6CqS2Jxa3yUYHd3E+6odfz4V3oKdLGwbNShLQpiXmImIt2GWoPA9v44hxvrI+yNNI7jKbacxwzIrUI7YFxycPoRzm8krpDoUzbUu4zXMZn9hDAkMoU5Q5CRRmAILSa1UxErdWNCeQNhfcRqQqcQfKcfTBrQ15QvyBpML7ghhIlQEauainqNQzhQuQuE9WoidUN0l36vHAZjamrQ9QRPRpJMsH2B8Kg89JZE5Ibwi5Lk2yXhM0UyHovT6ck4PMFzQkkbuXhj1zGUDnt1qaAhoK7jVpILhIgVV30H5wCkjeBVpqeoy2jYIDeE54IV7GUHYFT9nhybtXk19iY+GUSQvX8CQvahLMKr5b/jkmUO58m8QxmzQFiWWTTgBsyIaqVhjri4+qzl9fUbPfptzEE8F6CFIqko6NVNTK2sXiy2DHkmawKyBoytr1nA0SNvpTJ2ojaAhgygOVA2oen015dGL4Kqm2VgcEptV0qdD5RoRGxAMRCrrDKLWMJA0yxDawyALnyJyik6bmjWGyLY9xwUNI2lurbqGkrtsWP0KkHuWGQpJItCb7ivj6dnnoaO7pJM0/TE8I7+ZLdhQtHSE3KjvQtzsiduADSssaSSOkXTkT91Cgzk5RW7YE2l6pBhZsiRNRddIXDfnvuWWFa8HypVP44uShovRuCk4dEhD17kMdYFZmr7gwgE9bY108it5KZW+4hNVmrDDTbRqOiZVoKgvmfAnYxWjFDLi3UJvW4j3ofcTmiZOEZ4qr+n3MX+AIG4bmhZLnMFBp0MoVjnq3SiTsRlSnsQ02RLRCG4y9z6UmUhKT8EakHRrj3Ha6rYUFLVCtU3J0RNGfNJMh7QX+mpiESyhdqChqkrOn0aVYSyyyj2ADuir+iXkDTtXo4FkUMCOBCEaaC3q+4nHQhVeTOP6xGY0KSKt3oVKAdQTw1K7/wAWK9bTXS2TGRlwSSsGV9ko+iIXecSKBFVCUsTVfckaK1DBFmhEzmFAsnLk79JSao+QN+5LrNEozN3fRPJvvMeacKkiVuNkBhHo6FXz9VDiTYuy69htnL+4GPiPyJEu8419GDv/ACL/AJ32DCXewjfvHSX0XYNc6J0YN9tDD9RkpZFI+WpkozrvI7Hwn0N+7+mqPnDIeB9VjKB30Dboy6ekxESL0rbxYH9gLY1oAtxPQknJUuRybDqvb8I0MgSVMRjkrhOz1lJy1NCqUf3BaMfyE2sheUMCUxsgEqc1js/iUpD5gUpS+yG8ZNXN9A23+wSbq01mT1qmm0WS6JSH6iSuzk09FovvGU5DD75t9KHqc1Gic5HrAALOLge0T21Ew+AQZ2sVOfrFlbXdwKsluYRGlAiW5uGu/pkjRzF6EEi30uSJTca/wJEsBdxA1C4dUySsjV2mj8xfJDkBw0UgqtxOozfPT/gFz24kPKg7MCRpTomq1KMtouwjvb1MdTMfCh8vgQakm8qCQSSBtRahmeiKk7NKyJmZLTQgmfJFReuGP4V+hA/8cDhIbjFGzviP4lKVptbh92QJCrQz0C2yYt3JcsbEKSFa4ZBxxdX3LZopSeGHBBph1T+gIHgeyNlfvRMalK+IjcN6Ak6BAiCq7h5xNzrRnqHYCC89Swj7jGJbQjE1GElW2oKVM9A6Jlw9pKOkCMJaERVb8GSNeCkgVoqpbCtGaAF2NhWA9hI60B3AbKaFqKUeQ6JVboi0EnLTq/pEo9mURLEn6mMSbHLghWvJsaLABKTWnP0SN36VQj2AItvlS5IHXQqr3wO9GOslw4wcViSjnPPQS/hB+YSRt+YoFkiarKYxbTdIJAtZvwIBJZQbO/ufAyHfEoU0yoVodP4iZ1O7We46yAo6kUvgwjZ72hDOFvoquWRQRbB7VC4m0DMC2NXTo10SjElhNSKDdEpaIUet+4Td2nkpOKhDfuXsj81IZ5Ia1V+w9SjJkriRWylwaXzxMMpxjFkXuglFRWYEzFwyb4cq+iPllPco5LCpEWu7cIKLhCuHSihyRDZa61EErRer1uCBbxg2DaR8ng/VX4KN2VrBBKbaJNsV7fHQKM8drkENRlBNukEGzrECsrxyZ6mlKDOKMjgCI9rZ8iBJKQYPcMoqz2GIa8BmMwCOvVUWHRBBlorvIouDkXOB3OYCKPv0oxrd7yKaFqUnoOpydgQTSgKc7qqDadtqrMjEDmo0rRRIiegJ+Gh4ENzwmjJeL/HnCKiUHg9Fcwjt1I7VilG4xSFwmR2KikYwo+X0N0yEqmLSSrIpgmkk2K+SrCKu6irVNyhy/lQigt4UOBa6pB3oOI7WOdRC69ASvh7BEj4j5CMsuYFM1xwPnbRdTRVbk6im0BKoVNyZuHBUFPF0xLsKkaafpfRImoq905I2WFCEU01hOyXbIYYzr6Fwx/Ew8VoYZmZdgkvbcn3dFUG0h0z2SZhRyYV2vbkbWupxrJinfMhoiGsUwQauLWqKPZrcdLNl1ZZ1lClGR5cCWjUQuVIAKGa7CW2ldbTrfoXnf2PAh4kKjjuf8TZl0LOLDwvcjhdTQdFYfXR8pEsdJoqtFVlVxPYsZrAnbotoe4pE5yju5HfYeJCiIhw1KRsw39DAT+rNDuJmPSiRENcdhqB8NCgv2OQW+eDxFGU/UHQIk1PUfkk6lKHkVjNjBXnXEjX5T4EspqzryJW6V/ljZBBQ266FcpKgHYk0YLe2LsEhXOCbN7hUWejo+kc0Rqoh2g7V4QkTq3OS3P7wCHx4OAnAfFWDbMlLYPnZE1INJgz/ACg6KplZwyohPZkNiDZ2YhYR0kqbBhIZM2hU9wJoBrZ9hIVW3ES0lIgBf4ul/Flvc4JhuElZFcje4Oyhqj1kNaECGfgQoZVUH2I7etUtpEiokpxaQB/Dgle/Srep94yUMXiGCshUUBS0ixic2XAkwQomdzyCLq1KSqRDkcvgRIxvg/INcSSEnqm+EE/LxPXpo0rIrwoF21qLLKLL7okaTTLVGnVTPxq9C3UxHzkpkxehUkq3ScjmoQozGX01TPG5m1sGuBaDYSi2LalBIM+KTPLPKE+LuKMkUtLNO8RRtmWwkZSj/eCRKg20BpdIW9S9RVaFLOqhq63JSqPUSErbEiYvgzYDLo2FXNVkkDCVF0VYrIldYSV+QOePRFeu7bHWFvjJqzB1RFphFWhH1CoIQBjYU5aSg9ccb+EQnw+lpKypERA/cPBD8SE9LEs4fWE3oMKT99giu5ORFEHRJYwSzOhZlhTqIe5Dv1gupSNNykmn41gp2XB1q8BUKqUecdvDfkemSSpCdNnW1y+GV3nFBvAqSgfcILUbrAu09FHLEI1f9tEE4JoYgoSaiuJJ91BnBjdEusJjmWuvGiKTK/QSvGGim4tSl6UEK6m6tB17sOx8+JE6pgR0mjq107MoqdlAtZSF2L1GKPDkdxBSVNPItE3v10mQKNEftiMRGx3E7ck0E1exAi0oPq7BXgbbL1S1IaS3YQ1Qqw5IMuN3Pl+0dBDdhMSb5/iu32eGJyoPYp59j5GTwQjBKAW0FcVVait0qHLwOolRWbDovhLoQcAV0c7aBNows9VwlanV5LYzBRKa51ck0dKU0uJ5QiuWz/IjzylSObBjUC6u4mHnotfs0A8kPbvAkIIElCPWRHHkTUPIkFF0lMUO2uxINRr7xQta+e0DSpoJvApPcJxSW1GTgwAkRRudfAI52bbliKNE4GQru4JLoygU6qp6itqw4/CQP2lzgLrdwV4Ly0Z8jIeyqSiiIUHCusvZIM1Fkk2ZKpZsFURweuTfoFAOeaXz9GJFHR0QJClM6CNmEhCq3YaRYrPL9hEPVDHSrn+KaXp78dG809RCgKN0D0h9+hMqjUdE6Bdzt0lMcU9F1Q+AlMEJqXkYfkFoIukpZfyaH4nVOudbPyIt3vujpruJoxQlRdXUyalf6Ut6sjVqToyGkAa+S/0OTeKLn0KTotx+157mhUPZxt9E3qTg5Wqo1HeXxMek9ocidkcfTD+VhoCM/OhCVk0FJLYegiOzMIXo/QQUemlQweqyCaBBKqKxAbcf3ZS5w3ESPBv4HqNoahrDG1SjVU90JoIw2x1Q09E16A5gzCFkVLZ3fsO3UnbpkMArSTyN/CKSKyx7EpSTlEMxUzsiSPN9pRLTgsSRF80Qfwx8Ssn56jB5BeJIaPDFR6ilOlBiM9CrIuLCDLaRSLsO0ntIJHFY9kJgr1eeg2G4XHISsNh9JoyLtjLtGVjZPAvNam95FpLQ+Ng00jHSz1Sxv6PZ+xLVBJjCSQltxWyKDCNhp56WZCRwY41owT6sb/QKCZyfuJfWriCCRtrQ/RaHn5RdM0IWl2thqdSoKMIpr6npDS4PJHwhzBVtp8/H0egtRQWVUSsNsKC8dFDb7xAshSjqzTZCRqatEwYD0pVl72lEpPBLBLpA5uhTJKhHiOzNWGUD6AUHpdzQQ1xJiGqyR2wUTtd5Q8cSW8uBoysWP4ir4GfQmand9wpbAqjAqChaG4x9h0UXBCafVQSaIXM33SJNCWL1iBZa3ZIjiwZK0KDuQ9TYAWJ6Yyx213kDCpkh64vNP0Klg3CwSFsLoi4MJPkxWNs6wIkZFWFFRLqlxJVunfUGuloNltGhhqtl3021CSSEyrsigdQqhEEKriYFZ0WnRLWuLkbR9DdB3Ai5SH6miaih/QzW1MrppoFlPXIPl59ILXVfdFRt/oCLC1AglsqhhaZ4lWf0XycII2gzjU1juQOzBN1H7FFByJ8gyEV9kfLqijgjnHJH8L4GZowIj0Hxs9AdK4JTT7Io1a7jlUXhI/hd0QGmmfoQHWFEjWYYMQRGIJ1D6LBRcfRUXYMdU7CtCcJCJSLsDiVsHf6PUZZOoHPR79PgBkMqHBLmzM8Dldgp7CE9Kij6DQ1Kd/cQg6hXCrMccgksKyPIaT1fQ0PYATrwbbAmocS1/wAFfo2BHJKqPvqi58vMkdOy48Ew5KwYlzuD1l1Ng4RH0J865FkyrKlBLYosa4FO+tsjpJuVuPueH3Ci4XRTdf8Aw/gZjKwPUmRh8DPQvUKgKxtURI1SdFRWD0seddSBbvsM4mOmEZkcVCHdSVS3VykKnTy6LdjYJLD6Jw0LodhjjNKd0ri5Husr9Hs/YloFbJ6PfL37g+tWy6a7DPRPeYlFhv7kN8bqcBGleQno4cs9osUXtgUcoXYCcra6iRU6vOefdUNhfWkSZ7l4f0S4g0Jq4yK4KuDbcU5nqsibVHjTDBCnOesG3g9SiaXfAkTXTyONEint6u44IVLV2FLY9D7nj9wouEQb4Mf8P5GfSbCzk8CIu6bRV6VT0NQyGSnuWPHodJQGiQiqRP3A3S883AgQt+Qh1bvHMkeOI2KturcueRxXpgtuZJdx+kTS6bhkcrtrcUwAwUzLRv6ITeibHRLd9zMaM1DkluKol41+0VOvVxVwx4JIpuauyydkV0bWYmKntBq/1oTjJWnsG3tNsqfJJMhEdVdmVeRihrlYDlnDjjp5/SDCHjm3Fd/oaSmXBF7jSGX9y8lc8VE/PCFarxSusFMvZQGTuMHjTLLV9I1ufcYtSPaw4Fpsx5LEmdi+4tQDyIUtJt2sRwk6cef4fkZjS7CGR0qeWynBB3dKnDb3JC6oEXpeAEpnVtIoHSG/UblzLFXVpy0Y29vE+iwKoqarb5Czt2As5FH4GhFEi7XOGV0UjBG0GSj+i82hz4LPwPI6YLUUz1aigsl8AtUuZh5d7i6yLOCrJp9mOOhJ7B34TwyWJ1P0K6giN2mvuMk1IowK5PkajV0VQWGeTAt9BMLWZv0xH3Alt9EAudrShQCK0GRDIaZUvYlhiFBtbIwcT16OUmWCVWxx8vKIcqw1kg7EIUVELT6BmZ1QJkkVLoNYIJOkp4BlHDJKZVME6I2gjfT7lYzLGR1gSLTrOTt70/h+Bmep9yyoCTYcycv7xJUKDHcO46SbYrExv0qMrIQtAuHBS2C6VuWZe1bhKHrLKLYlcnzS6CQooa8kxd+sKI0D9hhFJWBJ46LMDUajJzX6IJqmvQi+ex2W59AgRLIKdh1XgjwGkbC3jApp26a/0OS6Ilfd+RdFhVNd730KKHiJCkqAsBvHuLk9i3IkCrcBNe0OFJ9tomN9YRlUDw2v0KyaqSuoVK2IO1AbAEiu5KCsVwd2b/Po4rBCUPwH+iCqNVI7OCllFruLp05kN32+Ccdd46VMt7io/lBB5KkldZMCDV6D7QqCeyiC14YlVFP4VZ+BWKv8uRiSJjdXUnh0p6YlsC47bfDUkb2OkiCk9sGqJmSXsKQeycSiSWgGu5IQTmwmxUpTccF1dUTIcGNpslgcTLRcxbQpvqFklUvhUP8A7xhD39LzkkiOwVx9FRXTR4JhhRyFGpRpG49R0dgwQYofsT9UuphNGxRQwutBaEfJhEtFWhGrZutuKyf0Vg4LJRruZq+faTDTLsIPRQC9xyybmobZ541HcpUrtRX6INaYerRGiJYD5+ZFWoErBP8ATOIQfrfpNGNgtZS5Z4Fg2/uUUShF5FUJR1ntxUF3Z3iwYXQKqrQVkpK58zc+BoVaWJ1z8CcN/wAJPw6xvq6sIoKJUaifqulRAb2ERW7XfSeiv2RDTcEhja6LRVGPql2uRhzlTQbEB0lCYYXV47VM7PYbmkD+sRQzNrbAyOTGsll9I5IoAvTrZcu/0QbUfhDJyZhFJJEkhygRC06QkZy+RotDLH2FUulhrWYpZoyzy/YnRXhdKrnpwHXJcMF4GzQLhZE67mk33dZ2as9Bj1lir483TzxM0W4VLMPEVL/QspreE6COEzD8q9nAMQVbbku2NVYJ3EhCF31E+lGOvTtr0F093ujswJGHa5EBJQNfJjabbMQVhMTcTVCidCWH5tiB4SS0KYk/4/4YGvuyO77sqDWV0eudK9bpTZTV4FgxtE6w5Zvq0C4TS3GTyTEiBMWb2ET9kfWwicJ3Qn5Z6oVC6IafVGMk7hvty37v0JqVm08E109xL6EnXUw5ZWCwXTklSL7Ih1KbSWGP2Gewe/WYFsdGNFBrX6QSz2iwnzqWdyKZ15yyZTTa5Oj6Ig3hYcdHKSTZZId5gwbMCbSgkYgeVv6COSDTs4WZhQByi58fPpGgNkhX0ROxQfbKJSUr8jrmE/oq9y8LuTCNUsFXlG0Wao4XGm0wXRY60mhfhHSyNvsLtUUdWV9fc/hlWvvR5BD1ZRK/0+DUkb1htRrVRGP7AmmdNEbzlWCfomaTZdkIrO7VEWkKCkR010wJ8bRokhGo52PUvAbTJaHWdxcEKOOVQYAdEJBnAr9G9C8ond7orc/QHupt3yRJsCXcXoruoI3Kk23GrADfu/okSCwkxTgdrmzZQkY82mXLE8Gdh3sM+hHYf2EQRaLD44CLRVGfop6i1jUaMAA+Hn0ZkOt4RYa2CNK0hNVZVY2zlPq1UPxFRncUQvctkwutdBe5+0CZ8s6whDn5sFOyPUfAz/hQtV+o/wB6ATRwynwV6a1JXVAqyNErQRjiYQjc41uKvxKiL+D+h6aVlFEKsw9nJkRVXm5IlcEhRTqxMionoxOKJySYgQSFnYIsPQJ9EatDwNBBJhDMMtRCDEPkWwktF00/BGInSluW7tL7kdEHX7wDrS7UM9UzoxM2ZcJtULbXqyLvRVY1U1Ek4Rvsjp8bBQLC1hCTNtoz9FXSqbxKJf6WUG/pFiono1N1J2Fk8PYRcQ2/bAkTkrO4kdLKbKHSVUN7iOYaoMWKVWVUWhWbLdiEoxoIka3HShUfVKdiqcnzU3/DK9fYNmO7GVPlPSO63RPvJPcyUtsl0i5EauunkZ+9wLmuvWWVTV08dHLBHubCg6YZrKQLPJhJkcjPSLQQYh/oKyOtlPQStneBWNvRkKFYZVlKd/og2hvwNHfLE7ifrG4MQ07rRZoIttHVPUSh/wCGPpcpudEkdEnNt2MUXD5exe0e5TKeAy7adPQawftHRN17RLfNV7caE3VKwbsMRqSj+ETPgYMaUrgmNTH0epUEYFQSbvcK1KtZJMX0BZZg7lddUkMlvaeNBRE+wTknO98g3y1lTKsCyxYbuG7saohYE7m/kVZOeCbSxfuGzxFGcksElJESxm7adLuD+GU+GfCZLiR6sUYYkerpDM6xajVnVFtCOxcJ1wkhBhRxA+j6kEw0m8QSSWPQaKTPcPwgYFTNzWmCChshICoaD5IShWHlDHgzPlO/0KHNoc8QOg45IwJhGE9sYEI25heHIVpFCVHYWV7svQwmMWONIUo7a4IpI0hLNezQFhkND9JOm06hTN/qpCG4Cs0xQUmVuVBO5ImHkhFO0x0rqga4CvSfoVKTascIpiAsJG4lO1vFpYEqk+4dJHNAYC3Vsz1QVqFd08FeJGl7FM0JpqIEpXTjYo6bRw8joZZK63mCETFbitqjcYvwMuQmZtkxLBOpOslmmGcp/n+L5IrJ9RSqx81R36JmUQSSozKw2VTThlkTp4nLMhdSw2+iXIim1IiVAOBJlGxtPRrUPVnJ5poIkCt0hjMK0q+mzCL3sL2iE1Jt86I3RU8v0SktKa8oWxTsDkSGcu/giybuRQd8xigyhoKiZ3Z2CRXdArBGmfeVYaVh1N9Ac6LkP8wdZvY1IT0s0H0IXXIyjPYNg5qlR8TUaS/pEOOUDV9FIbtd6Kx0JhE0VeQmpIHBDdQWhDmPNkgt3sIcDsLt5gN3cBDT8uKe8ciaAopKWb8UDKG0r1oLQSUweBunMYgPfR5JNYGmkzEMRG8yMT9l/F81UDJCCMkSbVC0FFWgSel5ZllYRigtqRnAVSFim8qKhfYV0KBSHcM01XCLDhE8qBmDTLrtalzxklbcO4KvFrUYSVunliviCo3yVydgeOrcF5RzBNJaryx0cNZ9yIE7qFgkOkbDZHQwgVEHAkeUAvYVnkOFtIGsos0gbx8qC2eg95fB9/ShLxM2OKdBW3FSh0JKLyjMJ7iKOXsJg4QN6UEv0SgKK3HCuygvT5E/Oq6SA3aiVJHaglSE+4Rndo1E+aI/BsM0BQOaWSq4MlUzkuDgEwIgXKwlceywklFVXQt3vJAgytUNUQQhrwPUaFy2yao5/h/GoygTFpRsKSFSvLAjET5idhuK8lpORmxTXuXSggcuJIVQO1NVI1KNAryT0PQjMHLRlRbqrIjAkthEyW2cQhWhyHn0o3EmoqHtBp390ng+sJvQ34QpQ/STiQo5A4QaSLhVukUIZsaHkaVKqBFSC70CcimyoPkbUBLs5oxtRna4W2ISNl2ZJNos0RwTNH8AnO408y7HKZbE8BYGOr6KnqEy3Ic0SVH1C9oY90KWokTEoyUKTfK24x1VoRJqJV3ILUSgUkzPiQPErLNDVvcFoq7UGSEQiXBeArf+i5JyKX9F5gmwkk5CGnZBD19mQr4w/iaxH/zwIAQROFfVMqTMkPAlxMElW+GgtJCNCaDXO4pET74xzqECGHUHZepeECuLFkY1mIYg867SaKMDPSgzB39ACoCYE70RoKpHGqKfVSVoc8QVGZ9MNZoLkbs0o1JpXGB5UWHY1ahOBIneENUgvYQn+mlwaAGZFsDfNOhdtecia/ujM+SNMdDVNVIjKuJ2QmIuEPoYMjyJwZqjUXf2Rgh7Gt3I4jIgoaNAglvVwWWd2JRKUGjNDeEQUVaEilqaJtJXSB1VNQrxQ5poPDAtkYcN5KNhjN6ocJ4HpSeBC0V6L+L/AAd+8tFuxVNJbjEd0fcao1u5EZu4WRpTvRmeC4NXEsqG1xdgUJ8xkzHAm8QgGl6IoSh8iDYgRRQWHoIIBoD16Lszz5yeQQhSFWJd0UBPw2VoUbgpXZsSI6BaoYWmgsBLEwxVKzOhRor8BrAa0Tah4lwswMp1/QNNLmEshQrAUNezgdhtTQKUvZGO+pHbONGT9HBfCBJKHDf9Bby2UdmiuMNiRVPm2PATA4RFY1IVC3LBIcBCigaSi2ZK+EygdAOmqm8PGnDLlBXDyOYcaiWQVSATNydHQQPsJqhWRoB/jedkQv4qKANw8GOw/wA3CXcBCIT8wbleVA6CnfgIp7y4k1HcrjKnBK0M7ylqhc+BWcjGhI2Shq24FQuECJY7Cek1wyjutAo7FQ+wkopqnIhbOH4TUCbNmlmljV9QbwKWbRmweql2JZfcnZ62ZeCs2KJtZFTKZmXqMAYgzCssmrqqDe+QykKkkNh+gy9xyaEYG8nUgsBUnhq0nyGhErSRNB9Uang1vAhxjISF/P5FQ2tPkxncnclUU08C25yGtN4Jl9y+8NDbttRF7RB/iGQ4a60EKHeSqhKUTRFmm4s57Fks9ACLAQY0rBK3EF3WdtP40oSma5ELeOXVQxFEqdyLuGj01DS1UEkRFVZ6oenabBQedyF/c2exCX1nFBlRy3JekPSE3XEys45o6DO4K640HsjFim8GDyFhmVNdOXFSGj1fRBKZUcLqJU7eyp3CjGxwbSJwHhBoC6IFEq4rWyBfcgj8Ahq8JtKsJCMc6iBLkpNpinS9EVo/IgpRAhyojqIJVpoN5lAJhdCufXqlch2YsKlh0pm5YwFZt8M0JgCyBFHPSmpvBvhrRdgrqBUJtMjveoW4jQTJRl0IVw1C3oX24YmmDAKm55JTTtwTS91F/J86CG4jA6VEyd0ySAW27bMdJIVhy0hFk0DtTYjS7MMUhBPgIVJ+8uBsqjRnrIkUsQnQtMhrNjke8sJSEUeA8iiPw2Br/QrLD+KpTGRkGgUsQSzkc0lI3XqRFBP9zV8ldjTsJ7CUC9ymi38Bv3Yuhsa7GHpEBQqkOsJieqK/BOF4HMOkXPGNDf0yFs56JYp1SxJBSVHcibHWJeR6wVSyl7S4TQitLvGUA0KodjeB44kcXpuKZq6+xRWdz3g6oiqqboiwOJg8cDdz/GBsrEsoXVfA6uYEsgHvQtg9v5CCq3QV15sNdZBaNo8MJc8JPQqR8ImonMTXemJU04ljwLEU+UYT1BVJFI5hAiorjQZqcnIdyaYtg9I050Qi8mFw53J/YOdUQ4L0JrK2PqcbAl4PcOCRElqSMUjNgVB07y/uONZKiggN+AaeFYsHKVTFS4ISK9AO+L2GItho+BS4ywVH5msJIjOmg9JJyCKmKR5F94wQKpRfZEqVlEdXgQabgydVAmepKflqQW1oOFepDQXRO0O4jeyS+WUS1UODu6srCiDBhm1BKFsnErkqZZaBjcDY8TQnEIqSdBtWg5glEcxGpWbULQsoZaJIX8rsBPWH+QJpP4kYAf8AcS+bE57ZQYWskBh2H2uhaArg0bABCRaKJVGciB6jXZlmfclDo1lmopHZLb4K6MwmVuQKWzCHXXk6kHN7h2sCdRrDQD9cfrj9cJJniVJjB6Z0ENUmSVIaF8qJWCdN1U1Hzkaid0fLNQ1DWGVCcwI9TVQIcpMZtPuWOn0RkjE+4URCoOuhDwTaSiDpDuU1CyV+RcK2pEPpqmFMswD9L+T9b+TBPZ1UZjhYJOwvJayWRVesF7V1EAjngNkq14wOaZEh1xcKgeSNMhQSY7XRJnzFJJSSXkMJM3kuIowNHBmY8P3H2CE76FOx4PbeBfzQh1TwMHZlC98Cn+oUuaYXAv8AF+D/ADfg/wAH4P8AB+D/AC/g1vngb9X4P8f4Nf44P1HRnw3sfDewijsxP1f0v/8A/eyjoE+B9y8zx+T/AAfk/wA/5P11+T9ND/D+T/D+ehf4fyfqfs/V/Z+p+z9X9n+f8jfL7lj49x/wr8mb/nJ8v5P0v2KrXzk0vzn6EAGzC32AxHwHv0t+l6c/Sn6HpnyPsa3j+Bv1jS+i4TnvIYKYfeAE9CIcKwvS9ufUf/yM/9oACAECEwM/EP6wA1K3J6Z4cT7NCDGTDlEJsezKAkqSGosno8LAonspScYBR0Lt9jRU1KuW2TuF3I+wTAnNiShLl6+bzTMZchpEfKkevF5t+4INPr+2fr1z71bP6+tguUXCM6xakQet/TIkPbITdFChgGjKhgQIQLY9YFLsMKgRloEcqCFke3pxyhyguSBwQJ+kKcC4Vwrhbf8A6mX/AOhSoIIOBBD0fheB9rr7X/S0oEHAUEOCuBXIuBQ5LkQ5KEBBBVhKjnOhuWnEna7dTuuSDdwuVza0SEvLtdsSnmoeiI00Vu1FtAKkzQSzEk+DTAtClAQ0UhQESY0IsL0RwE2tACJgoHAWhXK0DVciidfQDRkocAH3IXiXAdVLCcFYAG0SYisKIJSrV4gMZMrcIoFhjSzFQHlosrAlAtCAKCGqnVQHxai1a1BkNOUNLbl4Uq1TANRAlfEFJFoF6DCCygGamlR1L4D/ABMaFoY7K8BtkfqHJ0wxYX4LbQDG2liYloWway+q9vBC0yK+VTPPyUhrn4VPTgSGWq4GQPJY+G/gvoyEqAHlDdAh3LCQxo2TdlibsdGiJCENgaoHXVS30LJNGBQC0IlypDQrUvfQqxWv0oSt0NTAfLPIJIK1CCCeTgCgwgkKVuGQuS1Llvhg4GdGzAeKw0VJdCJyocls2ha92oJdlFWrDAIkyVClQFKOjJDBZUh0YlGyGigtJDRR8eQlqfm1Fm1EyWIsItSCkeVJTyFfwrOHtkKixsVMB4RINk2WJSFS1FDSVJQEknWNWVsQUi1OASHqDgZVUj+XLrRDspUICgbQ0KBQQBhFn9y1U4ozKhMMQjZbwvKj4l9arDZv2t1NqEOUCp1UNKhxL3uK+VB+ECrYlAIahDUsCrl1VgC6DDakEOVf4X1KsScF4DCaLQt2pyCfYwSS2eFNBcKX9WcFo7R3R1MSpr9hfQqw2b9tTNSmWcvRLdsZcSP5w3KpppQp0UYfUmluWkVFqT7C+jEklC/bJQJlTqyVK2aifcwl2GgrrRAYBtQw0CGhUhQhMO6qmsuAFaDbfC+hVhp+5tMSi5aNPuYy7CCCWgg1KVVIDXVAIt0JlFlqyBXwQaN1b27C+pVhs36QSEUGEHuDU4hs3GEJKLQjIWVa3W0wKR0tBht2MZRb94OVq276dqx8tbsL+FLHJRgVcKXi1lEqGgxcoJ/LCXYe8EBgWh3IOLj0FZuGAX2KiS+UURxIacTfBJMEAVr2pYhpRl7qshSTglRg/lXb95lu3a5N8kIXJ2RRRcKKmpcVTDCijgFFFFSdrgUFgVSKLii5CFD+3n//2gAIAQMTAz8Q/rDQBK1kG5LA2L5aEaiPZiUDdb/Rf82t2Sh2PwGijTsLTj4U7StnshOAJJX+7heclrFWsZYNcCNkf5CBI3XwexEgBqVD7PCAahbeULEnstCgidbwaRW2k7o3/YQmFyv5HsMme2im3FXu2OFvyP8ALRneBDuC6z6+QHKoNgXVllB8CqTyB7Al/Mrzhy4So+FkHhSD192s2QXNQHkevIzo0cs4A+vGnOkfby69a3oi1rQ7eVuQ5zZt8oIzAb7oomCdVKPWaiTjSAogZi2Poo9aD8wtUIN8vAoypK5tHYlA58n1lJHaLHRA3NzKI3KDlbq0JktGgl9OWy4M4ognl1wZMItGz5VyLnXOudcqFYB1COECuCI29BKlk7/QX/Av+Bd/S011UEWHhEr6rdZyX/kvD6Rbj6XL8R/8M2cohEIlo3KDgvBeRk6UjmJMKAp0aFTBpdrUP9F4fS3ZW63hA7QuEfCC8IaRC0Q07KQqVpwp/wBC8/ReUhA6rghwgVDA62vjmgBcqFsLJRJJINQxIRtagI1I+kJkSurt9LRUIeLO+AASdUPCgqQtgIRwlaKRsTqUmf8AkKpRFMHCjASydzoF+qHQC4BSVKsYs4QuArTBMbQvgSQPKi+4p4vVfraLduy8oS1AETqi7anlR84UfNjAamloeQxACt2OIVmAgwAO0XwviCCv4X2tEhSCSFBwIRZBPK+kg1JEqlGqCl5UKEcoQMSSt1A6wiYP/pFZtJzxSIcL6agBp6GRapFIfZ5HBWHMlAVKcVHwo8CP4MVEvkY/kCEeSV+LT2VBpJfbCpoIQl9qJ/Glc/XLfkr7l/uSifGRM9KTxkbDw8rlqKvokTm1R8qvgS9FftUH+ZWz7lS+AKPJ/t7PzBUd+R9goDyWOgX0SekXlVC+orTjTIA6ECEITRXlTRVuna1K2VSgNUCvKUSfCI0aVOWgRPChwG6Ggyv9UDBLSx/sibktIf5aG/K18FWwyR2z8LZy1L4KQ7NFAXwBXorjxuj/ANpY6FVskw3K1bwqKI/wXBQ9X0EZk6nAKKV5YVTpfbiUUGC+oNKhCu0GlKqNA3/XlCVwgo/0uGy/ygE8PGlndDpwBG/KjVfqkB4XjKHW13V9HATEyt1LQoUgj78Y/TrW+BNPHwR+JFXrupV8oB2/3vgTa3NqZPUvoQpgaNQw0DAFtwq9lPevpitO1/FSoKhinGC+j35NKB9sryUQoY6qCO2ihFGRcXaTuqUHVvK+jp+TGlFafgYDwzh4XwP8qjcNjar5KhUi2VstmhWCvo17hTvMrBUMVfoq8UkVfZSfTWgPJXKixu00tuHUb9G4aQK3+VXb7nbZSoBX/DRrsJDfC40GqnRgG/RXilWLdKVBW6nwtBw3Cjtcq0o3yl0q/WCsqWAAKV/ktBtAB5LQp003X00t+VffEgFIL8KWhpKhELd9HlfaJUDtTsAhk+GKhiQVRl3io3ZClQPLp+C+xWw0V9l+EMADZDiV4YNRKnpVG47rVfJRCq1KlQr1UqWqFRll9SIVIupS34K+9Ww0UHsyGAFoHZQ0hDnVvwqN+1N9HAFWwKUAgKNWunZrr6ngrU4fyW7YYIUnsvzg4xfhfQ37Wv5KgYA0NOqlX0a6rlH2lSThhadhfnAFLAbobm/DkatjS/zinBKsdBrqnTUoyLZxaKvTDlwUHCvovoaTrQHMn4MZ0qdZMCoOPa+nEnBZX0N9jDOL+QvwfTrHToxsIXPUuSCDByg4OUBKEKrjRkEhRBBDliCDlBBDlDlDkIZI4FVCZRHVDlBgQQQ5XJEtKkPP9vP/2Q==','portafogli':'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wgARCAJyAnIDASIAAhEBAxEB/8QAHAABAAIDAQEBAAAAAAAAAAAAAAUGAwQHAgEI/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAECAwQFBv/aAAwDAQACEAMQAAAB6oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgK0dEc4ny0Pn0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0+UY7HybRu/vznFtUNPoMBWaP1as0vtx7i1tntwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVuyczIy0w938ns81ey8xxZtPp3O987lq2Gt8XRr9J5D136Dg+i0AADXNhp7gAAAAAAAAAAAAAAAAAAAAAAAAAAAAA5d1GnERb6XJeJ2aU/Rcl6+L3UrxnPmq7XnLWB69zLpnvcH0XgBVsFIyvi+2/a4OilYbppROXoHMvvbz9NHRmAAAAAAAAAAAAAAAAAAAAAAAAAAAx5BxG42PlPDvZ7VXcXndFngNX1V9q/zqHp88ntndgAw5qcUC7RNq8vrgsUXYIrNfa9ZuLWlx90hNFtmuV9U93hCQAAAAAAAAAAAAAAAAAAAAAAAAAADV2hzWI7D8q5BN9ExnnPFR1lmUrQOiOX6R13m8BAl+t1XkvE7atuW2vq1jbutD1r0Oq2KE4uiC6/+cd/3/N784J7mO8OET1p60JkAAAAAAAAAAAAAAAAAAAAAAAYDLXuPZ6Uv8PEbmOeppWNSlSw2nBCE2ZbLRGbEhkzaObb91a+LfyUV+ywexPpXr7W8nLvDpTBvTC26ijVnrjQdfKlhHOrVlrfV0d4Hb1AAAAAAAAAAAAAAAAAAAAAAAKna+HlR6NX4Hl57nt2bP5l6ts2BnOhvfWYKAD78kY9eW5W5HDtNTkJXQ6tvkbtbqdG71j7jhaKdufYYfVWk+rklq/KRe+ndGvm7Or0AAAAAAAAAAAAAAAAAAAAAAVwpnLrHGVm5rvUPJ5qp0SEpfRPTdGoT2TLp7xWM8SWG7R8yXqUP5nfsoPJNfYiH9yqEZ6kfVUb8k/pGeZTyRfmW+WQ/ib+TEBjtpSm6t8r2mnQLrU7Z29QAAAAAAAAAAAAAAAAAAAADlXVeMm/X7O5Oyt32p1bLlvulE2rDmo2K2RfTWx7nPekcW2TY+uSPvzTqGs3tztrfoimW/GmQYwAAAB9oV8pvXXafPu3Gqtqpu2vbZnkth9HtvKBmTKAAAAAAAAAAAAAAAAAAABxPtfC4mV09rBz9uWXgdVWSq1ukYrVZVVq89mrepPTy2DYq0JhrZbRpWfPv0vMPaaISm3/xnb7u866LTzw56gAAPHtKiYeg6vZWvUiyVbupsYd350+hGeJX3MebZWoSafpLPX7BagAAAAAAAAAAAAAAAAADgne/z/W05i9+MO0DSxyKa7+7VfcRKVS378V59PylXcuvCSu5plEZsma++34z+ctcNlg/NIuu/wAz8YZ9c+8g951645RuZ16WochnFsQUhi3fP3QiKfVLfUfciZF/QefQ0tHfir4/oGdjpG+QAAAAAAAAAAAAAAAAAHj8/d44XS8x8MewAADD79kSezB+6zJV6a2lOfa3Tou+NEk9iB1rYs1Wka6WLJD7NdJDJp5q32vGFEfMGwmuhqTXuYrPm2e1aXqdCwTWoZrDqzMbn86ExsRH3Ppn+lMhNAAAAAAAAAAAAAAAAAAIjjXWuU003xj1gAAAAAfMuMje3YHXiJSG2duc6rp9L9S5tsXbQmIPcyaszu5YXEWH7WNAuzx7psAAPhCefErvyd1FswAAAAAAAAAAAAAAAAAKlzi+0XPXYGXUAAAAAAAAx5BGZd5NdfN68o3NqAwQtfumaqLLRrDAaZXL7H6cXnENsxeQefVbsGfRmIuz1e87cnUxagAAAAAAAAAAAAAAAAAHPqnY6/lt9GfSAAAAAAAAAAAB8gZaGvnt4m7tydW9x7u8D3EyamtAj+qc95/Q9x+zp8vrxfT+V9l25LgJqAAAAAAAAAAAAAAAAAByyL29fPbEMukAAAAAAAAAAB8+6hrx+/oaY+rDWLt0cFrHb4QCFmoiulEyYcnmfUQnfPz/APpLTn3BMAAAAAAAAAAAAAAAAAAcb9au5lvrDPoAAAAAAAAAAHwx6HrzanjVy/L00NrQuc5aUg1L4TW9TNO+HTYKh61qz+OA+c/pZf01+c/0bfEAAAAAAAAAAAAAAAAAADh+9GyOXRhGe4AAAAAAAAADR961qhNdLZ0pCaV+6Uy6JDPZ68jKxDJWpmGvlv8Ae+L9o25QAAAAAAAAAAAAAAAAAAODScVJ5dHwZ7gAAAAAAAANf7pWqE1AjZGO3ZpEXCrWmLBTUAfCOj9jS0wvnVOfdB15wAAAAAAAAAAAAAAAAAAOAysJN49IU2AAAAAAAAYPGraoTUACM2dbJbNY4SbroFNAGtmj5rrxsjE64dvtkNM3xAAAAAAAAAAAAAAAAAAA/O8/WrLj0hTYAAAAAAYDLp4vlqBMAADwiPe9e2cxKaO9nuEWfGkecZfPWhpnRvj+jsxfIAAAAAAAAAAAAAAAAAAD82Wqt2LLp9DPYAAAeT0wYpjcwafyYyYyagAAAMGfTmqPlYW1Ldn+ecuj351tdGTEWqBp59Ow6c/bRagAAAAAAAAAAAAAAAAAAHPuU/pelxPOskD9ptO/Nb1TTOwDL58JffgAAAAAAAI+QjJrIQFir1qWPyU1AAY8mvMat4o3UL4dAFqAAAAAAAAAAAAAAAAAAAAa3NOqD8y7nfuXRaCQEnTXb9eMMX2Xn1EgAAAAAAI2SjZpIQUzFTE2K6AANfYwTEf2zhv6J055ETUAAAAAAAAAAAAAAAAAAAAACG5T28fmKW7HyaLavyMlaa7LT9xbZEWAAAAAR0jHzXNDyl+tlznJ3aItHI/fRIyJqWSXjoeGnopxfprgP6BvkAAAAAAAAAAAAAAAAAAAAAAAABUOT/ofyfmqR6Tyyt82aPkK6Z2pki2cRYAABob+hNfHVeT9nvjaxagAAAAAAAAAAAAAAAAAAAAAAAAAAAAADFlHNeY/pjTPz3vWrnddJfJp79NfoiwAHzU2PE1ju88C/RumG4JqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZIcZpH6dgziO7tVWmtgau1XUInD785ZiE/S/wCc/wBG6cwTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACsWcfn+F/TNPieV7HmBrpYEdljTN+g+J9s05gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEHODlkP2sQM8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH/8QAMxAAAAYAAggGAgICAwEAAAAAAAECAwQFBhESExQVICEiUBAjMDIzQDFgJDRBkCU1NkP/2gAIAQEAAQUC/wBcMu2hRDcxVFI04qjiLeQJJ/pMh9uMzKs5lu9Fo2EEe7Y4NyrcD9LFeS1Jn0blfOZnsfo9zLXbWJamtit17skmW2I5Kc0ikRY6VNr2gKJ2isWHUvtfouIJWyVeHY5IYqWte4tWkdvaJgkS710q9Tk+7sWjNqY0mfX4NlGpj9FxsvyFeRS6BMsB1aIuJG3EOobWU3EoqT/i0vkYo9BbzbYTKYX3zG6eiSWspNYTzU6Y7vaVFZlIiIOsvGI7LAPkKXqi1Pm4r4ra4YryXLtbQ0UC1BWHyBMWlcKnEKH1d5xVH19TRPk/XVTmrTiTyZ5YhcIquLIfnC5kGhhxSa2twbGPR4cQWpV7FXWG6aHjdPZZZhUWckHNXHVZ1jc1vDdosnO8KSSkrSqitpLJSkMyWNrzIxpCVZttnEjKQuQty6nxWERo/A6tLbcQlWtpqjmP2856uc39CzacQ82tKVoyOqkYii5CombdA7xZwWrCMlyXRvsyodg3upghuppQW/BrUG5MvHaquar4/Dip7U1FOgo1bWo1Vbidxa3UVEJLFLBegEJrBSI0A9sqsGOmlzvL7Db7czC7Sj3PcMjctu8IeF2GzZaQyjixr/UfLRpuWpxOwsOXsYokarkWKa96RAsVe2o/NF0Yn76paUhywhthd5XICsS15BeKooVixIVix0KxTMFlbSbBuFlKqqp3XVikkpO6oDSmH232pLhTsQyXCZZqEG3BSqQ7M0rYa23IbVcEDsLhIw/cy37DuJnkJF1Xsm7iiGkO4sMOYmnLCrW2eCt5vDdshRlUqBVKAVWwQKvjEChxyBMMkNBJB5KVtYelapxxRwJSTJRB/DzanIlY7XWLy95yL6WUeHXk8wzHdJ5nxp+WJO4POE01Y2cmyeaquSa2OQTEYSEpIgpREFSWEjbmAT61D+YobPPMbFMMFXPDdRGN0RgVTCIWlSnV1dqmQkozsY9tfQDnvqCo0qWJcqPWx4EZ2zlCv6OCn/8AS9wxO9qaeOvVPaxGqb2ySRV8xQ3ORhFPDSEQ4yARZelY1LUoE9Z1gbxC2DxAwFW02WcOmUpaSJJC2aOPISolJ8KQs8S9wxPZFNkphk9X6x1lLDjbzXpm4ggcqOQOwiEDtIRA7iEHLGrWCsKpIK8hkW/Ig35DG+4YO3gKSuQzFW1YR1ltTBikWgsRE82oEefbsUW/MizN5hVacmO3KbYekVchixjPMrs4aAq7hkFX7IViAxvqWobwtFjXWygaLNY2KWobrWY3SQ3U2N1MjdbA3ZHG7Y43bGG7Yw3bHG7I43YwN1sDdTQ3SgHUjdKgdU6Ho0iInCj7z9d2u9m7DX1sPaChI/nKLSKRGXBNSW5LUyGuMcFER8FCjkCYZSNNlAOWwQ26ONrIwTzpjOWYynGNVYGNnsRstiNjsBsNgNgnDYJo2CaNgnDYZ42KwGyWI2axEZzWs+N0f8fCyNCl7Xjd0RUaqNaQTUdfdKaKPJZkpkQTQpC0ulMrzQK95hbiaqEE18RISwykEWX0oPQfjeGKZGhVdrxeenbqUSAlZKEqA0+HokiIqFeuIH8WxSvTYVNgJfEKe/XLiyWpTfhKksxkPXpqVtdssbfaNCNetqNtaXEenaoOLLSZKLwuT/kRcUE20ziaCsNW8B0IWlZdoxGeliKR8iizDcvIxJgMvh6FIiqi3S9FGiaTJia04zIr3a64bkC2skw0w6x2WtOyxTI5phTzjRPw4k5tbcqmehyW5THpLSlaHociApuxYUELStNl1zzitg4hA4qwTb7ZsXFhHOFilWbLiXmuy2Z6zE73yAyJRJN6KI0xp/wkwGXw9BkRlKmLUcSxS4JdalYjObLLRYx5LkeTCbRiSboxoUhMiPJinpMutzo7WlUWvqOx2XjriLVvddh5g01jXJBOoMcjKWgkLoP+n7Ks9ZiR35PF+Mh0IkyYojyWpBCTCZfEmteaEWc5HGuizUyq5xof52dZkyqVGUm5nthu3fRLs7Lbm4l2wTKLaEoIlxlgjI/RUeSar+ox1SvE0kY0SQ/NPzKMsqjssLruV+/hcitrND8pgMS2nvCRFZfEiqcSGpUiManYssLYejhqSlXhopGpYWFQWjB1yRu1Q3fKQCVZMgrWe2EX8ggjEJBF9FMItoSwiXHWCPMWK9XBi+XXQi6+BXOVJ5v16dGB2RR5JpeqYf541tocCNY2G3SUQdaQ6T9SkwpqVDNTqXAl1TYbfSvwS4ZBKiPxJaiGuUD1SgcaGoHXRVA6hJhVS6Ngltm4U8kbVIS208bY2sFKQCfbMEojCecpzqfQWijskxWjEoi8z00qNIS+ErSrwfgMOh6pWQdYcZNDy0BEpIStKglZkCcI+PSUQ1qxr1DX5hWoUFRoagqvimF1iAuA6kEbjRwU62f2W3Vo1dGXR63UQKS6kNymVn/h2DHdDtQHK6SgGb7QTKWEzMgmckIlsqBPNmNNJjP0k+3D6NO57LiA8qam/q/QUhKyJpTYKXJbDdjHWEqSsvyFxWFhVZGMKqGwdOoHUvg6uSN2ygonGHUHmjiPkRcomEk6Vx2XFJ5UlVygfTWhKxsaCMjmNgp76Am0YCZ0ZQS+0oaRH4SZIf6pH443zyZe6YuCk/zuy4vVlUV3Kt+uZEYOOyYOEyY2BoLbOM8GW1vynGbNkHMcbBWDYTMZMJUSi8Jn9abyZwQjp7LjM8q2FyrPtvHpS1nkmgL/AJQpChr0qJyNAdD1FXuibRSYgiStb4TfZOPpwWjKu7LjY/4sflX/AGnjBc5cg8mcMpzmcCVqSMRxSbcYXrWpfyTvdhVGjS9lxwfJH9P7JnkR8zZ5vyz8nC6enhuU6dZWHmy/zlTD86iToVHZcbn5/wCGPsunzETmU724bTlA4bY8q2r+Jz+1J+eIjVxey41P+e7yL7C1aJBZ5Jhl5M73RZ8qI2i/dIIv2gi6hmEWcNQTIZWMQuZV1cWUb/7oLWzOzYxPO2f9/wBczyJR5mJB5MxuTEw/OjOaMZTcVwKr4qgqoIwqpfIKr5SQqM+kaTrYJ5whSp1lt2bFXVeP/L9dxWkfhLPyW+TcjqkFyLxzMaahrFg1qBZbNhZGnddmxFzxE78v1nV8E32BHXK431aLLvTFwWjOx7NddWJF+/6ri8uGVzdMQucrjmn5c08msDo7PY88Sf5+o4vLic5zHeTVYWcji/AfPMTj6cGIyruzSueI/qLXlxlzmyfgqi6uJ4wv3zj6sLo0KXsy+d99NbnoMc5Mz4qsvL4VHkX5M/nln51OjV1fZi53P0TPILXn6MPmJ3trSyjcK1aRguch7qkNJ0G+zMHnZfQU5kDPP0VHkmF8c73Qiyi8C16Xi38sFOusuzxuU/1jcIgpRn6b/JmJ8Ez5WCyY8FHkFrNXA37MNo1l12exbOJbJUSk+jmRA3CBumDPP1ZXwMcmZPN8iyI1EQU6Pzw/iHg5GladnxPUnKTHkqYNEjTLWmNaY1pjWGNYoaxQ0lDP6M34kFkhXOSZmfG5ybe5RMEN9XaLihZnCXEkwHWpQIyMvrTfBnnI43/hm8m8GN6Nb2l9lt9uzwwHEPRHWpJH4kZH9OTzeVyTE+fjf9k4+rDberpu1y4jExuzwy42NJxhbUhKgpJKGkpAIyMvoOc5j3xQvk43OZzD86vRqoPbZ9dGnJs8OyIwQ8tsNPpWFNcydyP1y5zZPwMu6o9rG1pG1NjaGxrmwS0n4ZB7qkpLJPb7Koizys6OVCDUhSAhaHS1amwh0lH6rX9qZ8ODGkqiO1kJ0O4drlhzCsYw5hNQcwvNSF4esUhVTYIC48pAp62RJm9ys6GLMFjVSq82pKkjy3k5ONhDqV+pG+Sd8eD05VPfDIjKyw5HkCbAlQFtShkh0snEBDiVelE9k4YYRoUvfnEJdRZ4ZbWJEeRCdalAyS4WipIJXGf4i/DO99KnQqf0CRHakN2eGDIKS9FdakpV6DnxsFkzM+WInQifoU2FHmos8NPMhK3GFNSEr4nfiSWSXi05Zcv0WwrY09Nnh+TFDby2w28lzgcLNAjJ07f9HsqaLOFlSSoIakKSG3Ur4KQtZe/pNlQRZYn0cyGEPrQESkmFSEEnB7JuWn6XMq4cwScKFmWF5ulUVyK6N/s2/8QALhEAAQIEBAUEAgIDAAAAAAAAAQACAxESMRMgQFEQITAyQQQiUGEFQiNScHGA/9oACAEDAQE/Af8AKkKHV7nWWJ/QKo/uFFhS9zfhYgtDTzSOSIlJAeERz+EdzIeqhMgpgQvNEzPFjC88lTDb9qUJ3iSiQyzXQogHtdZBv9Vz88lEi/q3IRQ0MHlCYMmpvMc1TMU6+anlf3NKLTOYRAbzCFwnOE1UFPVOeG3WO1Y/0sR+ynFKpibrDduhC+1CeHCly/2qB4UR9Al5UVvnh6e+qcBEVAHQbGe1OjvKupTToRFlABB1JEuaez9mpj6uRTogasb6WI7ZVRNlOKv5VTE3VMTdUxN1TE3VMTdOMRqxXJkVxMtQWzEk6EQnw5pr5e1+TDftne2ocIPdpxfgeSLGuT4KpdDsmFr1U1vthoRHzlNOaInI3Tm0mWYsa5QWyeqQqGpzJaRt+JbspkXRYHJ/pvIU3N7k2lypO6dDc7msJyoKkpcYHeeLraSH3ZZcHNBToOy9zUIgVXCSoasJqwQhApsqXr37Jx0kLu6ElzRDTdYWypepxFiO2WLuMsTSQu7pSmqAqTuvcqiLqKUI7Sq28HWT76SDfrPXq3SYViuCb6p4XpfWTNJTj7U++kg36xuvXukw8YXeEOwJ19JA6pXlGEIpIKd+PYfCd+OamehodUsTlJHSQOoTw8qD5yP0sDpk8R5UG2R/nSwbdInJ4UPt4uT7aWDbozy/qmduR9tLBPLNNVZjZO7ULKri/SgyTYqmp9J1k/xkKffThxCa8HpOTrjIU6+pa8hB07KedyiHmqysQrEWJrA9A7KeU3US/wAEIm6H1k8p1/hGxN1fi6/woMkIm6qCP/AP/8QANBEAAQMCAwYDBwMFAAAAAAAAAQACAxESBCExEBMgIkBBMDJRFDNQUmFikSOBoUJwcYCx/9oACAECAQE/Af7qYifd8rfMnMOsz00ge7eVh8TebH6/BWvzfMoBvXEuzUclwdy0yVxDbh2TTUV+CAcskS3Li1ro1iX50/KpyU+ZNbaKbZZWxC5ydNO/McoQlxDc8ioMQ2YZddicOXHeR6p7gTz5FNDSeXmWHw5Dt5JrwF18jpDo1PLHMD5dVILXcpTJS0iX89eQDqgANOFvu5G/VMlYWhr+ya8yXBwy/wCLSN37JpAABV7fVVr1TnhmqOJavavQLfSeiMsncozHu9b1vdy30Yzqn8360X7hW18q30lKPOSiaD+o7yN/lCXfVdTZhdT1T2iXROxDgaAURxEh7ovcdTwWE9lGJWGrQqbz3ka3Qbm2L8qVk8vmCijljNbU6J2oWGBBNepLtVFNcfqixmI82RRw8TMjVWQ9mq0DSNVI/pC3rvUfwt875kZj86333rffet996Ex+db19Kgr2h6jnc51D1AcQap+GjlzGRThJH7z8pstwo78qdk0ed2SuJ1Kjgkk0C9jd6hSQvj8w4sKcy312Yfz9OUFbVBxbkVu2Hy5Kx0f+EMNE43t/Cc1zhdLkPROjjDL7U2V0f1Yp4gw1boeEGmYTcSD5woW0eVmqlB3SO0219VbXRBzm6qjHZ6FAuHmVbgrGeidDEW2EI4GI6FHAfK5HASDRHCTDsjE8ahNbVwCi1cdo6R+nFagXNQkHdZORaqbKLNXOVyD/AKK5qyQ6STTwbVzhb31W8aqsXL6qzhb0kmnh1VGq1q3YTArCrTsGqb0knjNUQzVgW6Clhohqh0knjwa7X+Vd0Okk8bsryzRDFFDFL2i4UVvSya+N2T+BvSya+O/Xgb0smvjd07XaE3pX6+N3R14B0snHTiGqGuym1vTW+IEOAIdPSqt8IIacAQ6mioqcYTVarVarespspxN0+BW8PZD4IWrTaPg1qp/oF//EAEgQAAEDAQIHCwkHAwMFAQAAAAEAAgMRBCESIjFBUWFxEBMgIzJQUoGRobEwM0BCYnKCksEUNENgY3PRBVPwJIOQRJOio+Hx/9oACAEBAAY/Av8AjhpLO3C6LbysSGZ3YFjWeUbCCqCbAdofd+SnSzODWNzoxWOsVn/zKfoqy1kcqH7O06LqqhMHWKLCgOBrBqEA7jLPoOT/AOLfITtGcfkgWaA8RGcviU0Bprka0ZXFYf8AUXljD+Aw3dZVLPAxmwKjmtI1oOgcLJM7Jg5HfCn2a1xgSjlNzEaQmzRVMDu8aEySM1Y4VH5Gme00ecRu0rfXZX+Cd/UJhqhBzN07gY0Yc5yDRtW+NBaMzaAdyZ9udR8eRtKXj/KoTR+ehxm6xnCIb6zcJm1S2V/4Zwm7D+RrLHpcXdn/AOp9Mu94P+dqihbkYANx0ltBwCatPgVhxuDm6Qmy2cYjMrtgy7hZ/akczvU0YyOwh9fI8ZIxu00WLNE7Y8c+WR2arh4J2DniwvqopW5HtDlZrJC7ABoXnTqWBOwOHgm2Zjy6GXMnbzG1mFeaKqfJ/clc4KVwyNwv44eCcefMwfVYhMcXs4oVZZr9QWLMexYVmlc5mgX9yENsAilyVzH+OenkcqI4f8oMN5jxCNSfYZDjwmrPaYrNNA4/aNA7lgush33avt9uGCfUbubzFfNNiNC/bbQayp7W/K84I+vCwI/vD+Tq1r7RbKuJvofqsCww77S4vyMHXn6lj2uGM6GRV8Vxdsgk1SR4Pggz+oQ7zXJI01YVvkOCJcoOZy+wWyuGLmE+HPJa4VByotNTZ397VHNBJgytxo5B/mRNdb4mw2wCgceSdiqO3c3uDjpzkYy9OtVscDMR1MCZZrN5lpy/VMhjFGMFBwXPfc1oqSpLVMMWtw8AjZ2ktgj86Rn9n+VBvMbfsVKFoCpWTbgoPicHNOcIteA5pygprak2KQ5/wz/CbbIrnsIwiO4qOb1jc7bzyYpcvquztK3mduFAcmg7Fg1Y/wBh+VcU6aH3HrjZbRKNDpEQMBp6LLyt6s7cCCt+jrWBHe48p5ynhPAyyEMQkd0S8qPC85Lxj9pvVnsjTQPvPbct6MIN17zylM2R7XRuOLTcfE7I4UW9y8qhicrVZne99Dz0WTMD2HMVhWSUx+y68Kkc9RqlVJrQANchWFapHTHQLggyJgY0ZgOHZ/3Popaf2vooaZMEKG1R/h3HVoW+MvmI83rX2m2TubhXtFELDaX75G/kO3LZTJ9ocrQBnw/Hn7GcBtWPaoR8YV9qb1AlXOkdsYsWGY9gWLZHdb//AIsWysG1yxYoB1H+U1k4ZgtNRghRjpx4J8FDhcuLinDWEQ4Ag5QUZjDyca8kgdSEkLw5mpWcQHCbFSpGq9Oe7I0VQfJc6QmQ9amlspeHEk1aaZV560/9xeetHzrzs/avOzfKmWe0vD2vrlF45yvRDrQ0n2b1iMmf1UXFWX5nrEbCzY1XSyfC2ix5Jz7z1Vxb1lY0reoLGld1BXl561yO9eaaromfKrmjsTmOIAIT7JIc+Lt0J04FbNL52nqnpIFpBBzjcJhmdG0+rSqY+B2HA4UfW4hbzH91YayP6R0BGNvnJLhqCP8ApJXYV9aZk2QCleBH+47684vkfyWjCKoSRGTixjIuNk6mq8OO0q6JvWsVoGwLGIG0q+VnasVxcdTVxdltDvhWLYyPeeAuRZ27XEq+eFuxlVjW13wsosa1Wk/EsYyu2vXma7XFCSxNwXs9UZ1vNqo2XJU5HImwyAN/tP5PVoXG2KX/AGyHLirDPX26NX+rkEcX9uLPtKDQAD6sYRtVq81Xt1DVuSwO5UbyOBH+47wPOM2l9GJj9Bqt8wsSlarCs8TWRnI6Q5Vj2trfdauNtU7lfGXe85YsEXyq4AbPJF7OLl06VR4MkWu8LjIHD3SsWKTrWBZIcH3RUrfbe7Cdlwa+JQDQABkA3BbIxVpxZB9UC01B3We+/wADziIoTWGLP0io6cvKCnQPrg1vaU18RBYRdTyl72DrV88XzhfeIu1feG9hXnj8pWOwO/2li2f/ANQVAJAPdX4vyr8T5Vyn/Ki1zzQ5asVbFNvkJ/DcCKK9+CfaXnWdqD3PaGVdeTqKukYdhV3NzrFZnapHDwVFVtXWU5fYKGnM4LS05szlh761mpxoQr7Q07L1cZHbGrFhkO00WJZu1y4uzs7CVdHT4FyiOwK+0OHxrGtJ+YrGn7lfKflXnHrlPWV/avX7Vkd2rI7tXJd2rI7tWR3avX7Vlf2rlvV0juxXTf8AirpW9i5bFh4VBpa5ONocX0fgtJ5sfI3zhxW7U+WW8XgVzlQsddjgHtRDhUHKCi+EF9mztzsV+MwquWPSg1zaSaMLKvMhebYOpcqMdi881XPJ2NKxYpnbGLFslp+VXWKTrNF9zA2yBeYiHxrk2cda5VmXnbP2L7xD2L71F8q+9R/IvvUfyL71F8q+8Q/KvPQdi5dnK/6dBxFDn4DBpcoPaq7v5sssW1xUbNARmhFT6w+qEdqBe3pZ1hQPDvEIy2OgJyxZnbE5pFCLnMdlC3yz1p0c4WDbXzDQ4P8AFV3sv1l5V1nj6xVYsUY+EK4U9CnhOWOQ8CIbVZG/pjmyFn6Y8Sryriq0wX6QsNlaD1mINtTcMdIZUHxScYPWHKCDbRQVyPHJP8IuZiydxW9yAmPOw5tiw4XVGjON3CmeG6s5WDZYK63fwqtjI+BcZFUa2fwqWmMxnSLwg6Nwc05x5QWto4t+LIgWmoO60aGpkclluaKVa5Y++x7W/wALFtUfWaeKqxwcNR5pA0YA3KglrhkIQbaKNOZ2Y7laYDtIWGypA9Zi3u2ME0Zy6Vh/09+/R54Tym7Fp8WoSwuNOkEGT0jl7isBlHTnNoW/W5zr82dbzDGXy9CJtSsWwGntSgKtqsksY6Qo8dywgGur67VhsOHAT27UJI8mcaD5MteKtNxCLrNWWz5cDOFjVYdYVWGoRGwLOFc5XEFVbhA+yVdaHnU+/wAUBbIQR0o/4TJIzVjhUHmZ/wC4O4I7lDeFxOPH0D9FRpo/oncrTBdpasNmMB6zcywn+dH4gy9awJ6A6cywoLj0cyDrRHhEZimxNnEENKve647B/KwLHJA1upwvTGQz0kw6kNdfRMkY8OuFaHIUZ7HRk+cerJt/lODm+y9jsxW9kneJPDyvGxMdtClDeTvhon06a9Qq+M9RV4cNoXKCzEIYOdWX3OZpj+q5O4FcjtIXGjfY9OdcW6/Qcu5jNo7pBVZxjdWVYLsZmgrBfytdxVY8dvfuVFDsKLoS9h9lXy195oTrRgswnCjgBQFMwocB7TlBUbJhJhgUJovPU2grFniPxK6/Z5EnQKoHS4lE7TwLwCmYN1a1Q1BWT9sczSu9pxR28KoxHaWrHG/s71RrqO6LtzjG36RlVYThjRnWCa+69cYN5k6WZYbDhR9Jt4WNincva07Qr2AFXYQV0h7Fiys67liX+65XG0DtWM8/E1Y0cTuqix7P2OWM2VvVVeeptBCxJ4j8SuNdind7BTfcJTjq4LRoCcrM3RG0d3MpOhPd7J8jjtBWJJVuh96xrjuUkaHDWqwOpqcq0c3WMi4xgB6TLu5YrqtWg7mngcoq+hWPCw9SvipsWK5zetYk3aFivYVij5XIsfv5Yc15C3txxaYNCEaAGqvZ3rI5cpXEFP1CiOsoDQKcyzO0MJ7lMfZ8pcVjDsVx3L2YJ0tuVYnB2o3FcYxzVcbljCixSDuaOHlKyrMr21WNA3sC81TYrnSNWJP2tWKWO2FHKNKs7elIPHma1n9J3gpzs8viPc1Y7A8aWZexUD6O0OuO5fGAfZuXFS9TguRhe6VjYbdqvAK5JGwq+q5QG1ecb2rlN7fJyO0klWUe1Xs5mtXuqY6/QaOAK4iVzNWULjYhINLFe7APtKrSHDVuY0TOxXNcNhWLI4bQrpm9YVzoz1rI35l5vvCocV41ppOUjyHUmnosJ5mn14I71J73omO0HaqxudGdRWLMJB7S42zV91YwezaFdM3ruV0rD8Syjt3MGPrKdtp5B51FdQU7tEdO/mY63gLa4+kXgHar4wshHWsrkwRyGj8o3Gtivkc65cZZnHY2vgqSw07le1wXKptWKQRuvXWrW/3R48zRDTL9Co9v19Mj7UTqURHq1PcsgVHtqsezxfIuLwoz7LkZbM/fWjRcexYD+X47jBpeE0KV3Sk+g5ms49s+Cg9LojqanqR2hnBuKba4Bg4Zx6ZnJrtKhGslNCi9ouPfzNZB730Vn930qqqpT1blodsHCnGgV704aCmamrqVkHsA8zWUaGlQD2B6VTcedJTRrRPSfwrR7qftTtTQE5Qs6LAO7maAfp/VMHsj0nXuE6txoQaw8XlALVjwsOy5Y8DxsNVeXt2tV07eu5Ys0Z+IKleW4BDWaqU6wE1vSfTv5nYP0x4ldXpb01dSjaQCMELHib2LFJb1rEm7Qriw9a83XYVjRSdipV7VyjerKP1AeZ6aGtCPpGrdO1N2JypwMpXKK5RV7iqkDISofZBPdzO8a2eATtvo9BwGjXuDW7yDzqXUApX9GP68zyfuN+idt9GoMvBiG4zt8gQqa1a3+6PHmeT970agy8JifsWweQGtwTQpHdKT6czzfvH0W7LwzqTlIdXDooxrTQoPaq7v5nmP6r/r6JRvkJSutPOvyDdQ3LK39Mczyn9R/wBfQr1q8jIU0LaeFq3Hamp1NNE1ugU5ncdJd6Dder/Ik6kdqaFHwdW7KdgUDelKPHmjrPl7r/KP2ILqTBqG7etXAldrKsw0Eu7BzRM3oyVGxBzch8ll3LlefKuTdicgFeVdwinO6MZ5o+02cVmYKFvSCp6uhVbRZlmWZZtzKsvoQ2po1L4ll4btiaNitUmpreaTJFxVo05nbVgzsLDmOYrjO0K68ejsG43b5ByaFI/pSfTmosmY17DmIRf/AE93+24+BRZI10b9BCx7j6NEESh5ADSQmhWfWC7tPNmBaIw8eCL7E7fG9A5UWmrSMrSr7ivqse9ukKoyegsT9iOzyDPeWwKzs6MbR3c3UtEdTmcMoRfZ+Pi1codSpm0FaDoKrGcE9ypKME6fQDqCcjdVcjvXJK9ZZe5coK5ze3dI10QGjnAmRmDJ025UXAb7F0m5toVDeFTuK4o3dEqhxXaD5aUrrVpLmggvAv2LHssPy0V0Tme68rEmmbtoVxdqB2sWLJC7rK8yHbHhX2WXqFVjxTN2tKi4pwja4FziLqc5lzRvMvSbk6wqyMqz+43IqPvC0rFx26FoOg+UlOtN2onpSE8+0ORF9l4iTR6pXHsLdDhkKpJ2qtxV2OFTIdB8k460xWfXU9/P5bI0OacoKL7C7e3dB2RYMzHRv8VSTtV9CsV1RocrxThlBN2KyD9MH8glk8bZG6Ci+wOr+m76FFr2uY8ZQVR9x8g7YmrqULeiwDu/IeDaIw7xCL7Gd+Z0fWCLTUUytKvuPCfsQGpBukgfkbj48bpjKi+Hj4tWUdSpm0FaDwCNyBumVvj+SC5zcCXpt+qLi3fIumxX3hXG/RwLP+5X8lFzBvMulmTsROBvkfSjvWWu1YworjUoy5o2HtP5M46FuF0hcVWy2jqkH1VC+Cmmp/hb2w1cb3O0n/k3/8QALBAAAgECAwcEAwEBAQAAAAAAAAERITFBUWFxgZGhsdHwECBQwTBA4WDxkP/aAAgBAQABPyH/AM4XmM+EiIa4weaigFhZ2H12E01Kt/iVGGlsYUmbmG14UcxS2oouArJ0L1B4KbVFZ86qUk0Ul6X2ZhR077uT/wARwGsPxp/ScA1DnvjC/aOnWINq0pTKoBgkjCAQ7pPydj6iEUbm9FdB3uC8ZtSGtTtP8MyED4GkjwpXJeCCJkTnzo2NkYnGrOCmYxhX1EqNCDy3YEBQfhDqivJE7iQwysA94uPX/DPWAfbkBcPRU3qBYwq7lAysVRqUqcgUGfjyiclWjuoOz0iSmgTkqDYS2n/H4eXjh1DzUfOOyJgT3ALuj6DsEpvKmyhapfkRlNrPYYnkN2sxvTQpSfUNx4NsB8m4mMc5fLu99/spbttYDvL8OpuzGAv/AEI1K9VGsGY0OMbzbgt75o1TlBdluRn8vQnIZe5LxbcB4IRtTZ1dUZR7CdKdkSP1L2YjC2C9ECuoXNlKtR5rqVN1W8cW4xw9yg1NdGUVXnj29Q647DOGn45asVlzoXENo2OITAZKDg8zuS/TPemP6+ZUAShHijAtJ+FUJpdq+0M4CVpm9hVEnoGiuVrf2A8DtL6dE/CkTXF/ooCgPax6WyiRNIWbbfwRQsJvQ3dlfMUl+iVfop6J7FFsY4LXjCEpjphOpVExZ6gAVR4oclv8ytCEqtAdm3Jq3j/RAUi6KN3YcmvYPSLTMig38aHzUmnXVmjb+iDdwpV9z2+Ptj6C4Ldb6DNeDeu24lVDaOgSGdGIZySlwr1dPTpaA8DvCBU7GH3CrJr+HzV7riZHhvyedctlrS6m1hp7khR8YvEsUqjL3u4sJDaPEyr8XBCiXq/FS3EnJbIOmrQk58YOM4wQ1tcTtlHSC4UrsQGQcHV88plHqj0QhJUvyIR5JG0TfH19hj5uQzzJY91QCGexsaYU3tEhqFE2So9hEQoQoyKiJMoADsGxwdjQuAqpdhscOPuPIwG3DszSSSYSO47i7p9xf1oQV4J/RFJZKUxKcNnySEbaEhCO4T6Shuc0ic2WCVr2EPo24N82N7V5fQhLRaq+ynO9qO2G0ZjBuPSAXR3tcte/qWQ7grBmPYKrIVqs3neDAEFJufcJ6FKsMaTUNSmXM/sCoM7RQ/6PqLhKyiajCYlvH9DMWGbfQgQML9ULD8I+RMwhtmiqUdUN7k5sonA8j79JE6U0+rgOh0RSJnGppnHQpEuMgis/DFBc/l1DfTo6KEQutYYo8DExF82vg1F1/hLmPgNy6++uGtcZoRdDOwSgOF3VCnAFn35mVGVoWBHQlboRp7K/kUI0nD0b78pJTUpYwlyk8NkhHBfn7C5OXAyTZ6jLbtxiuWEficsJuBU20Ujm0OfdDCr2aWRqt6kicKWPMrInZZUspBJQosF6O+0S5eMhSRKU167Js+QG4RLrT0Zos3SVPMS7Mg+jpkKmzPkNPxQ8h0vQ53ClpIXLdTLzuWfQnibCeyx1DqUSGknEq+xZfA7nh/oWSl6IqEY0x1mGrhsskWhIKyJKoXSIFXCEQksmtPjn0gl4nmOUl2xLpfnfaG42qPNkQ6MU7pCoueXYOTFY88DaJ8qA3Y8dB+cbefU/eM/vEzuHdba0eL95i+lBY3AQv6aMzhuxme52ULR5fKP+W7Dw+WPsoJ7n9D+wMI2bvfYQLhAGdZ7OXELH4x791diXAHUgmzlAQgKDEDkhcrrqrQj8LRrAiCs6L9iZinE0bBbd7LLDtyj+50L9uXJWjaIFzVJdVtgLpMhWwBgNq/oktvUnwOJPdW92JLp86Hiex5zsec7Hmexr3jQyW73Yjtx3YWv3sbewSZNeyNDM5f0lmLu4vjGSl0+sl9i8STO0yCgrkF4HRLb3IifFLmIX7UHU+oxhOiDiIcOQtX0BAON1BJBpKsVTCfQmOSsSLDYRLzf6CFdqRu9lTbvOBtI+Kn4zKVJ4hh0WucE31L2ku2sOt2OAB/8AYmkUdKO1WKHTaWjzLaFCfmSVL19gxr33UL1hTHboESxthVfAW4dFXUu3El7yDFcs5GZK/I0c0JawyfmQkpVJr1n85LHoo65PRogqjbByku2Vr4Sb4nxcX+xq9hKWrBIi23Z816T3i+BjZBXl2EmowaLOjJ+AVa8mg5J2bnEIFt0WjbSXnBQCNMGtkqp1zdW3LYP/ANaE8t5UVtdcKmcBUo7b+RkmBteItPQTy0ZHqMXqoy+U/wAa1isjEVC05BQQ+NUxEq/FDbXFy3GMR70JBbZa7AiJMhksaCg1vEMSs4vhtkU8Dt695WmXTKg+PjraInM130mmPVw1CuiT2RRf7ClSumdtJiPjmwY9bm6tSoDBJ/uzCntnm0Vo1MBDyGGx6WKi7i65YmYio3v2UxpTYz4HtX5asfOvxFKCi00oO3mhyrGRTk70Qc8hkBba+ONVXMEMoSWy+H7yDiTmPaLqTF4bCeLeOknpLvcayUVq/UJooNshJ4lgVJsZMzadm4SsbgsCg9DqNtcbVPKwHEfveDtEKooU2mQllTRRpll3OOi4FMutpI/wakgvJDezTnaIcJ4IiRQQzU+GfWebZV7lEN7EKSjNVo74BH6JXDuwkU85QS/isCxdpuBSxTR/2AoH1C/oALhkUOjBmEm0Nl7vi6VaknIUbIa1Wi+xYo2vsYi89DoIvsWhTnQ0CrbiElYI40K9l1LNlIe1tSWPyJ5QifCz1gkrLM5oufgWbwxHou8JNxMoy/TYfwTUntlxKRrPljyljYHNDKZT29N+mgizuuXoqWLMHciG6eD7lkee3eXj4ovzWUVyfUMQuGYG8ZWxE3yAL+QN3QYVW05XjKxkhGqrwmiZ8MK5sCi5/ku0juHqCk2Cp9NAimuNUOU5jV5s1X0lNX2l+F7e3YK04wkd4kYDIgl2vMrhvjR3uCoOrvi2JcuTgOaXX5BfC7LAQaNOv50+6C4M3jojiESHlUjUwdiuZiBN/BYoeSoc5CipoL3EuxCWqA7uRcCLMNWDAkzX4mA2lXLT9C+Fn+zxaQkeLT9GIN1RxL75BvFtD4DiHZKwa4YaR0Q6ouG1o9JFf5cMx03Il1R2ELP2INGbYTE5s4BloBv3tI8ipbxd8Tza6ffw21rkRZWbdF+pycw9U0LcdFLhJm45R1tS0AOQUgrJ3ouP8cCgIEoRl78zkVjoE7v9CdvhoF5zf0LD+wOWwOmmh0bB4C948ZoAhUdiziSW0wHkl9Z6hzvx9HCTZqT9XiC7hcxoFmNsGn4ZpqAu0s+b9tuFJVmCY0GYe/8AvEIXYOgFrUkZzzofITviTyYnuWcYfsIazh9DEm2TbJNxeXwxDn2BIek/t4Pf6GbhHiFLXte8gj2IE2id/wBGiqu0afKENuUk18Uvr4betwsL0Pl+1NMNIxvuIn1aRvT1/dpocInQaRmvmTbCHikdfv4aXMnmuw1oHQ/anhw9ZrbYNW3kl7po9HMSqamgPPBJA7H8M2BnzGwX7Ntxb00GYg2mxpySkhtWCg51Zh7lGPFY2FhWyxw60CHKmAcfpEuzhfzBGiPxBU+G0MWGDkn7CpmNmfpuAJuMkkMkQ5XgMYWdPQ5P/eWjH6jxinYGWALbEtRspaGDamaWS/Wo3Ofh2/ZAGyWesWsiFh6CwZwJBk9iXbjCMRDSrFtFkcPCCmf+m+HfZAFf66+y9m8AlEITxtx+/OSZWIksYvNPh23J5Ctmr9uLeEaE2Lvv4FOm0Quuj8O4M+h1b9Yh+2k5IeRqJF5r97cJfpe2ibZP+LyT4dpHnP6tt76t5PoeOASZRF78HvH34+RsIpJ1i3OfDt4VUL9PvH4OOeo8RzG2SL3JnY3UZWvNZM6ySM1k97Wp+GY+tM/SKWWGU2/CrZrG3wqGb7W4Us6I9N0CKBiJa+y/hjPKFX9FVFYc8t+HSZha2YfcpNtFPP2OhaL1V6zkGOUUL4druX1/M/Ti7umX42ASNVsedlDOJeslajQMnseNZkqW4gP4djtK9vErkOQlEr8TvkE82YBAzEfleNSBQn5I0kXpZkd7G20v2WE5Tu0+bMvHOLS+IR6MFfvIdHU4nwEVwaA0Ro+jPS9A86Sd2/0WhWY2QCq1+xdG97SMmNqEJnsEOb+JYPJlXHgPsyGa8hmAgSplofr1LNYqG9p/geNjA+0ycVV3BJ/firgQJyPEd4XEQJc1H27ATlSrD0Ulsurr9PeH7H2ExZ0E3+CrILmbrSRPFxvPjMkuzfYeBmfdldmYk7dQjHIh1v1i6XwS6HYtK6omSno/RoOSGhwWXZfgJD2iaGQvj1QRsaK3xVyjBP6Nw7lVCociQfaY+mkYtPz+A4DwLGEkqVFn4AsQUzBNwn4wnekyJzYdSeRTGJQxgj5DKidPezKOvh/wHBjZZ5ldSAqz/MleUoNG2hEWUJNv6G1U80rciU8wYjZswIdGvsaUrZfRX0KV3xzAZxsYDHcKtonydRdwagbarpV/g4oWJoutGNai6KQnxb8lQzQjxQ84KF865ITa6ZOhXYLlYbiJp9VsGMVCdA+PlXQrvpu406Gf4UV5ovRNpUX/AHvn7cTnKZtVir2PAY9Zrdwh0IeQp0nMXjg1M2fX30s0FjWbGojzHNT/AIF3Q4JQWXlr4ZloIjg4oWBde9oZqN0R6f8ACcyQH+D6DJSs34MQQ1qEoW9+7nBpMnoICQhYf4WGIy0V3kPYcV43YZ4BSk9F+zWb00sXJ/iK+Xhw39ilh4VtqwKPv1zm8eyEKtXDL/xVTWwqtommN/2K6KFQyF2OcdHliIxVydx3/wAZON5/+6h5mUvLDsPxApU48teC/wDTf//aAAwDAQACAAMAAAAQ88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888800888888888888888888888888888888888888DidH888888888888888888888888888888888884mQzBk8884w888888888888888888888888888888bqDUP88FOsz88888888888888888888888888888CYLvc84bQReW8888888888888888888888888888sXvU00gbOd6N238888888888888888888888888ZR3/+OQ6nNblb9sU88888888888888888888888ojEt9//wDc8THN8n89PPPPPPPPPPPPPPPPPPPPPPPGKfVF2pvPby3R7b/TlPPPPPPPPPPPPPPPPPPPPPOACc2L/c+OP/8A/wD/ALd+3NPPPPPPPPPPPPPPPPPPPPDJeRACxlvGlP8A/wD/APfGwcUVPPPPPPPPPPPPPPPPPPEnf3sNHh2X7jcMOevZPjtfPPPPPPPPPPPPPPPPPPFv/wD/AP8AnL2lcvTv73tpo/xNPPPPPPPPPPPPPPPPPPFP/wD/AP8A/wD/AMwvEFshe3//AP8ARzzzzzzzzzzzzzzzzzzwz/8A/wD/AP8A/wD/AO+5zjuvv3f5fzzzzzzzzzzzzzzzzzzy7/8A/wD/AP8A/wD/AP8A/wD/APag05eQXzzzzzzzzzzzzzzzzzzwn/8A/wD/AP8A/wD/AP8A/wD6uiP/AO8X/wA888888888888888888y//AP8A/wD/AP8A/wD/AP8Av6j7DNsFHzzzzzzzzzzzzzzzzzzxT/8A/wD/AP8A/wD/AP8A/wDPp/P/AF31zzzzzzzzzzzzzzzzzzyjj/8A/wD/AP8A/wD/AP8A9++SX/8A/wCtzzzzzzzzzzzzzzzzzzzwb/8A/wD/AP8A/wD/AO3776rX/wDrUc888888888888888888of8A/wD/AP8A/wD/AK/+++/if/8AvmtPPPPPPPPPPPPPPPPPPOMP/wD/AP8A/vPPvvvrZFe3PhfPPPPPPPPPPPPPPPPPPPOvf7/fPvvvvvvvmfvvvCvPPPPPPPPPPPPPPPPPPPPDEMdPvvvvvvvr5PvvPXPPPPPPPPPPPPPPPPPPPPPPPPDetfvvvvvqn4OD9bfPPPPPPPPPPPPPPPPPPPPPPPPKEo9fvvvprvPPDPPPPPPPPPPPPPPPPPPPPPPPPPPPLHDdvvvmePPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLJevPvIvPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLKscIfPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLHPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP/EACwRAQACAQIEBgEEAwEAAAAAAAEAETEhQRAgQFEwYXGhsfBQgZHB0XCA4fH/2gAIAQMBAT8Q/wAqGHQEBjT7xTCkAbHx+FoqxWsoDTL2q9YCqwypH4R9idJVB0rr0iCzAS4eNYg0eq+9o6JX7v8ApFO51wm8i5okQF190JNj55GyjUwMwETpI2NjqeT14zDFOXkuO9qkKlzBBNfmfKf4l9rPNIBw9Vk0doi9ovx7J9FSzPuluflNW4NtSYZqYQdsa/e8NLWvaHSc8MnVK6Op8QwyGmOYuFUMDq43lGqmN6LI4s6lQLeIu5B2jEKRlHEXY+cuxFn0lLf4n1f+T7GfYz7GfQ/8gtrPPhNdOQb01mDr3iqj9Z6cAXEqLt+z/UROaxCYhs9PilWS3nILZHrUsmRqO0YNahpQ9WXPwQemu6Ii5tccy9O0d0l2GULvpDZ4mt6GbX+01Oa+55Q0QvzP6j1BqUtkO2biW0T2l5aVwNp58XSDv0mDlStyplSDdwOWO8oBgjEOYttFNo7TLFupTvcsZi0rpMPgPZGnnMGr2lMuVYYFtc7sKOUWOuncnY09JTiP0x1Y95olzFMGw8FSZtdJn8ZXR5y6HaG6m4x5lljeLX0mbxVomKVL04tGO588ArXSbvFds/jABsmC9yTZX7ME7OnlAApiK3pMHxNvgZzUrkXx0uD4e2cVqoc+RaLpc3hbZyDrfWGhxW0WrrdajfldJFDgtRbi93S645kx7ObSppBNEPZFvgtDpXdks0ZeXlvg55scmDNrp8bPIZdZ8HGprLkwjt9UAdphtefI9Yhpnn8K/aV7Rbb6tjR1Ibl+kNry4vwa2NUY5crP+DFNSbMCajhvMn4VdRwxVdzU/wCgP//EACwRAQACAQICCQUBAQEAAAAAAAEAETEhQUBRECBhcYGRodHwMFCxweHxcID/2gAIAQIBAT8Q/wCqPQ7WCZ7HkfP1EtM9pp+/xFo69L3fZdV5Gj55Q8LC1zldpRahVdnjKDMz1/p6spzuX9kYRkb8P8plH9u5u8yw2to0YX9y7TlAeH9a8GVPKB02s/sC0O0z6+0zYexF/TLFoTJxw7SPr8/GkohS2qzw3PUlEsuQV55fx3zwUjYOoeucB2wZW145XBcuNmAXI12h378j2gwb47RRcEoV1b84W9agcrsrfsZp7AdK2YmRzp+X8fmKwWB+J2DzgMHis9h8DFRXx6YbAeIfuEwefsR/2f5Bmr5e7NdKx03O/wDfxlNTvyHyU9GII+itaXyNb72Ug1gvK/avtCLUSt3Hyuj0HFN6tTTwjYHgt9ZoV/DT8VN5uipTDCUtyHufaN9rfMshq0vav0iVr3VoTW4m5WSAK2u7XxJXjbiRCm0Uha5+f9/Mer3sf1T4EAyviwwj1mQB4H7ZTgI5h8z2nIPP+TufN9pX5fad35vtOQef8iGo93+Q5sKb3EUBP5OfO6aKbOTXz+X3wLfRwJnB2NsYDVNLngmwXd82W6wvgXee+vQbPD4MwicJ+2IPvUdtnw/ZTETRe4z8+aTIwPV7S7bsD5pCFgN7t+ukJu7sjk+bJpATXrHzs6qQH1c8zR8dmFW2JfN0VmnCZYY6NRWqJyzRYswaOLOZ7TsCRcROsBIAx4zMJD2Zng+Mzs5FPBjcxZ5p05cJn6vZHkmEjGxrzIOJiRlOcpLGFgG8U6oMAjsmC8MFPGNDmJcMNn3gtstySzeVADh6u7hPy/Tu51lm07ZgmGGYiMQ26TDhMTv+sN5cYrtF5QsgnHhMT6oXDDDp6RajnMOEzPqhXQoDBczuYhNHnLWvC4PqB0OE2HTRBwuD6YdLsdWGOPA6mwmbpMy42qB1uboC+jPhRrfWph15mmWHT3cKglMa4lEolfRzm96mUx4dEKJX0c5m6mUw4lLFGZ2OvugslJWV6JpxadolZ6ww/Yx5IiZ6rD7HVzkxOhtMPsqDmPLL/wDgL//EACwQAQABAgQFAwQDAQEAAAAAAAERACExQVFhcYGRobHB0fAgMFDhEEDxYJD/2gAIAQEAAT8Q/wDOFZ7HNB0ScPGKVCTRXu1dLV3tElIDKCXeb1UaUUSI2T/iZopN7BmuAGNEEFhLVivf4L1metn2XqtYSXWFyBaJxexF3hRpYeyrPhKcZcBpt+PY2an/AIRZ9OeHB/4dq9moDHLJqGFBVBE9XIM1m5dCg18DRNAu9i1HAPElxYl5tM9szEPJrdsynnRy43VdhlWXsK4p5qzT4fhbaXk2I8HUo6uqmjzt/wAMvYZTEsSbknKgrEdZ4OrLyKR4rDBqJNeb6cak7bIyCpA0i7aC98gx2qVAkSWbeRSXk79XQ5WZWsNTdUYMSxtpDjDUOZYcSEvo8Wmwx8QETkCa6/8ACmxYw3AeVLiJ4ySl1VJlBUaEKwVMIBuRJFmQi2CbVd56BTmUuiACAwlsqHW1QJCSNmhspoYlHIQ5VCSG1JQfsJpqPn5draPLHZoR/NuEXG3RHhpbhYJnGotAoJoB9am8DQNxBOBNxXakwLK2z6hco2c3NASOVgnMd6AAYCy39sChegGVaYKb8ZjD0agjkOmh6tD6kDNpC6HId3Snh9srF8edMT2/c34qe1S7uWHkrE5VWpvIPKWrmpLGmZuuNtzCpth+ZjjmDGE9weVMqSmZ+gqOTTEJzF0yjWTDpbSggQokIwHdYM4qToL3TiocJrBNp5ZEGeALA3VnjhWJ2xXJtsAOOrtUsQCbldVPWhELMIB6qDmoxfpQEqS5hrOwZvBqf8PrIb3sVxh56UlyW7YZWsjQNC3UEj3PQqTy+a3MaMiO4JwX5qWJUnIshGuXoqQRVnHifN1ctPzLeDFSIQjyoNH5AmRsmr2f3RrixAhza4CfsScvbYSwlhi43JiaFB6WQZONBKojGoSWB8p2rDXOk/OlmNVZbvuqbbRMgMNlFhvq0UoXOQZu6yu79Iv2WyUr0KdMFdB6QS/ug54g5k5BJcMkM6z6yhCthNEJkwzUttQs3MvPQoKNS6R/e1W9tPDcrE6dyrAnV8uXw/SJbPVGCdzSrEkG7XqxNk/MpfZeGoNTUzOTSG1wKLPKuq5mdRqVwgnF5lTqBU9rmahasOLkBSMQ7kcXn1VG6KRR5Oa6HpnQR0eMejDIy4y/VGAHc4V7DOdQSBlrI+AKXsE5lxjgJwCkvBHkt1sXedYLgRdmOVzgtQP8vskSLkIUwk4fwf4rC8/yYafFrtu4B4xPjStQ3niPh2p/M5C+GcdncvTsKyIDgLOc0PROxFRwJQkULBscBGgmC6fWZV1KH5cFFyPr1fo8R+7UaEEBGkTxS2OFwWKTYyIJhBO1xzKAPgEBjvLCLmNzt2mfQXA0wyvQGyJBmzNNwUVkcN6gOhMZTTyVPwh5H8dKkqTWuX5ad6k1qaejWZ+VAzs6z0Gmm0qcfturHkUmNKZrvoUmipeKpi0fDgK7uNNPqkKxhMVbXpehQukvcGscwk3zziD50iV0wJxEcSkvhgJCVuvhheipFM3SmbZigbPl5YqjoSSzaORuZBPfChsJX2iUnYVMu3tgxMnwrBqvh3XKXAbiay4Ia1IngJSUwgnJDr+SBoaVWAKsN8TWdJKd6nvhJg9qRO7O9vUpAAcHvI8UoQ5Rhz9WnZdZDdGhLI4rrsNHHwwxiiPSXyWmupg8FMSjvPWsQ3A+bXae9iu2qD0pCemgRo8mGo1hfIZQd4k3HWo/lmlKxmiW6tKMqpSRcEcymQzQiSJpS2emFhoMluM0kSCsAltnYInB1oAwfUAGzJuv6kEqluydu1nHapJzEcMLRoiXnTqiNyUhT0/mxIqKsAKjA/IbFroBXYpZb02Jf2Tyiil6l5sc3tQpLmz4igQmmcnvNDwHsngoGRtg81LBUyB9prg8npVJRo9m82ngCf0jGsBndDooK78Ip1eHqVdYID2KSfG2hT0yNV0Lm1CAvM2Y9+JUcuWwZcM2NQ2e1K0+czOMPRJKh7zm5wuPUpFk13BVqRxfSjo2JsWqMZOx3XQ1Xdoim5JCGBaM3litQMDt5UAJzMFh6j1+kUMD8hnx88ZSOmryoQak3psCcG+NNaYr2IZGoLxyaiohx8o0ZHUwS8r1rIXKchCoNV1k9WaHgnQPGlXFXj9m52ZmN5ty+s0AWopiNj0WOFGzO4XohR5aLH6y0ilqJA85zIqXfZA18rHWj6uIgjADI/gXhA2WHgOI1rL/ACmT+YBUJh+PJlQC6tRhMBbiydQLHNzrJ2dWQuxhwaGJSBdAbcY4NGSVPJDGZJhGX2pM3SnCevauyIvLUrbNfcr4O/CsWHwLUk4+A5U9f8wV5tQsjmeq0UIMBXQroiqPmeJq1h4xe9OtQUlxEijaTLFOoRHfUcalAzmEcyRrzjh5qzsmkLBdYvNTQ3VfhrdpCn8cRdcNddDp+mtCbIgN2rWgODV3T8nHGJS8QcOOylt5y5uRyd8TOhmGGkCRb8SzXTg8MUa9N/IoxlfhY05HMz4FYWDaiW2JaJRa5HSryGCieOY0tx+FZtZ98A9azu4FRsW5PpQeJqAYF8bUHnfO1f6ev9DX+1pXJ+dqVxD5aUpgNBmA4y9Kyz4t60jEoHxnD+9d8gKSkxpIRcNHKp+Oo8vCrsK4/jCdDk+U3YC8ikmUAKVxv1BebwqzW3XEQJHpR3TSJA4iUprHHtr6zLvReHZdi1HJpaTEGw20PZo+eX4o+zzWNT48Wrtu4vNC3CVAbzi+NKzJp6BQfA5FfLVb0L8/a1h+1Dzj/FPPRqMRwc/SvCBK+ADaj4jwVTO/jLHIbiqwYceqwd2Kr3VAoPPbDntQtHRWRCMdPokd7JUGEjnAZ2D8ZkEAatCYCObZL3Wm1re+LoZ7nOobWqW95wdHjUbJLiOIXKcd87O1/wAbtWDgJ66Jlvg0eqEJ5ms7m9IogtkIQobnPWn0ABHOpDDRhIj4Jmoy24RvSi4C2DxX+hWNR96Ak4TVhOJups9n6FQ5C9iiuEIk3H1fjF0oO/61YEZQxakp+5MziUm6fKxbMHzvQ1kSsPEF/CtBOgC4mHY0BLkv9H6DJpV+GB5dJeo5LWsmLEeid+tOze43DyXh70aBgNZdMjw5fyK3XXAbvininjFPjrUedsvf1JYixbfWFTgNC6XHA70cWJkj7hyKCxYdk57qNoklImv86WCdUrHihDAA5DWh5cxbnNPigvRIT+wrYPQPap/DlNrHx0zbYp8fD/8AuajZo2QY+SezbehzHnWIzywl3wvZoGzMgm6hfwoC3Woe4e7DvShi7LLO+6bp2ahDZRI5BieGgBU4LsuNml5tgEw2y4tnrULZY9wcPSM+GK+8LADKWTQX4VG0C6eNHuVBi1hNuSyrCJkRdWkG7QWSNu7Hh6VEjYpa0OgP1Sr3qUNzyX+2qXgMgcmlXoTLw4u8TmVCFrKQeJ+qCYbHko1Lh2B70m9JLzWWXNrCU4pUDTaR7q2E1HsWlxWyncKQ8kouYZESEj+FcGmks9hNFPLO38FDKASNXcHc0j1OXZqXDYc9teX8XG3KBXcwfO9EEbk03kLnKiXsJWFuNvu0cA0IcsZeOFSBXdT1GXjhVlVq0TAM2UMJtR98L1Wrg+QYXqWsMJxqlld2WiIbJTCCysTHapxFiSzgxgzNq25kBaOxoF9axpwFZY+g0zjGazYXckdp1+7dV2Er6/ei9unTEIdqIS8ClEtOVM+PAL60pwPxNq8zX0oQutGD3qPFWsGki9SMFNJZcY+X8NmiCcozxSn6A0oTuW2d9fNQjLMaxxx69aFwJPZD2n+Lhl+0MHnUHQXgsN/bNEJ8iVNkcuDTCb5rovy1WDG9lvfNxKJATqmFBkvwQZoEVzghoxjVmRozvBoAGkkHBg4NSmySVQsvBNQcaawFnQicZy0qPBWnpkUxDOgT0WoU/UPGgmJHH7BvYNciakYyn1Pat+3rz7/zLrQUFbDVluQizBJamyce6tM1n15Pr+Falr3P3KU3VefqiNDI0p1iogkzIL178a3QIo3g48v4lRZbVzz5zTIxzg/RrVabHkm5yq5a6IbxjzOdGz1eeU2Zc6gY9XNzyqYYyNSM6oCzVp0Unohr1ZvkpDZ9l9SirpoG8JUuaHxJKQsh8VJUdIM19DTpwgrtR7B9/SfVUWObk7eirMhp6RFOAi5BPRaCkPVHjWC5GyuY92hks5zKpv8AQH9fT/um1wQ9hVqYWjc/CwYIToJpOKZvOpS+qvf7EQ0dFvBxqPDsDicLB1amM3GUk7NYm1afCJE4OJyqdnL7ALnOaVDM+YSW61LqHECXHE5RRonWd4cOVR0qzbPB/iKHgtW2LWx/hKlo7MV5eM0OQB0odxfFm9KwEWq8TWLBoB8KvwNIO4aweuI8NM10ZE9RqI1weUMmplTsrYJEYiYnCsrom6bUQ3j5ZleAEfWsE4EldjoaH+1EVcHSebFGXhaNiPwtz4uXBNfKQy9Kx+29Z9MulPh8bSsMV0bNJZExxHOoOW3nTB6Vp5f/AAHtXWgG4ODUMIjfKiThIe9DTsg36VYljpSwTW+FCCUJqfSW0cKwz81aw4BrG15RSxB2iz5pOUWZHxWKz18A1clNkPcpMg2GO4+lSZEwsvQFKRi7JJMmrwKLnN+GbJ9Uj1r5VIdZfev7ug+eOkVafiZEPJrZUO9DFyokEXkkjUksZ0+1u1PlRp8B0pUMcl22e1IWhm47KwCeCu1TBLWSohL4dKsruxDxWJfkrtWn3pOD8ErHD7BdihMl3ZPSrST5TVg/C3pifmm9bzg6ft/R2g7NHtV/0fuNhVuOYqi+NK1Rs2HMkoC+ZI9qJAmm3Km1ZyF9SKl5F1fWa+Kw6RRZ2mTwWnezPmnxhm9YUPhZ0I3EhMPEYowoDjVJ+uY8i9KS0upxT71Op7F+G4UMfE+VfJ9D/UOjdAXrjWkRV/73oW0ML7q+9FQAxb4vS+rB6B9KBLjlPyK+FB412qw1Ik5a1Z20PHvpuMGLxRCMDHT64i/RUXUng0JbDH4fTWEg1HcPT+wHBugPmp27cz6awjjP1mndqD6UmqlbEkkzFk9v4BniGAM5LtqHQo3g+rrJqKSegqIFNo9ZTISe6d62rgk/lhZF5krYNOg0Q8us4CfJ+GjR9rVAPlvp/bJEwBLSbYmhePFbnXtWJwLhOHuV2KpKvQuJA9GjZRxg64mlQJwYk82mxhQcXUDgvCjABYix7Xb+OEzyJa+ESP3SmIRHAHlfwxZl02HrW9HnX1/twg929LvkR1j3qSax62pmSznMXgfpALhquPKjCYbRgDwDzWtCHA2hkLPet008v2qfSPqf1U2l2Ov8M8X+Dr5TIe/9ocGhT41WaWwAfOVRf5k+lRJMQPW+n1ClkWyD4nrSKLW+CHtT/wBO4VAGi9alkhYv4bQM5PxKny0R/tQi2veNZ18i6+tcXD0P3UvYp5D9/qFTj10lbQSdqZ++xWuBE6ApgkPTA/DGzL957dDYh2/s4T8GNYstbnXtUG6709K30ep/VGclVRS3Rie9GATmt+WhyT+FIVC9b/JoHkXkinglMFvWl3UeUyEqicSPZPSk3ovIe9Z7dnCgCAgLH4ZAcDeaetWjRv7Ch7FI8/A0P4kWsetqjGq6lr5LMfWhDqQ8NG1SkNYiXrCsfbidhV2iaTdxrB52S7lINtr4toqBV8YooQsIA5VceRrMutOJvns73xRh+G+JZv60pPSDt/Xwq2PR33/mAfIn0rbHxUkNykdioiwAdP5wwtWGTgqD7tBwLnSSD3RoJQZKFvL605SyfIju0Yfhcq2M+U405O7+vJLWzen0ORY+j+6iaQFILGHpW5frvVZBxiuH/AoTliDoh8D+GcGsRz4p0t08v9aCtdi6fTxfJ5p7VtELTqbw1yF+xucA8VD1oNlnSatfFE+n4ZwafCj0fZTk6q/1TMkvtSllx+nZpPlqFMvFVkP0h6/WS2QJaW/iDlM+lfABH7qPUMd1A+V/DOFZsR2H7UYH9QptOZ0pVZWX6j8htPWp7qHUlWV9Qf19cIPdvTjbpV71Jr3qf1U0Y65kdg/DNT5rdKsH9PGTj7PscJQ+OVRuhPLUH6oH7+plyzVpkWVZa+QdQrajdp9aksgG2K7v4d/qIv8ASWaDzVncLXj9jC9cD/q1Hqm9D91C6h4PT6SRYDFppcBg/i5/sVanejE8Vgir5Aen4dO2b6/0fXxyKlgX7O9x7VDrnsFS6B9T+qhGp1P6EBVgMVplgnv/ADtPtKMOXEbJnt+HNRJi6z7xASoGrVoubYVltpYfblG862qY6jv+qizTeWvhRH8y6DQzaQjCw+hLuYeRUZJebQXcKMPw2CkMCOwld2irzhjb7WGfnWFT7FLwN7dpeU4/u8QB3qE7HremAZIOhUAZB0KwAHTOkbRUMVVc36Fgul6zpNS6/l3qT+ItPUWxuRrctmWyKbY7kVZpo7VbjZl5OJXzmvlNfIa2+itR00rkOAUrHktOIvF/o7QPhrYQ+1Ll2izP5/Xumu1OUsg9aQVZhxW8H4m1m0XWxnsvrNX/AB5w9Rs8OpQsRHS8ntRN4wVJ/XSdm+h60LDIq+Y/s/YtzF7iFAF8BHrViiOdTTu/iuD9Gk32d6mtmfhL46qxeZgScGyb1HlsMXtRAovBGRpoTM0mKRR6xZOJ/T5GvUe1bTL2qU/4H2B8wRU2gfW/qji0mLOQdo/GMI2ZGG1G64NFpXpYPdh2vGpNvlodFYNS621dwfeihmHERwmsfA3x8MSjCVgqf6OyBfLXGz7Vus90+xwiPkLXwSY+tEFmHEE/joPeR0e9LJtTF6DYhv5Ogq85EORtqVBiVmY8HOpue4gdQphmOGLhOVIQVI4P3/nWX3rjwDuVFPIpJFJ8HxWX3BGsc4gPrWTfFVhZ8ZKxYcBRCWPBmgXDMooTTCPYosLAORH5CcjlmS9g49Ss8vTlHU4rm9QKxZlzg0uDIXG/zhSpzavJycqiCDGx0c/vDa3ke1TBovLTGMow3MGrJQY9cINSJNz8BJRQlwI52KWt2j946UPG5evrolhup7KVNrxn7rXAivPlMJ4MgFJcViANaPyMUWdfxZeg8SHenijiu3Li+Mc6jAeke9Dlo5eoUZT8+C2c6anBiMD3+5xVHu1uhPp+1W9vOagek/XBUcaj8oLtIBImiUo4M0Tf9bahcwQ3km3Jh2qMgdK/MzomIMmjmYlZL+fB4OdXeTxH/T7OKhuM1zi/FNmQTnH2/PnfGATbjQBKyrHuXAycKGgMI2NRwHCaXNkduZQ9T4G/RoTuVHDEc5rK51DwS31rZE9qkeo7/quEE9/1U8EXHH3n/A4zc5gOpmO5egrRYOdsB4dVNWy7rmOJvUIHePahJREczBoIIPq2S8dQPj63qY9B60ROHRQf8HCYy+RuDcqLeXthbZcsO1QwaMkOiNxqBebJWeD9Tj5Vq2qHas8O5wetCOCIP+Emn8JI/f42ZKlzmOHu5xlypWbHZyuGlHHVHy1+iLsgdUpxasRMybUH/Dm5DAK2Yc996axSCEHW8d6heHqzg0WBnAP7+hxFnIH0aMD/AIhBL0mVcRZei8SGpFb0JAa+iRvV+QbQzHrUANalnvQFYrAzNKlKnkJ0emn/AIqKYyzS9rYnnNZShTIpCJauWtwupc625YosZDI46/8Apv8A/9k=','portafoglio':'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wgARCAJyAnIDASIAAhEBAxEB/8QAHAABAAIDAQEBAAAAAAAAAAAAAAUGAwQHAgEI/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAECAwQFBv/aAAwDAQACEAMQAAAB6oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgK0dEc4ny0Pn0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0+UY7HybRu/vznFtUNPoMBWaP1as0vtx7i1tntwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVuyczIy0w938ns81ey8xxZtPp3O987lq2Gt8XRr9J5D136Dg+i0AADXNhp7gAAAAAAAAAAAAAAAAAAAAAAAAAAAAA5d1GnERb6XJeJ2aU/Rcl6+L3UrxnPmq7XnLWB69zLpnvcH0XgBVsFIyvi+2/a4OilYbppROXoHMvvbz9NHRmAAAAAAAAAAAAAAAAAAAAAAAAAAAx5BxG42PlPDvZ7VXcXndFngNX1V9q/zqHp88ntndgAw5qcUC7RNq8vrgsUXYIrNfa9ZuLWlx90hNFtmuV9U93hCQAAAAAAAAAAAAAAAAAAAAAAAAAADV2hzWI7D8q5BN9ExnnPFR1lmUrQOiOX6R13m8BAl+t1XkvE7atuW2vq1jbutD1r0Oq2KE4uiC6/+cd/3/N784J7mO8OET1p60JkAAAAAAAAAAAAAAAAAAAAAAAYDLXuPZ6Uv8PEbmOeppWNSlSw2nBCE2ZbLRGbEhkzaObb91a+LfyUV+ywexPpXr7W8nLvDpTBvTC26ijVnrjQdfKlhHOrVlrfV0d4Hb1AAAAAAAAAAAAAAAAAAAAAAAKna+HlR6NX4Hl57nt2bP5l6ts2BnOhvfWYKAD78kY9eW5W5HDtNTkJXQ6tvkbtbqdG71j7jhaKdufYYfVWk+rklq/KRe+ndGvm7Or0AAAAAAAAAAAAAAAAAAAAAAVwpnLrHGVm5rvUPJ5qp0SEpfRPTdGoT2TLp7xWM8SWG7R8yXqUP5nfsoPJNfYiH9yqEZ6kfVUb8k/pGeZTyRfmW+WQ/ib+TEBjtpSm6t8r2mnQLrU7Z29QAAAAAAAAAAAAAAAAAAAADlXVeMm/X7O5Oyt32p1bLlvulE2rDmo2K2RfTWx7nPekcW2TY+uSPvzTqGs3tztrfoimW/GmQYwAAAB9oV8pvXXafPu3Gqtqpu2vbZnkth9HtvKBmTKAAAAAAAAAAAAAAAAAAABxPtfC4mV09rBz9uWXgdVWSq1ukYrVZVVq89mrepPTy2DYq0JhrZbRpWfPv0vMPaaISm3/xnb7u866LTzw56gAAPHtKiYeg6vZWvUiyVbupsYd350+hGeJX3MebZWoSafpLPX7BagAAAAAAAAAAAAAAAAADgne/z/W05i9+MO0DSxyKa7+7VfcRKVS378V59PylXcuvCSu5plEZsma++34z+ctcNlg/NIuu/wAz8YZ9c+8g951645RuZ16WochnFsQUhi3fP3QiKfVLfUfciZF/QefQ0tHfir4/oGdjpG+QAAAAAAAAAAAAAAAAAHj8/d44XS8x8MewAADD79kSezB+6zJV6a2lOfa3Tou+NEk9iB1rYs1Wka6WLJD7NdJDJp5q32vGFEfMGwmuhqTXuYrPm2e1aXqdCwTWoZrDqzMbn86ExsRH3Ppn+lMhNAAAAAAAAAAAAAAAAAAIjjXWuU003xj1gAAAAAfMuMje3YHXiJSG2duc6rp9L9S5tsXbQmIPcyaszu5YXEWH7WNAuzx7psAAPhCefErvyd1FswAAAAAAAAAAAAAAAAAKlzi+0XPXYGXUAAAAAAAAx5BGZd5NdfN68o3NqAwQtfumaqLLRrDAaZXL7H6cXnENsxeQefVbsGfRmIuz1e87cnUxagAAAAAAAAAAAAAAAAAHPqnY6/lt9GfSAAAAAAAAAAAB8gZaGvnt4m7tydW9x7u8D3EyamtAj+qc95/Q9x+zp8vrxfT+V9l25LgJqAAAAAAAAAAAAAAAAAByyL29fPbEMukAAAAAAAAAAB8+6hrx+/oaY+rDWLt0cFrHb4QCFmoiulEyYcnmfUQnfPz/APpLTn3BMAAAAAAAAAAAAAAAAAAcb9au5lvrDPoAAAAAAAAAAHwx6HrzanjVy/L00NrQuc5aUg1L4TW9TNO+HTYKh61qz+OA+c/pZf01+c/0bfEAAAAAAAAAAAAAAAAAADh+9GyOXRhGe4AAAAAAAAADR961qhNdLZ0pCaV+6Uy6JDPZ68jKxDJWpmGvlv8Ae+L9o25QAAAAAAAAAAAAAAAAAAODScVJ5dHwZ7gAAAAAAAANf7pWqE1AjZGO3ZpEXCrWmLBTUAfCOj9jS0wvnVOfdB15wAAAAAAAAAAAAAAAAAAOAysJN49IU2AAAAAAAAYPGraoTUACM2dbJbNY4SbroFNAGtmj5rrxsjE64dvtkNM3xAAAAAAAAAAAAAAAAAAA/O8/WrLj0hTYAAAAAAYDLp4vlqBMAADwiPe9e2cxKaO9nuEWfGkecZfPWhpnRvj+jsxfIAAAAAAAAAAAAAAAAAAD82Wqt2LLp9DPYAAAeT0wYpjcwafyYyYyagAAAMGfTmqPlYW1Ldn+ecuj351tdGTEWqBp59Ow6c/bRagAAAAAAAAAAAAAAAAAAHPuU/pelxPOskD9ptO/Nb1TTOwDL58JffgAAAAAAAI+QjJrIQFir1qWPyU1AAY8mvMat4o3UL4dAFqAAAAAAAAAAAAAAAAAAAAa3NOqD8y7nfuXRaCQEnTXb9eMMX2Xn1EgAAAAAAI2SjZpIQUzFTE2K6AANfYwTEf2zhv6J055ETUAAAAAAAAAAAAAAAAAAAAACG5T28fmKW7HyaLavyMlaa7LT9xbZEWAAAAAR0jHzXNDyl+tlznJ3aItHI/fRIyJqWSXjoeGnopxfprgP6BvkAAAAAAAAAAAAAAAAAAAAAAAABUOT/ofyfmqR6Tyyt82aPkK6Z2pki2cRYAABob+hNfHVeT9nvjaxagAAAAAAAAAAAAAAAAAAAAAAAAAAAAADFlHNeY/pjTPz3vWrnddJfJp79NfoiwAHzU2PE1ju88C/RumG4JqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZIcZpH6dgziO7tVWmtgau1XUInD785ZiE/S/wCc/wBG6cwTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACsWcfn+F/TNPieV7HmBrpYEdljTN+g+J9s05gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEHODlkP2sQM8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH/8QAMxAAAAYAAggGAgICAwEAAAAAAAECAwQFBhESExQVICEiUBAjMDIzQDFgJDRBkCU1NkP/2gAIAQEAAQUC/wBcMu2hRDcxVFI04qjiLeQJJ/pMh9uMzKs5lu9Fo2EEe7Y4NyrcD9LFeS1Jn0blfOZnsfo9zLXbWJamtit17skmW2I5Kc0ikRY6VNr2gKJ2isWHUvtfouIJWyVeHY5IYqWte4tWkdvaJgkS710q9Tk+7sWjNqY0mfX4NlGpj9FxsvyFeRS6BMsB1aIuJG3EOobWU3EoqT/i0vkYo9BbzbYTKYX3zG6eiSWspNYTzU6Y7vaVFZlIiIOsvGI7LAPkKXqi1Pm4r4ra4YryXLtbQ0UC1BWHyBMWlcKnEKH1d5xVH19TRPk/XVTmrTiTyZ5YhcIquLIfnC5kGhhxSa2twbGPR4cQWpV7FXWG6aHjdPZZZhUWckHNXHVZ1jc1vDdosnO8KSSkrSqitpLJSkMyWNrzIxpCVZttnEjKQuQty6nxWERo/A6tLbcQlWtpqjmP2856uc39CzacQ82tKVoyOqkYii5CombdA7xZwWrCMlyXRvsyodg3upghuppQW/BrUG5MvHaquar4/Dip7U1FOgo1bWo1Vbidxa3UVEJLFLBegEJrBSI0A9sqsGOmlzvL7Db7czC7Sj3PcMjctu8IeF2GzZaQyjixr/UfLRpuWpxOwsOXsYokarkWKa96RAsVe2o/NF0Yn76paUhywhthd5XICsS15BeKooVixIVix0KxTMFlbSbBuFlKqqp3XVikkpO6oDSmH232pLhTsQyXCZZqEG3BSqQ7M0rYa23IbVcEDsLhIw/cy37DuJnkJF1Xsm7iiGkO4sMOYmnLCrW2eCt5vDdshRlUqBVKAVWwQKvjEChxyBMMkNBJB5KVtYelapxxRwJSTJRB/DzanIlY7XWLy95yL6WUeHXk8wzHdJ5nxp+WJO4POE01Y2cmyeaquSa2OQTEYSEpIgpREFSWEjbmAT61D+YobPPMbFMMFXPDdRGN0RgVTCIWlSnV1dqmQkozsY9tfQDnvqCo0qWJcqPWx4EZ2zlCv6OCn/8AS9wxO9qaeOvVPaxGqb2ySRV8xQ3ORhFPDSEQ4yARZelY1LUoE9Z1gbxC2DxAwFW02WcOmUpaSJJC2aOPISolJ8KQs8S9wxPZFNkphk9X6x1lLDjbzXpm4ggcqOQOwiEDtIRA7iEHLGrWCsKpIK8hkW/Ig35DG+4YO3gKSuQzFW1YR1ltTBikWgsRE82oEefbsUW/MizN5hVacmO3KbYekVchixjPMrs4aAq7hkFX7IViAxvqWobwtFjXWygaLNY2KWobrWY3SQ3U2N1MjdbA3ZHG7Y43bGG7Yw3bHG7I43YwN1sDdTQ3SgHUjdKgdU6Ho0iInCj7z9d2u9m7DX1sPaChI/nKLSKRGXBNSW5LUyGuMcFER8FCjkCYZSNNlAOWwQ26ONrIwTzpjOWYynGNVYGNnsRstiNjsBsNgNgnDYJo2CaNgnDYZ42KwGyWI2axEZzWs+N0f8fCyNCl7Xjd0RUaqNaQTUdfdKaKPJZkpkQTQpC0ulMrzQK95hbiaqEE18RISwykEWX0oPQfjeGKZGhVdrxeenbqUSAlZKEqA0+HokiIqFeuIH8WxSvTYVNgJfEKe/XLiyWpTfhKksxkPXpqVtdssbfaNCNetqNtaXEenaoOLLSZKLwuT/kRcUE20ziaCsNW8B0IWlZdoxGeliKR8iizDcvIxJgMvh6FIiqi3S9FGiaTJia04zIr3a64bkC2skw0w6x2WtOyxTI5phTzjRPw4k5tbcqmehyW5THpLSlaHociApuxYUELStNl1zzitg4hA4qwTb7ZsXFhHOFilWbLiXmuy2Z6zE73yAyJRJN6KI0xp/wkwGXw9BkRlKmLUcSxS4JdalYjObLLRYx5LkeTCbRiSboxoUhMiPJinpMutzo7WlUWvqOx2XjriLVvddh5g01jXJBOoMcjKWgkLoP+n7Ks9ZiR35PF+Mh0IkyYojyWpBCTCZfEmteaEWc5HGuizUyq5xof52dZkyqVGUm5nthu3fRLs7Lbm4l2wTKLaEoIlxlgjI/RUeSar+ox1SvE0kY0SQ/NPzKMsqjssLruV+/hcitrND8pgMS2nvCRFZfEiqcSGpUiManYssLYejhqSlXhopGpYWFQWjB1yRu1Q3fKQCVZMgrWe2EX8ggjEJBF9FMItoSwiXHWCPMWK9XBi+XXQi6+BXOVJ5v16dGB2RR5JpeqYf541tocCNY2G3SUQdaQ6T9SkwpqVDNTqXAl1TYbfSvwS4ZBKiPxJaiGuUD1SgcaGoHXRVA6hJhVS6Ngltm4U8kbVIS208bY2sFKQCfbMEojCecpzqfQWijskxWjEoi8z00qNIS+ErSrwfgMOh6pWQdYcZNDy0BEpIStKglZkCcI+PSUQ1qxr1DX5hWoUFRoagqvimF1iAuA6kEbjRwU62f2W3Vo1dGXR63UQKS6kNymVn/h2DHdDtQHK6SgGb7QTKWEzMgmckIlsqBPNmNNJjP0k+3D6NO57LiA8qam/q/QUhKyJpTYKXJbDdjHWEqSsvyFxWFhVZGMKqGwdOoHUvg6uSN2ygonGHUHmjiPkRcomEk6Vx2XFJ5UlVygfTWhKxsaCMjmNgp76Am0YCZ0ZQS+0oaRH4SZIf6pH443zyZe6YuCk/zuy4vVlUV3Kt+uZEYOOyYOEyY2BoLbOM8GW1vynGbNkHMcbBWDYTMZMJUSi8Jn9abyZwQjp7LjM8q2FyrPtvHpS1nkmgL/AJQpChr0qJyNAdD1FXuibRSYgiStb4TfZOPpwWjKu7LjY/4sflX/AGnjBc5cg8mcMpzmcCVqSMRxSbcYXrWpfyTvdhVGjS9lxwfJH9P7JnkR8zZ5vyz8nC6enhuU6dZWHmy/zlTD86iToVHZcbn5/wCGPsunzETmU724bTlA4bY8q2r+Jz+1J+eIjVxey41P+e7yL7C1aJBZ5Jhl5M73RZ8qI2i/dIIv2gi6hmEWcNQTIZWMQuZV1cWUb/7oLWzOzYxPO2f9/wBczyJR5mJB5MxuTEw/OjOaMZTcVwKr4qgqoIwqpfIKr5SQqM+kaTrYJ5whSp1lt2bFXVeP/L9dxWkfhLPyW+TcjqkFyLxzMaahrFg1qBZbNhZGnddmxFzxE78v1nV8E32BHXK431aLLvTFwWjOx7NddWJF+/6ri8uGVzdMQucrjmn5c08msDo7PY88Sf5+o4vLic5zHeTVYWcji/AfPMTj6cGIyruzSueI/qLXlxlzmyfgqi6uJ4wv3zj6sLo0KXsy+d99NbnoMc5Mz4qsvL4VHkX5M/nln51OjV1fZi53P0TPILXn6MPmJ3trSyjcK1aRguch7qkNJ0G+zMHnZfQU5kDPP0VHkmF8c73Qiyi8C16Xi38sFOusuzxuU/1jcIgpRn6b/JmJ8Ez5WCyY8FHkFrNXA37MNo1l12exbOJbJUSk+jmRA3CBumDPP1ZXwMcmZPN8iyI1EQU6Pzw/iHg5GladnxPUnKTHkqYNEjTLWmNaY1pjWGNYoaxQ0lDP6M34kFkhXOSZmfG5ybe5RMEN9XaLihZnCXEkwHWpQIyMvrTfBnnI43/hm8m8GN6Nb2l9lt9uzwwHEPRHWpJH4kZH9OTzeVyTE+fjf9k4+rDberpu1y4jExuzwy42NJxhbUhKgpJKGkpAIyMvoOc5j3xQvk43OZzD86vRqoPbZ9dGnJs8OyIwQ8tsNPpWFNcydyP1y5zZPwMu6o9rG1pG1NjaGxrmwS0n4ZB7qkpLJPb7Koizys6OVCDUhSAhaHS1amwh0lH6rX9qZ8ODGkqiO1kJ0O4drlhzCsYw5hNQcwvNSF4esUhVTYIC48pAp62RJm9ys6GLMFjVSq82pKkjy3k5ONhDqV+pG+Sd8eD05VPfDIjKyw5HkCbAlQFtShkh0snEBDiVelE9k4YYRoUvfnEJdRZ4ZbWJEeRCdalAyS4WipIJXGf4i/DO99KnQqf0CRHakN2eGDIKS9FdakpV6DnxsFkzM+WInQifoU2FHmos8NPMhK3GFNSEr4nfiSWSXi05Zcv0WwrY09Nnh+TFDby2w28lzgcLNAjJ07f9HsqaLOFlSSoIakKSG3Ur4KQtZe/pNlQRZYn0cyGEPrQESkmFSEEnB7JuWn6XMq4cwScKFmWF5ulUVyK6N/s2/8QALhEAAQIEBAUEAgIDAAAAAAAAAQACAxESMRMgQFEQITAyQQQiUGEFQiNScHGA/9oACAEDAQE/Af8AKkKHV7nWWJ/QKo/uFFhS9zfhYgtDTzSOSIlJAeERz+EdzIeqhMgpgQvNEzPFjC88lTDb9qUJ3iSiQyzXQogHtdZBv9Vz88lEi/q3IRQ0MHlCYMmpvMc1TMU6+anlf3NKLTOYRAbzCFwnOE1UFPVOeG3WO1Y/0sR+ynFKpibrDduhC+1CeHCly/2qB4UR9Al5UVvnh6e+qcBEVAHQbGe1OjvKupTToRFlABB1JEuaez9mpj6uRTogasb6WI7ZVRNlOKv5VTE3VMTdUxN1TE3VMTdOMRqxXJkVxMtQWzEk6EQnw5pr5e1+TDftne2ocIPdpxfgeSLGuT4KpdDsmFr1U1vthoRHzlNOaInI3Tm0mWYsa5QWyeqQqGpzJaRt+JbspkXRYHJ/pvIU3N7k2lypO6dDc7msJyoKkpcYHeeLraSH3ZZcHNBToOy9zUIgVXCSoasJqwQhApsqXr37Jx0kLu6ElzRDTdYWypepxFiO2WLuMsTSQu7pSmqAqTuvcqiLqKUI7Sq28HWT76SDfrPXq3SYViuCb6p4XpfWTNJTj7U++kg36xuvXukw8YXeEOwJ19JA6pXlGEIpIKd+PYfCd+OamehodUsTlJHSQOoTw8qD5yP0sDpk8R5UG2R/nSwbdInJ4UPt4uT7aWDbozy/qmduR9tLBPLNNVZjZO7ULKri/SgyTYqmp9J1k/xkKffThxCa8HpOTrjIU6+pa8hB07KedyiHmqysQrEWJrA9A7KeU3US/wAEIm6H1k8p1/hGxN1fi6/woMkIm6qCP/AP/8QANBEAAQMCAwYDBwMFAAAAAAAAAQACAxESBCExEBMgIkBBMDJRFDNQUmFikSOBoUJwcYCx/9oACAECAQE/Af7qYifd8rfMnMOsz00ge7eVh8TebH6/BWvzfMoBvXEuzUclwdy0yVxDbh2TTUV+CAcskS3Li1ro1iX50/KpyU+ZNbaKbZZWxC5ydNO/McoQlxDc8ioMQ2YZddicOXHeR6p7gTz5FNDSeXmWHw5Dt5JrwF18jpDo1PLHMD5dVILXcpTJS0iX89eQDqgANOFvu5G/VMlYWhr+ya8yXBwy/wCLSN37JpAABV7fVVr1TnhmqOJavavQLfSeiMsncozHu9b1vdy30Yzqn8360X7hW18q30lKPOSiaD+o7yN/lCXfVdTZhdT1T2iXROxDgaAURxEh7ovcdTwWE9lGJWGrQqbz3ka3Qbm2L8qVk8vmCijljNbU6J2oWGBBNepLtVFNcfqixmI82RRw8TMjVWQ9mq0DSNVI/pC3rvUfwt875kZj86333rffet996Ex+db19Kgr2h6jnc51D1AcQap+GjlzGRThJH7z8pstwo78qdk0ed2SuJ1Kjgkk0C9jd6hSQvj8w4sKcy312Yfz9OUFbVBxbkVu2Hy5Kx0f+EMNE43t/Cc1zhdLkPROjjDL7U2V0f1Yp4gw1boeEGmYTcSD5woW0eVmqlB3SO0219VbXRBzm6qjHZ6FAuHmVbgrGeidDEW2EI4GI6FHAfK5HASDRHCTDsjE8ahNbVwCi1cdo6R+nFagXNQkHdZORaqbKLNXOVyD/AKK5qyQ6STTwbVzhb31W8aqsXL6qzhb0kmnh1VGq1q3YTArCrTsGqb0knjNUQzVgW6Clhohqh0knjwa7X+Vd0Okk8bsryzRDFFDFL2i4UVvSya+N2T+BvSya+O/Xgb0smvjd07XaE3pX6+N3R14B0snHTiGqGuym1vTW+IEOAIdPSqt8IIacAQ6mioqcYTVarVarespspxN0+BW8PZD4IWrTaPg1qp/oF//EAEgQAAEDAQIHCwkHAwMFAQAAAAEAAgMRBCESIjFBUWFxEBMgIzJQUoGRobEwM0BCYnKCksEUNENgY3PRBVPwJIOQRJOio+Hx/9oACAEBAAY/Av8AjhpLO3C6LbysSGZ3YFjWeUbCCqCbAdofd+SnSzODWNzoxWOsVn/zKfoqy1kcqH7O06LqqhMHWKLCgOBrBqEA7jLPoOT/AOLfITtGcfkgWaA8RGcviU0Bprka0ZXFYf8AUXljD+Aw3dZVLPAxmwKjmtI1oOgcLJM7Jg5HfCn2a1xgSjlNzEaQmzRVMDu8aEySM1Y4VH5Gme00ecRu0rfXZX+Cd/UJhqhBzN07gY0Yc5yDRtW+NBaMzaAdyZ9udR8eRtKXj/KoTR+ehxm6xnCIb6zcJm1S2V/4Zwm7D+RrLHpcXdn/AOp9Mu94P+dqihbkYANx0ltBwCatPgVhxuDm6Qmy2cYjMrtgy7hZ/akczvU0YyOwh9fI8ZIxu00WLNE7Y8c+WR2arh4J2DniwvqopW5HtDlZrJC7ABoXnTqWBOwOHgm2Zjy6GXMnbzG1mFeaKqfJ/clc4KVwyNwv44eCcefMwfVYhMcXs4oVZZr9QWLMexYVmlc5mgX9yENsAilyVzH+OenkcqI4f8oMN5jxCNSfYZDjwmrPaYrNNA4/aNA7lgush33avt9uGCfUbubzFfNNiNC/bbQayp7W/K84I+vCwI/vD+Tq1r7RbKuJvofqsCww77S4vyMHXn6lj2uGM6GRV8Vxdsgk1SR4Pggz+oQ7zXJI01YVvkOCJcoOZy+wWyuGLmE+HPJa4VByotNTZ397VHNBJgytxo5B/mRNdb4mw2wCgceSdiqO3c3uDjpzkYy9OtVscDMR1MCZZrN5lpy/VMhjFGMFBwXPfc1oqSpLVMMWtw8AjZ2ktgj86Rn9n+VBvMbfsVKFoCpWTbgoPicHNOcIteA5pygprak2KQ5/wz/CbbIrnsIwiO4qOb1jc7bzyYpcvquztK3mduFAcmg7Fg1Y/wBh+VcU6aH3HrjZbRKNDpEQMBp6LLyt6s7cCCt+jrWBHe48p5ynhPAyyEMQkd0S8qPC85Lxj9pvVnsjTQPvPbct6MIN17zylM2R7XRuOLTcfE7I4UW9y8qhicrVZne99Dz0WTMD2HMVhWSUx+y68Kkc9RqlVJrQANchWFapHTHQLggyJgY0ZgOHZ/3Popaf2vooaZMEKG1R/h3HVoW+MvmI83rX2m2TubhXtFELDaX75G/kO3LZTJ9ocrQBnw/Hn7GcBtWPaoR8YV9qb1AlXOkdsYsWGY9gWLZHdb//AIsWysG1yxYoB1H+U1k4ZgtNRghRjpx4J8FDhcuLinDWEQ4Ag5QUZjDyca8kgdSEkLw5mpWcQHCbFSpGq9Oe7I0VQfJc6QmQ9amlspeHEk1aaZV560/9xeetHzrzs/avOzfKmWe0vD2vrlF45yvRDrQ0n2b1iMmf1UXFWX5nrEbCzY1XSyfC2ix5Jz7z1Vxb1lY0reoLGld1BXl561yO9eaaromfKrmjsTmOIAIT7JIc+Lt0J04FbNL52nqnpIFpBBzjcJhmdG0+rSqY+B2HA4UfW4hbzH91YayP6R0BGNvnJLhqCP8ApJXYV9aZk2QCleBH+47684vkfyWjCKoSRGTixjIuNk6mq8OO0q6JvWsVoGwLGIG0q+VnasVxcdTVxdltDvhWLYyPeeAuRZ27XEq+eFuxlVjW13wsosa1Wk/EsYyu2vXma7XFCSxNwXs9UZ1vNqo2XJU5HImwyAN/tP5PVoXG2KX/AGyHLirDPX26NX+rkEcX9uLPtKDQAD6sYRtVq81Xt1DVuSwO5UbyOBH+47wPOM2l9GJj9Bqt8wsSlarCs8TWRnI6Q5Vj2trfdauNtU7lfGXe85YsEXyq4AbPJF7OLl06VR4MkWu8LjIHD3SsWKTrWBZIcH3RUrfbe7Cdlwa+JQDQABkA3BbIxVpxZB9UC01B3We+/wADziIoTWGLP0io6cvKCnQPrg1vaU18RBYRdTyl72DrV88XzhfeIu1feG9hXnj8pWOwO/2li2f/ANQVAJAPdX4vyr8T5Vyn/Ki1zzQ5asVbFNvkJ/DcCKK9+CfaXnWdqD3PaGVdeTqKukYdhV3NzrFZnapHDwVFVtXWU5fYKGnM4LS05szlh761mpxoQr7Q07L1cZHbGrFhkO00WJZu1y4uzs7CVdHT4FyiOwK+0OHxrGtJ+YrGn7lfKflXnHrlPWV/avX7Vkd2rI7tXJd2rI7tWR3avX7Vlf2rlvV0juxXTf8AirpW9i5bFh4VBpa5ONocX0fgtJ5sfI3zhxW7U+WW8XgVzlQsddjgHtRDhUHKCi+EF9mztzsV+MwquWPSg1zaSaMLKvMhebYOpcqMdi881XPJ2NKxYpnbGLFslp+VXWKTrNF9zA2yBeYiHxrk2cda5VmXnbP2L7xD2L71F8q+9R/IvvUfyL71F8q+8Q/KvPQdi5dnK/6dBxFDn4DBpcoPaq7v5sssW1xUbNARmhFT6w+qEdqBe3pZ1hQPDvEIy2OgJyxZnbE5pFCLnMdlC3yz1p0c4WDbXzDQ4P8AFV3sv1l5V1nj6xVYsUY+EK4U9CnhOWOQ8CIbVZG/pjmyFn6Y8Sryriq0wX6QsNlaD1mINtTcMdIZUHxScYPWHKCDbRQVyPHJP8IuZiydxW9yAmPOw5tiw4XVGjON3CmeG6s5WDZYK63fwqtjI+BcZFUa2fwqWmMxnSLwg6Nwc05x5QWto4t+LIgWmoO60aGpkclluaKVa5Y++x7W/wALFtUfWaeKqxwcNR5pA0YA3KglrhkIQbaKNOZ2Y7laYDtIWGypA9Zi3u2ME0Zy6Vh/09+/R54Tym7Fp8WoSwuNOkEGT0jl7isBlHTnNoW/W5zr82dbzDGXy9CJtSsWwGntSgKtqsksY6Qo8dywgGur67VhsOHAT27UJI8mcaD5MteKtNxCLrNWWz5cDOFjVYdYVWGoRGwLOFc5XEFVbhA+yVdaHnU+/wAUBbIQR0o/4TJIzVjhUHmZ/wC4O4I7lDeFxOPH0D9FRpo/oncrTBdpasNmMB6zcywn+dH4gy9awJ6A6cywoLj0cyDrRHhEZimxNnEENKve647B/KwLHJA1upwvTGQz0kw6kNdfRMkY8OuFaHIUZ7HRk+cerJt/lODm+y9jsxW9kneJPDyvGxMdtClDeTvhon06a9Qq+M9RV4cNoXKCzEIYOdWX3OZpj+q5O4FcjtIXGjfY9OdcW6/Qcu5jNo7pBVZxjdWVYLsZmgrBfytdxVY8dvfuVFDsKLoS9h9lXy195oTrRgswnCjgBQFMwocB7TlBUbJhJhgUJovPU2grFniPxK6/Z5EnQKoHS4lE7TwLwCmYN1a1Q1BWT9sczSu9pxR28KoxHaWrHG/s71RrqO6LtzjG36RlVYThjRnWCa+69cYN5k6WZYbDhR9Jt4WNincva07Qr2AFXYQV0h7Fiys67liX+65XG0DtWM8/E1Y0cTuqix7P2OWM2VvVVeeptBCxJ4j8SuNdind7BTfcJTjq4LRoCcrM3RG0d3MpOhPd7J8jjtBWJJVuh96xrjuUkaHDWqwOpqcq0c3WMi4xgB6TLu5YrqtWg7mngcoq+hWPCw9SvipsWK5zetYk3aFivYVij5XIsfv5Yc15C3txxaYNCEaAGqvZ3rI5cpXEFP1CiOsoDQKcyzO0MJ7lMfZ8pcVjDsVx3L2YJ0tuVYnB2o3FcYxzVcbljCixSDuaOHlKyrMr21WNA3sC81TYrnSNWJP2tWKWO2FHKNKs7elIPHma1n9J3gpzs8viPc1Y7A8aWZexUD6O0OuO5fGAfZuXFS9TguRhe6VjYbdqvAK5JGwq+q5QG1ecb2rlN7fJyO0klWUe1Xs5mtXuqY6/QaOAK4iVzNWULjYhINLFe7APtKrSHDVuY0TOxXNcNhWLI4bQrpm9YVzoz1rI35l5vvCocV41ppOUjyHUmnosJ5mn14I71J73omO0HaqxudGdRWLMJB7S42zV91YwezaFdM3ruV0rD8Syjt3MGPrKdtp5B51FdQU7tEdO/mY63gLa4+kXgHar4wshHWsrkwRyGj8o3Gtivkc65cZZnHY2vgqSw07le1wXKptWKQRuvXWrW/3R48zRDTL9Co9v19Mj7UTqURHq1PcsgVHtqsezxfIuLwoz7LkZbM/fWjRcexYD+X47jBpeE0KV3Sk+g5ms49s+Cg9LojqanqR2hnBuKba4Bg4Zx6ZnJrtKhGslNCi9ouPfzNZB730Vn930qqqpT1blodsHCnGgV704aCmamrqVkHsA8zWUaGlQD2B6VTcedJTRrRPSfwrR7qftTtTQE5Qs6LAO7maAfp/VMHsj0nXuE6txoQaw8XlALVjwsOy5Y8DxsNVeXt2tV07eu5Ys0Z+IKleW4BDWaqU6wE1vSfTv5nYP0x4ldXpb01dSjaQCMELHib2LFJb1rEm7Qriw9a83XYVjRSdipV7VyjerKP1AeZ6aGtCPpGrdO1N2JypwMpXKK5RV7iqkDISofZBPdzO8a2eATtvo9BwGjXuDW7yDzqXUApX9GP68zyfuN+idt9GoMvBiG4zt8gQqa1a3+6PHmeT970agy8JifsWweQGtwTQpHdKT6czzfvH0W7LwzqTlIdXDooxrTQoPaq7v5nmP6r/r6JRvkJSutPOvyDdQ3LK39Mczyn9R/wBfQr1q8jIU0LaeFq3Hamp1NNE1ugU5ncdJd6Dder/Ik6kdqaFHwdW7KdgUDelKPHmjrPl7r/KP2ILqTBqG7etXAldrKsw0Eu7BzRM3oyVGxBzch8ll3LlefKuTdicgFeVdwinO6MZ5o+02cVmYKFvSCp6uhVbRZlmWZZtzKsvoQ2po1L4ll4btiaNitUmpreaTJFxVo05nbVgzsLDmOYrjO0K68ejsG43b5ByaFI/pSfTmosmY17DmIRf/AE93+24+BRZI10b9BCx7j6NEESh5ADSQmhWfWC7tPNmBaIw8eCL7E7fG9A5UWmrSMrSr7ivqse9ukKoyegsT9iOzyDPeWwKzs6MbR3c3UtEdTmcMoRfZ+Pi1codSpm0FaDoKrGcE9ypKME6fQDqCcjdVcjvXJK9ZZe5coK5ze3dI10QGjnAmRmDJ025UXAb7F0m5toVDeFTuK4o3dEqhxXaD5aUrrVpLmggvAv2LHssPy0V0Tme68rEmmbtoVxdqB2sWLJC7rK8yHbHhX2WXqFVjxTN2tKi4pwja4FziLqc5lzRvMvSbk6wqyMqz+43IqPvC0rFx26FoOg+UlOtN2onpSE8+0ORF9l4iTR6pXHsLdDhkKpJ2qtxV2OFTIdB8k460xWfXU9/P5bI0OacoKL7C7e3dB2RYMzHRv8VSTtV9CsV1RocrxThlBN2KyD9MH8glk8bZG6Ci+wOr+m76FFr2uY8ZQVR9x8g7YmrqULeiwDu/IeDaIw7xCL7Gd+Z0fWCLTUUytKvuPCfsQGpBukgfkbj48bpjKi+Hj4tWUdSpm0FaDwCNyBumVvj+SC5zcCXpt+qLi3fIumxX3hXG/RwLP+5X8lFzBvMulmTsROBvkfSjvWWu1YworjUoy5o2HtP5M46FuF0hcVWy2jqkH1VC+Cmmp/hb2w1cb3O0n/k3/8QALBAAAgECAwcEAwEBAQAAAAAAAAERITFBUWFxgZGhsdHwECBQwTBA4WDxkP/aAAgBAQABPyH/AM4XmM+EiIa4weaigFhZ2H12E01Kt/iVGGlsYUmbmG14UcxS2oouArJ0L1B4KbVFZ86qUk0Ul6X2ZhR077uT/wARwGsPxp/ScA1DnvjC/aOnWINq0pTKoBgkjCAQ7pPydj6iEUbm9FdB3uC8ZtSGtTtP8MyED4GkjwpXJeCCJkTnzo2NkYnGrOCmYxhX1EqNCDy3YEBQfhDqivJE7iQwysA94uPX/DPWAfbkBcPRU3qBYwq7lAysVRqUqcgUGfjyiclWjuoOz0iSmgTkqDYS2n/H4eXjh1DzUfOOyJgT3ALuj6DsEpvKmyhapfkRlNrPYYnkN2sxvTQpSfUNx4NsB8m4mMc5fLu99/spbttYDvL8OpuzGAv/AEI1K9VGsGY0OMbzbgt75o1TlBdluRn8vQnIZe5LxbcB4IRtTZ1dUZR7CdKdkSP1L2YjC2C9ECuoXNlKtR5rqVN1W8cW4xw9yg1NdGUVXnj29Q647DOGn45asVlzoXENo2OITAZKDg8zuS/TPemP6+ZUAShHijAtJ+FUJpdq+0M4CVpm9hVEnoGiuVrf2A8DtL6dE/CkTXF/ooCgPax6WyiRNIWbbfwRQsJvQ3dlfMUl+iVfop6J7FFsY4LXjCEpjphOpVExZ6gAVR4oclv8ytCEqtAdm3Jq3j/RAUi6KN3YcmvYPSLTMig38aHzUmnXVmjb+iDdwpV9z2+Ptj6C4Ldb6DNeDeu24lVDaOgSGdGIZySlwr1dPTpaA8DvCBU7GH3CrJr+HzV7riZHhvyedctlrS6m1hp7khR8YvEsUqjL3u4sJDaPEyr8XBCiXq/FS3EnJbIOmrQk58YOM4wQ1tcTtlHSC4UrsQGQcHV88plHqj0QhJUvyIR5JG0TfH19hj5uQzzJY91QCGexsaYU3tEhqFE2So9hEQoQoyKiJMoADsGxwdjQuAqpdhscOPuPIwG3DszSSSYSO47i7p9xf1oQV4J/RFJZKUxKcNnySEbaEhCO4T6Shuc0ic2WCVr2EPo24N82N7V5fQhLRaq+ynO9qO2G0ZjBuPSAXR3tcte/qWQ7grBmPYKrIVqs3neDAEFJufcJ6FKsMaTUNSmXM/sCoM7RQ/6PqLhKyiajCYlvH9DMWGbfQgQML9ULD8I+RMwhtmiqUdUN7k5sonA8j79JE6U0+rgOh0RSJnGppnHQpEuMgis/DFBc/l1DfTo6KEQutYYo8DExF82vg1F1/hLmPgNy6++uGtcZoRdDOwSgOF3VCnAFn35mVGVoWBHQlboRp7K/kUI0nD0b78pJTUpYwlyk8NkhHBfn7C5OXAyTZ6jLbtxiuWEficsJuBU20Ujm0OfdDCr2aWRqt6kicKWPMrInZZUspBJQosF6O+0S5eMhSRKU167Js+QG4RLrT0Zos3SVPMS7Mg+jpkKmzPkNPxQ8h0vQ53ClpIXLdTLzuWfQnibCeyx1DqUSGknEq+xZfA7nh/oWSl6IqEY0x1mGrhsskWhIKyJKoXSIFXCEQksmtPjn0gl4nmOUl2xLpfnfaG42qPNkQ6MU7pCoueXYOTFY88DaJ8qA3Y8dB+cbefU/eM/vEzuHdba0eL95i+lBY3AQv6aMzhuxme52ULR5fKP+W7Dw+WPsoJ7n9D+wMI2bvfYQLhAGdZ7OXELH4x791diXAHUgmzlAQgKDEDkhcrrqrQj8LRrAiCs6L9iZinE0bBbd7LLDtyj+50L9uXJWjaIFzVJdVtgLpMhWwBgNq/oktvUnwOJPdW92JLp86Hiex5zsec7Hmexr3jQyW73Yjtx3YWv3sbewSZNeyNDM5f0lmLu4vjGSl0+sl9i8STO0yCgrkF4HRLb3IifFLmIX7UHU+oxhOiDiIcOQtX0BAON1BJBpKsVTCfQmOSsSLDYRLzf6CFdqRu9lTbvOBtI+Kn4zKVJ4hh0WucE31L2ku2sOt2OAB/8AYmkUdKO1WKHTaWjzLaFCfmSVL19gxr33UL1hTHboESxthVfAW4dFXUu3El7yDFcs5GZK/I0c0JawyfmQkpVJr1n85LHoo65PRogqjbByku2Vr4Sb4nxcX+xq9hKWrBIi23Z816T3i+BjZBXl2EmowaLOjJ+AVa8mg5J2bnEIFt0WjbSXnBQCNMGtkqp1zdW3LYP/ANaE8t5UVtdcKmcBUo7b+RkmBteItPQTy0ZHqMXqoy+U/wAa1isjEVC05BQQ+NUxEq/FDbXFy3GMR70JBbZa7AiJMhksaCg1vEMSs4vhtkU8Dt695WmXTKg+PjraInM130mmPVw1CuiT2RRf7ClSumdtJiPjmwY9bm6tSoDBJ/uzCntnm0Vo1MBDyGGx6WKi7i65YmYio3v2UxpTYz4HtX5asfOvxFKCi00oO3mhyrGRTk70Qc8hkBba+ONVXMEMoSWy+H7yDiTmPaLqTF4bCeLeOknpLvcayUVq/UJooNshJ4lgVJsZMzadm4SsbgsCg9DqNtcbVPKwHEfveDtEKooU2mQllTRRpll3OOi4FMutpI/wakgvJDezTnaIcJ4IiRQQzU+GfWebZV7lEN7EKSjNVo74BH6JXDuwkU85QS/isCxdpuBSxTR/2AoH1C/oALhkUOjBmEm0Nl7vi6VaknIUbIa1Wi+xYo2vsYi89DoIvsWhTnQ0CrbiElYI40K9l1LNlIe1tSWPyJ5QifCz1gkrLM5oufgWbwxHou8JNxMoy/TYfwTUntlxKRrPljyljYHNDKZT29N+mgizuuXoqWLMHciG6eD7lkee3eXj4ovzWUVyfUMQuGYG8ZWxE3yAL+QN3QYVW05XjKxkhGqrwmiZ8MK5sCi5/ku0juHqCk2Cp9NAimuNUOU5jV5s1X0lNX2l+F7e3YK04wkd4kYDIgl2vMrhvjR3uCoOrvi2JcuTgOaXX5BfC7LAQaNOv50+6C4M3jojiESHlUjUwdiuZiBN/BYoeSoc5CipoL3EuxCWqA7uRcCLMNWDAkzX4mA2lXLT9C+Fn+zxaQkeLT9GIN1RxL75BvFtD4DiHZKwa4YaR0Q6ouG1o9JFf5cMx03Il1R2ELP2INGbYTE5s4BloBv3tI8ipbxd8Tza6ffw21rkRZWbdF+pycw9U0LcdFLhJm45R1tS0AOQUgrJ3ouP8cCgIEoRl78zkVjoE7v9CdvhoF5zf0LD+wOWwOmmh0bB4C948ZoAhUdiziSW0wHkl9Z6hzvx9HCTZqT9XiC7hcxoFmNsGn4ZpqAu0s+b9tuFJVmCY0GYe/8AvEIXYOgFrUkZzzofITviTyYnuWcYfsIazh9DEm2TbJNxeXwxDn2BIek/t4Pf6GbhHiFLXte8gj2IE2id/wBGiqu0afKENuUk18Uvr4betwsL0Pl+1NMNIxvuIn1aRvT1/dpocInQaRmvmTbCHikdfv4aXMnmuw1oHQ/anhw9ZrbYNW3kl7po9HMSqamgPPBJA7H8M2BnzGwX7Ntxb00GYg2mxpySkhtWCg51Zh7lGPFY2FhWyxw60CHKmAcfpEuzhfzBGiPxBU+G0MWGDkn7CpmNmfpuAJuMkkMkQ5XgMYWdPQ5P/eWjH6jxinYGWALbEtRspaGDamaWS/Wo3Ofh2/ZAGyWesWsiFh6CwZwJBk9iXbjCMRDSrFtFkcPCCmf+m+HfZAFf66+y9m8AlEITxtx+/OSZWIksYvNPh23J5Ctmr9uLeEaE2Lvv4FOm0Quuj8O4M+h1b9Yh+2k5IeRqJF5r97cJfpe2ibZP+LyT4dpHnP6tt76t5PoeOASZRF78HvH34+RsIpJ1i3OfDt4VUL9PvH4OOeo8RzG2SL3JnY3UZWvNZM6ySM1k97Wp+GY+tM/SKWWGU2/CrZrG3wqGb7W4Us6I9N0CKBiJa+y/hjPKFX9FVFYc8t+HSZha2YfcpNtFPP2OhaL1V6zkGOUUL4druX1/M/Ti7umX42ASNVsedlDOJeslajQMnseNZkqW4gP4djtK9vErkOQlEr8TvkE82YBAzEfleNSBQn5I0kXpZkd7G20v2WE5Tu0+bMvHOLS+IR6MFfvIdHU4nwEVwaA0Ro+jPS9A86Sd2/0WhWY2QCq1+xdG97SMmNqEJnsEOb+JYPJlXHgPsyGa8hmAgSplofr1LNYqG9p/geNjA+0ycVV3BJ/firgQJyPEd4XEQJc1H27ATlSrD0Ulsurr9PeH7H2ExZ0E3+CrILmbrSRPFxvPjMkuzfYeBmfdldmYk7dQjHIh1v1i6XwS6HYtK6omSno/RoOSGhwWXZfgJD2iaGQvj1QRsaK3xVyjBP6Nw7lVCociQfaY+mkYtPz+A4DwLGEkqVFn4AsQUzBNwn4wnekyJzYdSeRTGJQxgj5DKidPezKOvh/wHBjZZ5ldSAqz/MleUoNG2hEWUJNv6G1U80rciU8wYjZswIdGvsaUrZfRX0KV3xzAZxsYDHcKtonydRdwagbarpV/g4oWJoutGNai6KQnxb8lQzQjxQ84KF865ITa6ZOhXYLlYbiJp9VsGMVCdA+PlXQrvpu406Gf4UV5ovRNpUX/AHvn7cTnKZtVir2PAY9Zrdwh0IeQp0nMXjg1M2fX30s0FjWbGojzHNT/AIF3Q4JQWXlr4ZloIjg4oWBde9oZqN0R6f8ACcyQH+D6DJSs34MQQ1qEoW9+7nBpMnoICQhYf4WGIy0V3kPYcV43YZ4BSk9F+zWb00sXJ/iK+Xhw39ilh4VtqwKPv1zm8eyEKtXDL/xVTWwqtommN/2K6KFQyF2OcdHliIxVydx3/wAZON5/+6h5mUvLDsPxApU48teC/wDTf//aAAwDAQACAAMAAAAQ88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888800888888888888888888888888888888888888DidH888888888888888888888888888888888884mQzBk8884w888888888888888888888888888888bqDUP88FOsz88888888888888888888888888888CYLvc84bQReW8888888888888888888888888888sXvU00gbOd6N238888888888888888888888888ZR3/+OQ6nNblb9sU88888888888888888888888ojEt9//wDc8THN8n89PPPPPPPPPPPPPPPPPPPPPPPGKfVF2pvPby3R7b/TlPPPPPPPPPPPPPPPPPPPPPOACc2L/c+OP/8A/wD/ALd+3NPPPPPPPPPPPPPPPPPPPPDJeRACxlvGlP8A/wD/APfGwcUVPPPPPPPPPPPPPPPPPPEnf3sNHh2X7jcMOevZPjtfPPPPPPPPPPPPPPPPPPFv/wD/AP8AnL2lcvTv73tpo/xNPPPPPPPPPPPPPPPPPPFP/wD/AP8A/wD/AMwvEFshe3//AP8ARzzzzzzzzzzzzzzzzzzwz/8A/wD/AP8A/wD/AO+5zjuvv3f5fzzzzzzzzzzzzzzzzzzy7/8A/wD/AP8A/wD/AP8A/wD/APag05eQXzzzzzzzzzzzzzzzzzzwn/8A/wD/AP8A/wD/AP8A/wD6uiP/AO8X/wA888888888888888888y//AP8A/wD/AP8A/wD/AP8Av6j7DNsFHzzzzzzzzzzzzzzzzzzxT/8A/wD/AP8A/wD/AP8A/wDPp/P/AF31zzzzzzzzzzzzzzzzzzyjj/8A/wD/AP8A/wD/AP8A9++SX/8A/wCtzzzzzzzzzzzzzzzzzzzwb/8A/wD/AP8A/wD/AO3776rX/wDrUc888888888888888888of8A/wD/AP8A/wD/AK/+++/if/8AvmtPPPPPPPPPPPPPPPPPPOMP/wD/AP8A/vPPvvvrZFe3PhfPPPPPPPPPPPPPPPPPPPOvf7/fPvvvvvvvmfvvvCvPPPPPPPPPPPPPPPPPPPPDEMdPvvvvvvvr5PvvPXPPPPPPPPPPPPPPPPPPPPPPPPDetfvvvvvqn4OD9bfPPPPPPPPPPPPPPPPPPPPPPPPKEo9fvvvprvPPDPPPPPPPPPPPPPPPPPPPPPPPPPPPLHDdvvvmePPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLJevPvIvPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLKscIfPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLHPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP/EACwRAQACAQIEBgEEAwEAAAAAAAEAETEhQRAgQFEwYXGhsfBQgZHB0XCA4fH/2gAIAQMBAT8Q/wAqGHQEBjT7xTCkAbHx+FoqxWsoDTL2q9YCqwypH4R9idJVB0rr0iCzAS4eNYg0eq+9o6JX7v8ApFO51wm8i5okQF190JNj55GyjUwMwETpI2NjqeT14zDFOXkuO9qkKlzBBNfmfKf4l9rPNIBw9Vk0doi9ovx7J9FSzPuluflNW4NtSYZqYQdsa/e8NLWvaHSc8MnVK6Op8QwyGmOYuFUMDq43lGqmN6LI4s6lQLeIu5B2jEKRlHEXY+cuxFn0lLf4n1f+T7GfYz7GfQ/8gtrPPhNdOQb01mDr3iqj9Z6cAXEqLt+z/UROaxCYhs9PilWS3nILZHrUsmRqO0YNahpQ9WXPwQemu6Ii5tccy9O0d0l2GULvpDZ4mt6GbX+01Oa+55Q0QvzP6j1BqUtkO2biW0T2l5aVwNp58XSDv0mDlStyplSDdwOWO8oBgjEOYttFNo7TLFupTvcsZi0rpMPgPZGnnMGr2lMuVYYFtc7sKOUWOuncnY09JTiP0x1Y95olzFMGw8FSZtdJn8ZXR5y6HaG6m4x5lljeLX0mbxVomKVL04tGO588ArXSbvFds/jABsmC9yTZX7ME7OnlAApiK3pMHxNvgZzUrkXx0uD4e2cVqoc+RaLpc3hbZyDrfWGhxW0WrrdajfldJFDgtRbi93S645kx7ObSppBNEPZFvgtDpXdks0ZeXlvg55scmDNrp8bPIZdZ8HGprLkwjt9UAdphtefI9Yhpnn8K/aV7Rbb6tjR1Ibl+kNry4vwa2NUY5crP+DFNSbMCajhvMn4VdRwxVdzU/wCgP//EACwRAQACAQICCQUBAQEAAAAAAAEAETEhQUBRECBhcYGRodHwMFCxweHxcID/2gAIAQIBAT8Q/wCqPQ7WCZ7HkfP1EtM9pp+/xFo69L3fZdV5Gj55Q8LC1zldpRahVdnjKDMz1/p6spzuX9kYRkb8P8plH9u5u8yw2to0YX9y7TlAeH9a8GVPKB02s/sC0O0z6+0zYexF/TLFoTJxw7SPr8/GkohS2qzw3PUlEsuQV55fx3zwUjYOoeucB2wZW145XBcuNmAXI12h378j2gwb47RRcEoV1b84W9agcrsrfsZp7AdK2YmRzp+X8fmKwWB+J2DzgMHis9h8DFRXx6YbAeIfuEwefsR/2f5Bmr5e7NdKx03O/wDfxlNTvyHyU9GII+itaXyNb72Ug1gvK/avtCLUSt3Hyuj0HFN6tTTwjYHgt9ZoV/DT8VN5uipTDCUtyHufaN9rfMshq0vav0iVr3VoTW4m5WSAK2u7XxJXjbiRCm0Uha5+f9/Mer3sf1T4EAyviwwj1mQB4H7ZTgI5h8z2nIPP+TufN9pX5fad35vtOQef8iGo93+Q5sKb3EUBP5OfO6aKbOTXz+X3wLfRwJnB2NsYDVNLngmwXd82W6wvgXee+vQbPD4MwicJ+2IPvUdtnw/ZTETRe4z8+aTIwPV7S7bsD5pCFgN7t+ukJu7sjk+bJpATXrHzs6qQH1c8zR8dmFW2JfN0VmnCZYY6NRWqJyzRYswaOLOZ7TsCRcROsBIAx4zMJD2Zng+Mzs5FPBjcxZ5p05cJn6vZHkmEjGxrzIOJiRlOcpLGFgG8U6oMAjsmC8MFPGNDmJcMNn3gtstySzeVADh6u7hPy/Tu51lm07ZgmGGYiMQ26TDhMTv+sN5cYrtF5QsgnHhMT6oXDDDp6RajnMOEzPqhXQoDBczuYhNHnLWvC4PqB0OE2HTRBwuD6YdLsdWGOPA6mwmbpMy42qB1uboC+jPhRrfWph15mmWHT3cKglMa4lEolfRzm96mUx4dEKJX0c5m6mUw4lLFGZ2OvugslJWV6JpxadolZ6ww/Yx5IiZ6rD7HVzkxOhtMPsqDmPLL/wDgL//EACwQAQABAgQFAwQDAQEAAAAAAAERACExQVFhcYGRobHB0fAgMFDhEEDxYJD/2gAIAQEAAT8Q/wDOFZ7HNB0ScPGKVCTRXu1dLV3tElIDKCXeb1UaUUSI2T/iZopN7BmuAGNEEFhLVivf4L1metn2XqtYSXWFyBaJxexF3hRpYeyrPhKcZcBpt+PY2an/AIRZ9OeHB/4dq9moDHLJqGFBVBE9XIM1m5dCg18DRNAu9i1HAPElxYl5tM9szEPJrdsynnRy43VdhlWXsK4p5qzT4fhbaXk2I8HUo6uqmjzt/wAMvYZTEsSbknKgrEdZ4OrLyKR4rDBqJNeb6cak7bIyCpA0i7aC98gx2qVAkSWbeRSXk79XQ5WZWsNTdUYMSxtpDjDUOZYcSEvo8Wmwx8QETkCa6/8ACmxYw3AeVLiJ4ySl1VJlBUaEKwVMIBuRJFmQi2CbVd56BTmUuiACAwlsqHW1QJCSNmhspoYlHIQ5VCSG1JQfsJpqPn5draPLHZoR/NuEXG3RHhpbhYJnGotAoJoB9am8DQNxBOBNxXakwLK2z6hco2c3NASOVgnMd6AAYCy39sChegGVaYKb8ZjD0agjkOmh6tD6kDNpC6HId3Snh9srF8edMT2/c34qe1S7uWHkrE5VWpvIPKWrmpLGmZuuNtzCpth+ZjjmDGE9weVMqSmZ+gqOTTEJzF0yjWTDpbSggQokIwHdYM4qToL3TiocJrBNp5ZEGeALA3VnjhWJ2xXJtsAOOrtUsQCbldVPWhELMIB6qDmoxfpQEqS5hrOwZvBqf8PrIb3sVxh56UlyW7YZWsjQNC3UEj3PQqTy+a3MaMiO4JwX5qWJUnIshGuXoqQRVnHifN1ctPzLeDFSIQjyoNH5AmRsmr2f3RrixAhza4CfsScvbYSwlhi43JiaFB6WQZONBKojGoSWB8p2rDXOk/OlmNVZbvuqbbRMgMNlFhvq0UoXOQZu6yu79Iv2WyUr0KdMFdB6QS/ug54g5k5BJcMkM6z6yhCthNEJkwzUttQs3MvPQoKNS6R/e1W9tPDcrE6dyrAnV8uXw/SJbPVGCdzSrEkG7XqxNk/MpfZeGoNTUzOTSG1wKLPKuq5mdRqVwgnF5lTqBU9rmahasOLkBSMQ7kcXn1VG6KRR5Oa6HpnQR0eMejDIy4y/VGAHc4V7DOdQSBlrI+AKXsE5lxjgJwCkvBHkt1sXedYLgRdmOVzgtQP8vskSLkIUwk4fwf4rC8/yYafFrtu4B4xPjStQ3niPh2p/M5C+GcdncvTsKyIDgLOc0PROxFRwJQkULBscBGgmC6fWZV1KH5cFFyPr1fo8R+7UaEEBGkTxS2OFwWKTYyIJhBO1xzKAPgEBjvLCLmNzt2mfQXA0wyvQGyJBmzNNwUVkcN6gOhMZTTyVPwh5H8dKkqTWuX5ad6k1qaejWZ+VAzs6z0Gmm0qcfturHkUmNKZrvoUmipeKpi0fDgK7uNNPqkKxhMVbXpehQukvcGscwk3zziD50iV0wJxEcSkvhgJCVuvhheipFM3SmbZigbPl5YqjoSSzaORuZBPfChsJX2iUnYVMu3tgxMnwrBqvh3XKXAbiay4Ia1IngJSUwgnJDr+SBoaVWAKsN8TWdJKd6nvhJg9qRO7O9vUpAAcHvI8UoQ5Rhz9WnZdZDdGhLI4rrsNHHwwxiiPSXyWmupg8FMSjvPWsQ3A+bXae9iu2qD0pCemgRo8mGo1hfIZQd4k3HWo/lmlKxmiW6tKMqpSRcEcymQzQiSJpS2emFhoMluM0kSCsAltnYInB1oAwfUAGzJuv6kEqluydu1nHapJzEcMLRoiXnTqiNyUhT0/mxIqKsAKjA/IbFroBXYpZb02Jf2Tyiil6l5sc3tQpLmz4igQmmcnvNDwHsngoGRtg81LBUyB9prg8npVJRo9m82ngCf0jGsBndDooK78Ip1eHqVdYID2KSfG2hT0yNV0Lm1CAvM2Y9+JUcuWwZcM2NQ2e1K0+czOMPRJKh7zm5wuPUpFk13BVqRxfSjo2JsWqMZOx3XQ1Xdoim5JCGBaM3litQMDt5UAJzMFh6j1+kUMD8hnx88ZSOmryoQak3psCcG+NNaYr2IZGoLxyaiohx8o0ZHUwS8r1rIXKchCoNV1k9WaHgnQPGlXFXj9m52ZmN5ty+s0AWopiNj0WOFGzO4XohR5aLH6y0ilqJA85zIqXfZA18rHWj6uIgjADI/gXhA2WHgOI1rL/ACmT+YBUJh+PJlQC6tRhMBbiydQLHNzrJ2dWQuxhwaGJSBdAbcY4NGSVPJDGZJhGX2pM3SnCevauyIvLUrbNfcr4O/CsWHwLUk4+A5U9f8wV5tQsjmeq0UIMBXQroiqPmeJq1h4xe9OtQUlxEijaTLFOoRHfUcalAzmEcyRrzjh5qzsmkLBdYvNTQ3VfhrdpCn8cRdcNddDp+mtCbIgN2rWgODV3T8nHGJS8QcOOylt5y5uRyd8TOhmGGkCRb8SzXTg8MUa9N/IoxlfhY05HMz4FYWDaiW2JaJRa5HSryGCieOY0tx+FZtZ98A9azu4FRsW5PpQeJqAYF8bUHnfO1f6ev9DX+1pXJ+dqVxD5aUpgNBmA4y9Kyz4t60jEoHxnD+9d8gKSkxpIRcNHKp+Oo8vCrsK4/jCdDk+U3YC8ikmUAKVxv1BebwqzW3XEQJHpR3TSJA4iUprHHtr6zLvReHZdi1HJpaTEGw20PZo+eX4o+zzWNT48Wrtu4vNC3CVAbzi+NKzJp6BQfA5FfLVb0L8/a1h+1Dzj/FPPRqMRwc/SvCBK+ADaj4jwVTO/jLHIbiqwYceqwd2Kr3VAoPPbDntQtHRWRCMdPokd7JUGEjnAZ2D8ZkEAatCYCObZL3Wm1re+LoZ7nOobWqW95wdHjUbJLiOIXKcd87O1/wAbtWDgJ66Jlvg0eqEJ5ms7m9IogtkIQobnPWn0ABHOpDDRhIj4Jmoy24RvSi4C2DxX+hWNR96Ak4TVhOJups9n6FQ5C9iiuEIk3H1fjF0oO/61YEZQxakp+5MziUm6fKxbMHzvQ1kSsPEF/CtBOgC4mHY0BLkv9H6DJpV+GB5dJeo5LWsmLEeid+tOze43DyXh70aBgNZdMjw5fyK3XXAbvininjFPjrUedsvf1JYixbfWFTgNC6XHA70cWJkj7hyKCxYdk57qNoklImv86WCdUrHihDAA5DWh5cxbnNPigvRIT+wrYPQPap/DlNrHx0zbYp8fD/8AuajZo2QY+SezbehzHnWIzywl3wvZoGzMgm6hfwoC3Woe4e7DvShi7LLO+6bp2ahDZRI5BieGgBU4LsuNml5tgEw2y4tnrULZY9wcPSM+GK+8LADKWTQX4VG0C6eNHuVBi1hNuSyrCJkRdWkG7QWSNu7Hh6VEjYpa0OgP1Sr3qUNzyX+2qXgMgcmlXoTLw4u8TmVCFrKQeJ+qCYbHko1Lh2B70m9JLzWWXNrCU4pUDTaR7q2E1HsWlxWyncKQ8kouYZESEj+FcGmks9hNFPLO38FDKASNXcHc0j1OXZqXDYc9teX8XG3KBXcwfO9EEbk03kLnKiXsJWFuNvu0cA0IcsZeOFSBXdT1GXjhVlVq0TAM2UMJtR98L1Wrg+QYXqWsMJxqlld2WiIbJTCCysTHapxFiSzgxgzNq25kBaOxoF9axpwFZY+g0zjGazYXckdp1+7dV2Er6/ei9unTEIdqIS8ClEtOVM+PAL60pwPxNq8zX0oQutGD3qPFWsGki9SMFNJZcY+X8NmiCcozxSn6A0oTuW2d9fNQjLMaxxx69aFwJPZD2n+Lhl+0MHnUHQXgsN/bNEJ8iVNkcuDTCb5rovy1WDG9lvfNxKJATqmFBkvwQZoEVzghoxjVmRozvBoAGkkHBg4NSmySVQsvBNQcaawFnQicZy0qPBWnpkUxDOgT0WoU/UPGgmJHH7BvYNciakYyn1Pat+3rz7/zLrQUFbDVluQizBJamyce6tM1n15Pr+Falr3P3KU3VefqiNDI0p1iogkzIL178a3QIo3g48v4lRZbVzz5zTIxzg/RrVabHkm5yq5a6IbxjzOdGz1eeU2Zc6gY9XNzyqYYyNSM6oCzVp0Unohr1ZvkpDZ9l9SirpoG8JUuaHxJKQsh8VJUdIM19DTpwgrtR7B9/SfVUWObk7eirMhp6RFOAi5BPRaCkPVHjWC5GyuY92hks5zKpv8AQH9fT/um1wQ9hVqYWjc/CwYIToJpOKZvOpS+qvf7EQ0dFvBxqPDsDicLB1amM3GUk7NYm1afCJE4OJyqdnL7ALnOaVDM+YSW61LqHECXHE5RRonWd4cOVR0qzbPB/iKHgtW2LWx/hKlo7MV5eM0OQB0odxfFm9KwEWq8TWLBoB8KvwNIO4aweuI8NM10ZE9RqI1weUMmplTsrYJEYiYnCsrom6bUQ3j5ZleAEfWsE4EldjoaH+1EVcHSebFGXhaNiPwtz4uXBNfKQy9Kx+29Z9MulPh8bSsMV0bNJZExxHOoOW3nTB6Vp5f/AAHtXWgG4ODUMIjfKiThIe9DTsg36VYljpSwTW+FCCUJqfSW0cKwz81aw4BrG15RSxB2iz5pOUWZHxWKz18A1clNkPcpMg2GO4+lSZEwsvQFKRi7JJMmrwKLnN+GbJ9Uj1r5VIdZfev7ug+eOkVafiZEPJrZUO9DFyokEXkkjUksZ0+1u1PlRp8B0pUMcl22e1IWhm47KwCeCu1TBLWSohL4dKsruxDxWJfkrtWn3pOD8ErHD7BdihMl3ZPSrST5TVg/C3pifmm9bzg6ft/R2g7NHtV/0fuNhVuOYqi+NK1Rs2HMkoC+ZI9qJAmm3Km1ZyF9SKl5F1fWa+Kw6RRZ2mTwWnezPmnxhm9YUPhZ0I3EhMPEYowoDjVJ+uY8i9KS0upxT71Op7F+G4UMfE+VfJ9D/UOjdAXrjWkRV/73oW0ML7q+9FQAxb4vS+rB6B9KBLjlPyK+FB412qw1Ik5a1Z20PHvpuMGLxRCMDHT64i/RUXUng0JbDH4fTWEg1HcPT+wHBugPmp27cz6awjjP1mndqD6UmqlbEkkzFk9v4BniGAM5LtqHQo3g+rrJqKSegqIFNo9ZTISe6d62rgk/lhZF5krYNOg0Q8us4CfJ+GjR9rVAPlvp/bJEwBLSbYmhePFbnXtWJwLhOHuV2KpKvQuJA9GjZRxg64mlQJwYk82mxhQcXUDgvCjABYix7Xb+OEzyJa+ESP3SmIRHAHlfwxZl02HrW9HnX1/twg929LvkR1j3qSax62pmSznMXgfpALhquPKjCYbRgDwDzWtCHA2hkLPet008v2qfSPqf1U2l2Ov8M8X+Dr5TIe/9ocGhT41WaWwAfOVRf5k+lRJMQPW+n1ClkWyD4nrSKLW+CHtT/wBO4VAGi9alkhYv4bQM5PxKny0R/tQi2veNZ18i6+tcXD0P3UvYp5D9/qFTj10lbQSdqZ++xWuBE6ApgkPTA/DGzL957dDYh2/s4T8GNYstbnXtUG6709K30ep/VGclVRS3Rie9GATmt+WhyT+FIVC9b/JoHkXkinglMFvWl3UeUyEqicSPZPSk3ovIe9Z7dnCgCAgLH4ZAcDeaetWjRv7Ch7FI8/A0P4kWsetqjGq6lr5LMfWhDqQ8NG1SkNYiXrCsfbidhV2iaTdxrB52S7lINtr4toqBV8YooQsIA5VceRrMutOJvns73xRh+G+JZv60pPSDt/Xwq2PR33/mAfIn0rbHxUkNykdioiwAdP5wwtWGTgqD7tBwLnSSD3RoJQZKFvL605SyfIju0Yfhcq2M+U405O7+vJLWzen0ORY+j+6iaQFILGHpW5frvVZBxiuH/AoTliDoh8D+GcGsRz4p0t08v9aCtdi6fTxfJ5p7VtELTqbw1yF+xucA8VD1oNlnSatfFE+n4ZwafCj0fZTk6q/1TMkvtSllx+nZpPlqFMvFVkP0h6/WS2QJaW/iDlM+lfABH7qPUMd1A+V/DOFZsR2H7UYH9QptOZ0pVZWX6j8htPWp7qHUlWV9Qf19cIPdvTjbpV71Jr3qf1U0Y65kdg/DNT5rdKsH9PGTj7PscJQ+OVRuhPLUH6oH7+plyzVpkWVZa+QdQrajdp9aksgG2K7v4d/qIv8ASWaDzVncLXj9jC9cD/q1Hqm9D91C6h4PT6SRYDFppcBg/i5/sVanejE8Vgir5Aen4dO2b6/0fXxyKlgX7O9x7VDrnsFS6B9T+qhGp1P6EBVgMVplgnv/ADtPtKMOXEbJnt+HNRJi6z7xASoGrVoubYVltpYfblG862qY6jv+qizTeWvhRH8y6DQzaQjCw+hLuYeRUZJebQXcKMPw2CkMCOwld2irzhjb7WGfnWFT7FLwN7dpeU4/u8QB3qE7HremAZIOhUAZB0KwAHTOkbRUMVVc36Fgul6zpNS6/l3qT+ItPUWxuRrctmWyKbY7kVZpo7VbjZl5OJXzmvlNfIa2+itR00rkOAUrHktOIvF/o7QPhrYQ+1Ll2izP5/Xumu1OUsg9aQVZhxW8H4m1m0XWxnsvrNX/AB5w9Rs8OpQsRHS8ntRN4wVJ/XSdm+h60LDIq+Y/s/YtzF7iFAF8BHrViiOdTTu/iuD9Gk32d6mtmfhL46qxeZgScGyb1HlsMXtRAovBGRpoTM0mKRR6xZOJ/T5GvUe1bTL2qU/4H2B8wRU2gfW/qji0mLOQdo/GMI2ZGG1G64NFpXpYPdh2vGpNvlodFYNS621dwfeihmHERwmsfA3x8MSjCVgqf6OyBfLXGz7Vus90+xwiPkLXwSY+tEFmHEE/joPeR0e9LJtTF6DYhv5Ogq85EORtqVBiVmY8HOpue4gdQphmOGLhOVIQVI4P3/nWX3rjwDuVFPIpJFJ8HxWX3BGsc4gPrWTfFVhZ8ZKxYcBRCWPBmgXDMooTTCPYosLAORH5CcjlmS9g49Ss8vTlHU4rm9QKxZlzg0uDIXG/zhSpzavJycqiCDGx0c/vDa3ke1TBovLTGMow3MGrJQY9cINSJNz8BJRQlwI52KWt2j946UPG5evrolhup7KVNrxn7rXAivPlMJ4MgFJcViANaPyMUWdfxZeg8SHenijiu3Li+Mc6jAeke9Dlo5eoUZT8+C2c6anBiMD3+5xVHu1uhPp+1W9vOagek/XBUcaj8oLtIBImiUo4M0Tf9bahcwQ3km3Jh2qMgdK/MzomIMmjmYlZL+fB4OdXeTxH/T7OKhuM1zi/FNmQTnH2/PnfGATbjQBKyrHuXAycKGgMI2NRwHCaXNkduZQ9T4G/RoTuVHDEc5rK51DwS31rZE9qkeo7/quEE9/1U8EXHH3n/A4zc5gOpmO5egrRYOdsB4dVNWy7rmOJvUIHePahJREczBoIIPq2S8dQPj63qY9B60ROHRQf8HCYy+RuDcqLeXthbZcsO1QwaMkOiNxqBebJWeD9Tj5Vq2qHas8O5wetCOCIP+Emn8JI/f42ZKlzmOHu5xlypWbHZyuGlHHVHy1+iLsgdUpxasRMybUH/Dm5DAK2Yc996axSCEHW8d6heHqzg0WBnAP7+hxFnIH0aMD/AIhBL0mVcRZei8SGpFb0JAa+iRvV+QbQzHrUANalnvQFYrAzNKlKnkJ0emn/AIqKYyzS9rYnnNZShTIpCJauWtwupc625YosZDI46/8Apv8A/9k=','cinture':'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wgARCAFoAWgDASIAAhEBAxEB/8QAHAABAAEFAQEAAAAAAAAAAAAAAAUBAwQGBwII/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAECAwQF/9oADAMBAAIQAxAAAAHqgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4PaKwa22NqGPFt3c+xpdKczqr0tzjMTvbT8k2dByE1zBMAAAAAAAAAAFjVYtuPjlWr017JDclsHTYXTL60tGersWxa5yJw2YMGuamMbxmEx9qVKw3uWpLFyLGPWZ6W0PIienbFxzMT3f1wubtn1lBTunOEwAAAAOfRO56LpuLl158VH5yMLJkExaukaBA9e1rS/7rbGrctIrW15MhjVMlY9RN1X1FvNCYWL6YjsWcrbOHkr2PFsjeND9Vt3qvKOp9HBcFqAADlxh617jMev3ZvZ9q0qV1CD3hTM0wbG7bLbPjmR3zKtThGX2xNOOZfWExyt1QcpxuvjiUd35E/N+H9OeE/NVz6CjYtxa/0mAi+uU9RMWlEfkRbI9eVdMXddQjrZ/SrUdu05gmoGvcXmsbLpwMOuUnIFdFUnMRO7b/AJunJg5xaoAAAAAAAAAC1dGk6P24fM8h9Cczrpzytqcrrc7t82d8mkwL4sbJ1Y4xMRslzehixGw4k1r6hJC+ct2mL2C+IWzAAAALUEbE0GMOouUXTqTnU2bUtXQAARJLW+a6Cb1zrKkc9/F8w7YTtHHOu9HDuIvi0ndtUOR58dI83pBTSkdJLUhNis29Ofapfmti2fYM3htu1PoC/wDOtEfSlz5l8zH05hfOFEXMf1SYoqKK1PK5VN/snE7aPoGK5Jcprv8AAwt+t8GP2bCWsZkZIRbIr495dIpExfZOM/Q3V5mSLUYuUPnCXkIvDtuDLpAAAAFSlcDJml/V9j1jXn2PJwMvPouPKt/SJxdMJ+kJ4mM+Ev2deXZvePkc3oWLWI0xlxl0W4qUhNeWav2Y2NM7M2npevJETBfIACO4T9D40OCZm46pn02/MZg102FCXotKo+5W+Yx7sW91p6i0NlZy+WPrmya5pz7CrkZdNFVdMSzJLZ4bKxy1By0Tvx7BkxfnLplqxEpMWo7fci/PyvJ6ptl8uRdUn0wAAAAAAsXxAxW5jnEZ1ocTj++D50w/pcfMNfpbAifnqz9CUR8+3er4UzzWnRbUOe+el5cxyevbJw4HvfWhH53pAJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/EAC4QAAEEAQMDAwMEAgMAAAAAAAMAAQIEBQYREhATFBYgMCEzQBUiIzEykCQ1Qf/aAAgBAQABBQL/AEtSk0WnkKg0+aosnz9VlLUA1LUbRXqiC9VRXqqKbVA3UNRhdNnq6jm6TqGWoyQ7ICfkydosXK0homfEi586JnbLomTJJSswdeWvJK67ll1/yXUhEmvHiuwNePBPWT1pLgWCayVlG2mKGaHOY0LKXRoOfIyr5imb8IpICjYzoII+YuFR7UZPK265mImrzdNWZMAaYcG+R/qpAG6lWdcSCULU2UbI3TbSaE5jVbL2wKhkgXPltWQ1YW84SaMSRJEtL+QzxrKI4R+DZbOuLriuK4riuK4suK4suK4qYYyT1E4CweNmcVAkCr6s+MzPx5fUAwJiFM5jxgv5DygCLe/ZcUzLZPKLJzDZeQJeSJeUJeSJeQJMYTppRfpyXJcmXJlyZbsndnThFJNGUVJnWHy3jqMmlH353MSszCGIkexugg5Jvo3saLuneEU9kTJ7ihG8ZmxOWI0dNZCajpa2vShF6UkvSkl6UIp6WsqemshFEwmRgp0LcFwnF2IZk1mSaxFRLB1t7eSsbxlgMmwvfqfKO7gEwo2Tc0EPtltBeRvIOHydpV9KsgYDHiQa4A/LKLSadGrNEwtGaNpipJH0sZkbDZCupzOGTWVEw5dZu0YVJbE0/c74fZnL3gUakXdXJ8YVob+xmQu7ZJR0yyq1QVY/jFHAsLmnKZ1c07dApMWtME3K1qX7iC/hxFzs2PZqaz5eUZtmu/er/Z6MsZQnlS1awqovyyQiSOoy0q4wD5yiofxWcQTu43paKwK1Xch1YF3ICJ25M7SZVKs71isCFYP5ZJxHDLajUISNKEdmV372mp88X01NPhhaLft6HAxF+8MxnjJ8NWFXqfGQkBxNmscJyaoqMn1YvVZF6sdD1VXVfP48qGSBYe61kalVW9URZWbVrISGBmTR63v89Ktthumr/wDqaX2esmaTTqKHkVZA1HfGharUNT0XTagxqhmMfNfqNJRt15JiQfrbsDqVzmJYL76tk1QmJzgLQC5nHiRdS0IIuqoo2pb02sZC5YQoNN4ghFMmbb2Xv70w22D6aohywtH/AA90oQknrDdPUT1JrxSrxirxyrxyLsTXbmyk8ls62fp9Vs62dcJrtzUoSj08SaaomrDZREOPQleE00pgkov1k7RYQi37dYLV6/S0HyK1TcZ/nZTlylW+lfdbut3W7r69bcf4XUH3giliNDsQm/ScGJGtJ4zj/aKaIlj8Vayb47HgoD9mqab1b8JMSHyPaghziSM32H/53ojhF2lHpbI/KBu2/lEXkFUikkyB9pT4xtG4mj0ISImCzksSlEbSPMssNp5o++/UHdrW6tjF2YWRyTO0vj7JQzrDlBH+wobxGAfbH0KJ5SgCTz8cS8cSlXG0FW+0v76TKOCJak6/t2Nxajgblt8biq1BvgsAHYFb0uKSNpzIDRKd0CY5GTWiJrbprcU1kSY4nXOHTbqdtwKu/IPs2dP9E5xMp222QzsIXmqBjmcWKydlVdKuj6WjIoNL1oqpj6lT5yiGVi4fHlRdN4+aLpULomlTMp6avxUsDkmUsZdipgOFdyS7k13SdG+i7pF3SLuTXKS/vrXqnsrGabI84060X2b84ghlT42i6/SMejYigUc9K13XpNPpUi9KnUdKTQ9KjZC01QggYukD/S3/AP/EACcRAAIBAgUDBQEBAAAAAAAAAAECAAMREBITMUEEIVEgIjAyYRRw/9oACAEDAQE/Af8AEwjHiaL+IaTDeZDNNppv4hUj5FRm2mhb7GWpj9g/Fl3nv8yx8zIJkE01mQjYzPUH7NVT9hNKm/1jdMeIQR2PqAvFpIgzNNVm+k0xuZa2AUmZJZRuZdPMzU/Mukss9sIQw0U4gDLzeMgcd46ZfSFFIXbeAF/c2JqKJrngQ1XPMLE+m4gb9moZqjmB1MBhIzZTzGXKbHHp0ubxvdU74E5RcxnLb/NTfKe8RdTvKndb40BZJVpX9y7xanBlR83z06JO8VbSr2JGNH6DBkDbxum8GHp3mk/iabeJkbxCCJYyxljMploKLniDpm5h6YjaJaD8wqNma+PTP2y+sOp7CdUdhEItbA1wptP6UlVwxuIndYajXwqkZhbeFxTHeVKpf0A22i9SeZ/UPEHUJNVDzMwwWkFNxOq+wiAdjgaSk3hVBvKxS/ti1VVe8PUrxHrs20DEfLmMvfeXI2mYy5/yz//EACURAAIBAwMEAwEBAAAAAAAAAAABEQIQEgMhMRMgIjAyQVFwcf/aAAgBAgEBPwH+JyjNGSJMkZIn2NpGf4eR/rPE2/LSSzJkzyY0swa4ZlUuRaqOe91N7IwS5Mvy8mRLPIio8iWbkszqHDE4E57ZdbhHx2V8WYGK7t7YmJiyD6kTm+pVGwtqbRIlHuakbxFzfU5KK42Y0UqPfVXA3JTwr1/Kyqa4Fq/p1KTJGSJXbNs6Tqo6ox2pUK+qvvvxaNIqT5stNtSdJlKhblXJirUcGLqKaMe16SOkdOowZDs62zS4G/q2TJqZRP2OhtnTYtNL3ReF/Lf/xABDEAABAgIECQgIBAUFAAAAAAABAAIDEQQhIjEQEiMyQVFxcpETIDM0YYGhsTBAQlJigtHhkpOiwSRjkKPwFEODsvH/2gAIAQEABj8C/otTcQArVJg/jXSk7GFVQ45+VWaPF7yAq6NLbEXQN/M+y6t+v7Lq36/sug/X9l0Lu5zVXCjj5R9VW97drCqqSwbalk40N2x3rMyZBV0hpPw2vJZKDFftqVmFBh7zp/Rdaa3cYrVIpDvmkujLt4qzDbxVUMcCs2Xcs5oWUiTVbnK48Ve5VP8ABeyVUHDYs6e1W2cFePmCyUSIzddJVR8YfGJrLwA7tYf2KlynJu1RKvUsaI5rG6yZKUBrox4BVObCb8I/cqcWI6K7tOMrDQNqqLzsVcgq3q4nvVTGqr0dYBV0tisuB2r2m7Fak5VzaqpELJxHt3XEIYz+WbqffxUm2IvuO9LjR3ho81KisxB7z7+C5SPELj7zysmJ9pWl3krbuCqb6peq2hWXcVMA7WqT7W29SHAoETBF3YhDph7BE+vozComUie9oCMSkTMQ6SpNtOWl37K1aPoK8Nbm8V0jVneCvPBe1wXtcFneC6QKp7ePoK5FZg7lU+Y1OU23+aDIhJo/bfD+yBaZg6fQGi0I5O5zx7X2U73a1iw7tetTdU3zUhUOdbeArMyqmjvKnCgRSNbIS6GJ3vAVowm7z1ajUfxXWmfgXXB+X911wfl/ddbb+D7qxHgnbMKrkX7rvqq6MTsIKt0aKPlVzgr3d4VYaVW0hVPHfzxGh1H2kIcQ5F36D9OeaDRjXdEI8lL2tJWK3M81jRO4c2bzirFgQy5xuVbOTZ/MOL4L+IpB2MH7roeUOt7prIwYcPdbL0snAEK1R4X4QuhlsJWTfEYshHY7eElPkHHthmaxYoc12p7VabwWdLbhJdcpG51SMCIcpC8RzXPHSOss2oxX1uP+TWKPa8ljnRdzOxclQYRe7WsenxMc+436rFo8JkMdg9XxIrGvadDhNEwcaA74axwU4YbHZ8N/BYr2vhO1OEkaqwsX3U06WitQ4pOYZO3ebyTM2FYG3SpC4IbqbzNLKI2861ydHYGM7PXMWI0ObqImhAgQYYpHwVYimc0KZWLoze5QHG/Fke6rDFim5jS5F7zM5xPacFWcLl2aQpisYBAZU2+IdSbChCTW+uF0Rwa0XklGFQO+L9EXOJrvcdKkLsG0Ju8cNIleZDxTz24Zip/mtLSpOsnwQ5F7YmNW57dJ9JjRHtY3W4yUnUph3LXkrEKM7uAVVC/ufZdUb+P7LqX937LKUeM3dkUMtyZ1PEkHQ3te06WmfPy9IY06pzPBSokEn4oinGe6J2aArdZ1KvCw9ihHWSfHD/yBO3uZJwmFkz3FY0MxIZ1sKtOhxd9v0WVove16rZHbtb911iXyO+iqpcLvMl1yj/mBWaRCOx4VTmnvwujRnSaEYsdxe86T6DHo8R0M9mlH/UPhwYrb8Z0gVapcP5bXkrPKxN1n1WSorjvPkrHJQu0Nn5o8tSIrmnROQ4LOa1V2j285io3zf9jhj/DI+KeO3n2mgr2h3qqJ4KpzV7PFZniujXRldG7gsx/BScXbCqgVcVcVcrirjwWY7gsx3BWmkYL2BVxPBV4xVTG4PdPYsSLWObNxkEIcJs3uu7AocJuaxobhiwT7bS1Phvsuul2+olx0pmDStPNnqOAHBav1KVbcOKf/ABGG7/Dh1u1IRHZOD7xHkFiwG1m9xvPNFIh1Mi1/MsYelucVNqcezAwGZsi5AtuOEMnIaUeTrb8S9ngs7wUnOJGBuzA4x7tCnBh3aQFXfgtX6kD24xVoyQZBaZmoSvKEanibtEPR3890GLcdOorEiirQdDlXZ2qyQdno5wq+1OL73KJswDFZjYza61I334Q9jsV4U42KexZnis08U6Ta5a8DdmCtVKt3cFYs+arKxYQxe3SVjRByLPeeK+CyTcaJ77r/AEJhx2B7DoKnRYph/C6sKyyHE3H/AFRxoFIaBpxTJdIe9eye5VsHFVtcr3DuWeFnt4qrmRNmBstAkedWQFn8FYbxwNBa5VMHFSgsmfhbNdDEA/mWV/FUj5YY/comFSeTZoBZjfustGixNllfw8BjDrvPH08osNjx8QmrVEhDdGL5Ky2JD3X/AFWRpMRu8A5ZKlQ3bzZKrkX7rl1X9Tfqq6HH7mFZSFFh7zSFnu4rpHcVnu44Kr10juK6R3FZ7uKzncVWThyEGJE3WoPp8msH+2K5qbaPBB1hgV3r2UhsfvCa6nR/ywuqQuCxDRYTe1okVk48YbZFdd/tfdVUph2sXWYXBWqYBsh/dZSlPdutkrQixd5/0WTosLaWzP8ARb//xAAqEAABAgQEBgMBAQEAAAAAAAABABEhMUFRYXGBoRCRscHR8CAw4fFAkP/aAAgBAQABPyH/AItYkAJZS6aCeSlGdvZQjIQHUqqXpTUsMmOyIvMX1EvqNZ8xU31V3XdkdE98ngFMSz9a228/6SwIEySzIi1rP7iBEQyD1VHmMg1HBA/UV0cEHJwjzkq6IRAIJuZGVAOiOqBncr4RUNslB0K45DgI0gagr9JKE6jIbk/hQk5Aryh9iqUnIUbGXOGxTG4Kgd00y6M0NEUodckCCHER/hLxxMIE7XcHXPhOS1GczjcYKRD6lRhoCimuLlVFoEB1CdiDoQkAyCc3+oRvgOqgzlsAgRKcDEkUkD5FV24xHNE4PBRTRA5QTkUZAHrhN1UdjUnaX+2ybnnkEynbDc+mRNha4bK2iCIbb5ImO6Qdl4jzUgnuYlOTX5usVhLIT7hZ1nTblMuVmJnAbcqCSTCG4gU9FvDyWpiHR9lmhBzgfWTFEg8TErg0RxJ/TbmgQQ4+oqxkn1unuBmOW7ZJ1a2Qpkkg5eCjvaKgFPkDNELyDQJ1lIJmKmWhFY85ErHBniJxw1rui4U3mhGE0zFMsVmLM4GMgDGDGKpxnZQw9pfdOIOEywI1KJALIE4AuCPouvw7CgaQE6RkjvK1df4RBywVQAIIBQfGgLlIOpCyw3VHaH1EC3bBHNk+g16YdbjQegKoxk/shVFkXnj90f0aD7X8i9mOgL0SyxUdG4mqteSA9wQXjEf5peDJOZ2cXEfhEVQIYrAghfFFI5MH5eb5xST1u6kE7+SdEsCtsCPq/wAWTMLVOieI4GcHJ0CjJzegIoFjjme5MxJBqNklstfT9uBCCFMmoPHSXdTFNCpOuN5L1nGgimQBbHdfslcC0PEMjtYi7oL+G3PsiulKJ0z8cBcYq6IocTSxMSboyGjMgyIYFBj8HHLsEyVi44jzAZlOXN1hqlHsVjmZnX/OXTBCAdCveTs3Zk7YpWZm7LHgn2FPiEB2kU+3KbNQ8N6CPKixShshEfAjt1hMgCljBP0DJkKjg5vxByXLARJsFVG4p2CBhdSrO/8AsLSNNkKntk489qmyvIRxNkLkgQunWSzItLOdE6cQpuWi7B0+42SK8Bq89gjkcEmgRK5XhhnlkTVvMB/sDs92YDVQicCDoRYRzxBKuZQQhYeAs+yVlPdL9+JnRt3FZyAceY9TMpTI0PlCDJq+oJ33iIEZ32GYQmAHNOoOboFdHMdV+kr+nQVORBG+O6EwiRavdJSgxCAdR8zZAtOE6Ip8OcocgoddKTSkosWEl+qRs4hmCG6fj+c4y/ea9jD4M+WihFyz6zRnV6PD6hQsL60KQM3sCER5E9kLm9ipIJ7JoUfXxW5GO62nA4jED8zZR3JnoZYfRtxlmEjqjJDQQYwOVNpnPcUy4/5EEYJfoACmtrk6ghtSDhdEEyNZVSAfTJCCwdsGQJB8JfAndMM8Q5GiQ+VHlBO3yciq57zRUuGT5INbVah8wjiFwvIsZsj+Ov65CWFqVjhmGGiBg5AyX8Apj+Ca5yX8BP8AnJ7yuDgIIAydMDbVCvrCV+Infmy3DEP1TlmpZPbDHk5IIBZM4YYKYBBcGRTkDxL2innQYKXipU6NA3ERYwfbOGQCGATKbDLr/gmCJXklOFeYfmU65WImImIU4VKc34CgCQpCsqh04M4cToQW0hk8jxMdE3K4EWwBSeD8Dke9lgUUN3Fq+Gzz8RFOZaV85oYqzFj9oZIFkzRUdViDMLCI+i7Ez4wIWSgihPK4iCky5iaboEsgTtjBEsmKS25AEQmyYPDaeDCCTnpggcKKLR3wUWFiOfB8HgrKqQUrbUqdE7WrAue38TCc6aHfkgAAwl8gHWwnQIRpEMn95JoeT5Oa3gTpjY/UNFgMSOaHz9J35o2QMk6RMGQF2rgjDNEXYcZXoPdOnHYJ8l7jX9yjWRhs5GLcNm4EAGAEWIdAGQSspZE5hUAFt5/hVJ0zMos9JzKECzTiuSONwnGLx9MyBAXRs4fd6a2QQdi9ZoTiC/eXVe1dFVbIgqFZEFEdQvcNwgSRdKEZgcinWKY2TFNDhDPiwW4sbJjYrAKIb4ICnIHI6eAUuGfxUkS3LTZhzR8smXJnNBY426DFQBEBWa9LIuqDFHNiZSYyB3UVwB3UfvwekHqXsRMi3y7yXqPlmW/idLofyxR1AUx5DIa3a6cIIBT51f2agEQyMSgiJORFwggCXN8NO+ev7REmYaphZQFVIsdnIQNZBEYqC7MRIINEcgBGywnL/cOYRg9SnugHtwGyAWYtQvaW5BGwkD74Duv6lFdSE2bnzXK4/ImJqRLcRj/xb//aAAwDAQACAAMAAAAQ888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888+z879918888888888899T5NnThAjULn9w888888yAPCwDAIN2+GWNcBNGF8884ZBAHHLE+8MMKx1UsFSs088KaDRv888888888888sAQc8of7v5888884w448884p3fB8s09N5ykKYi1z981CHB+16R8s89999943KMN958WQ83Ni8887OSxz5odXT8TCJRQzH88888888MM8cKjMnhu0v888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888//EACcRAQACAQMDBAMAAwAAAAAAAAEAETEQIUFRYZEgMHGhcIHRseHw/9oACAEDAQE/EPwngFBI4AfsnxeSDY/yRLlMsPuYHcGLImEWoun+4cNHxN2frLMvzF20uK8RbEM/IZ8Y9bKVqD3Vx2in1ItpcW/n+R2IohdbbAYGmAg+XSFPDzDoPMFwnmCbkZ2Rid1T8zbijvKgY73x6AVomb3Ain06cXNvy9o8UTKRkH0CHEB4fP8AqCYRAOR+p0FfcwjEMMZwfo9Yz8Wu/wDiK04aHAf952RHSuZYlk2dajvEUgLhZeowe8CtEUuANEXd0f8AvOqHSx+D/aAxvEo7rxEOUyBNi6nYl2CdiKGnRiMgm4K+2IjtVdSMS4UC2Eo1Buyet2zfQKwu4aXXEOsobUVCywRNuOdCSt2N+k2bB6Ed5QZRuC5hGWoYED4SG+JbBn0IoHppYBMUDxGCQgt4XC5s2wm4GfcFMTusVkhmIrzHqaqufxT/AP/EACIRAQACAgICAgMBAAAAAAAAAAEAESExEEFRYSAwcHGR8P/aAAgBAgEBPxD8JpbZ7YNqV/xwe2AdP2bRmetzPLiJCvZmOos6CDNT3QknRHSxK13TVERsggs+S1E4mQ7YrWEVd8II+JBtEpdT0xBsjpYSDDuLizJTHeGH+3xegJYOUX1A9twPRADRL5zwR8RDLdMQ3EO4Dg2ShZzUp3DTXfAlRB0+6pjcOhMUGnPKuQ8KdpklL7tbgDERWzNOcFxuU8CCdwfue2DdwR1LJcslPMw6iHcR1AOyoVLuBHMBWiUA80tPmgtIdssKOQCL1QKUKgf7wW96gnGoH7fBLwxGmovpiWojsiXXAFM2Rs8AiiGgsNWWiGIPtnuog7+2niAGog7lGiAHNB+Kf//EACsQAQACAAQFBAIDAQEBAAAAAAEAESExQVFhcZGhsRCBwfAg8TBA0eGQUP/aAAgBAQABPxD/AMNPae3/AMSyOwrMwOsuLU0OiG4fje0C5aPrUy2nGfkEqUN4h3zXTkscDMLmIMiPpuJgdj7tmUrO4+QQT7O3InXEHwSI0rs32WWb/wBgW12MBurOflM7Ip2/T3ie0JjuuSR8y3ukvK5z6KIKXHSq81FhguAWewE+gAbsO9ryk8BnxUdUClHQekNTwkB8Mww94dsT9IcSDq8vmGFt5Wl3Ji/FkTqmM0OAr8MJo5sIiCnoS6okGuHVzoDK9ulvmAlgEZX/AJHeIrpF11YusPqIWJkn9HLNkw92V43LxFfSAeV0ocbJR1uCckR7SpoULX8BMvso+MCN2O5vjobM8DDqrM349vBUAwHFK6sqa5CEVzTzf4RRsYPROxRYo3dA6NkKLwIXEmsF1XNLJTG4E75KsXAewiOjsVhgADuklOKgAT9Ry4c3MgCqC8Lz6BxP5TC1gUrbHacCJgZdTnZCKNfQ5Yy5IvrjYT2RdkI6p4AgAPsflSpR7PzRzCfyILk0u/2kP2IaodWC1PsQGr6Q1fSvjQC228FimQnJjohBK3Iiqb94VcoNrodnREDyZfHNykvYHeh9R5mHsGx9oBHJhjNg0UTHeuLwOQgSQRLEb/irdt55PlMh9ilpYUrQ0gUGUfnTN4EXUgloJ7CULG3kXywwIACgCg5B+NhMjQbuBAzR4EA4K8rZSZg4lE7CpnlofAYhlziiWZ5KcTpf7N/318MGz5qGTDyeQI9Sew7CkcI5OdxyQ9GcKT9CCavRhwvsk4OGIOiMxlVui6XMHV3cL0KJFIkSlqE1bOzCLOjLLcoBt40gWImY/wAD4lXineQYyBK2A10Bqy9XEMvgGpACxccn/ImXRbycX8cGKeehM5o1C+hbEsQ3EdVLjnivoBHTbLuLSiRs75MItOdmdz+UzzcXmd72HO17s9EvODG/uHgQR3IRBW5v5kgXEw8a7hwqlitDeHVGYR1BwQs3UQ/DMDA7JfeiD18SA6ln4DkI5NTOkEvCjWdA4C3HJlZ/H/Mk0w/JPLazmuFWKEUI/AdAlsg2Lko1eGxAxzgUMDiPBFtVbX1zQC1yCIKwWJvkC1mBYSR+xcrKty5ga2bu2XaNR+m17QHW608wnZL3Fc8a6D+SjaPkrMSd4K37q3dalXHi7Zggt7jsfBLTgxHtC1dsBdRhJngQPQMXAN4/GxgC1oeeJKaHMckbHknowLBUtygI6IYKKurt4iwxBm8nmGT+JvRSx9AMYaWB6hzltVj04aszA/LDQNRskYq8CKrb6oFB1dQBmqx+12UdboMKN1xVnI2LMF0iQDPdOKf6/cMdJAjDAJFFYnHxKFipbZnxeG8WZorFHVkSCxzKMpnFlY2OV6EsqhKmoqrxLiQ7VVp084QCYj+C1tzhYXf8vaZHk5RAE0e6YkPgFj6ggDK2jMVYltowYQGPTirFaqbVxf7mRttuaEqGlDU5Drg2GUVQKZTzjivNlCiNlOo4MNrj43gCzX3huynV+qDC4zD07Rjw4oLKt4q+iOBiIyrr8iFrlWQiag5JBD5YeE0eD6Ju4OJGaEFIJrHdXVf7lEWAj7qwJbf+BPez5sPLK8qNoXFHNZXM9AZu7xXVmFAFBkS2OfuZZ8R2P+L1dgCgPAL2uUf85ivn1sENddDY8ZikalAj4EJNIBrZui3FEDmnl9Q0P5MhISHmkJyUaPqCII1orHuy1ojsx3Ze5ATX+usn39gcYLn3h1fV74eYr5SSI/ngqb7IL2w/IkL893h0I7wX5WDBKUGlcF8xhIAAASgDIwyPUz/iS/zP3s58PVZOvhnrH2H4OF3Runccx4kaTel6ewiS4UKg0VpODBnk4Ic1OYf0qs94KOMtO5C8XYkfaB8JEZnlMv8AaTSO4JPn1fB5VcdIbrG2iq3rYDQaCggAUFH5n8PbvhGj2HCF7eWaNXGJ9sx2Q6c9R5TR9NmknJcRdx2Iz4U9uTOIYyC98mQx4d4YA9kFwQyID2qbgbuL+DG/iO5ICJmGl1f1q23tJb2YLq/aFHx+QixDuNSxV3NE6imYl7xHQMeryBeRgMo5v4gMjkA8xDV5P8xDP27QGfsliGcxe19wY4wwm8to2yaYXaFBGlnEInmcv3ufucNDr4ZZ+SQyCcpY+Ic0RqmIhVoXUsBWJAchbVroQKhg1R4hNm5X91maOAkdiGiBMrHraa1dK2dIcjXIsTxlyC5a03LXcQQmEINiaIx8daFjueplgKqgqF0DmsRMFpBqg4GrErVDc0Kzxa9boX1NXb2uI8AXaVlbJX9AnGULt5ERZVW3jZCSZb1jP27P3TP3TBMB3YWOaHmsu1RVKcTZjXQV0cbIL5DHcbVuofRVplgl1ut0S+4gTFNCyIlnpX3i3XjoMQqsA5lyw4MC06NszhCKzBMuaN1kW9kidZRdEfTA/HNDrFBfTxuVzhg19Yf5AuiU01pAEuFFNMCMQvN5zvMjwitbtKihLbgYCWqrgiaI5nrVGi5UPwEYvExYtcgnjuHys1T9VgR1NioRRsmYxr92ivTGfpAWh3AFJGq6YRtAObKAIQB7gLfSiRRZOLx2N1lGhaQwAG1lrJCzNyRClBJHGgBaKtBGObx4cbo7UJAAAAKA0PyVVReUXVEuW21Cn1OJ1gEbTC24CAWNuPgxPMOY/wAJWpYiJuODMOJBDAcTIxBAItSKVVG6xlcZ1QmZ7yoBaBZEq2CglhxgjYmij1rT8CUPcShRiUhaUKgjuDkPljpBylYCy6AJEINg7hMTcL0xLFdIdEZUKAMAUByMCWIZ/wA5rAhqVdaJ8QUiRVrbxNXs1pkcuRMWJ6D0FmEiKKcEOjgfw6WnlXomybkUyOVX4GAHWNHP/AZOWdx7CYsQdGkZ2Bgs3nU7ohvqRuMX9oeUz/mR8LMiLk84R+uGEKm+RD4Z+uYlmpwGJxQ9EZgkdWBEzRhETM9BMlLv8mfqmHKOZvnEj6J7NKXslsAsq6QoGwTU4UCYqUsymbQ4u+AmITZdPaYCbhiiT3iHcf1+yVe/BSNANyCAnS59sXeIA6JjYmlj3fz8PU96Bg9CfTigOucz0eaEr7H6psyeAwVon3QipNd+8hl0nGvkwmiByIO0M8JBuZAigiUiMvIJYQCZZIqfJMimfXEc4/OCuac4d2JsC0RcBBzajGRi52gQWcg0V7YbkTsAwGGF21Xen97glADsYBX2plH6pGeaItuWMav68yhc2bmGfuYmzhrQ+4++YjmEbeWYWUrdB2SXnHADr90AAAoP/Fr/2Q==','cintura':'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wgARCAFoAWgDASIAAhEBAxEB/8QAHAABAAEFAQEAAAAAAAAAAAAAAAUBAwQGBwII/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAECAwQF/9oADAMBAAIQAxAAAAHqgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4PaKwa22NqGPFt3c+xpdKczqr0tzjMTvbT8k2dByE1zBMAAAAAAAAAAFjVYtuPjlWr017JDclsHTYXTL60tGersWxa5yJw2YMGuamMbxmEx9qVKw3uWpLFyLGPWZ6W0PIienbFxzMT3f1wubtn1lBTunOEwAAAAOfRO56LpuLl158VH5yMLJkExaukaBA9e1rS/7rbGrctIrW15MhjVMlY9RN1X1FvNCYWL6YjsWcrbOHkr2PFsjeND9Vt3qvKOp9HBcFqAADlxh617jMev3ZvZ9q0qV1CD3hTM0wbG7bLbPjmR3zKtThGX2xNOOZfWExyt1QcpxuvjiUd35E/N+H9OeE/NVz6CjYtxa/0mAi+uU9RMWlEfkRbI9eVdMXddQjrZ/SrUdu05gmoGvcXmsbLpwMOuUnIFdFUnMRO7b/AJunJg5xaoAAAAAAAAAC1dGk6P24fM8h9Cczrpzytqcrrc7t82d8mkwL4sbJ1Y4xMRslzehixGw4k1r6hJC+ct2mL2C+IWzAAAALUEbE0GMOouUXTqTnU2bUtXQAARJLW+a6Cb1zrKkc9/F8w7YTtHHOu9HDuIvi0ndtUOR58dI83pBTSkdJLUhNis29Ofapfmti2fYM3htu1PoC/wDOtEfSlz5l8zH05hfOFEXMf1SYoqKK1PK5VN/snE7aPoGK5Jcprv8AAwt+t8GP2bCWsZkZIRbIr495dIpExfZOM/Q3V5mSLUYuUPnCXkIvDtuDLpAAAAFSlcDJml/V9j1jXn2PJwMvPouPKt/SJxdMJ+kJ4mM+Ev2deXZvePkc3oWLWI0xlxl0W4qUhNeWav2Y2NM7M2npevJETBfIACO4T9D40OCZm46pn02/MZg102FCXotKo+5W+Yx7sW91p6i0NlZy+WPrmya5pz7CrkZdNFVdMSzJLZ4bKxy1By0Tvx7BkxfnLplqxEpMWo7fci/PyvJ6ptl8uRdUn0wAAAAAAsXxAxW5jnEZ1ocTj++D50w/pcfMNfpbAifnqz9CUR8+3er4UzzWnRbUOe+el5cxyevbJw4HvfWhH53pAJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/EAC4QAAEEAQMDAwMEAgMAAAAAAAMAAQIEBQYREhATFBYgMCEzQBUiIzEykCQ1Qf/aAAgBAQABBQL/AEtSk0WnkKg0+aosnz9VlLUA1LUbRXqiC9VRXqqKbVA3UNRhdNnq6jm6TqGWoyQ7ICfkydosXK0homfEi586JnbLomTJJSswdeWvJK67ll1/yXUhEmvHiuwNePBPWT1pLgWCayVlG2mKGaHOY0LKXRoOfIyr5imb8IpICjYzoII+YuFR7UZPK265mImrzdNWZMAaYcG+R/qpAG6lWdcSCULU2UbI3TbSaE5jVbL2wKhkgXPltWQ1YW84SaMSRJEtL+QzxrKI4R+DZbOuLriuK4riuK4suK4suK4qYYyT1E4CweNmcVAkCr6s+MzPx5fUAwJiFM5jxgv5DygCLe/ZcUzLZPKLJzDZeQJeSJeUJeSJeQJMYTppRfpyXJcmXJlyZbsndnThFJNGUVJnWHy3jqMmlH353MSszCGIkexugg5Jvo3saLuneEU9kTJ7ihG8ZmxOWI0dNZCajpa2vShF6UkvSkl6UIp6WsqemshFEwmRgp0LcFwnF2IZk1mSaxFRLB1t7eSsbxlgMmwvfqfKO7gEwo2Tc0EPtltBeRvIOHydpV9KsgYDHiQa4A/LKLSadGrNEwtGaNpipJH0sZkbDZCupzOGTWVEw5dZu0YVJbE0/c74fZnL3gUakXdXJ8YVob+xmQu7ZJR0yyq1QVY/jFHAsLmnKZ1c07dApMWtME3K1qX7iC/hxFzs2PZqaz5eUZtmu/er/Z6MsZQnlS1awqovyyQiSOoy0q4wD5yiofxWcQTu43paKwK1Xch1YF3ICJ25M7SZVKs71isCFYP5ZJxHDLajUISNKEdmV372mp88X01NPhhaLft6HAxF+8MxnjJ8NWFXqfGQkBxNmscJyaoqMn1YvVZF6sdD1VXVfP48qGSBYe61kalVW9URZWbVrISGBmTR63v89Ktthumr/wDqaX2esmaTTqKHkVZA1HfGharUNT0XTagxqhmMfNfqNJRt15JiQfrbsDqVzmJYL76tk1QmJzgLQC5nHiRdS0IIuqoo2pb02sZC5YQoNN4ghFMmbb2Xv70w22D6aohywtH/AA90oQknrDdPUT1JrxSrxirxyrxyLsTXbmyk8ls62fp9Vs62dcJrtzUoSj08SaaomrDZREOPQleE00pgkov1k7RYQi37dYLV6/S0HyK1TcZ/nZTlylW+lfdbut3W7r69bcf4XUH3giliNDsQm/ScGJGtJ4zj/aKaIlj8Vayb47HgoD9mqab1b8JMSHyPaghziSM32H/53ojhF2lHpbI/KBu2/lEXkFUikkyB9pT4xtG4mj0ISImCzksSlEbSPMssNp5o++/UHdrW6tjF2YWRyTO0vj7JQzrDlBH+wobxGAfbH0KJ5SgCTz8cS8cSlXG0FW+0v76TKOCJak6/t2Nxajgblt8biq1BvgsAHYFb0uKSNpzIDRKd0CY5GTWiJrbprcU1kSY4nXOHTbqdtwKu/IPs2dP9E5xMp222QzsIXmqBjmcWKydlVdKuj6WjIoNL1oqpj6lT5yiGVi4fHlRdN4+aLpULomlTMp6avxUsDkmUsZdipgOFdyS7k13SdG+i7pF3SLuTXKS/vrXqnsrGabI84060X2b84ghlT42i6/SMejYigUc9K13XpNPpUi9KnUdKTQ9KjZC01QggYukD/S3/AP/EACcRAAIBAgUDBQEBAAAAAAAAAAECAAMREBITMUEEIVEgIjAyYRRw/9oACAEDAQE/Af8AEwjHiaL+IaTDeZDNNppv4hUj5FRm2mhb7GWpj9g/Fl3nv8yx8zIJkE01mQjYzPUH7NVT9hNKm/1jdMeIQR2PqAvFpIgzNNVm+k0xuZa2AUmZJZRuZdPMzU/Mukss9sIQw0U4gDLzeMgcd46ZfSFFIXbeAF/c2JqKJrngQ1XPMLE+m4gb9moZqjmB1MBhIzZTzGXKbHHp0ubxvdU74E5RcxnLb/NTfKe8RdTvKndb40BZJVpX9y7xanBlR83z06JO8VbSr2JGNH6DBkDbxum8GHp3mk/iabeJkbxCCJYyxljMploKLniDpm5h6YjaJaD8wqNma+PTP2y+sOp7CdUdhEItbA1wptP6UlVwxuIndYajXwqkZhbeFxTHeVKpf0A22i9SeZ/UPEHUJNVDzMwwWkFNxOq+wiAdjgaSk3hVBvKxS/ti1VVe8PUrxHrs20DEfLmMvfeXI2mYy5/yz//EACURAAIBAwMEAwEBAAAAAAAAAAABEQIQEgMhMRMgIjAyQVFwcf/aAAgBAgEBPwH+JyjNGSJMkZIn2NpGf4eR/rPE2/LSSzJkzyY0swa4ZlUuRaqOe91N7IwS5Mvy8mRLPIio8iWbkszqHDE4E57ZdbhHx2V8WYGK7t7YmJiyD6kTm+pVGwtqbRIlHuakbxFzfU5KK42Y0UqPfVXA3JTwr1/Kyqa4Fq/p1KTJGSJXbNs6Tqo6ox2pUK+qvvvxaNIqT5stNtSdJlKhblXJirUcGLqKaMe16SOkdOowZDs62zS4G/q2TJqZRP2OhtnTYtNL3ReF/Lf/xABDEAABAgIECQgIBAUFAAAAAAABAAIDEQQhIjEQEiMyQVFxcpETIDM0YYGhsTBAQlJigtHhkpOiwSRjkKPwFEODsvH/2gAIAQEABj8C/otTcQArVJg/jXSk7GFVQ45+VWaPF7yAq6NLbEXQN/M+y6t+v7Lq36/sug/X9l0Lu5zVXCjj5R9VW97drCqqSwbalk40N2x3rMyZBV0hpPw2vJZKDFftqVmFBh7zp/Rdaa3cYrVIpDvmkujLt4qzDbxVUMcCs2Xcs5oWUiTVbnK48Ve5VP8ABeyVUHDYs6e1W2cFePmCyUSIzddJVR8YfGJrLwA7tYf2KlynJu1RKvUsaI5rG6yZKUBrox4BVObCb8I/cqcWI6K7tOMrDQNqqLzsVcgq3q4nvVTGqr0dYBV0tisuB2r2m7Fak5VzaqpELJxHt3XEIYz+WbqffxUm2IvuO9LjR3ho81KisxB7z7+C5SPELj7zysmJ9pWl3krbuCqb6peq2hWXcVMA7WqT7W29SHAoETBF3YhDph7BE+vozComUie9oCMSkTMQ6SpNtOWl37K1aPoK8Nbm8V0jVneCvPBe1wXtcFneC6QKp7ePoK5FZg7lU+Y1OU23+aDIhJo/bfD+yBaZg6fQGi0I5O5zx7X2U73a1iw7tetTdU3zUhUOdbeArMyqmjvKnCgRSNbIS6GJ3vAVowm7z1ajUfxXWmfgXXB+X911wfl/ddbb+D7qxHgnbMKrkX7rvqq6MTsIKt0aKPlVzgr3d4VYaVW0hVPHfzxGh1H2kIcQ5F36D9OeaDRjXdEI8lL2tJWK3M81jRO4c2bzirFgQy5xuVbOTZ/MOL4L+IpB2MH7roeUOt7prIwYcPdbL0snAEK1R4X4QuhlsJWTfEYshHY7eElPkHHthmaxYoc12p7VabwWdLbhJdcpG51SMCIcpC8RzXPHSOss2oxX1uP+TWKPa8ljnRdzOxclQYRe7WsenxMc+436rFo8JkMdg9XxIrGvadDhNEwcaA74axwU4YbHZ8N/BYr2vhO1OEkaqwsX3U06WitQ4pOYZO3ebyTM2FYG3SpC4IbqbzNLKI2861ydHYGM7PXMWI0ObqImhAgQYYpHwVYimc0KZWLoze5QHG/Fke6rDFim5jS5F7zM5xPacFWcLl2aQpisYBAZU2+IdSbChCTW+uF0Rwa0XklGFQO+L9EXOJrvcdKkLsG0Ju8cNIleZDxTz24Zip/mtLSpOsnwQ5F7YmNW57dJ9JjRHtY3W4yUnUph3LXkrEKM7uAVVC/ufZdUb+P7LqX937LKUeM3dkUMtyZ1PEkHQ3te06WmfPy9IY06pzPBSokEn4oinGe6J2aArdZ1KvCw9ihHWSfHD/yBO3uZJwmFkz3FY0MxIZ1sKtOhxd9v0WVove16rZHbtb911iXyO+iqpcLvMl1yj/mBWaRCOx4VTmnvwujRnSaEYsdxe86T6DHo8R0M9mlH/UPhwYrb8Z0gVapcP5bXkrPKxN1n1WSorjvPkrHJQu0Nn5o8tSIrmnROQ4LOa1V2j285io3zf9jhj/DI+KeO3n2mgr2h3qqJ4KpzV7PFZniujXRldG7gsx/BScXbCqgVcVcVcrirjwWY7gsx3BWmkYL2BVxPBV4xVTG4PdPYsSLWObNxkEIcJs3uu7AocJuaxobhiwT7bS1Phvsuul2+olx0pmDStPNnqOAHBav1KVbcOKf/ABGG7/Dh1u1IRHZOD7xHkFiwG1m9xvPNFIh1Mi1/MsYelucVNqcezAwGZsi5AtuOEMnIaUeTrb8S9ngs7wUnOJGBuzA4x7tCnBh3aQFXfgtX6kD24xVoyQZBaZmoSvKEanibtEPR3890GLcdOorEiirQdDlXZ2qyQdno5wq+1OL73KJswDFZjYza61I334Q9jsV4U42KexZnis08U6Ta5a8DdmCtVKt3cFYs+arKxYQxe3SVjRByLPeeK+CyTcaJ77r/AEJhx2B7DoKnRYph/C6sKyyHE3H/AFRxoFIaBpxTJdIe9eye5VsHFVtcr3DuWeFnt4qrmRNmBstAkedWQFn8FYbxwNBa5VMHFSgsmfhbNdDEA/mWV/FUj5YY/comFSeTZoBZjfustGixNllfw8BjDrvPH08osNjx8QmrVEhDdGL5Ky2JD3X/AFWRpMRu8A5ZKlQ3bzZKrkX7rl1X9Tfqq6HH7mFZSFFh7zSFnu4rpHcVnu44Kr10juK6R3FZ7uKzncVWThyEGJE3WoPp8msH+2K5qbaPBB1hgV3r2UhsfvCa6nR/ywuqQuCxDRYTe1okVk48YbZFdd/tfdVUph2sXWYXBWqYBsh/dZSlPdutkrQixd5/0WTosLaWzP8ARb//xAAqEAABAgQEBgMBAQEAAAAAAAABABEhMUFRYXGBoRCRscHR8CAw4fFAkP/aAAgBAQABPyH/AItYkAJZS6aCeSlGdvZQjIQHUqqXpTUsMmOyIvMX1EvqNZ8xU31V3XdkdE98ngFMSz9a228/6SwIEySzIi1rP7iBEQyD1VHmMg1HBA/UV0cEHJwjzkq6IRAIJuZGVAOiOqBncr4RUNslB0K45DgI0gagr9JKE6jIbk/hQk5Aryh9iqUnIUbGXOGxTG4Kgd00y6M0NEUodckCCHER/hLxxMIE7XcHXPhOS1GczjcYKRD6lRhoCimuLlVFoEB1CdiDoQkAyCc3+oRvgOqgzlsAgRKcDEkUkD5FV24xHNE4PBRTRA5QTkUZAHrhN1UdjUnaX+2ybnnkEynbDc+mRNha4bK2iCIbb5ImO6Qdl4jzUgnuYlOTX5usVhLIT7hZ1nTblMuVmJnAbcqCSTCG4gU9FvDyWpiHR9lmhBzgfWTFEg8TErg0RxJ/TbmgQQ4+oqxkn1unuBmOW7ZJ1a2Qpkkg5eCjvaKgFPkDNELyDQJ1lIJmKmWhFY85ErHBniJxw1rui4U3mhGE0zFMsVmLM4GMgDGDGKpxnZQw9pfdOIOEywI1KJALIE4AuCPouvw7CgaQE6RkjvK1df4RBywVQAIIBQfGgLlIOpCyw3VHaH1EC3bBHNk+g16YdbjQegKoxk/shVFkXnj90f0aD7X8i9mOgL0SyxUdG4mqteSA9wQXjEf5peDJOZ2cXEfhEVQIYrAghfFFI5MH5eb5xST1u6kE7+SdEsCtsCPq/wAWTMLVOieI4GcHJ0CjJzegIoFjjme5MxJBqNklstfT9uBCCFMmoPHSXdTFNCpOuN5L1nGgimQBbHdfslcC0PEMjtYi7oL+G3PsiulKJ0z8cBcYq6IocTSxMSboyGjMgyIYFBj8HHLsEyVi44jzAZlOXN1hqlHsVjmZnX/OXTBCAdCveTs3Zk7YpWZm7LHgn2FPiEB2kU+3KbNQ8N6CPKixShshEfAjt1hMgCljBP0DJkKjg5vxByXLARJsFVG4p2CBhdSrO/8AsLSNNkKntk489qmyvIRxNkLkgQunWSzItLOdE6cQpuWi7B0+42SK8Bq89gjkcEmgRK5XhhnlkTVvMB/sDs92YDVQicCDoRYRzxBKuZQQhYeAs+yVlPdL9+JnRt3FZyAceY9TMpTI0PlCDJq+oJ33iIEZ32GYQmAHNOoOboFdHMdV+kr+nQVORBG+O6EwiRavdJSgxCAdR8zZAtOE6Ip8OcocgoddKTSkosWEl+qRs4hmCG6fj+c4y/ea9jD4M+WihFyz6zRnV6PD6hQsL60KQM3sCER5E9kLm9ipIJ7JoUfXxW5GO62nA4jED8zZR3JnoZYfRtxlmEjqjJDQQYwOVNpnPcUy4/5EEYJfoACmtrk6ghtSDhdEEyNZVSAfTJCCwdsGQJB8JfAndMM8Q5GiQ+VHlBO3yciq57zRUuGT5INbVah8wjiFwvIsZsj+Ov65CWFqVjhmGGiBg5AyX8Apj+Ca5yX8BP8AnJ7yuDgIIAydMDbVCvrCV+Infmy3DEP1TlmpZPbDHk5IIBZM4YYKYBBcGRTkDxL2innQYKXipU6NA3ERYwfbOGQCGATKbDLr/gmCJXklOFeYfmU65WImImIU4VKc34CgCQpCsqh04M4cToQW0hk8jxMdE3K4EWwBSeD8Dke9lgUUN3Fq+Gzz8RFOZaV85oYqzFj9oZIFkzRUdViDMLCI+i7Ez4wIWSgihPK4iCky5iaboEsgTtjBEsmKS25AEQmyYPDaeDCCTnpggcKKLR3wUWFiOfB8HgrKqQUrbUqdE7WrAue38TCc6aHfkgAAwl8gHWwnQIRpEMn95JoeT5Oa3gTpjY/UNFgMSOaHz9J35o2QMk6RMGQF2rgjDNEXYcZXoPdOnHYJ8l7jX9yjWRhs5GLcNm4EAGAEWIdAGQSspZE5hUAFt5/hVJ0zMos9JzKECzTiuSONwnGLx9MyBAXRs4fd6a2QQdi9ZoTiC/eXVe1dFVbIgqFZEFEdQvcNwgSRdKEZgcinWKY2TFNDhDPiwW4sbJjYrAKIb4ICnIHI6eAUuGfxUkS3LTZhzR8smXJnNBY426DFQBEBWa9LIuqDFHNiZSYyB3UVwB3UfvwekHqXsRMi3y7yXqPlmW/idLofyxR1AUx5DIa3a6cIIBT51f2agEQyMSgiJORFwggCXN8NO+ev7REmYaphZQFVIsdnIQNZBEYqC7MRIINEcgBGywnL/cOYRg9SnugHtwGyAWYtQvaW5BGwkD74Duv6lFdSE2bnzXK4/ImJqRLcRj/xb//aAAwDAQACAAMAAAAQ888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888+z879918888888888899T5NnThAjULn9w888888yAPCwDAIN2+GWNcBNGF8884ZBAHHLE+8MMKx1UsFSs088KaDRv888888888888sAQc8of7v5888884w448884p3fB8s09N5ykKYi1z981CHB+16R8s89999943KMN958WQ83Ni8887OSxz5odXT8TCJRQzH88888888MM8cKjMnhu0v888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888//EACcRAQACAQMDBAMAAwAAAAAAAAEAETEQIUFRYZEgMHGhcIHRseHw/9oACAEDAQE/EPwngFBI4AfsnxeSDY/yRLlMsPuYHcGLImEWoun+4cNHxN2frLMvzF20uK8RbEM/IZ8Y9bKVqD3Vx2in1ItpcW/n+R2IohdbbAYGmAg+XSFPDzDoPMFwnmCbkZ2Rid1T8zbijvKgY73x6AVomb3Ain06cXNvy9o8UTKRkH0CHEB4fP8AqCYRAOR+p0FfcwjEMMZwfo9Yz8Wu/wDiK04aHAf952RHSuZYlk2dajvEUgLhZeowe8CtEUuANEXd0f8AvOqHSx+D/aAxvEo7rxEOUyBNi6nYl2CdiKGnRiMgm4K+2IjtVdSMS4UC2Eo1Buyet2zfQKwu4aXXEOsobUVCywRNuOdCSt2N+k2bB6Ed5QZRuC5hGWoYED4SG+JbBn0IoHppYBMUDxGCQgt4XC5s2wm4GfcFMTusVkhmIrzHqaqufxT/AP/EACIRAQACAgICAgMBAAAAAAAAAAEAESExEEFRYSAwcHGR8P/aAAgBAgEBPxD8JpbZ7YNqV/xwe2AdP2bRmetzPLiJCvZmOos6CDNT3QknRHSxK13TVERsggs+S1E4mQ7YrWEVd8II+JBtEpdT0xBsjpYSDDuLizJTHeGH+3xegJYOUX1A9twPRADRL5zwR8RDLdMQ3EO4Dg2ShZzUp3DTXfAlRB0+6pjcOhMUGnPKuQ8KdpklL7tbgDERWzNOcFxuU8CCdwfue2DdwR1LJcslPMw6iHcR1AOyoVLuBHMBWiUA80tPmgtIdssKOQCL1QKUKgf7wW96gnGoH7fBLwxGmovpiWojsiXXAFM2Rs8AiiGgsNWWiGIPtnuog7+2niAGog7lGiAHNB+Kf//EACsQAQACAAQFBAIDAQEBAAAAAAEAESExQVFhcZGhsRCBwfAg8TBA0eGQUP/aAAgBAQABPxD/AMNPae3/AMSyOwrMwOsuLU0OiG4fje0C5aPrUy2nGfkEqUN4h3zXTkscDMLmIMiPpuJgdj7tmUrO4+QQT7O3InXEHwSI0rs32WWb/wBgW12MBurOflM7Ip2/T3ie0JjuuSR8y3ukvK5z6KIKXHSq81FhguAWewE+gAbsO9ryk8BnxUdUClHQekNTwkB8Mww94dsT9IcSDq8vmGFt5Wl3Ji/FkTqmM0OAr8MJo5sIiCnoS6okGuHVzoDK9ulvmAlgEZX/AJHeIrpF11YusPqIWJkn9HLNkw92V43LxFfSAeV0ocbJR1uCckR7SpoULX8BMvso+MCN2O5vjobM8DDqrM349vBUAwHFK6sqa5CEVzTzf4RRsYPROxRYo3dA6NkKLwIXEmsF1XNLJTG4E75KsXAewiOjsVhgADuklOKgAT9Ry4c3MgCqC8Lz6BxP5TC1gUrbHacCJgZdTnZCKNfQ5Yy5IvrjYT2RdkI6p4AgAPsflSpR7PzRzCfyILk0u/2kP2IaodWC1PsQGr6Q1fSvjQC228FimQnJjohBK3Iiqb94VcoNrodnREDyZfHNykvYHeh9R5mHsGx9oBHJhjNg0UTHeuLwOQgSQRLEb/irdt55PlMh9ilpYUrQ0gUGUfnTN4EXUgloJ7CULG3kXywwIACgCg5B+NhMjQbuBAzR4EA4K8rZSZg4lE7CpnlofAYhlziiWZ5KcTpf7N/318MGz5qGTDyeQI9Sew7CkcI5OdxyQ9GcKT9CCavRhwvsk4OGIOiMxlVui6XMHV3cL0KJFIkSlqE1bOzCLOjLLcoBt40gWImY/wAD4lXineQYyBK2A10Bqy9XEMvgGpACxccn/ImXRbycX8cGKeehM5o1C+hbEsQ3EdVLjnivoBHTbLuLSiRs75MItOdmdz+UzzcXmd72HO17s9EvODG/uHgQR3IRBW5v5kgXEw8a7hwqlitDeHVGYR1BwQs3UQ/DMDA7JfeiD18SA6ln4DkI5NTOkEvCjWdA4C3HJlZ/H/Mk0w/JPLazmuFWKEUI/AdAlsg2Lko1eGxAxzgUMDiPBFtVbX1zQC1yCIKwWJvkC1mBYSR+xcrKty5ga2bu2XaNR+m17QHW608wnZL3Fc8a6D+SjaPkrMSd4K37q3dalXHi7Zggt7jsfBLTgxHtC1dsBdRhJngQPQMXAN4/GxgC1oeeJKaHMckbHknowLBUtygI6IYKKurt4iwxBm8nmGT+JvRSx9AMYaWB6hzltVj04aszA/LDQNRskYq8CKrb6oFB1dQBmqx+12UdboMKN1xVnI2LMF0iQDPdOKf6/cMdJAjDAJFFYnHxKFipbZnxeG8WZorFHVkSCxzKMpnFlY2OV6EsqhKmoqrxLiQ7VVp084QCYj+C1tzhYXf8vaZHk5RAE0e6YkPgFj6ggDK2jMVYltowYQGPTirFaqbVxf7mRttuaEqGlDU5Drg2GUVQKZTzjivNlCiNlOo4MNrj43gCzX3huynV+qDC4zD07Rjw4oLKt4q+iOBiIyrr8iFrlWQiag5JBD5YeE0eD6Ju4OJGaEFIJrHdXVf7lEWAj7qwJbf+BPez5sPLK8qNoXFHNZXM9AZu7xXVmFAFBkS2OfuZZ8R2P+L1dgCgPAL2uUf85ivn1sENddDY8ZikalAj4EJNIBrZui3FEDmnl9Q0P5MhISHmkJyUaPqCII1orHuy1ojsx3Ze5ATX+usn39gcYLn3h1fV74eYr5SSI/ngqb7IL2w/IkL893h0I7wX5WDBKUGlcF8xhIAAASgDIwyPUz/iS/zP3s58PVZOvhnrH2H4OF3Runccx4kaTel6ewiS4UKg0VpODBnk4Ic1OYf0qs94KOMtO5C8XYkfaB8JEZnlMv8AaTSO4JPn1fB5VcdIbrG2iq3rYDQaCggAUFH5n8PbvhGj2HCF7eWaNXGJ9sx2Q6c9R5TR9NmknJcRdx2Iz4U9uTOIYyC98mQx4d4YA9kFwQyID2qbgbuL+DG/iO5ICJmGl1f1q23tJb2YLq/aFHx+QixDuNSxV3NE6imYl7xHQMeryBeRgMo5v4gMjkA8xDV5P8xDP27QGfsliGcxe19wY4wwm8to2yaYXaFBGlnEInmcv3ufucNDr4ZZ+SQyCcpY+Ic0RqmIhVoXUsBWJAchbVroQKhg1R4hNm5X91maOAkdiGiBMrHraa1dK2dIcjXIsTxlyC5a03LXcQQmEINiaIx8daFjueplgKqgqF0DmsRMFpBqg4GrErVDc0Kzxa9boX1NXb2uI8AXaVlbJX9AnGULt5ERZVW3jZCSZb1jP27P3TP3TBMB3YWOaHmsu1RVKcTZjXQV0cbIL5DHcbVuofRVplgl1ut0S+4gTFNCyIlnpX3i3XjoMQqsA5lyw4MC06NszhCKzBMuaN1kW9kidZRdEfTA/HNDrFBfTxuVzhg19Yf5AuiU01pAEuFFNMCMQvN5zvMjwitbtKihLbgYCWqrgiaI5nrVGi5UPwEYvExYtcgnjuHys1T9VgR1NioRRsmYxr92ivTGfpAWh3AFJGq6YRtAObKAIQB7gLfSiRRZOLx2N1lGhaQwAG1lrJCzNyRClBJHGgBaKtBGObx4cbo7UJAAAAKA0PyVVReUXVEuW21Cn1OJ1gEbTC24CAWNuPgxPMOY/wAJWpYiJuODMOJBDAcTIxBAItSKVVG6xlcZ1QmZ7yoBaBZEq2CglhxgjYmij1rT8CUPcShRiUhaUKgjuDkPljpBylYCy6AJEINg7hMTcL0xLFdIdEZUKAMAUByMCWIZ/wA5rAhqVdaJ8QUiRVrbxNXs1pkcuRMWJ6D0FmEiKKcEOjgfw6WnlXomybkUyOVX4GAHWNHP/AZOWdx7CYsQdGkZ2Bgs3nU7ohvqRuMX9oeUz/mR8LMiLk84R+uGEKm+RD4Z+uYlmpwGJxQ9EZgkdWBEzRhETM9BMlLv8mfqmHKOZvnEj6J7NKXslsAsq6QoGwTU4UCYqUsymbQ4u+AmITZdPaYCbhiiT3iHcf1+yVe/BSNANyCAnS59sXeIA6JjYmlj3fz8PU96Bg9CfTigOucz0eaEr7H6psyeAwVon3QipNd+8hl0nGvkwmiByIO0M8JBuZAigiUiMvIJYQCZZIqfJMimfXEc4/OCuac4d2JsC0RcBBzajGRi52gQWcg0V7YbkTsAwGGF21Xen97glADsYBX2plH6pGeaItuWMav68yhc2bmGfuYmzhrQ+4++YjmEbeWYWUrdB2SXnHADr90AAAoP/Fr/2Q==','scarpe':'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4QB0RXhpZgAATU0AKgAAAAgABQEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAAITAAMAAAABAAEAAMb+AAIAAAARAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABR29vZ2xlIEluYy4gMjAxNgAA/+ICKElDQ19QUk9GSUxFAAEBAAACGAAAAAAEMAAAbW50clJHQiBYWVogAAAAAAAAAAAAAAAAYWNzcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAPbWAAEAAAAA0y0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJZGVzYwAAAPAAAAB0clhZWgAAAWQAAAAUZ1hZWgAAAXgAAAAUYlhZWgAAAYwAAAAUclRSQwAAAaAAAAAoZ1RSQwAAAaAAAAAoYlRSQwAAAaAAAAAod3RwdAAAAcgAAAAUY3BydAAAAdwAAAA8bWx1YwAAAAAAAAABAAAADGVuVVMAAABYAAAAHABzAFIARwBCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9wYXJhAAAAAAAEAAAAAmZmAADypwAADVkAABPQAAAKWwAAAAAAAAAAWFlaIAAAAAAAAPbWAAEAAAAA0y1tbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wgARCAIAAgADASIAAhEBAxEB/8QAGwABAAIDAQEAAAAAAAAAAAAAAAQFAgMGAQf/xAAaAQEAAwEBAQAAAAAAAAAAAAAAAQIDBAUG/9oADAMBAAIQAxAAAAH6oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiUqt3AqZ2mEi0oYynV+8/YU3sBGoAAAAAAAAAAAAAAAAAAAAAAAAAAFBT2tFryW+6v278EzDTMppq834I8mQva632XNTc+u5R5FNgSAAAAAAAAAAAAAAAAAPD1p3AAAAAHN479XDrRSbLmPY8e0uuWv5rYe69lZY5jDDPTNdcmJvptZTajVz91257TXbqPKm3vQEAAAAAAAAAAAAAIGNRNcomc7bihbZkdEy1o9Oe3S+U9rXo2CLAAVdbdRvI6a/Dbq0c1NvKz1/LsZPNWG3PcR6uJCZtyseD0ds+HIx19iy9M6VujfEz7t3T8Re9/k3fmvaAkAAAAAAAAAAACmrLqpIEmv97fHnTeauKaWWEn2l42qXrrbZaVGuu/QKiwptvNK3mrLzj0ixt/vJvExl6k64U3T0ZVK53axT+WFFxd/VWFLaV5tmOeHZjAr7Kvz74FpVTfT8K8seep1+6crd10nhIAAAAAAAAAAEHm+o57Lokc1ayNebkbvmrnt8vrttZNxvv91exbXhDkUvIy37eTs0yMNc6e1c/Vx7wrissda+YSY3PpEx9xtMPZz1zvE+RH3c96Xpebv8rTsXnZyxIUyNXspp0d3+XdYWM++fJbej5iuvTbq+wAAAAAAAAAAANFZb1/PtRararx78+Yv7Dq4KaZnF7PJnxay75+iZnXbfF9e3kRZTDf5i7s8Yk2Hz6aKm3purO93UdzvzwJ8Ow4+6rqL6J0Z7mevh66m8o7is2WOHunNpjSo9t4NfaVfZzdVaU1z0cPlB0FNTfdZ1VqgEgAAAAAAAAAeRZMTG8KJaV3N2xI8/CvRokas4znqpbPLCdqqlTai04Yk+YbuzmRd+qZj1drHa0nRc1a+z4smZBl+b60fZrV0wwz0U2rberm1WO2HvYosnHWYFXftjoOY6Dr8qRWWcOm0e0rLOYCLgAAAAAAAAAYxJMbHTTq3Y8u0DTOg06fdO2p0zsHzn6FvTOxr5/LvVXFXO5VlsjbdObbh7j0U0eZ44bcvOjZe94lpJrMeT0pnlbnjrZR4uPL17vKWRva224Z1p7p16aWQ7Ox3yi2tJK6/P6WNJ0Kx59fPmnojUAAAAAAAAAaTCJKrODplafdGGqJnpw3339NZejx8FaVNy6ts7RvzQZcOfztm/UrnI88dGbHHXhemhWFD7Xldno2exp86+h0GnHt7Xfw/vLr0PPbold+k0bJOmVfYy+fvnM53zZXprOr53pfT8HpsYVjjvXzIm2cpYjYAAAAAAAABX2FXWZdbYRPO6Kxhjw+htw89TOjbdPrefSWKXz9sWXJ9356qwyyyn1nlauLNesDRaeU0o+W+ic92cc265Dq9uOgkx7X5/24WNhvrnEprTD0aT4W2brNTun16ZmXNTr13dH5xevH0txyPXWpBxz0ItUGdGhGixNmhTQJgAAAAACBlo3818tG7Dm0ptUjT5/o4e+ovJ2Y7/AG/JpW+sx75WFdLx1269svq58pczKc9DHTFpKFqi0/n9lHfNe8j03b5eqRHgeT61/Y8f2vZzSXNwMN7yl5ToZ6JVrKs7YZ+UnDaZTYU7ZtjddfwHU35LiuuqXPfy6q4p5sj9HGvPXFRcIkiaAAAAACCV9lE3cGufnuPPaBFsa/n7cMNmK9njuh+55GNfB5W1+323m7m3qJdi0yg5SdMtevZoi+rR5jTo019zrieO6C5mdPn1G3KX5vTyULvcOXfnbuRryioqOw5/1K2VJ0t10ZcR083lIjoqjm+vi6hgcv1YfZJHL9NPJC9tYlNmvXri2+xo7yY9AAAAAArLOkytNh7dPBtN1+MCtsYsbRcvN+sy6udXepx5cZ9Nh115T23w5+2pidMvn84l7b5118nosoy5XR2E7TLnr3TGrWfzMLZvyy+n4ftZ4d8fbA8b04+3ifpXp4e2Ffy+WnX8fQSLdCxt51NveXuNuuHHSO8ytFPeVNXrw9dP5npprpjWHi3mQAAAAAAaubsIXL1b90HbwdGyVCkxhnh6wtClaZ3oY1vsWx6527YMitsdeqKtLw2yFeTz7bZM8/JtdE56M6+oT02XAwMt/pEX5p7G0vsuB6j0vA6+DN0+P6HLQe881nib22icfZ5RdDbdXPW2urlunPrKmnt894Nb08RpztB2GOkR+uqLPp8i5Ud5TYAAAAAACo05ysdqbKTE4O/ORF2UpKR3JG6RE3+phQ3dJd21ebYl86nke15Xs5u738HK5uroYW6efP8AfLZ9kydtlVrVweh8yty8bt/Yv89fQrD0PIpLidT4VTdUTh31Ud1xvdXvqbnr50Qo/WaYvV202bbKNv52Npl0/PR9tdqWl6qsjbd3Xybsu7xO6VMjHecAAAABX2FInbI16stNsOb5S1HlNrOPt2aMNXF1W02Fu9bz6+8qbzOI8aTrgjabPopj55X1vYxPZ9qxJcisjOVhwlPn197TQ5Ubauyky9eDZhzHGy7it4yw1z+kaYtp5Nq6LZxb61m6dGnfG++YXPo815xXWTaa8V2XMdZXXZ5Z5W5KXblVRpf6ecgL9BHoYnRyfS7Ph+otz2ArcAABW2Q+Yd5zNBn1/QMvPIy31+yZE81X9PXc3XaUl3w97dVb85acqZG3xpyi55w9NJ9DfV3ZzQLKp1Rp7jee8/Tyk3o6W9La3jYzzR6HtNs15S111UadBhzOmunY+8db68d1jVWvn7xIkzTfWD5b7emNfkW01ylSamjZzeWqumx7pt3GlVp7Eka70qq3r56fn/R3/vRwaZ1TjZcCYAAA5+H0NPn0cN30Tiq7/R4sCznDyRhCtEXjJV1j35ydWPDpbbK6Vrnlhswoi3NVl1Yzs9+q+eMeHItVY7KCadNz3M0cbXGvdf8AJ3apsnXfCvqulxz14+q+kuviq7DPdblj4e4eb6UjKNs6a1EC1ideWqy928/XAjW/O8uvQWOF/p5+ndm35MMvfZePUvIsvCyruY0DWLl57MAAI0kczj0XM59XJ91W1LTqeEkSVq/suS7Guis6SvctBN31vJ3WuyLJl5qk+zTHboy256ypu42+VRItZuHXD02GtFB0NnZRjXz1FtzXurhtDXp6zGfTahruvrV8IvP9Ttxy9kbLzvSz807LXS9Oeld1BdRbZdPNr5dOPd7qy1zzYJZsPDPHzy0+4+6ZarTnZF4uhNAHntYRaXX2Ma89o7GorbmI+W6OqD13yj6BC9kR8Z48dFgWo9k2Pn0bMoUim27T76rn5oTXGptaRpO6Wmtb8thWc5hKimVnUU6radWbcK2WGGnbHGJO21tzfP8A1D3bPkLq2hXy0RsJDSNCu9tdaHK+i2w0zI2xEzbXYTW49q90RO9ieE2HH2J8hy0z4ja038uqtbYAIE8cP2VdBW6VTeI08v00iu/zrTdWFOyH1/ztOXfb8dTmnRsZdqQ4FzhF6jKVV49srTpzz6MYUuDpjEx9mxpv37NUTri3nLRS22aeo566rTzPq85jmmuLJM4skxHpr7G9ual5w9IsMa+XOeWPvtsvc67JFllX6k26H5XSfjqrq7SfPclscdnkTtvaC/nIJqAp7gchs6fXFqTonqNXJ9j4nk+b6PZl3/PfpfN8dev1zGttYw2bYmy2XrzGYgU3SZY93K6+irs+uF5jBi93sr91qS6jOVfDoJsKbhzS84ue2Ehp8tG5qTOzHwe+EyqrGDMVnrG95erRLUywwxmMJOrSbduj1G/OBsJir1psofu+NbG6or2MQmoAAAAHnH9j5FuVgSfcu/5x3MvhbPrGPAd3GOcffV3xkeel2cLfF5Wn3KIr9VrlMc1t6PK1KDZe+RFVtnJrH27M5jz3LKrW24xbDTnitF3Z6ZmXB8xOL3z9OtfN06VFKdebChx6DUtUTfIJd7uNi126KD51UXtZ/ns8QAAAAAAHnKdX7E8JvtOcz7qWs66BOvSbfmXWWw6DKv2TnawtU6ESXF2TG3zFOLZ5ptnK9h5KyFXNlvyrcIm4zhwK3vdVd7GsiHJkxOGGeBlr92ppqHr+mtHxqL9v9PhHv3TUt8W3/YfYt8om/T/YcFbdOnOJM89nEAAAAAAAABAnj5/B+nc9Xq4ubq0R02uuRnbONL3aWc3XXEXGumlon7q2RObZnDJejOMTNWvbFscoklMrVDko37q+LMWe2m1LW8DKbGm7ouX6hzBNAAAAAAAAAAAAAAAAPOf6EfNYP1eBG3E2mvm2nZY8VPmOh0wZs5xtN3mig9vUaUC+1Rem03vkXpfLv1NLsutsxVSZFdKdu5uqieuoYt1Fr7ookyeAJqAAAAAAAAAAAAAAAAAABU0PZlvm1R9h8jT4Xu+1QJt8s2fQoqeLy6jWnnMei9i3NY9TtW43X3u5Pz6X3kqI+f3XcbWfOX+aeb0TAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH/8QAMRAAAgIBAwIEBQUAAgMBAAAAAQIAAwQFERITIRAUIjEVIDAyQCMzNEFQJEIGJYBD/9oACAEBAAEFAv8A4YturqHn6zBn1RWVl/2rbUqS6+0yuvvxaHcTpKCl9ySnIrt/2atmyK35FWnLYt3nqEBDR1V4htriZazf/Wp7Z/etlbebxW3CxlDTiR4qChTKIFdi2D/TvBF2VUMmtGhaVtF9h47TaFYybsl1qyu9HP8Ai81P1Lzxv9VT5WMuQrMVXf1UvuB8psCzrJEbqA1cwUKh66508eYDlk/OvyEql2TaT0g88vVsnVqiZq77/RsH6rDpQbo2RRXn12B67q3lb8oDN49oWW3mV4tjynGpSE7DkI8sacpgWgZX5ubaacbJ2xa6eCgEQ7ceU91VOnFy+MB3HzWD1kThwjLuWdLVuwba5XZ3F3ZriYWJalBQS43BJnAQSyWjtFbhmVuVCkMv5erDfT8w9bFDxXj2Sow1jf1CKd4E4EZXCKwYfI33MOxEZfBVauO1dobAV4+Lk1zF2RbbOAx32K91X2b3f2ef3b/Jx242U+i78vUBvg4pAsurOPaGltnfDfceDIGnEjw6WxW91iOriF1E5K0Y7APyYzacYWG2waC2xZ1wwbEx7palmNbjtuK/D+mj++R90zbTUvm7mlWQ8pt5fk5n8Qjmo2zKDujWN68M7AH5HbaLZOoN+gbD5WqLXWsdgoN9UFw6xXx/u1QSbdoribAzYZNOI5WIe5jR5Z7Zf7EyKTkUDTK9rcd8cqSDW3JPx8n+PehgJaXVjOrs3WzGb00v23m8J2D28nro5RfTOoBN7DOkWhorWMJavOqq5XrceA9yOpbk6jk05S2JdQ3Za+1uV+nqSfafY/a0MuG9VLcqqPtjgOle+2KfT+Pd+0wl1Z5KeTX0VagGS3EtreB4tnGFnvsqCIvMBu5lfbxf2PhVa1Lo269nUSlZm4VF4xa+lpzftD79W7ZlH2r7RoZZ74v7WMfT4bbZFH7v47d1YRxLK9zy3PV5KdPreNj5NUsu2lS9Kt3PKsARDuF929h7H2h98obX4lnC77LR7J2XPJ6YqYlvtE1j+Tjftqe7RoZZ7VdrcU9vCwf8mr978cw948YRlBHFlm3Zb7EnmEeeXoslmJZSK3DCowRoPBvc95mD9M+zNzqHsvtf3yo0H26v/Lx+1Z9+XYwtHaN2vxj6PC8frL2t/H/onYuOQMMPsgJtIm0AleSyTNr4FDB7eA7Sz3lq860O6UHfAMT2t/f8B+3n1tZmqtmw6hgqsM8sxnk4cRIMaoSntXU/Urlo9X/b8c+zewMsTws+xfu5HkOo0DiyEzF9VdG4WtvBTGje3gfTZhdzSEen2lnLkG38P/yynWvP83QIMymeeSHUDDqF0OVltC2U7UYwQY3pslsHv+O/tB2YnYust/b/AOt2NlZNO1+DkWsHX+6P5DdstIp8AYPHMHHKwm2y6RcA2SBGykrNlhJ64nWTp6vYll9KCIkYAAxjtEpd4iLWMjNWs4PJb5Z9v5F32KY0bvOW0uPoqG9ky6nzcp+EX3r/AJFv82uCA+Bhje2o++O22Xj/ALvFXyL1434JPlAe81JOrh4h3QSyJVZbK6EqOVk1US2+/ImOOMSwIo7x/tifb+KzcQ3cfazHtCY3dcXu1ziqqmk2yuvgD2VP5Dd8qv2MXwPtyjHtnDehW421nbJsrJXLOLa/xB1nxG2DUbt3ycmyjB+xd2iVKpa5UXJyLLZtXUQtjw0vXNOp3GGdk8K/f8Ww8rpaO5PcNG8NP/a1l9sXH3A5w3LxSxOsndx2nKbichOQjMNy8s7q3tW/LwT13+SraeSUR8ULErVLMakVWswWHJ5HoX2EYaRKkqjGV1DKYStuWbH+/fY/i4/q8Lo3v44HvqdXVdMOmDFoEWmrbgk4rOKzgs6YnSE6Inl1M8qk8om2pYdVVeI/LDDjjp53r5xLkeEch1OStTa9ox6gd+0uzqao+dkWzGwLbD2VdQ1PnNJDUeGR28MdtxLHFa9V5XaD+BlOVprAVT72j0t7+OF75rKk87jifEqJ8UqE+KJMjP6MTUw0ryHeB3nJ51WnXMOSBPOJNUzEsrwLOGRWxVdObarNyExlxrr8yhKey7AHuL8yiiPqjPFqyciY2IsrqVJkX149eo6jZlSkTDc2U0OLKr06lVbc0duk0durlDG6zZFSY0pO6/Wt9eSexb2P22e/jifsuA8twKyXwVnQTeuhBMqgX4tGNXXFhjNCZvGMMzh6lPexu+CN6NerZk/8dsjOta3apWs55GW11DUZGLxErTlA20ztUSiW2XZVlOnXPLsWzFXT6ntsq4490sHSv9xVd5YaYhamam3OUjZfrUtyf3Aglo7+DHZa14Vp3uscs9LLkRsTILV4mQIuNd0xQ86TCdMmdCeXhojYxMOK8vwr7Bdj245oxbrKqMfy7OhYWYdlbDDctRp6iVIAmq43Xx8IgJ1VRLcnJzDi6KZXi1UgzJC5QUBEvzFsvxbustiB0XksZQwTsrJkNKcZKj9bLYrQ6BVqO8PYy8eO3JpjHdtSJGlaRcas6L4lgIbqxPM0R8yiHLqnmKzOqk5F5XUqtLnFjjudhNvBobFQV4Vhuq06lYBsLHStcrWqllJytQsrRUTU86Y/Y0WdWU2C1IybTeHINYx7bMiz61/e4dwvaw9xD7MNvCkb3TT25V5CcDZi49do1DIM89kwXZdk1dbalBZolLNEwCZ8MVo2kxNNNjY2nU0wR3Wtb9RNswGMGzQdxfYK1tcViqq55TjV1+F+RXjpk62zQUX5RqwhuirWmfmmyV0gRNNve7F081wY6A1Md49atPK1b/XLb37y+K248HG/hi+1zcasQcax6g9Y3fGSCmsSsAQ1C+jFU12LKd+LWdxVyn9O6iPfxW3Gz8phpuTXXh28LaBOXfK/dzrrKdWptF1duTXQuRqlthvxLrBpoTceo+msXUZOVKdNpqiIqRmCizUaUh1d3bCew5H4LHiqnsrQndaj28DH7SgbUZx/4yDamoxjDNo42lm6zUkXzNFVrHoZDRcVwBjLPL0iABZvN5Zk01xrK2ycSz9O9djbX1a8uuq2cuFVWG7GvDVVT3fFPnMfDKRUCx2AD5lcd8u2NjkxqwBavCzBvFiY9/IfgZr7xvugMHawHxuG9Zmon0U/tj0E+7MeSM1sCbxcamKqp4vdXXH1TFSXa1XH1m4x9Qy3ha6yDHJj19NtMcMmO5erbi3FbB0AIQBDeoi0m8ooRbrkpS7VmcovVCTaXfaKbXjaY1op03HrHSqgJx3+uRyy7V5eAMf7f+3ge9je2ceV6yzaL7Ztxr03Dz3qapuaG+uqWarSstzMt8fzWVkyrF5RMOuLRWI9aQogjMohcS5lZMS3p2128CQHUEoxb03bs2TqNNOZTk1PTkakzRKGsa7FOO9TcIivZBTFrVJbfXULtWpQXatkMbcjLc4IrulF3I/WxT1JYsdN/Dfdd/Ty7B95Wd7zG9WoL4fab0UR9HuDb2mVYLtEwUVRM/H8vbSS5rpyCPLGeVqgopECqsLABaXulWNTUkt/4z2LyG+0v9E1TT7fNV4j04mJSANhtWGtmPiVUiyxa1v1dN98rInw+swYVSy2tFlihlUPzxvNWIj3AV27t9PNO2IVCRW3jrGXlH9g0c9g0xTukwh1LyNvC7tKwHU4WNFREBM3gbm4xA824CFgJdqGPXLNWErysvIfExOl4E7DK1bHplltuXjJ9rrvF9MNHAmkhixrFaN199pdnzVEyeWn7Sp+QLqJxd4cLlFw6Fg9IaxEj6ljLPOHJOJd1qvpanatWMrRhwitvHTeOOcsBUsZvtMUbYtr8KtMHGhu6xojcG37MZzLTpAxTAZlZlNMyNZsab35TV6f6cfT+q2Nj149ZIUZer1VzJyr8o9M7adkNj21OqeDLv4N7Y3fLvyratSvyGy66EnFRFw7as7HwOMWtUEvzaKY2dbZGTLuj6YY2LxAdkbGyfMnGvF9X0c3HXKx8LNfAuVtwy8YlnZ03DjZb6mrFnqWapZxpwztUrSwQntYCRQ8vO1etOadP0rO8wLc2muXZOTkCjHE1DB4zT+yV1G2L6RkaklcejPzjTou0XT8esdCpYcagwY9WxresIwZWG832Dhla/yOQ7bXRBwXl1pQiohO0zNXrqhycjLbEwlSBFE2lm8aPT14mlZRNdWVTbRclw+jm4i5GRiZVum21WK6Oh3rs2nZwQ1ZrqrOVMy3r5dTbRWnLcHwf0MvrDdNqfI4ONKaXseqgLOIViIlKYuUG3hx7LZTj11Cy2usW6vjJH1Wx4czMMOZliDVL1mNqT2hcmvzDezd5/YTcBVWWFVpp4iq/JTHVLGzXuoerJw6wkDEQNvHcLOlbZExalgm02l9HM1ZDB/oZg6eTl4yXoj36Tbi5NeRXYgeBmR7LecRAi6plCiugfq7cYjbQGe/gZWTW4CWoMWlDwE7CWNWorqsYJQizcAZer0US7VMq814ltxpxEWdGWoFjiWVhwrWY9uPkrlJz5eHvATvZ6q9RVrtP0+25RUvMqnGaovJKm3UWApVRY0rrWsbTb5ba1tRXfGPz2oLE2ao3VLYtlV2nW4GoV5a2+oU1ipc3LXHU7u2HSoqdGxx/SNAfF15LRaVbfeMdoN7VwVp2JCjI1WpJZffltbjGm/Hr6cqabjYPzjY1tk+HbwYFALYGMwXAxVnlapcGqm/hvGazHd7brhTXxDmXrywKG2TCo6YH0DCNwgOMfnsRXW0GguAwzcIo+M26X2ES8FcpZSuycWrj0RXBitB48N5S+0t9rD/AOox8joPlPdfdThEyrHVJlY4sShpRRa8TFrXxZlUW6hjIX1ZI+rXxtVy5p+TblAWWUWq4YcovqnNVU84qBZj+tdLr6jKd/qdXpN85AYNWa7rba6JcL7ho1lgzNSXbKpXk9B4xl3j1nlZWmU3qrdTAZt4Ou8U8p+rjsW742P04Wh7zvfMfFWpvDJ1Oik2ahl3kYVtpr09RFw6wGqAl2MlgursxbcbKrz1XFBsZL65WwL1kc61WtOUwT30n0Ytc3m83m83m/y2Ota5X6sxrmDfNbdzFT25hfTunEcPLVFd+vP0Tp7rZbXvFO0BV1uqDBjullT48QhgPFh3Uhgw2Ln0lyWx63tapQgEzc6nDXL1O/LbExucqrSsLt4GPtDLeFoOmZBfjmdCm8ur9KyDFoaNh3rLFtVcexEmN6cdbOMXIE6yQWKfmbJqBZ7mCH1V18JaFsrx7OrT8maf0NU3uy6UWtJl4ovmazJTrgDECzEs0vPrygy7zuXRw8KRQ1JegPEf1bzebwzlCdxfacbT9NyEuoLBBlao1hxcZIcRsfMrO0RgwVtiG7dTnPL2PBjVCDsPC7GWwva+Oedbnp7QNaIXJBTFM6OGYMKlp8Onw5oMKwQY1wnQthr2hSmb2bdEE9URn7kNwwuy/Jl1m2nL366OLE8NSC2jVW3yfY5eGVbS9WFkYcg3eByre8ZJYEuFiWUQEEeJ9M6a5ONi4+Vi33GzIsrx1Ufemor5nCqbdd5X1LmqxFHjtNpt4ERlDCyl6RRZVaN1EAt25EQ3JP0mnBJxm3h2nJZ3MZWhNbNYtjE9h6HswNxd8t1ZR02WC+2G29pstcx6Vsxs/CfDlG1uPqGBymmaq1BUh122XkawCCCu8G6R8ZLI5ao9QTebmXVhl9RFNULAQAq+HsTjbqKKzfYiqir7fRycXkaLU5WoOVKtGexJs7QnZlG7sOM5bT1qnmLOT9XgOq03rM49MbtUDwZcNuWV812OYbkRvM0CV1vkNCNxdjHDb02JqGALZg512n2Y19eTXtsw7slnInwJ7WYaPLK7aYLuwsKt6Vsa4lqiBLm2FD7ZeT6M/Hr6NSwdh8u/y5WMLZXatAZrLCqoI9rLETrK/wCkFZjCtar+s050Ii0l4bTyPCBLEhvStjztfE/kfOyhgtaL8uVQcVlKumfhLctb36dkYGdXmIwBB9t2UA7hiFAKvOREtpx7JZp7iXV21pRYBatqIGbnVW/6ti8tWR4pn9/RZgi9XlOj1g9/RgBtit0wytbFHRnX6kNOxOQzDeuNeRBmYyKcotD1LIibBmSlNNJsX62VQ2GyMHXKxUuS6m3Bu0vVFyfAembKxYsGsOzKeR5gTbaB7BLBVZDhYrk6XaJ5HJSDqLkddRBlgQZwgz1gzq4MyqeaqnmaZ5mmeYWdS0xzaIOPLpFyW75VK5VHll5LQRBXdOF84Xzo2mdG6eTZouCgi0ARUhQIt2pVJKg7thp08b6+VjNiNXatiW1raudgPQdN1jaAhh7yzmzJW1yjpCdWxGCjivIwllnOt501E9YnUuE61k6s5VT9CbY04482pm6ic2hNhhTebV1TrcpazAOXWdOuZ5VLa7azK9jOEFc4TZRDdQkbUcNY+r1x9Ty3gptvaqlQ+LgkN+DmYLI9NwsB7jNwFeYmbkae+FnU5YDdNHstcjG5jdAvXLHo7FvQEd7RZ0qzyTfuG2tm10/Um7zk03abtPXNnhIE5Iw8xWpY7VLj8YnOcxtnYbXVWaPmLG0/LWNTck3M7GCpDFori01RMYGV4eRK9NJlNNdK/h52CLzzZbGl9a2LbhtW2n5N4xKshYfM79FBHurNatbaRX0ZbYCV5uVXyoazrQVIJbUhnfZahxs51xebMyAKepB5cImKSOpfuLK0VaU34F4zcn3FjI/LJ+Q1oZ0q500E2/JycevJryMW/EgZXVphfsvWGiLbVGt3NbY5N1pZa+o5BGPGu60WviWIgay0+X6cbKWdBmCg0Q5HUby3Z8hq4iq02e0i3pgBYE5wh4cmpQxe01D1/wCFl6ZVccnHyMaY16oVIcCbbxsdGnl3rnVyVAvUFcrHE8x1JVWql7C0K28icdQ97xQzwvSg/UI69VaGs2xrrFVcnGSWZWPPN5Lwo1kVYiTEsGTk/wCJk6Zj3nI0zKoKZdgZM1JValnia1MOOhjYaGeRE8rYJ0skRlydh5oDfLn/ACuX/NM6eSYMdzBiJFoUQVgTjFq3l+Xj40svuzW0lQo/xsjGpyRdou0yMW+mVZDiLn2rF1GqJmY7QMrTabTaFZxnGbeG04QVx2rrj6lhpLNXaWX5WTKcXYYtD3CioUVf5ORgY2RLdDSW6RmJLcXJSEopW1hBl5Ig1DKE+J5M+KZE+KZE+J5M+I5M89lmeYy2hS54uGYMTaJXTvVi5DynTUBHb/PKho+Di2RtHwDG0LDMOgUQ/wDj6z4BPgJnwIwaKRBpBg0pYul0RNPxUKqFH/wn/8QALhEAAgIBAwIFBAICAwEAAAAAAQIAAxESITEEExAiMEFRFCAyYQVAQmAjM0Nx/9oACAEDAQE/Af8ASycQ9QPaDqItqt/d60HAi+KXMsS4N/besWJiPSaz4YmPBHb2lepuYKiYRj12OkZh6gtxA7RbvmBgePsrO0esPLelZTkTjmDLHAlfRY3aaNMXmIoxLrAtpX12TWhhUqcQeCnEW2A58FinPg1CPK+k7R1ASt0fY8y5MQSqfyI03AxW9aidX0mdxCNJgPglLvuItWjwrEfyGKczVpGYt2TiONsyzzKGglc/ll3DSr8fWpOIMMMGdR0WrdY/Tuk6Sg2N5oKviMuPCudYD29QnTW6hLfxlSZ3ntP/ACExvEn8muqnMoPl9ZJU0zNm5hoX/HaK7IdLy1ZxF5jjUpE6c6HxLPwlI8sbiKRoAjERbUEvdbayso22jHAiHI9RIDvtFbMsfQu0puLNpaX/AIz8kzCIPC0aLZjKyl/8TCJTXqSGpSYOnrHMs0Y0pH0JtG4lfqVDIirAuN5d+USjB1mWnIg2rEO/gFnXppfMrbyCVpqn07TpxpBUw24O0HctMFaKPMY9J7uTCInPpiVnBgXaYh/7Y1w+I76thM7YmoTUs7yTrMXDadONQxMkDAncPzNZzM/qZcw+TmWN/kYlgfcTGDnwAJhGPQURYp28C+bYgV41CrB+4TAmeZ2AZ1XTaKiyzoHw+DOoby7RItZiVjGTHsPCxaWc5M66ryjTKKioz4DeMcbCH8fSqORHbAzKt2Jmsgw9TZjE1tMtAbIvcHvHZmGGg6YBtQgPsZWUXgSxi0rsC7GNb8Qa3hT2nUsa0wsps1bGYgzD96DJhGIBKjidS2ElA5iqud4ETHEfA4ioCMxnxtDYfabczqNWnyTprCG0mAxLmYxamcyvp1B80awLssDKOZa3cXTiNWtW8DBtxM+h067x65jw6hsjEqXCTG87mNobBF6plXSJrYwK5i0mDpiZchpuwYhyIiVg6p3tto13xAr2GCjTzFwJ1PbdNMrqKeijaYrB4V3mmFcmYwPBs5iU6hkwog4lQr05huX2i9QPifVEe06z/nbVKhpGIBmWflKa1PmMNmk5Es6nUfLBW77mLQvvH6UMnlmHRsGY+4czEVsSuwNsYE2nvHODiYzCuDOOYT8RcmLSWnbRBljLbdeyxKGadSrU4Kyt9QzBg8xm0ptDWxOTCipxHtrCfudwniDuPBTOqD0+20R9X3adQzCMQGJ1BC4MpTUZdVvEjLmWAniUqW/KZVRgRbig0mOc/kYHA/ERe607DtzDpRsRRmDjBgCrvGs1TtE7ymgBdUcmBwvMfqQRjECgTH20v7RlzGXEUEys9gZiuHG8ZMQS1PcRSY1mJ53i9PggNOyEENuInWIo3nVmq8ZA3lGqs7xWDjaNXiJS04GJ0zeUqfaX3b4WZ+zH21W+xjLr4lQ0nEubEVvdZXcrjB5jDEJnE7ZieXYRyfeWdWzbCeZotJ9521HMNIYeWJY1L+aJdW8P6mCYW0kiON5iYmJjwK+/iJnQJXcV5nLAiW78wjHE1ZiXezTniFcxRgx7e0I+X5n05A1GVV5XIhSccwXheJa/d5EAAgOODB1DiG/JyYbFM1LNQmRMZmJzD4k5mIrdveBlsEZMRkmYthSV2q80Zj1a9jK6Cm7Rjk7zpzpYpL7tPlWMSTv9zIDDX+52z8wI0UEQHxfn7MiE5iOVMVw4jLGSERDK7nWL1KHZoGDLzNGI3lfMbMImJj7Ss0iYmPDVF+Y3P3o5UxHDiFYyzTgwfqavmZEN7L7xuqzzPqBDapncWaxBvMeHMOZqmoTWIAze0Xp2PMOisfuHf0FYrxK7Q8KZjpMeB3jCFQZ21hqWCkRahAMfYbCs736neHxPqB8T6o+wjdQ7epX1GNmhcMNoYcT/AOQiFJogSaZpmPAKYFAlh3/pAkcRbvmeV+DCjCEuPaC2d0QMpm0wJt4aWM0qm7RzqOf6odhxBe074PIncr+Jrqncrndrnfrn1KjgRuqb2jMW5/0n/8QAKxEAAgIBAwMEAgICAwAAAAAAAAECEQMSITEEEBMgIjBBMlFAYRRgI0Jx/9oACAECAQE/Af8AS0rPGaBxa/m4GmPu4pjhX8uOd4sv9EMiyIffklFLkk4o1r+AlbPHRQ4lV6My97MWaWIxdTGaKvg45M3WfUCGXWt2N7GogrjfzqVM53Gu1GkrtOFtonDQxP8ARDqMkCfVeVaXsZMcq2OmlUq79Nvjor5sjowZvpnKK7ZM0Icn+TrexqbJSp0RXkROOlii5zoydPUbRjlTGtGQsR0j2aH82YsxdVp2ZHJCR1ebxR2JSv3S5MeR6jVvRmW9nRv3UzqMSMK95lyaY0RiZl7iMrRE6R1OifPzZP7GUfi9jyy/7bk8cciuItmRep2jJvEwSqSMq1RsxfmZn7iJmxyb2IYZiwyRii4Ssn2fyZN9j63HKjHDyS3MuFRjqiYvyszLTMxuiRHZmN6sZxIz4rWpGO/syZNLPI6s/wAib4MermQtUt+z+TNk0ysnPcc2YODLn9uhGNVRnV5CPtY+C9zo5aoUNVIyyNRkVpM8drcSjBGtvhGtaPlk6R1HujffF+A8f9kFRKFys0Gg8B03/GzNszLN+R0XJPcwJ6akUUirIxctkSjpdfJnnpJ72u8I1jRJpHnRs1ZSNVHlo6fNqnTOpjaOngnmdmSO/A5Jcsk64Ev2bI6easySV/Jl3f8A6Rf0ycdLMUdUkiWyo8a0ngh+hRSVLs0hxT+iEVF2iWZtUZ04y1RJ9TlfLIyvkwvXEVIZHbcwY9TuRONP4sstMRS1qiT+yb1HSRuZM1tIeUxyt7kp0xW+1sxKN+46vEpK0LFc0jL0sIpbHBrWm0KLe77Rk4uxSnkKrn4epewtnZl2ZdHRLlk3v28d7mihxT70zVGPLE1kx2jItMiXUz00KLm9zDj8fJZqRuYZSjInNS+Ga1E4aSW8RnT7QMj3E7INUSaTEyblexpZLFf2Lp0/swNYY0Z46/cjVtR0aWgyy07IjvsRx0NqJ5CGdaiWlq18Fko2Zcbjuh7siqSQ97IyFLY3fBwOVnHInfAti65MSjkTRlxvFOmRbW8TFc8nuNlwRnuOLcjY2RrMWmf3uSjXqaEUS6dOWpE3pRCZNb7GOf0Y3Rlpbo3fA4+TcX6RQ4xFJR4JY3kW5OLxyojzaNcpGiu2TKo7EZJjRFaTzNid+mS+0ci/XbJDWqHBwE7RVGOQxQKo+h57dI0ah4JWdPrxbPgzwjl4HGWPkx5LPIhu2dVFtpoxKueTnuhP0yj+i/32qxq9mSxODtFWRVdtaolJsiLDFO+zo1CypPcyYlljsSwTgQv77ONpEYlFFFerklGxbclC37PGvo4ExkIajjYT3M2TTweUW/B47IPRwa7GjQhQNBpKK7X6+R+0q90J/vs0mShRZCeknNS4EZ1cbIx+2Re3oTNhMsssZp7r1NWbxNpF1z2ZKCY8bXBW/Zq40adxRNJRXZd79FD+ChpxLUj8S+2ko0mk8ZpNJp9HBd+mzn4nEUvpiXpRbLLL9K9FFfI4+qyy/RRX8miu9l97/nbmn/Sv/8QARRAAAQIDBAQKCAMHBAMBAAAAAQACAxEhEjFBURAiYXEEEyMyUmKBkaGxIDAzQnKCwdFAkuEUNFBTovDxJENjsnOAo5P/2gAIAQEABj8C/wDRicR7WjaVqNiv+Fi5S3D+Nqm0gjMfxu1EMghaJgtNwFXn7Iua1rT0na7u9VixFK1P4lNlqG7Ni1gIzc239yk12tkb/wCM8Iivq6G6y3YJIvdVzvQ6Q2Kl/itcBy5N9odF/wB1KKDDd1ru/wDi/CoZufXwRYb200t3aKhUM96rRSXJks3VHcuUbMdJlVNhDhs/ij3s54dMdyEaDzss9MP4R6e3NWve6TaFfzPBylOTuiaH+DSDhPf6x8+ZTsVtl3vNzXHQOd5p2xbpenUq+S1RaCk8DtqpcfFAyC1jGfviFcxw22yntcS4w3lsz+PAdMuNzRUlWS4Qeq0W3/YKb4bn/wDliTVYEP5VyMWY6EX7qzHaYTutd3+qcv8Aj/6/orcLG8dJOMM2Ispf5RERtl3pb8BiuU5MZXlc2ZzdXRSquQorlwljqTLSO78c5zOdQBNbDnxkQ6zzeqK7RUdqwc09y5B9jqmrVLhDeL617VMXen2aNW7o/ZW2OsuHvD6ri+GNHxYfopwuVZ/UpXOGGjYg1otPdcFMG1Exf9kK1OCy3K7v9F+raDmCm4qbCXQ8sQgRcfxkaWSgR8Bf2qnoTGq7MKotDNq1TvU4LuLP9J7Fy7bPXbVqm0gjP0RpmKFawltwXJGQywUuEwhvvU+Dxux1VWHa+GqJdSK+kjSQyVOcVtKn6UI5hwWwp8PDnD8ZH+Ep8F/Mi1b9QrBu905jQexDTULPesirUMmG7q3HeFyzZjpM+ymwgjZoq5o7VqkHQ4EWXDTq0K1s5aqm0z3K/vUokMEKcMlj9n2QETscLit+mWmCcn6IcRsp3LneCrVX/iY3wFWXGT24+RRZE1Yzf7mix1HBHf6dVJus7JqtO5M5tOsta074nErVY0di13S3le0B+GqhGzElOySWyv8A19BvxFTxzXOtDaPqp1HiFMd4ToUS/wDuqLHc5hkfSJyroY0GVZqsSJPYZK1atwsze1TxQP4iL8JQc3nD+5IRIRsxG5+RVuHqx2UIPkiHCRnUHRLTVShgucuWda6raBBrQAMgpXnIKgDfiWvEed1FMMGhwF8qJrrpjSz5vNWbwBOWaewWA1hlKyhwmGLNZRGqab3J3XAPpPbsTDsTdBaag0UjeKFS/EP3aLbOd5q3DNmI3+5Ffy+Ej++0KzGbLyKppstMsz0VYbQee9SvdkFrHsCkPSfDvaDdsVqFVuLUC1M3HzTnZoue2T+kFFGER2rtR3Jm9Qj1fTlkSEzTFG2a7PxB0zFHZoCILL8D9lY4Q0RGKfBYtnqmoWtCLh1aqtDkUGe9e7aVZYZZnJU9QD0hLuQydRFuDtYfVM7UEGNvfRWojpkXAYIpm8KF8KHpRW7Zpul+0BDcfxkjctWoyKBF8p7VKc96lFb9Qps1fhKmzlG+Kp6i10TNbVBijMeKHxHRC2NJ0s7Ez4U30mnMSQO3T8qh9v447mjw0Xdymx1VKJdmv2hl3v8A39Q4ZhAqI3oT+6f8ehvw6W9iIaJyaFzW/mVbIXPb+VVi/wBKrFf3Bc+Ie1c2Z2qIw4TTXDEaAdiYet+LmNDtyinapNE3LU4t+xr1tVkp8J913YrLr2myez1ERuTlHZmEwm0SQJ6y1XHtqrUpyHuqYOjcnW3ATYL17VqoSdzVRkU/KtXg8VavBu9yo2E3xQaYpM/dYJIcZrHLAKLDw547dAQ/GTCfuT/iTocJtgPdNznGU8l0Ig8VwfhLRLjBIpp2re1Rx1p+Hoy0nrCa3tTg1rXNa4jI3rlA5h2oEndJWxDig46l6rMbwnC0JqE9tRLJUHoVVeTb4lSYJfVWIevEyyU4rrT3t7t38AduTRm6eh0GGKNOs7JQYEIzZBvO1BM3FR/l8vUQ3dih9yjDbNQxEE22XGR3qI3JxUKZrZ0xBkJpuiq1BJvSKne/pG9a51uiLyq8lDyF50QYjjKRkdB/ETVfRO5QjsmnPNzRNF5dVxm5SGhnauEHrS8PUHZVQzkVvZ5f5TCz2jLvsjx4fCii9WYVWC60FzWrmtUWQZKzVdq1LszcpnXdmVNxUmHi2+KrecTeVqQnnbcEXOs7lxsS73AjD/lmz2YaT+Ga3o6x+npjMCSDOm6Sor1zgmazccVEObz6grcoD86d40Rjm8qoluVCmuJmAaoCVHapRaakFTcVKC0vOwLXss+KpXKOe/wC5NjW7gplf8IvPS0P4urQ2T9+kHL8M+J03U3enFG1QgSZDJVaTvcvZNXsmdy9mzuXNb3K5YrHResVeVeVaZO0b6p4HOh1Hmg7Aq1vPjokHtnvRBxVkTfEybmi8lsKfzFTILzm+qkLtmirpnJq/wBPBkM3K3w55d1MFkAjD4MaYvTWuuiV3H/GhrtstFk3t0WnKZ1divn+ANnnGg3oNbc2npxTtATXvdIL2ngV7x+VUY9UhvTS+C4W6iqpCd3qkBy9me9c3xXN8VVniuY5c1/cuLa11q+oQnc6hToZ/wBvV7EAg+I230Gm7eUC+FAEM3VUosR8TwCk0BoyGjXiCeQqVKBD7SpxnGXcFqCfWwVL81aiukEWt1IWWamuLB5RtWJrxinNxNyDkIvu3O3aD0IVPmU44mzBmHamxYTQwTk4C4hbqevY3Bmufp9fUT6TiforJU1RVRpiuDz9w2VQTPqGns0Mij3xZdvChP8AlKY8XModk1Gh/MpxHBo6ylBbbOZoFJ7jYybQIseLkLImcgpxa9UXfrosw9eJ5K3EM1zO11Am2i1wOIVqZaxt7h5IWfZxDIgm5366OpE8HKtyMOKdVomw5jJNe73tc7zoh8HbznumdgC319e6J03eGH97fTJTG5BRNkgnNa6yxnPd9Ef2cRnAe+X08V/ty2uR9lXrfoi0mHUzVXN7lz/6Vz/Bc89y55VH+C9qPyqj2qQDPzIca2U9qcH8mx3SvRgzmyINU7VO51xRdwezDnfxcwp3nMrlKow8lxo9pDv2hUVpzpBWOBw3WOkp8If2NXJsrmdHFtNAdZ2X6oMYJNFwX7NDN97tqrR7ecEWm4qy+pzzWsJqyyTVSKxo2MTnVc917nXn17rPONBvKbLmjV7FW+7RP0GNzdojHrqPLGKQ7vUOtHap0DTUqsRnevbQ+9Uis71SIzvXtW9657e9ckJ9Y3K2daJ0jhu0NhQzyjXWtytdLz9AObePFcYTq+aeYGrBNxegYs4zutd3KQuU3uDRtVmA0xD4LXfxcEX2U1jBZaME6Fwc73K1iE2JD9qB+YZK03/GimkECzCGPS9fDGWsiHYqRxp2jTI6fhb5/wBnRPpOd5qJaZxkCJz25FB8DhFAZycjzZfCqPH5V7Rx3KHEZFiGG7aqkqjVreCuKo5cm4uHSwU3co7bdotPMmoiDqszxKdZ5412oFvNiVB26CUP2mNYcbmNqVTVh5vbJ3cp1c/pO0Wozw0KzwVnzOVvhD3Ky2mZQawSaFxXB7sTmq1crTGWWG+1Ra8X8oROtM42kWPOsPEaKhTLJ76/gIh22e7/ADotC/6hTwPoxHZul3J7sggM22hvCmFVvguYqMCIGCi8GdvanQ3jWbTRVSYLTlOMbXVw0Vc3vXJsfEOTWq0+E7YCZAInk85Wkx/eokHDnN3H9VM0wdvUOd3GBRIk9Zrqbk2I25wmpxXSVng7bA6Tr0YrrTiKma1hrKTe9fRS9lC23lVm5ajWt3KbjJSBtfCrMJgbtcmmO8G0NWQ/BEnBCd5qdBCIGHkfQmmZyn3p+2ia7FtUW5XbvQtZIPbe1MjQiHWxIgIcjEl3K5jB8SlxgHwtVXxHdq5gO+q1WgdmnXiNHaonF+zLqKDF6Oo7cVblS5wzCdDca4H6oftwdDiinGNuchB4HFjO8gpvn23rape8v9OJg3ge6uUdXIKgkq0UoYdFPVVA2EO8qcVzn71qqi4t5s4tORRZE1Yrbx9fwPEtBtPvOQR076fX7+gW500Qxm9AIdWnYdBa3DnE4KcN8mdJwv3Ba0V3YJKrS74jNarQ3cNOvEa3eV7S18IWpCcd61IbWrny3LWiPcqhbCnMdc6hWvz26rt6kPl+ymO7RRGt18hcg582swGJVloAGxWorg0KXB2yHScg6ITEO1S0YBakNx8Fyjw34alXOeesV7NnchL2Ljd0T9vwEX4WjzXWGmeVfQhjbPu0QW9uieFx3Kt4oVHc2+2R4yTWxCXQ7tyzXKva3eVyYdE3UT4sFjGhvaVWK6W9axmqhUY3uXNb3LmNXuhXq+qrzShEw5r/AKFbCq1dj1gpjFMhgytmU9ibCLDxcO4NwK41rxxeas8GbTpFWuEkunmqeyOPRWxare0rWd3UWq0Ba72t3lShhzyuTDWjvWtEiSO1Sc5zY2E3UKsRBZijDPd698U+8bt1NExfloO5Ddpd1W+f+NHwgaJFVw1T9FFhRqQYvvdErVfDLOlNNgw4r3MYJUuVaKlXbVaaN4QiwvYv8FyTXOOxa3Fs3mZWtGPytkq8Y7e5eyb21Wqxg3BTdIKo4uHu1j9lKHCaOzQD/tOMiOiVMXi4o5YjLamRcIbpncnR4DeMhxK6uCdx9oFx1Ie3NVw0EQwDD6Trv1VBM5lWnuDRtUoDbZzwXKxCxvRbRVDjvK5oWqpFSaCXdVBseAaXOJsla9jerL6Ow2+si/CtWjdmCkb1NZO80c/Qe7N3lojPzdptYXHci2JWz4hez7FJjQ0KmjkRbzy70ePNoGtgc1WWiy3IaKmSrEmdi5OGTvVmEGjcEHRnGLFzOG7TJp4x3VQiWhxc5uY3JDJUvUsPJcjEfDGQuVpznPdmUGtE3m4KzHk7VtWRcpnmojg4tdY3LjYzy9hxyU8QqKRNclSHTrUWu/sauZP4qqQoNi13NbvVHWj1VYgwTO8FzpSWtSI3ntyPq5vMmlzR46Op/wBVI3+eiT6OwcpOofPTC3T76pz8hNbfQ+G7a1UqNBsSsi95uXKOt7MFLBVUnOm7ohSgss771rFzlrGqk24XuwCssG85qZKLYPKv8Fyr6dEXK5WU2z7F3N6py07PLRXoU71EiC8OlLYnFs2wW+JVEWvE4TqEJ0GCC9t+7epxnzOTaBajQ3do14gnkuQgGWb1rR7AyYFNzrW9apkV0XhAtIh8Lbdk5WpScKObkfVPhRLnI8D4ZzWmQfl+ipUKgmzo/ZVNMHaLMQW4fi1Wp24WDwrIvdq962IN6RTRonom3nC5bDcMjknuGAmoLYdAZCfYuLinlBjmpA239FlVQ8WMhf3oHPFGMwU98ZbdyLjzVN82w8sXfZAASAuAVmEONiZBTiCTMjQLlIncubNezaqwIR+VEBtkOvlitVxiAYG9Ai4raiMB4JsSHzm+Kt8IYWxccExkFljg7fFVRYy7F2SssEvqplFsHlHeCq8gZBTcK+jqtc7ItwU9RkrjaTovJvtc5rcdqNk1F4N49Vwljr6Pb3S+i4nhOtAwOSDmm003FFzLzeMHKgMhe3Fv3CtNRMPtabiuMhAhrPdODtFOaKDTt02vdPO2bUQ7tX7Lw3m+4/P9VbfEdEyBTn2LNq4ZBVqVP3Tfs2qonszGSzgP5hOBWqC5coZNyWqFrva3etUuf8IXJQD2q5gV7e5a1g9inxFqV9lyk0ltv3HCVdG3Aqn5fssJKa46KdwNwTeLM255qbzXAZrl6QTSyDjtToRvBQzUtEjfkv5Y21KmRbObvQtAlkUXPCEPhADIhuPuu3ephRvddybvp/e1EOC6fByg+E6bfJTucLnDBYNefyv+xViGJRMZ+6g1tysM9o7wQn6Yb+T7LNpwIU2w2g7Bp1iug3C1eq62OsqqTeUfsUmagyCtRCe1XejNtHeaDmmUVuBUjquxGnb4FPAvlcoD2VaOcnMh1acT7qdEebRneVLpDxUHhIvOo5Aqt/mpuPFjxWo30yyIJhSjEug4PxG/7+ocxwm0qxE7HZ/qiCAZrjeDHUxatXVfixWA0Oc7A/VWQZnFxvKkKxDcEXvNpzr0eMbahu72qZ5Tg5udkptM25+jIo2r/e++l0RziIQypNcY2rne9kpuMlKEOMd4LlCbHRarE6HmuzCoqqeC5MOf8IVzWbyteIexe8d7lrQ/FUghCVoSycpnWZnlv0VVT2omCRI1sm7sVkhrG9VDJDNcJZlrhFB8Qa5/p9VIqX+xh1f09RJwmFJ5mzB/3VVxvBtWIK0xQDxZjFoLmqzD52eSi2iSczoa1Ew6g3swKMXgXzQlShxHozuIuKs/2NiMr1CsXUtI9E4Kw+glOwPqtZWe5WLj7hyOXatejgZEKcuLHWvU3C2c3adYyXtAT1arUhPO+i1ITQr2jsUv2mzF6JbenMiABuQVNFg9ioKnAKcRwhBHM4lPB96GmTuaLR9a2G+40DvUEGoViCbUPEE8ztVpxm7A/ZcYCYRFW9JRoXCKveLW+SB6TEBep3tzy0W2GzEzz3qvJcJ8/uFYitsvwyO70aX+eh3FNESG6pZ9lyPAbD8zgi6KZvdeVQSGgtY2ZudO4K2deKb3m/TZHKPyapQ+TGypU4rifiOjmhU8lUKYwucgyLJnCBccHKwx3Ex77N7XblysI/E2oQkcVFOE5KyDaF9dHyK0fePl6ybyoUMzBcZyyC4qPzvdd0v19Mm1Zgj3ul+iscEbYgj3yKdi4yA4vii/jPe+yN4cL2m8KDGHuvE9xUB0sSEHNKm29Hi7sWZblMFSd35Li+Fi0zB/3U6vh54hTHoTbf5qumVS43AIgzYxpkTj2Ky0BrdHKHW6IvVmdiH0QsgqD0L9FnnbBVcjCfZ20TeOgOMWGZtcDfvXJvnK9rrwuXgTOYqpQY1nYVSy7tkjahPHZNRJuAkxQm5N0VV6o4elK1adkyqnJsBmb71agAxX/wA2Jd2foi4utPN7irM5PNWH6pj8x6MpytEN7yoHA2arTfuTWMEmimi0DYii54USHGbYi4ZO3KG07VxkA0VnmxeisjmpiTYuWDkRc4XtOCotSrOh9kYnBTZdixFrhZf0T6bHQ/ax73IBmqW0LVNxkBiVxfBMff8AsnM4TrcdS1kUYUXC45jRI36JrkwX7rlNxDdgqtYW/iqpCmm0JtiC54vQbwhlDc9tx+ysuInk5apc3cVR4PxNUnwWuGw/da3By35fsqRC35/utWM/8wVIz/BUju/KqcIP5V+8f0r94P5VrcIf4BcyJF3zPmpMDITe9TiExD1lKGOMd1VyjmnZ7o+6L3i06IZCslEb0Xn0XNbzrxvUDh8NpIbSI3JBzTNpx0sgSBc4h24DFNmDZlKeE1NcbwehvkPohC4VqvwdmqocaZEc2IPqrEUSdgcHaJihzCDY4kcHBa+vD6WI3qh057FMVb/d6/ZXOsxYdYZOIVoQ/GhXKvtNGDeatqkb/IqHwoc+HR31QOiUMTljgFOIeMO27u9QQ4TBwXJN42F/KdhuWpCiw5dEr24GyI2S5rXDquVYcQfKqu71/tnuVAFSfeve71iqq8KjSVUtYNqs60Z2RoFYa5u64BCDYLW3uxorTJNazEKMCb5P9IxYYnPnN+qtQTYnlzT2K6G7c6XmqBjNpdNOcXEuNXPcncc2Yi1IKLmzdwfPFu9Nmi5nP81xPCp2BSeLUC0gtKkRbh9HJWgTEhZ4hTBmDopdkrUE2H5KUUS8jpmO0Zq02rfFqkXxJZTQwCqq+94KPAdzX1705jr2mSs3MHOKDWCQHq+MhasXzXKz4zrK0xmt0RSatcZEHVtTWvF7S29ElkL5mKT+DQAfNS/ZoUsSHGi/dwdttCXBm1u1kDxMEOymrDQy2fdkqxQH7ApuGr021mgyEyZ2rVc62fEqo13e9grNJCpcohlSy2W2/wBO3C52Lc1KLybsn0XtW9hmgXtLIIwN7v00SKc+CJ8HvLehu2LMFTFH4HNcW8TZiz7K3CdMeStMo7zR4rUiXlhuKlItf0Tpk4WgpwTZOWC1m0zF2i0P8qnNImFYh0xLsk0s1gb3YoHIqGcwQuEDrT70GY47/WzuwKINA2hzC/09OtgVrmb+tetTW2Y9i5TmH3Z+a1HiyMCtfkxmVNjtbMFatkt6Ssntnip3MwY43qxzXeAUhrHPEqYM3HA4K+3EyYpxKDBouR/8Y8z6iRE1qsaNw9ExYQnANXsHu7QqVaVW/B2SpQ+Dlq0eL2qqlF1gLnC8KuuzpBUU3GQU2kHcs1rNsOzuXJvDhtomh8J4lOt4T8QRJSY2QTpZKEestkg49ir6ybzIZlWzqQRW07FGLYFu1aaHZISkz/jiU7itaK35TMqkMz6QrNdDbiplvGHpTUmNcTkrRfDtZe6pBtra1TcXWsKGio6mZopAknvXJQpbXLlHmXRFAqCStxTJvmjwh9OMub0R68xYInwc1ewe7tCBaZtKIImPJB7CaXOCEOLqxv8Atomyn1Wrybz3FTIBfOywYb0OOhgu6TKFcm8ROq6jlKICw9Zas27l7rvBctwftlNcnFLDlP7rk4rXbxJDk7Uui5PiPgxGzaBzVfLeucO9YK7x085e0avaBUbEduYVqQHfM4BcrGhQRsr5qcOG+K/pxblajutnAe6FIVdkiwytNudtWRWrEcO1Ujv717dy9se5e1Pcv3iItaK8/Mrpq7RaiEMbm6ilwZvGu6R5q/aOEuLiLlCabw2v4AxeDNtQTV8MYbQg5hmCiCFbhVb5IQ+FmmD/ALqYMwqqAIfO1nVXKmUjcEWOYJ+asNdbBwNUXPhvgSxaaLk3w4ngVrw3jxUptOwrV1fhMlSK7tqr2HsVYbD8y1uD+Srwf+kKvB//AJr2A/8AzXsG/kXsR+UKkIKgaFz5bmrWe8/MpyazauTa5+4LlXhnVZVxQa2EWh2E5zO1CH75vNyDyZNcSB2Kj296ofQqQFrRoY+Ze1tfCFycB7viotSxC+ETKtRS5xzeVZaDEi9EIROEEEi5guH3/BGPwMVPOh4O/VUvF4N4VUXQtV3mrDhNnQP0XJu1uib1Bi+7ZsuVqA2ee1B0R8zhK5EABuas8/KQvXK6sPvkuSiOEsCZz71VsN7doVYbmzxYVLjojZ9Jqlx8KeTqKnFO3OXsf6l7F3eF7GJ4L2URezevZuXM8V7o7VWMwbkSDGiAZUC5OEwOzcpxIhcT0fouMcbJGGARivkcsJBOe+pNzTgFChQyA+1OtwXMhv3OVeDRPlqtaHHb8pVXOHevaf1Lns/MvaQ+9e0nuWpAiu+UrVgNZte77KceMT1WCyFZhMDRs/CcbCPFxx72e9cVHbxcXLA7tEnCatQTd3plscY24g3qzCfIfy4lJbijJpDU2Ja4zyKkBTyVm7rdJTOu3y3Lk/aeasxJQ99ZoljbTfEKmt8KnwhrAdlyLgSztov9wDpcYbK/eIk87a9vEd81VJ8eLC+Mqy2NFJ6VpUdEe3pA3Izm6d9q9XlrcGlcXDawy95uCrU42ryuMc2y/Czgph1qGMHYrX5ov2qZALQoFmrbRr2ejVo7l7NvcqMb3firEVsx5KdY0HpDnDepsMxoOxxVQuRiEbMFy0LeYf2QMKJZiDpqTmOBwI+i5d3F5EY/ZHixNik3W2NU+EVyyU26ksVZDG/FgUHTtywdcNyskOtHCSmBxam1kz0sVYsuc/oyWs6XVbzVZkKdDBW4rrbtlzVKE95h4k0QY1hBuAVqJKI/wC1TZZ5rCWasw5xCMG3d65SQZ0G3KB8Z/wCp/gdtk4UXpNx3hctDtM/mQ6+CdjDdWbcFNhDhs0VVy5F7m7ipPDIg6zVrwXS6r1qOdBPw3r28GW9WgRE2E+S9mVU6veVImbtt65J5eeip8IfZHRatSywZrk7fF+J3KUnM2EXqdnixuqVZLGgbDJa72krk4TneC1AyGO9cs5z96po5IzhQr3Zn+C2rPFxOkyitMHHDpQ9Vysl1o9GIJOXKNczxXJva7TUK7RRasR35iqRXd6kXzG2RUg5svhXPb3Kdpk/hXtVWM7vWtFiH5lUKg03KRdxkToMVl2pC6Dfqo0rrUvD+Dyjw2v3hT4LGI6sSoXL8HMumzWC5KOd1612MduotdsRvZNUit7aLVcD6zlIjGb3KjzEPUauQ4OBtiFSiRXEdFtAq6oX+nEmYxD9M0GNnIZ4/wqcaCwnPHvXIx4jNjtYLV4qJ22SuU4LF7Ba8lXVO0SWpGd2OVIz1z/6V7n5VdD7ldD7ldD7lez8q9p/SvbxOxazojt7lzQtZ0lJs4hybVcnB4sZvp4Kcd3GnI83u/iGsAQtfg8I/IF+7gbiQqca3c9UjRh3fZU4S/wDKF+8n8i/ef/mv3kf/AJ/qv3j/AOa/eXfkCrHi9kvstbjHb3qkBnbVSAA/9FP/xAAtEAEAAgECBQQDAAMBAQEBAQABABEhMUFRYXGBkaGxwfAQ0eEgMPFAUGBwgP/aAAgBAQABPyH/APgO3/4Db/8AL9hNUdF/FK9YFodcDzpDS1oln/22WxDdXgG7DRoI6ftGQF1yvdiW6p5IfEbKZ4UYIXLfoe0HrpDPWNBe4q8P/s5itA8I468ZxEJfjpKa4S8GI2xdkrYOJi+IxlY20HbWA1WbuE7/AIRVguXc6aIBMOP/AKm34RtVHUF+5K1HrSpCR7jMyCUT8R2R4a/OsvgXz08xunY6jo9pauPnvenadSZhnU1JzKYr/wDqaZq4Tjjue8AfEzSkG3Uz6ytga95or1g6/JUqaFSm0O7SuBh8zijiPX0e8QpocK9LR7SjeJH0Pxf/AJz/AGLRmD7HgP8AYt2tk8Vav3hCzavR9Rz98TAW+xg/Vlw2UbHCMKk4B6EqB1ig/hjMcPSV5e9pAyXILP1FtgMhpfqMRsNGO7bDtXheg95ztwWe83y4GTUvsn/lP8Nv8rEaH/CidB0zzhcsPFl4MSynXpH2m/uveNUCUPu9NELZP9Ou7hE028Or9PEWNuq3HNyecomNtmeg+Yo5m6cicneOVmCOf5HNnlHUXVqMiuHFYzbu3Ze2hELK/NTMXBt3QXHlte0qLXrGv8lOHyxIBcJq0+P/AE7f41TGQchaF+sCgqirYat+PMFMXu1pf7nLo7kmGXDgyfuCfPSiu3787bdpct8Go77d4ZIK3NP9BVRsXmvA8f0lMjANQ5D4Zgx7HdxvVS96ZoPhlFt6hYTtHMmBVcX7hX02mSL1vbgIGq2QGWLjefd5gOcnjlFqQ7yxQIhKLl7/APSHeOVvocejHDsLH/2JuGR1Egj/AATB9YJgywlVl7X6y6mNVycm/hie3g+P1BDkNn7JmldaGfgdow03E8m53hdC0DY/4mGs/Fk5DZ9zFArpGf4lC2/U/vKEFq26O+pNqfS+dZrEOL9msuPrGQfy18SkOSvQ5ssBbyK5Vjo8orjC0MiOETD7lH4lfn9v32JzlPPqefeWH/m2/wAah9qg96xOl/d7seZdf0MzFKukPeUweUH8ZLIaOid5sn0nzDW8+BlGVtX9RZh16ud9RD/G5X+PX8pMHCcMywwLwupuzlLuzZvz4ghSY2pbWtHtAJOTILvF6TQbjXn9zebyynikr9IK88GO6xBDwv2GHlDp2h4rhHLUdS/E1aYcCnZEg1Twbhc23nzz8QV7QEA508MCtq+ev52/8O3+JsPrUskUGmo7P3ZmC2prZ2HJ/cr7YpOEu6L2/srnn+IfyONXMtCukHd3WU/UWQu1ULqmPeYME4/OT0XxGNB40QjXYn2kp6wqkrR7PLEiRhnnL4xDlOhh8zQULjPoj0oDue9NTZ2k93726o1g+LP3zMGYJNr+Avondp4suCaQEvCmC8CB7QlbbSByHme0EhwnElP/AECy4+xFuDpcHiuX6IxYCuTjyv5Kqf3G5cGNOGzARmOcILZqQJrAwbFiXFV3RtzXQIL1XGfLqw0De3RHVkdi2On/AIq3wfuPjQq+mZrq8Ut8sp0i6uW6jT1lisJzibsZ71DYeWcTbtj1JyRY5r1mQw4JfH1OzNJ135xXuN+j+Q8r3XT49Y7DMpz/AAmyc2Eek5il9I76H4MWjbow05PNGPiajtn/AHn+k2fP7SzEBZoa8DwYoaLN+xuS46XrZ9MwgnaOocmCgqI6tygsUVoW+QfLwmUOvxVxW7MNaNdjq7Sv0iftgBQBwMR/Atw4/Gs78+LJ7+kw/wCZ7c+Ubqsqx4wwDOIzwS/Jb9PfZ/kO9VGZSGga7XD5k1vJF9phiuM6w0SCCCuqYF/qWXfkfuqwf3Nrn9z/ANBocSpSyyUL1aDhw5kBQhoO/NC6ncTPc/UCfqZzJ3Ujr41mUWDYpWX48T5exp2iNEaevIc/aAgKJUxwod/hMxjgX5y/r4jnXPfrt95wOBXQdns92e2esdCKp1q3pWr6e8Ii0BojTnCa1D1r3jz8SUSaYrz+Bjtge5/J5P8ANXMfvPN+D/x7fk/GiEFQoy6KhFbM3jnmTv8AuZqZ4LoEzzpSHq1zIUrV8avTSWQ6ePHeAVTXIszQSwMGyGlDGDwfZo+8DaujrOeK7YPueJjyB9Y8Jgdu74P3FmhnrPeTLlfNjAcA/BlRlYVwEqLnn45PmCXNB7/nAej1h74en8/9DqlZwg4dYMwTBPKEJtV8vmapp6niKNW8/wBWZHCdmMav0zCIaaBNHh2+zylaR3aXYQLI7UwRpOeaTol6zj8vAaSoclvJHl1mq6fWLGPP9ZgenvqxmEGDG8D5EvxP2GfmPwj+oW9sEEt0OQ+I8OJotagumoX7QKNRP470EccN7hP95/p1IbhjpPmPxg/PHXSfQIpaa1aUcV2JUXD1tPtCsmOM4RiWZBj10NDu/r4mYLd1lX3rNphKMTi4SreP4HOaujn5nQW+RJf+MrFtQDQumnwy0UihXe/DWEcgeH4PW+YmhuLVosNZ2W579xgfp9Zul1oj9Xsy/wC7rDQnozjexFhmtvb5ebHSGs6Or1Hz+DqgvqX/ALz/AA2/xVOXNBxlubfifVYHcUspxgSaA1r9x3Fu2n7EuFKnnWH38yxkKvow/wBg6V8hHNtlyzDFrDGWDYfDEuD6jA7Yi6KXb/swdqrHD30msX5qsCpTRWdXC5R7vJZuIkwLdG0bwZYHQg1n8qAbdTN34qelt3mMg5d3qd52sbTqYOIB6FHQcM+j+D6oNNw0/wDIfhmsEvjxfCLVB9MBcxlOBa+H41wHcw+HWNYCXxaVB5CY84vaeogLiqWEGarmvrFUaXxV3lx4jGPI/MP0yoWoBZer095dJVCuGZlpg3m+lwVtavaZ/wBJpi1VQcZnOTPsbygDvPZw7Q3VWmTsTAK7oXNhAN7p5sGYL54OH99oqCaQXA0jseP/ABbf4Eq2/ALZB3xcTIkx/FEHXflU1zyu02LtbK/fSGAQAdT3mPR9k7J+Ah1wbxZ/I8UvixQ5JrLJ53dQ1YZLaN6rk/BFzA5rP6f+QWAGpUvpPusZQ4m8BThOpa3iCnCNk8L+u0A4zoHQ2mKL1uLdUGX8EtFBrJfyTIH8R6zD9wujerxi64rt0B1erLH1cer0JGVSkeLjn76f7j/Db/DgCPi+T2/FTZtJVrKOT8Uf+KNfEqzY7DL7RrVvpEmoJYDo8ZctrYjCkbevOPZDDJ+ewawzzLY6zuVGhN8IHNL/AE4n4CXml2MfEcm52Q/Q4loQKrDj70mEC4uv31mgDLemINQOstOOl0LDuHoE9Kt+kTWk45POsAFardls3L2KbHKCig8QkKhY0C4OtL6fjBnHP37vOWFnp99v/Ft+WK/8wwfL3hqwWwZfi/ww4E+HP7hFGxyqe9aZpHcLg1Vpyzh+DP4QIfzYhxR3nP8AKc5nPR1z+IqUYjq6La1xNRHiw9mZY3jpD5l8yljLgI1acIGHooUzbN1G6HPQyesMUrQ/4k5wPfZpLgwcGBLrepg+7jMZbYM0N79LeqcsboBNImkNXkcoS/hvpr7Pwr9Z7/2vP4tWtq6mz4+fw/TB5XhLDCO58wnBGln/AIP2KtggNYKdCYdUuw1JrRPw6TH7Uf2DEaWZzLo3xEdHpOb49glmq8TAvGjbJ8B0CujzSP2+2HKRU1n2Q3Hwmoem/MQ19d8wZuE1UfhqmQyqX3HpXiKr9GCQS1uhrxNa7MAIeSrOgZuYdNxTm6hr3gGY7NEMLIn4xhd18TmB6X0JVKRxHo3ZncuNr/yOTeuxW15HMzEQyoZZ4mn3nMKALTcdyUNgMuDsw6Kr1ODuefacBnrtez7v41/tuCjL2PdmQn/ScXSEDUm0hrTiNes1/VP+8uDnccfThNTMrTOBTj+TS/hsPadN7xFxG98wGbHe4FS8xS2Db0/nrEne/XiEnVGArEQFyzG35x6LGTqMflKA85doHq0el+krTZ7W33nDHW6nqD01O0a1cYBz0fic5bqpeo+wbsRA1hwkrWKvqS7nWmpMVTg0vWH6IW0cG8dUuye14DkQ+yh9DeGvGBMyuOZl0c4cnM4HAfrWvxp+rf04+48YggLWEdyajBbs7uZM5CnmJf6/FDINzla+hM/xf72UvpH6MOrHtBhPxE/HIsucYTHrv63F0D0r+YdzbORq6baavMlox01E8t0QNJch9pyMccVvMNFa+/M2r7v3OC9v6jro/QIj+BONnb+5lPYfM3h7JCrtNxSJZRVs8JUGYSl3NENu8PVIU1Q1PntAYaRwWcxNElmxjka8xshXW1YgPYlcK09TZ+8IlBt/Z37sAoCnNbzHY92IidKCr76BLFUddT1cS7AHmPmKUjtkc14RRo9QNDLcUA2VzgqDRcF/TB9w5gTTe08esowC7yXmMEK9CsTAcRWPq1ONDvf+8/4KMPeHmB/To16xRw8up99YILp5TDcT8dIw9DL6EW2+863TwBHzX0R9nmUvRqNkfw/h+GaAHepoQ6mJa+DBleEi4v8AI5d+rDFo9E/vtOmS9k2hmXHCXNK63+ucVAKNZwGp94RrzcSbQIUcjb4Nz7wJVTcpvZ+/7K/F2JMcjV/5HFh0dLpogEIDQMVHRru6Jc6L3pC8fQcDpzh9sMh3oZ+xGjuL7xxQNE6cRB2lojqtx5xBKSLlmcIglwsrgzVqPDVw6c+R/vptt37Hv6RGZGEbwlb6bntMRnJ0ZkpXk/HMRHvh7RvAp7h62+PaZt6MLeJXBx4JSFqaFE7x9CNq1XtGrD6CWjx1YWQszU23O0IF/Vua6PWcI8hcdg96lNqnVlUAYdB779pRDzzh0P3+D85arMmtD6MSyMu6O53I7hj5b69mPIlOicHeKzYjBqsdETvI09MH3qJhNVqN8jQ7TrOvBtXtLilyLfEtrdcviPqU3cofuDw++4gsqwPoOUdOwMziRk8XprMv2dLuy4D1rC/EtEd/wPv4/HuHvN0PO+6BX+w/PBOg7P2vEILRzQdw8lniAQ0rI4Y56koc4wdgOg/azmcvpFO2PUPj1gC3DzLRC+MX7p2xMz3GY4KrY6OnydiaeNWcL/T8SgU9vxNHjKOiBodWX+gjB/febDQMBoEbwIsXY6nPWVEDYvUSo1jiGbIU10bwG9wz/TS3kmiVrr4bH7xJhz5+PWoRlm+x2qJbdBK4b7ar2mc65i6GhGsOsdqQjA3DK7NvGGacAWvbjDO++BBNfvmh+YXRnJXrKcRxWpZqfATrgxct6iYw8S+JXv8A+IdAC1jLfInPz6TalEOXTrtOBCx5D9dotnOXOOVvsldeK65fMqLl82MMfB39IBVzdTT7yim8yleECg5Hp9z2lg2bJxNz7wJx7wV5NfdJQScxT1jhvM7PoTET4fKs91FfaUbfst56cYjzMQawG6fjCi8psV9JlTl+he9esDWP2x2/cFyoc1Nuo+JjzNDsvuzxY1Adm09CHEs6uSmKHVvMrcH15xQvuL8Phelf2EX9DvC6Lm4y7IG7pLTyR2edJcd+wzFebEwEHSNdhbZyeEzel4nb+9ZhjyVfJy/8Kgc0LR2lfUhoucGNrHXWl+7R9cZZGXKw4T3albalfOngZjyUXVbeh4faa0VUaXRcPVmX11Bq6TNc7iuq7wh8srF4Yz/zDKK5B+GZrpSTjxzGe6sE9f7M3OeWo96hGro6yqLwX3iw/Nbyk6rsN++veNLQvPg79DDQTjwPCGmo7TQ/dl3Wmsid2kAjV6HPeB6zh5sFETc6d4i+5tI/cOQ7aSmKV0lIQpeTfFzTAd3DyzCr7B66TKvoOCBb22bMzCwFb2j1eln/AIMp29Yoos5nM+/P4qYqY1p4P/ZdKtIsudxPF+6mCicHHya/cxKgpf8AfffeNw13c4+JZPdDzfgPacekWp5SgrZtmzjAbxnM8THPclPLM9FkdHjw+sVa10Hgl21fiErL1gf4TzSvBCgOw1B7fMdGhk6wwvWFiIiuqS8fDo9ThKa5LaNdBkHk6kJK2ZDGis+NQFvoesSux6LiVv8A2WZDqsV1l7Q4PL0P3ERDQu668oGUqVbVcH9yhBhZ4CPvvL7MatDjWfMaMwQcSgolK5KLQI9sCVZ5lIt0Zfb6bRx4j/e6qC4DYbT7xlmTWFca3Qxo3i9oZMFILTLxeieUNSoLr0N6X8/hQjoMFy+J5bvjzNarvg3emgnecmCwY6TX86uk8MRSwdesIODkdF9JgGRou5udYea5St3D7zlW5T3XfSFadS9KC7fle642esT2m5fT8oB4FI3YDdmRsOI+rz0gYmdT5nSYD5wNzk8JUpWbgTfYt1js5Ma6r7gFPvfaLQuzzV+v3ONBz5DjBCLoB1gGVVzgCgKoum5yQJh9MtdDaJwHdUQKfxuP2YEtVs2ly2OMxL8uYLdMdo68nBmFmcUWOuPaxzHUhAVupU6aXMJWFrYcv1/sahrYgNnjg8pceY5PObLb0haa4O0WA0EwA7SvV+C4zb7APe5rOcaHS/4S/wAvwClbBTx3eNfMyXMHfhP3gxfF1Y8QCS6AQdkJVb9qMdf8QTP9sf7O0SAg0GiMJsBziVBwM41746gdw86jqygKM7XQ+fwFi11irUNtB3hxrkfJ1b/xmdVYYrJNdgNPvCIyctPp6cGI1izhbdHSEULGvX6ik20G7HXNA3F6PGJFlU6VFdHa6T9ys0HbHwraLZybwLoRA8jL41lGqOJ08awcqzgUeWbTfG0UoeUKhlmc1Rin4QuClTxG7ifeMrDQiin9H+vN8I8Cl/MC7HDmYTndZr/Ew9Rpw6JQhgXa23kyn/B4dEsMxIV2zKI6t/X+kDjXFa7m4MxLixErM0seQ6kohdmjxm1F9YWty4BqstZvF479502gDFTBxEGeA8rLAB45Rr683EXPoSaH2V9C2b6Wpqo5EBqsrzRuYHeLhe3j+QTnk6O/KZgz0vW8uH/Iw8t+l9ukVMOji3/RwYEgWmo9TL4i8U+/SmK6VMGaWcTb7ygIAoOESC5o0H9RVbKN4HN92msHG/U1ZRiOSPWYLkzLPKRUeJ6Ph9ZYtvntmAqNtmA0vJ5n8glIZbPB5QhYy5qWp/qxdFqajsxCLqDJ9PFwwtZkSJ1QjU5/pMLM9DR68GE2Oo7ywT5fmffrKFCZ4Dn+/aB3tB3V96Rq6NGCU659Iz+pxGqbTNlNBACU9vnBQApn1D5HePrRR4iPr6HDL1fZjJjdmivHrL3uYedCMguK2usY7dbmUf3/AGXcEcO7Yc0I+DRbAjgbR1OD1lBbGwAJcs0dUO8tw4zV21gZX8jNdOpmk8hc1OOmLrgoNDshVIs685O71ip3kGdMNH46SzBxDXq5k6VNsHU+8CepDLNUpvSrw80JkT9SjnMGDyriu7CFlBKIUYs0d5VOkUhuZz5YJpKGkq6QlKylTuyvy0hGyK0o9aLhv0l5Guy8XFRraNS8E/1H9um5fyQMJRwZ6jlyhqx2GRIig3L1P3EwTr+fsfdIhVEciaMpIz9xoyoj1Qwux0Le5+MAsv7vvKYEvJodn4OYbuHx8B0mCBdBs3ucn9w1ZBjQAaN7CWsA1WHljWYRKwlAaEy8C3p1XF8OPaIOwwrTcUIraL03CTj+iJr7lp5htE2118fuUqo5FHpLUQcVTAM9jzF9FsufCf8ACZvDwI/FOGqOzHmx82xxnX3DjFHMoZDUgaBTqjhx/SCTa2QBW2bjAWepNMbsrBVWDi3muo0dYyKtRWrZzf0mQOl1NmGhjONT1hQkLloC17S7kOL7TQip3W+mhBy/KJYwak5PE5M0QoT5XHk+v+nhCX8Lbfmzslje/PXrKy23J90ZYQvK4MoLPOD64SoNz0X6f2MrmhRp4vxxh948cq7rzlhivx4yoMaz15y1Lyajs85enDmDzjBZTCTnm3N/1mZ1xi+s502EnA0lcMloIHGM3yreVdKnLZ6fvlNKLvJXnjWlxzSgjSyG2nzMKn6vma4bd2wQrv1nVNGb4yt6ygaOzDbVeB+oVjWZTxuc9ptCOV9ziS+Ma1db3Oc1yr9v0sbqgi2o1Lr8km2NfvGVe5GocTDeHxyqQFw+IffSaCNB47et+YsAUujjj0TOrgH1UfUF6uq9XVjwQ4pUr8JcGG+owRoUvh+3PjBv/OnMaRIANbv+lgmwKR0Yvc7rOOfEmaKS016nEi8MQrjyfyWlc4L+p9mby8otbQXx0mas3jY3IfTXBrzfcSvq7mTZfwLf4NuuPB4ws6PjwPzOBG0QWnerWJuutcAhsXjC9JekVAHFl67iGB3m7JzgK/ctq2bY2n7zmu1MTbKLkBu4heTWHnSLX5C+CVphcCHvMqPqbSpW9/7nqltv3jpuytxBb+Lv/VzhbJpLKTIhTkaa05PGXafbfcVw/svUepkspVUNoRXis+fScqvzfHrCQ6XcPElp7Dnxisv/AEaoCBY4R3hPJfd9vEP83d8xUtqXU25ftKUIfa5QwFy5zPVja/8AII07VZJELuOq0n/ZsJXGxUaANdehwYb5IVXEr4e0tdA0mzwmKO5USN5bVanmWLYLqnf8ODLckxGU6Nsf9j3rdca3tKM4oS6/aA7TgbSq1PFucITwsvifs91QgrUE1vhUFwLuL8Nu8XEddrtofm9CebUeXwrJDfGkd6jmXfSSruHUKDlB5x4IPLgS/O5gRGkefZ/UA8+ILKxVs1rGW+ukLIWFKWs6BD97y76P1NvX2lyt4Y/yuKRfwgiJY4SFEUndaDw/0GSIUjokr++yW3JzKAO+GL5N+sOKezW3F4HKKE5A7t3i/E+/CP8AZgfJySjax7uqALITEXUDgNyUnDNTSv04k+fhzV+ap+KN0wrOg4P72lbK2Yzr0ef8gJNFlpHfg7c2Ll0HCLWqr4iBpQbTBhp2eDBbuALr8HE0ifQFPLbt+XSvU/WVLE2PqSzPeb6QXN9ip6iHMGxs7I2BviawQyWssfWNwdSF8it+kdsAy4HFa1ymyA+tqSndob6RreB934lxFvFjreUZo7frDT/C/pfEq2n4X/Gv57v/AAwiGhxXgG7K0lg6EPbNQG1669P1k/zp/LWGnoduaUAPp9IbsVBaqy/P4SsUrWKnMmMV7wU+/pNZRf6S5EU9oBaV6GNcFPV+m0zJHHn+4ADBkGFcR2YdQbk18Hmek8efQ5m/UglROMX4GeFE0/64MBGvba/7yhYI4ngQhbjiXtC40wrPD9toVMNAisl8temZTUJtW6nNn3dsrIBEtPwpUar6zRCxOWEbekaqNQ5zzLjJ49RuZXpv0lw2gOXg7jNr8Dt51lgtLd9+jmbf+VnrDdKkxR5JeFEw4lRtm+ur7w8riNRDlJqQ7wR/Fy5zlC8lX9IlG4MI7aHdlmwnbQMtcDr/AETygIE0+uMxpSSnB3/xaxstDYAfmJWw2vo8D6QWIaAfimVhk24PE5SiEF0zQmV8Qd7FaeIHbTXfHB5TgtWt15nEmxw6CGW7paf3uS1B5wfXGE/CdyRYrq26adJThZmwL02ZakHXU/5+B+D/AK2jhl10eP3hAThMKmTcDh7esD6icBz+845JnKUEobWle/1vEaJkWXZz90IxGrkbD95ygBoTtCMShxBbGq15Qsp/ifdpLCF6ry4mcVcX7NISppwMfioXb9MTxOTMtIrLbpuj0xXT4YD1vh40n0XOZOjEh9BHb52I9Yu9msR7Jk+Ih92KUfCT4Zf3PvPzAtaORhB8d9guXdb0nqqeN9l4wEpCXNuw7aEubgbaDq6E1yA6XyMIoCZTq8HLjLragxzz8/4pTXoDZ7QjGBmp3xyt8EKcSwaP5XTSWXet+HeKoAorq5q+NVNHgZlyfCPWFVGjonK8GDRo16R0CcwD2fDyhwSYD0ODy94gKZW3OzrQQAO2zydpf9gPA+Yabhly4tXRTfYxU1l13HhAgRG0/THYhmzQjjR1+6R/WijEH569YtEyKvhNdK0vI3857krRWkcLrwczmafi0cdPHc3eUGFeG+uMCtPwllOErrKgQChqUWMwo3c/dfaLGzUmn2/kuUM+o4mQONfun7sj0uaEzvPeXpPkQ+JQJoPRQRv5YXx82V/SAaD0jbfaq94EvjxWzJerspOKcJiqVpINshaOXZxfmZBgUcff095kmr0lv9H+SchojXk5+8vtPmgtOPA9JS872YhldvnsQPxJUa9jXEBhYn7Oh4CIc0ueTxHPzCrsKuKhhqrb+4LtYj9TiQaiWJkSNq76rL0frxDyIbr7p69YTNkCZEhQ8WXG26MYdxNMLzPkmans69BnMrrMzEQutxSaDgzQsajqcP7EtF2sUslGhKHc6Gq9o4de3Wx/PabHDHkKfb1i1ab7RUFyR16HOERxgJb/AEH8XeM7HXz5x274HRfANn7mFeR3VdFbyiImmyed7ylOiJP65QOtNsa+syE2C7Doaj1KDVC9Gs4GcCqOsHMt9JeSRxqOtawMB6ARiaG7Xt1w4wLQb5W3QMoB58Xs4q6/SWrcmmp73/Jgchba7fomrFqOvLKCZebqLy/zddIstp+rLVvCPdoyrqvCw9iK9K9NdrNvdCCgWOoxUCtPLzfBtCgiGsT3hGMujyMSqtzbc4G3vXiuCRaJxuHVBayvdP8Ap3hMwMur/TmTREHX+xVGXWzPjeWnNnPhqRPMdTCcDznGpqOggWeLO3L38SzhhY2cYMFwbPVOQm/HzOaI+57QVW9HZfzD6sfFa/eUF2/4iyWfhf8AhchEnUlY6LXPMXc5y/5dF6HzCrwWftp0h9Wvoz/t3iI9Bt5RYdGbJyuKjZuffT+zHJzxf5LMvutDXLZgyOuabVxmhXcV6nh0mknjuhxslZSu783WO0N82jhekQGfhzVyvQhEgLejPF4sFf6FaAhwS4/bPIP8U3o+kq4kFKC2Jok2aGhr/Et74hqEv7rZ9T9kpQ6bVKIFyMLx+5M27tDt7h7kAlCOiZI9AG60QTB91dQ5fzw+Yrdls+hmW2mfMYmoIIGBeJFegjshXlLaFabp2yfMG90dufwmPi4wKK6y7HLMGXL/AM3hT1SiY6Hgwvpw/kDkUw7HgeuvchEXnN2HodvaBiHhUHeE5Z6/IZgS0X3vtPmbd+izrhWhLt3KpQdVhiaMrx4cespRGiuIHVAzQrcucT7sbh3wzfuSGS8bN4u6zcr2lKn/AE27DqIGxpOWHcVwDdmTjU4bdHXXz/vU6j6WriQahLEyM32Jz5iDBC23aD0dI2OjnyhLJS+5tBmVq01/Z7yhmZy7Vb4ezNAEsfFHo+8XBi3kEaHvow1l1NH6m7hzLeSZu5dh9RmU7rR9IzY3O9Rcp47BsH3qAtQNt66TedokasmNqvvN2O0K1HyRW6Q4E6zjeSc56Zlkoe9X7hhV8EC3n9IKNsmQdL+CUtebEpOm71hVzGae8zCC9jiOkLRVetT0Q1DaPygP6T9RTV+z9TeeP+pfjByaj6i1Mk9/M08/hSBm5SGPLDQ+WVMDdtDobR9Jzu3/APA8xG5P64hBdMkOE3hvRigHVo1/iPyI+r1hgSFiZGUYDDOPeLlvWe3vMhtfrj1fuYcC5d6o4jrDgMh1T3GEImTf8P5D4dZeUEK+kMt554YZoeog+Lz4TYdez2Z8YM9yZbnRcv1fL8y3oeEE/Whs+DOH4SGivYI/PCzYP1bz0dtD0qeuJQ+YDz+g8uJYhdDLOFzgJEs5jWWVDdai+b8dyVtVVaQJAWidmC4TjErwj6xmevQJpPQVgvPIP7mJr/cWDOdwgLh03XXYOsScV63+X+4/wKRrafNOEL24lYy8E4xlUK0+DtFoV+flQZ1+MTCl2cjg+feaQQqmg/f9lymttvllSANAxTxuFeXtA4dY0GvE1d+xAlTQxw1K6v3mAFNwUvhrrEwFKgvz4ioKnULe8F0db/U4ngWWde2nzPtftP8AjH7h/LP3D9vR8wt+5nL6yfiGZ7kt9440yX+CU1p0C3rbtAXDUtvwENFXXbP9f3DkrCt7o8/1CrtEHOxji/JOJxxyDZ6TRuz/AHI75wPYz1JDiPqyIOp5RrPdEBs9k+I5z4A71ojtP4A9LTHI/wCo1nJa41/8lNIsEweB3Idea0eK3IpSmOcuF3BdDvKXs+BGeO/eGDh5L8mgy5U2UsDqZy+8Di65R0OnH+zGh4q/cL206iqcj3npiT0uEvgbaUX0JBTATJn+E4sbev7iDXDg1p8V1j5swDLv8e8s09bGeFwwaxoq+Wst8j2OjtOcGgUXIN2CrExor8esEoraG/yB6KaX12bvT0iP40yX6l+s85a9XDXKBoBi5Tt48o0LLs5Okxo2mLF0sixdf6grpTK7Fwv7tDVsvHPJ5QbVWy9mHg/wodSagesf8lDQDoIA0/8ATX3rnFcR2ZddHMfJv1JW7xiCZlwcOxRzF8efBiZAXV1fdicLOnV8qceJvVvLp4oiAUuQe/dyhZtsoZR67kAdfwOd7QPAmeh5+kHY7ToO5pHyhxYDjWrBJBxmvYEwwsQ73+5/eZ7aExzbCm35lqKTggddKl7OXyv6gOXTdgczYioLUL+De+cszJyKdB3YNi6hkXrKyu8zfJj5cpVTlrhKtuLGVATa2miOuiBhdA93GVHw/wDhgndf3GGWbV7FO+oj4tzdW6cJzX27jlBQuEVAi+yX8i1uCUWdSXkPBceHMWveN49XGZUzuFPIwf2Sj2EerpXEB5h0/iWSJvj5Onaaclsz6nzM4uEOerNFhijTKJu820HJ+5pW8Ra67s0k1aE9Q4QWG4KTXfaKON9TpXCK9OKyhWicFiICrz48aRMA8aTdcVquKgFJbzMrHILzz/8Aivrn37d9mIyDyHtv2lXA61L5gsc2qnpB/AOZcS5oIwrb0n9AuNuYdMTZroU/qeL6DEPaI/KgKjw7tiVYnRrZHc8QPibb9I8NNpx71zNPZpBDljcaJNc5r3dCEa7L2u7eUlqkdh/8eu321Do6kYdH3rakt2u/aYyQjNOJr4czHcxS474U9Jo75ZvWZjobf+JFcIqX4SoN0gmJwuel1DMBwYz6uIjHXZ6E+7v2CLZUcsonD3js/wCJz5wrVuv/AIdv/Sz0L14MxT4g/ZLZZ8l6mJo84tSKh305pk689xVM2a9RA9Vx/wBT+5/1v7in0+8X0GXaToI6n0E9Voli6euWEbMeJ2hIv0hhTxX2Mwo48gUPrjACiv8A55VcAJc8w7D6qjkxD1j8xnvSjYnqk5e8f3D/AJX7gMDavh+4LXsQHrexGHbrB7SyIeJv6yiN4BX/APhT/9oADAMBAAIAAwAAABCQAwwAQAwgwwAAQgAwwgwwwwwwwwAQwxwAAAAAAAAAAAAQwgAAAAAAAAAABAAAADwAAAAAAAAABz+i+OwgAAAAAAAAAAAAADwAAAAABAAACQ6Ot4zwEwwgAAAAAAAAADwAAQgjwwAADyqZtkkW4YtAAAAAAAAAADwADwAxXJiwzz4xUB2pbS7DEwAAAAAAADxADyGEmTcn/wAYWVvhvA/EJeJgAAAAAAA8EA8lLL7q4x0xXStyF9qIrJVgAAAAAAA8UA8TUcLQGLc/kHguAwP9ep0hAAAAAAA8EAcSM06I8azvmhPD9cKzWyFJAAAAAAA8QA8QMkFGfKy5lEFpugRsalCKAAAAAAA8QEoMAD2c+USTiDwAGWO8m0xFEAAAAAA8AcSeYY7/AHA1vgN/+o9IEiNbtXCigAAEPFPPHuotdpomvLEMoK0rpGNzwSXGgAAAPFIMdRLDS2S/mRZx0rvyXNayjkAvQAAAPFEznnEeJEk1q6MzVRG+DSCzD91YAAAAPPIKs5BzfnRWygIsikbZbNMYxnnSAAAAPPHWkI4kg0V8QfA9ulA3+OoGzxoSbAABPFOFwYz3ATLzlQ41zLmWNek8njfR0bAAPFDkNNVua8HP5zT2tdpqP/S9wyM8hZLCPFCDwQJU1YwIMpGd150+8yGU+fw+SRTbPFDDSWUECqBk07YEyfUzLMbYgOoMKpOivFNBf6G8rHiG69vRBhEv6inAH8hG+pseIVFASONTJ/CDGCf3lpRE7Odp93TnXyKDgVNHNuh8wTWGAhN36dHB5KWBYWVOuDBGAwAIAANNaM/6npAY4xn2T/57cp5hqdDFSQAAAAAPO3X6REOf5T4Mx1Kxq9arnl7aPAAAAAAANGNOhCplBfFbMSx3UiwAMAAAPAAAAAAAAMMMS9hcrTFm7wRHjEgAAAABPBAAAAAAAAAEMIDA7eumjuC8XwAAAAAAPAAAAAAAAAAAAAAAAAAAEMIAAAAAAAAAPHDPPPPPPPPLPPPPPPPPPPPPPPPPPPPPPP/EACURAQEBAAMAAgIBBQEBAAAAAAEAESExQRBRIDBhQGBxgZGhsf/aAAgBAwEBPxD+yzOsXhXLiXWPP9aFDr4I7zZnVwa6XbQjyf1QhFn/AC3WJxuB3q29m8DIbQtGP7xV+X1AicjPuGN5fhoCOx7mU68BjAXawE5VkcAuMdUDDvJ+7FSN+T8jfbxXiw9PhJyWfmfrsu3Mu7FsFi+5Gn1Pkl5Mb7cWQ7+3Lo/E1wfIE+GOgsRzrZ9xZ3M4PYBsjZGSM2Nw7I/yhDmWY/GupJdP26H4gEw3mbcAYEIZwLAlnGymeknJe5XQJ6nl7dw4xJDmxPq2g+Dr9gV4tD+S67AWHYHLVBOp9sHfuTGM8gq+k6u5zQMIjZBTW7V2Ap3BK/LQbkP2H2Q1MNynaGD31EcfUmCt+GCP+IdLd/zCJGccLI7h0WylygkEH+5qF5Yap8J+w0PZ92PgloCIV5PLQZwINs5m0LFPtrDjg5ZhqhcTW4FOL2RbacbdhcUfrOvxIMMGRO3W2jmCUIyUdSHllAGQL7JsHjYfBhKwB89xjkjwB/5ZG94ReAgYfiuskWP6NLgjcSW0Xy7RsJfbGP0hXAh6IdAydIPuLA/9RE3e5POYTU3V1TLyDBydzsmj6ZNLysdchvf5nLHXF/JYsTq05GWMjR4udd7jfZjxsuSOW0brxlv6FyMdJCPTHvG34blnz/3EA79sfoT6Iry0OP5rkWrLwbTloH3cak7HM/0uMjIrNCAusP8AciNMlhcyBbjV8nQOXBjZickicsnt5QdQR2zIjXSF9/oJWwPUP/kGcyFOQ+4LpgLELs2whN3fcleRMg4OZ9bVpRniSDveyFg5W43qbkmyvfEmfoRGRn8/A3b++QRCxInZIK4Mb7j7xWGON2PpZPoyFvYEM0B5aHKEXXBPxMueMIPbZ3rGFA21m5+R0E4mWjzeGMRpk1J6yfW+BeWMOqZNEE+7uoS6EywwufzCVFx7BkkmC6BAk0YXhzGOZomTFcjXF5lhNfaA6fiOOwBEqy8WXHv02OeFyovTZ/5gScbwCVhmHJvTCtj0Z+5fdkk9xUXEsowxdLIcty2Idxv8FwTBf4nNc6Oj+ZZQzZ+n444oTtg5kQJdBt/OHs64hsjAeNg3nLHSdX2ouiCZ94XJmsSzD2XKafFCderoBx9yGOL7x/5aPptd2vy/gHOvjU6sINXdnnHTn6uhURcWxkGoBTsYhD1+4nL66g//AEgX7ldo7S5D5sGeLpXP8wDfNt5OJivctsFq1agE3B8uTkgE7ZzOZaOe7QwTvYHG8P3Kf/WM5/DPzWABqyfe8dbh5H5Eyp7KOFZyYRgXAM/mhuUYlC7S/ktffiF4jHdnTyOOHwcOxEt2Ym5J+RY8kI4epTR4+rjHhnLmyCYnTMbnHUOSkQ68hWHMoVanVrawXPjcg304gep9q7B2dO4UgzPwDiPQvdaIuN3qQP8AmY4bkxje9PqDwzbSGmFyZcf6gBXt/AQD4OGc6yDfuPSScSC21mFx5T1v56ItARNqYxxGScdrh1ntOJfCJyZb/KX1y8Q4A6sjPRK9IJ5tOiRwnIcLiu4tb+hDYVjwwdJR6tnHUcdG3qusi7l2BbOZCse7fbj9253zD4cQes0BD9Eexguq+BEZuWry/qFHSf6ltncjm046gwgeHPw6JnqwecwiefEjuBKduRbT+ioapTg7b5D/ADcsc/4u4UhwkL3dRA7CwWh0bHDDJLtzav8ASu5Qu+bxNp3QPIHyJx6mwrpktq3+yf/EACQRAQEBAAICAgICAwEAAAAAAAEAESExQVEQYSAwQHFggZGh/9oACAECAQE/EP8AC0WEI7J/nUYfcLDPjrJomfynAvK2h3DAttseEFPKXLm/wGIIlOQvUrt+DiZxtzg6R7WRyiB2KD4Zm5G21kqUf3sNhCCfJ5nUxR8Eh5kwLJ3g3a8kOpqNt6fVq+11p4uyXM8TvmeP28BsHwT2k4fgEHz6hMHCew3v0O6dS4MYLl56SwM6ey3snsey5fEGjn7tYMMdPgIu7Dp3epUcswdYH3WQgnjMDbmtqdlssWyLYaeO5Hi1PaGP9yA9I4/UhleRltwMTHjTxJj3Jlo17JWfdxCOMjMXJtmNgbnG3dZAW3N2DX9okccV5tOMfKwPjgHgbdy3CSE46ZRhP1cNxKj8+ppwZF1bZcFswWqcX1ENdR3d/wBjH4MWs6ZCC8Q7WqH4zSIuT5vCfB/UrdsuBlyWDyWFw63/APpaHPh6/XoNjN4YUl83WnkkGcZXYU33G++Yu90ioPTY2k6GAMMx+B4nXbB8hzEMEJot4z40Id/QuM68zB7TS6k3iyz6udSC4DqE4O7KfBKFllxciePiiXBHEnkDkG7b8qUdtwZmDv5DXbOfz6NlrvUQfIcWiX9iRxELyNt19ogHBYeoHi7iAQ5LVLRGPcLkKke7Ka9kA55ZbzaUJo67r439GglorsnEPZ3ABLDfU+AjO7m3My4SMgS5thTt2UciagEoVOlsOmh7ALTXs3px6jTmy91kJbyZ+hMk2g5DpnogBY8EqHFow2HcmtYQ4CdziU7Z5sH124CTw79y5Sv1M1XD4spvVs244tInFyAfpPQyqHF6jjHP7tREPuTlnAc3tLjoL2yreN2SvMJCkeZSvOavcCOxtnUa5dgJHghATiIkv6/PlAMTiG7C6F/VEhLyR9kDojXhYHnlkGEmNmvBt/0kclBB5kn+hh98fNlakHBl6k4V4s6d3mwIHuJYQjx/I1c7kPc4h3D7LcbZ2w1wGydRrmTRjbwSIHRO7QYcQnu7zNcsgqNPfwMtHGkAzO4RFt55nc9zPPcqcQPd5ngsH4n2DPqyR0WBwRrrGf6irkt+GyyprY6EIp3r4E8jzLWcEuQ1R/gk7n/UHbuceWVG8oUIO8d7QRNG0/HXmGDlPwEceLvgQBKtuzSO5I8OEeeP9yTtB4JDtkeLiC5L7nODS2PraHVvPV3Pm3bj2jEdw7+H2hhRFDp1ImZM54yeVjcy38vBPihwNpCdterh3lKWrk/FT5eIXs23uDLB+DwL6Qefw6tt1lpWIG8RMgcZ+R1GLYp1faIcWF5xh/42gzgs+CUuXJIX9bHqx6gNizPjp+GQZAMZE4sDTuFxhjyQv7K5BbD8M+ebeZxeI6PlMfGhjnq1LVu3NjC82PF4/NCYymkAx7sVzGrh7n0tHcB8XM6v6Rnxf0+CBaeC5e48yANmfq5tzzIO7fD9KbxOOlwdkB0/GWZGS9fBuXLnmy+/hcW2zvudeYB+wHqBO7Ysgzn4cpmz8cr73Efw8uoSwlWrq34F5l93Lgjg/jZ8a2/PNi8x7QB1/hP/xAArEAEAAgICAgICAgIDAQEBAQABABEhMUFRYXGBkaGxEMHR8CAwQOFQ8WD/2gAIAQEAAT8Qf/3qlf8AiuH/AE3/AOmv+Fy//wANf/bf8XLl/wDC5f8AFy/+V/8AuV/FSv8A8I/9HH8FXLSF/V7+Io3vnV6aX8QyudP0pY+Wap5EnpMS8QZX/wCwa8k2JaBlKwFszYNB0F02OcraVuV5iglHatHwCQyfEH+gE0YOgL7wMLrJK0eXhPDcPh+0DdpQvqvUUQDti+VPyYg3/FSjr/2n/fX/AEOBgI8sQE2vDbOzqKcWj9A6DwDARAEDlUwI4xjcyu3GBdvdiOuZtviD520/CepQS2qvsKh8YgHiDIuwZGUJ1TK10G08XcE4vBZb4MvmnxC6CjCNjOMfxWP/AFn/AJzqERTeeGDzSQwwV5w0nhMjAF50yhy5iNeUfkn9R2P4gYSZF2uxwj6j2EO9Ho4fNzBphorb0cPzT4htLqoQl5Vif7c7sEC/tL+WXYTwt/1Nphs44GXTWn/lX/4NfzX/AFZbLHaQBbwYF4yjuGulgIs4agPNJibrhHCI5Kc2OyZVsB+BcoW5P2i/3AA3ELKI2Hp2MDVQ6NfBo+JdtT0/5iS8tO/CE+tTYHwX9gPSIGd/IEe360UvPKwfLKeSyXie0G+ZieP/ACcP+ipX8YgMoA2uCMeqAv0N/wA1KOv+bEbBovUPA6esoi5UUGgB1kPQpA6obU6KN1TVZrOGHVgpEAbEciOxj3f9KX9QXmJvsg0SyCR3Ly7AeRl+i4maE2hP/iBllpf7EIPJqiydlZRwiTZsNmgwgNPtxAlIsBl4AHxFr9c48jygWCaWelXLQXlJz/5OH/Qf4X2jP6JzXa0HLHBPISxp7B3ddwvh+aPiT6IuBHA35FDcbAB0iK6Ox4uzxGANRYV8OXzT4hEURLsbH5/hlf8ALMCy2OkpGBWSbAg7Ay9jfDEDpSGiqsBLKNDDpiS2EqClH6440xCpA3QOIPk+SO3ommEBaOzvyQK3A1UKQauP7MIR0BFDQC/AJVbSoAT2H7LZ5ydZ+wcHwEzIAdoFfOpp/th96jJmyoKcO7Y9OrQ4qbLrL4l1lvtf0wua04sKnt4rbBxjMxEOv/WSI7kZvRzWVc1HvzqjLR5FsAYNCXyJaMLM2ra9ltYv+pmX1hge1oyeWYe1Pt0Ch7E8yjJgKaJyck35NtzuhN37pBJi4Bt+D+FIEFBEH2H+alfzY2rs/hf8y5i4gm2oqLG1GgVyrDAuQjKTawyd+4lZZu4dQ/JNdMSW7y4HxofJT4lqymA+8gSYcIbXrqUDXocnl3GNZR0KFqvAMq6IMJiCpS7Sb+PLtYSMQ1CvJwY20dR2Aqky0rKMfB8xofli/tuviNbcLXqZTsVGpuTJGvceIuUQoNXiwsXKWjtUI3dzTnIcMFCYNsRyM3/6T+CcYn3EfqEiqFTCAv6oU9QMrBgXH4ii2DzF8Q+xP6mzbMVFR2D39hH5Bmhi4vtbT8viUe6gLo5FLPSREcKP85u3dXxDymm875Bb4FHcA+dhA7Eww/lmQ8JDaTJvzFFEpOILfatJs6RwPD8RAIJSCp5Mt+bs8wRfMML/AEXj5E0NUGjyBX+2YQr5lIeAIPm4W0vjFPp+Ezm5DVVAEEUWrikxdTUCxukuQ0HLuOxouuAVeX/+EELd3Tvlgm9ksR07gN+kYWencCzw1KaywfgSKBgwJ0DD8hTDAFAWaBIXQC6jkP8A6R/FMbG+rf1LVhXDIfBep6I+TsPZRb00/c3bw7jjGwpe1v6mSgC3xASVeI2WtSvpBE+I6KeqfSKfk+Ywou47DqyxPGSChlZwTtPmSnzMCVxNff6ITzFKvAUesc+JcIpDov7S4q02qmfJiGo4hEPy6iYgWDLdNCxoPI0ljA0iHl0w2eXh+c+YyAKUhOTdK53C4qOEPsMHwxSghw/tueTWwP2Go0NG3RWhDQvivcKxeycGUzmja9jAdrCx+It75jMWksl3eA1FKmmzPuLq03yn8sathAfDF3sjdABahLpxHE4OvQL9MHFlyL8CV+blKRTRA55rCeSvJ/5w/gnixCvnETGPGL8mqeLBmWdihhxOwWzjBltd1+XFPImR5Iob4Pr/ADhu9tXgxBQRscnzC+YMUjNbOR0RGqDptj4zF5JsH3EQ+aQSekqdLF8wew6wexpNpPCZ96hCiHGInVphiW4N2l/ISvohnD0VzYKQI4LOGdkUav8A+GDFGSrkQrmlOIopuQKV0GPbcIB7Diehk+SWBYN0sfZ+mGSNCjhHg6CX7xDtEB4uhTw7PEULw4f6is8XTHSXDTAChriWLyrgQeyvif0RCqadenUsmJAgAaDbnBKqvk2jwH7XAQsBRrpEwy0uHaIAGsebIQbWV4dP5P8A0eKH+cU0DvpQwOVb4UJY4IA2xQNqs15ET0xZU3u02tnjmBZ8KiopM9Y7Mk3nLpPDkgJq0eT/AOQC1R24jMCLyR0QG1lGpsqA6tV5Tvgm2UL8IOK/Q9QGDsDA9ETdAWjOLC6+anyeJ91UUCM7J9IF8saoFhuT5sYlNDowfiYgGJyZl8CXJVkKLQUFxi6lGJ7hbqO07PuMNmn36EUC6AWfOCXtMBCSq1Uy4SvUrPhC2LAjWRS+ckBX0Qa8BpHv5lbdzyKT8xjjTw7otkVzwP8AcVb6Y6nkS4bsl4OkRitGfn1BMn5a90v8z2P+k5lodR7wJ9MydW9iq35bR142w+0f+/h/zP48qH+UAKMSkAVBwTVGk4djFK40bw5QOTYnsYmRi28g0NVk0MkYErRfJan00nJLXI5GVqqNW3MdFJau5SFIqxaENKlDlyyut6yvYbCd6NBNmOFFXsdB5pz4me0i22J7f8B4j8CbAB9H8vQskuRzxHCVxmPoKVQVplxVUpxACwB6HeeQdsPEokUC0OJRf/ZTOtUfTQfbcFHcXGwq9gOb42mU+hfJa7VmDrMtPkT8XHX+iRP7lC7Xf2/3AHqj9R2cyxjtfJZ7jWnJsmRZavAv/MTvzx1aH4ZRuaf0/wAME7RV6c/LDpcVD4/yf+Y/jyi/bEZLyORhp7lyJ6Nd9hydPsY8hlsA9hqnsaeyFgYFFp2uFO6PiMPvlvB6LT579R5oPG9mn4wyIe7msCkG1wSnJtX5DlzoeLR0xKt4cj8IbXhgzBZDdB3yryvK5ZandUyodOJQvOJQPPMFo7GYNQ2vDklL4SvNg+yDAmg8C293hgr6nHwCAeFaO4G26PzYa2m1fmoWxYkiQqpmqU1HYKDEVg74t4leYa/hi+ffaH9ytXX5z/iMo2L+CApeHDEdNOSWVbYQGEh6agENJXgh/MbrufhIajL5/kLH9T6q/wDMcP42+mKfo9MVCZIAUM8zfxQBH4Zo9F8YHd+vtKmYAGxKC06UxUqKc4La9lQeuth/kMTcoiLAmld4eSYDC1BTaqtkbtSl6lyccXrI0iOkcI5Juecn9yoPWYh8zcQ5syQjZVDvEoYfTK62W3y/otKiqBb6GR+EghClD0NXwwKm6b+ySwulPzf9x3HDPKn8MVEWA5E/Edr5oMCd/wBt/UUuHA+COr84iqQfPMVFWiMQN1K7ysozTXtf4kEWD/jF/cNTqD5o+i/zByNo+W/+Yfw69EbujJ5lyyBY9+JkEUlOnT+Lhn5rGdYam9FXeqLPK/qpeBnfb8t+ll3MBBT9jVfMM5VqpSdU5PJmDU0whoCubUvNjDINjqEA0lkWDqHd2RF5tSixpP1HCAqX9yiH5iO7RfoU/klBN1hyA/FEsaI+if7lg9L9EN8so/OMxW+56k/iYzsFsATTK5vxCq2AcvFcDKQbAF/pggLRHQr8icI+n+1AVof9DDK56l2S3jAluV61UiWW0NPEUBElIFhaVwRq0RRsyWn8W/7gjF44P9Dv/v4f9Lz+GWXZkiOl5Vx5lllbsHPkiWQ+EX8Mr5paXqv6kKLY1oA2pANW74IOn7R/CBfFxuKKoKNszkTkiCwqF7cZGCfqq4CgPrCGWwkdqLvsLioGw68P8Nhp1CoHeXxELq3/AFBEqCzgGPJT8Q260R7X9TOjeEAMhRhMQdyLaHZrZ0eZY7a0YZWsCer9webUVYwR9x1V2g/H/wAxwCYAUSC7an4FWPwMUmGz/wDGjluHKD8pCGQ4x/ysAa3Sf7AhwFW7SPrEVh2SeRJKOVo8w2TQGxOaf1BwQTQod0BtA4D+I9hk+z/5BM8AexE/X/fw/wCgwHrWKlEhsWtP6ly538n/AMhvmyh+z+4rJ/1GGJdZT8rDECHpVCDgLVAXSClMSVZDksw1Uykg5NNinkoX1FHdMexH9zA8P9hAl4Ap77+ZmPUsOY16hFf80Bt5uoEUeIJwN8mSvxLq1d8i/pl7ZDyUC0VhsWoMGBArQUQNqkrE8AVeUrFee6hG/CIph0NHKbIb1jCjfkCJsrSF5VsrHK1DManAsSjYW5vEP9GoIMpbrhqpVC1dWy3BB4xdC8roDavAZigisgEvDsL3l4jIqbVUnLZXvBwR8JVV+bssFdGZb7eLulvEKX7VH+A14H+JQDYjFYf/ACcP45RPM4X1ctVeTcqJ2tw6FwlJ0m4w0Xe669Ql6Lh8MuYtsOkokGjDi9Q7/IMLaLgQ2krKVFkwAOmrtSII6D+VqI//AI2X/UX+5msVNdRF0kAk+ZksjxGFz8xGZ5fPMy0p03pxZ+SXk4b+Rr8x+eF6vfmFCkHDIipssUPeHxMOgOq1LEm2qrcYv4jAHvFNspxX1CgGxuUXanxiXLJAT6a/NQB2giBsKoD2yiA3KBPjfBaPMNvApqybAFDxTzAHWve8DPy0RxbiXX9AMcErDgl5BRXuC76gBQ+6tvFoKAUWI2PzA9a/rP8AEL+TL2Y/8g/hrb4BtVoDyuCWYpaU1rWaiA6aSOxDdJLUcPEcbhNPcLyvyCJAI19wf5RZPnIFh86hzIuyiSuBBoaLioMcvb2yktjvwLgs9H+D/UXQVPjv5lXZL8Nyujp/c1mWcNmYA08waDXcY7KwfDbAt8KPiy/xB4L5y/6hPhX8dTDQNXwpK9FEdmrBQcbhM1B6/XfAooWqNtPiFWp8H+UCWiIsrhB2+YiK4qzEoXV1ywgntXpplUy6Loeqy/GHbCjsWCWeKz2bfMxwespdAbYuVrah+HIerfMMgtIse1tPqGiBr5Zgx6iRCmmIOCgWXBue0N0xS9FC8Rrbmpy4J6/EgER6ikNin9StrgB96f4V/wBnD/mqKOZHRdoPtgZUvLklqUlYi9p+o6Hu8XDKXpg8iZyWqFX0vnf4LSDUByRY4/EE+wQ/cQfujUyZ7mkcBcQoVbeLiSzRmzETxRiKA06h4fRBG9MO38RC1KPuZwLweIgQa6Jt8IjxUUGxXsx/UMvwy+EJBfzqERhBsRDvEYqLl1fPDOODiz+yUgVPIRscVdxW4Pjmil/JUXhICRVkGtOO5SChtVjx/wDJXB8KifWD5SX2t5ph6xHpZWvKZIQ+xPbCr6kL+1ag8xkvgPKwnRQ5IisfF9kxwQTIAAAoDQB0Er/QK7iTpFjoircwLWAB+cP0kJ7kezD9bjf80df9R/xH8aSyG7L/AF/hqBtLw4+ZhOUs8vUo9jBqWBDTuDR6hIbUB4X92NDYcStDajoOIQBnd/hhCdSf9VrGPAkvVpgQni0X7GUNUVj/AABEOSez+jGFfav7uD6+o/1Bf8Z/iWb+Gv8AEau17P8AEX4fk/xHlG+T/EtChGFAcDg+IlFgPmkUfIRAzSP2gSvhiBZXfKqVWoVqtAdq6h9+00fQOfiExaA8JT+4mqBBhLq3QbMuoLe9HoQB6Zq+ahIabs5eDRggAygADoCO7AbXXyy8OfuulMESuvpFLwBi3wXAaVg0B4qUV4PmaZqhgI+AAjp9bwg6ens7eI8NFKbBLC+wt8/w6yyOg0X9ECJSWJSPI8QaNK7tC/m28n8K79RgtDQA2q0HcbJ3wAB5tV91g7gqyYMIPmmvqcf9h/LcqU77bD0t+pScCfgA+wi9I35IxOxZDadt/wAAdzfGnafcprAUnZQtrbVAupbsKIzFr+i/dQRd+IjcPllBwDTkZPSxzfFOMZxdb5gZaHTg+6hMtaRn21N17n9bK9r+GXyoIC2fS/tIbZDsChB+qP0UHeTsGsxltUqFdcQ6pcL6YkdV4Qt+WIYnNWPaWP3iJDa1VATdGgcZIkayaIaGwAlmkl4TBYKHgPkrPU0NQAXwVLwrJkCOUzzZOkLr5qNcxgX5A/2srRVlUDumaruKS6Zq+VNp3g8wei8pqadFUHgVCyvBeV6Ayr4iZBui0fafoxBvcAH1lhjEDXJYfA4fEC+pJ0sJ5ER8kZEO+Bz8CDM7A59k0h2CmM/1TXw8F9z4gIlmmGsGEuwJ76OmBEJtqog0PN4WA2XC/u9KCoxYQ7qjFS1vHun/ABX/AGH8iNlYOsx/lRejp/1iCHsiueag0ihpPmDNSsxLKj82S+EfglgRrLy3Rv1LQbpYF7K1BUEOLB/AyhgzhhhKgAtBYnwyqBuzdVouuK0lHh8Q16NEo3QIsTQbYvV+0A1nu4mr7lPGvv8AcQpyYh1+TfVD9RhmkCPpnJg9QCr7QhNJajs2n0tQt8t1RCuklmrpLkGt1gS0HkynWJil9DS/Fw4D4zn5yVHx7jeloG/gum3LWVj1Ag8pkR8/uIPahCvKuA7XBFNB02PHZpR5o6IUBTgBQFGgDVTH0aTl+Rt8HzGTe08G8HB4Mw8xTC3eQcvghpidQdET8xAtKxLJy4VeXQZZeu/Rbi2reBT3DiWSKoHirJ4CWQCSAQLEKRORumDk630VWePHkzLkVC8xX0DDQeIbmohmkb1kDtgpQFkdXr8f9hGOolEqwKyDEXhW9wcDZmvPJLxekxEUbOIgLM1Uq1uJiA4Yenouorn6WX9oW7YR7soGXoqFNFthMksAAjarUi6ppb6AQ1IFKfkBH1FFgAIrpsceVQB6BJMC6ELuoIGE3T/sQBaPlP7gcArwD9rEO/gioz8n+aXqcJax+kayHpX6QN2vDa/DE1ohK8I7DhjiCrkEORWb674l5gigpY6YJS0s4i/6NB6LwmniNLekTNL2pLR9kQwrAUm0MqLzRGB1nLfKqxgrcnT4YjsAVAK38vC92ga8LQZDK1408BHVCHcOXlwy3E1rfgNr4Ig4OWA9tPCG4KwTYLvhCj6GPyRj8Wrr4qdjlzblgs4qQFsOlaA1thy6QZrtXlXKu2DjAw0EDEwS71xLNsGNtGE7DI8kTUiKYTkR4RyJpzEicElAwUMA0nDkhwqAAANINl5r1hlXy0WvgASvRLloN74VR9MdpRFbDRdAB0AQwf8AcsJDKtiDHptMaQusUqB9ghgbyE6rgX07PEMgeyVp6cHzCqcm/wDP8CWXKOZCvkkMq2qve4N7Y/HJ/Ut1HQ2JjfsB6htUO1wBZ4ckuWelr9n8eX6heG8j9mcGHR/uAUDs/wAbHCLpT8WYxQfNH+4Mwz0F/cNNDv8A+0Dp2ZZ9RBX4t5YbVK0Zvs0l7LXlllaqu1yspOB1Ihou0apnZg1cb6dSeWvuFXFvFVNMJX6lAVirh/ctWdMDJOcAEdU1YvW9IPl4a2ymEC6FoSOFtIt8GB7uBVagAHQFVMtUEgfLGn3e0nwpb8RNUFWoc0TZNDdbYEA6VrnavK7VmdUzgh4V64XniZzVts0c2/EYWjDVatTsdPDmXGiUaiaHAcJK2k85lwdmabP8kIvfgjROS3QHatUSxYkBjVQL2btGFA5jv/uVhKT+Qz/NyMDSUPIlJD6Xc/ZWPy3C7Qw/0ywHoXx0/EG9IfcThePUTEo1PsgD+EFVvVlyiVPqJD7UAkBtqmBIygWrIoQHgQ7JYWBclZBlmGYzstlQ6vL1FIQMlHNeRgAjC9HMQoMpqDWNQwi0t8n5lyCLpV+4iF5yKPtqCD8jX2lQ7C+0/sSgCGbBA8tEaODIG+WNvFmKUi2UVPbeebepbBsCjoOg0Hgg+dyqPR2vRGHgba+h4V1nzLHWQHgx6kp+4CwA6GCWcKGTsI4UBegtD448Qi1bKC1VoA5VaCIMAAwOhKVeGqLwQWtXfFuKyLOdnEtpBtBptasjloeZd7X5Z0Zm/wAALV9RtW2C4eQ6+fqBwrkG+gwCXLnXmFRxY0GtsBKjRfO1OLXast+Bh0aU47PPEq7dosPQWr5iziMMgpFaHwSs5Q3i3Cf1EbFLucgoUQWGB3LpIKdW16KzgNc21GyBqC9LPsZl5GTYGD6SQgAUGKNf9nD+OYbCU9PY/iRnEc8RZduvYIAfSxJ4QR+IVR2RIs8T2dfEu0MMnnsgyXLW914BAFxVe+RJ+YGWQngA/JBOTAnhVnzHt7woK/KXCpELu32BI2WXf+S4KtXU8j9EgDHSTjRKJ9PpgZqZoXhrfXXiEomDPLd15hu3nYPKmA/MoDUzaX5ML84eJaEw6AA6AoD1LGI7EDfq5W+zEatWCg7YTCXAZ0Db2uWX2AUU2LQoBaNTYYoelgPrceokD7EXHop4gVBIOAWA8N0vUAlHGuqty8QGIFcpdBB5Kojw91tBLp8mnzBzcWZr8G1vxjzKX8cI9RtOc2xsDko2VB1W6KxGKBlF2chfJGJK4Gw6PPniCDPLnuWhap2y86bR2fk6PDXmEb95bHYWj2ztzYafez8xIKbF+TEtD2wfbiCWTgQn4MXEcAwcoX22A0liX/3n8MLTEcAWswFih5V/TSLC2zXqPQ5C+g39kqEhVZPQfiVhRvAz5P8A5D7QmnOzzCq4Iq9UWxseQ94u/mKdaWXxj+JYIpAc5A+V9whFiE7yo9agytny4I1WtvbLHIX0SmtZUm3Vvs0g3PUhz4u8mTzCxqtcei1FpZhhcuVtLB5YUwXsERTqqD4hMHtpt8qpXyzA88CX4JFpyHJd/Jlv4Op+QIyVh6t/zClYHbj8sUcwAL9FsScoCDO0HInVyz8ieAXwFRU9owb9DltfqEigIu1ZPYZ82gJscUJwqCC7wI0MEE67atqAFVbAsvmCrVWn2Vv8zCjVG7bEeG9VE4HJEDHVD8JFetgjTUqCuw3VKmd1b1nhRb8VG9s2DPstr8xEVZVAe1xDF5inF8uh9zNLZBwPjAw5LHKlH0alQE6AQBcLnoy/2IDQIFoDaF03k4SjHxGRXDdFu1+HDL/7iMpniUC+A8uAMrHaKpoeFsjjZuCaNU3ASqCrlX6UJGEjnZGXZi+OoBw5nPR+yX4XNEoFA6DB+pWbkqeHfuZ1sOH1CtZBZ5a0+ioa9hcKHACUnIoymwKAysORlJ7DSgEEqwL1DKmCuvZXBFoCZaLFUvTiWwngj8E3nHzKL36hqBN2H0sLoRcflaCHaCOQXyhbGECdKX/RLksuBP22zImdg0/ELZDa7f7Yh9qBqsHJ/ZMTafGDA9Ooa3L4kfQNPEOsC5TXMP0dTPxrTApYUdj/AJJf2B3RP1UdpF5yL66JyQLSciBD4czVEZXHqwyxijI3ChfrA+Dnt5hUZy8+AGV9Qg+qu18g/uMluVdq8gaEQwiFAKPgMEdkGZTRHwHOYl0oBT8H4uMC6igdwIqDji4YwwtSn6CCGgZDV1aLLiUDCiKB4TCaSGIfxX/WRgOshlbOB5jksFA+JD/eEbJiXTNhHF9T+qRO6TZ6SyClkM6iwtlz0qflDteIaMqx5A/qKANAEwhdEO8C/DmFW7tfYMfLKJ+CVdlGqVrEdwCEACiDAopoOOtQGO4EdgWCuEjy3hQS2tFckeeL0fwn4Jlm2TgWgQoGb50jWluFVeKCNyqLZ+1sPRvyX9zboc0fyyrbZqga+CXqJ7rFAUw0W8pcez9KDUXD5qnC+TEoVoutUOn4YBKBJgaEDNnBwkMEMQqxNiJ9iSs7VAyGAnVhDZiHwEAyI5s9yhIalKHHhaB4ygQmwA7SVWDPdwjtgpozdmqS9OXiKJac3yPrw/SU4FF7V0OFqyqZz9DJD9Lo0eYdGsRto928xVobLfist+LlMxhk6fLlfFRop7Nn7VrGbHAA/V3CgZvodbaX4jB+wP5FxfqHRsgqJ2gFX3MV4gdZLakUyMYzLd3tTs55HD/Nf9RHUeFui6gTy2K8cJQHoZHdd2cjyQegc93k7v8AMCcZ0wNioTstMi6j8WS8XIZqbpSbHc4qEHl1/AipOJT8lPhE/wAyEy64iGLJEdIlJ8whY3EbW2/pbMO26aMIAC5AqDi6MZq/KJ+SRbrqzzGkmVxRQDBDlb6uUVrlcvbl+6mTSgg+B0p0xqIgaywct4ps4i02lQ02V9HXWEHBmxh7YD5qYYMB+wFQfmPtvof8KUEmz2Y+yhF8OOUf2mVAg0frCGi7JAHRrngNw/yNWvAmD22uo5QsBTyoVfLKQDANBgPgju+KHVyulsPByQ2tgba7O75NJiDSBnBpn2WzhzDmgDC244G6PggOfiFwFiFqqsTFQusGJlYqkoAwDkMs2cMtIMsQNFG8Krm74lOBh1hQR+LQaWKKs5TwTAOAzNgPifY79EPEMZ7vB/gm5TwSDq0tPnMFWbK1Xyu5irDkL+1jERarAD8EL6hLBsNJ5Jhv5Tt8JQ7/APkYhQSGmkNh6RlVUfqCwA7I08EMyOEulttkTlZP4r/kf8LxoxI02lY+5SIFBRcKCVwYTkzKcASwOB0HkfxHKVHITfb2PIxxqMvKgNovPfJzMFNgRwjVUy96qUPcDDRs+YgiNJm4uenL3GhgHbX9QdpZPCh+IVptauaJcFgHz/tohAMB6AmVGxE35grbUtqZ9bUNjNBAHiW6s86JXsAMvgigo5SlDCRVmkspxBCkbokqlFssTaC5qH5jFmdUUQVE5ntQH2x0PcK/sxFQ+6CfozM75qoXZXAByx8OoHO7MAfkwtMxcIBaoAO10RvV4XFvLwfFy/b2tRtVqoS0AIIekgtWCYR5Ejoqs2SynYnK0kUcVyxdnSeX/Qw7WFMJbQk9CjxN5SiIPAAAfHzMYhBDVba4AC1dEFjAhpqqOamUaF4hQuQLQIZPASgNpLR3UGWb6ltHhfmaQwHhMMbTCSjIurWoVwPJyMuZOrF9AVG8SZDe7dfIRVYjaP1ZH6CJjX5F/CtfiGmuAh+gI/3Qo/u3KXdyfzaJTn1ky1uyLkLsokKkFXVFkp5cJYmv4f8ApNgffSMmuKLRlA4yNmciPIxmFC0yr2bt8nHqXqZmdUO7WfabIWtsbAaRNImkmjIgC3gcFrxgeGcjw8gNqxYcmzkjiZJp8dMQqgWfBli48c+bFX5jqVXsGj5cSwtpPfF/csNhk/uUtNJslDeOTxzKtLTYVcfa5PEAEAJZAlie4xQfL/UWEtcqDSbCcNUDi5sZHYrT3bHaTxLqYU0AOlBqZAqwN/h+ZWxC8lfIa+Ynl8fqjRAm3ObK/GAJaUEFYA7HliLsRGTkE+g1ywhSwaT3F/QYOIQFLUAHauCWp4Flrzs14+5fo3Fp+wy+24jig1Sa+IcTigai21fCa8yxXWxi1t6E8tOIWamAIAQWinaOVyfJBa0pNi+heX+ljhT/APsF5gK5EBHkCFdjVykQz/TcbZthecWlpaM44g1tMoUB1CeWg2rCPlfw6gNwvAtaNAlVnKWCYTqZQXhFfgPEX88gF+VMvzGArTthbQ+e96ouXJYaxrsGWXBcbrKeLZlynZVvouota1kPqTi+yI0+CnIaRMK1Zh0xSFh8bSXKrJsckKyyreCR5rY8mf4r/maltlAFYmw8iDXOoBFK0BhBXKhvvAxzAAsIiWImEeGGq7OkW7txSbfpLEs9YSXVHgcZoXELEIiAsHIjMq2sS0cImA4TCAdNaFpaqYDiuHmCzV7/AAt8DcEIaCg4Ao/BCowonzvhafMCwoH72zPpv9z+9D9xFbXDJEM0Dh8OmO6aNssv5H2FIrX24JGL2ArSC2kyORdsLSDH6O1qhz2Zl6pYAAekP3PxD0socG9JVWdURuSS3EjSt7CZHwiXmYtI2e128OGDVAYBVZbeIAKMjZu1tfsREbqCg4A17jgmvJV5A2+C5c0myovGa9uZTCXLa+2oRRpQYrfQEvIQAt6N028Sqe2Nv2EZrStDWUovTshKpURAcNUdbdw/xKHJ5HImkcjiFVMBKLA5RytI+yKIAb7HgO14dmmUhNmaFNY8XVjwwQB5AirNWDnqz4YkUppZcFXlzlX1cL2C2q1nqWCqlMCBNDhZw4DLMfe22qG02pyuYrABVUAO1dEWymTU3nl8RGxtN+fjFKwKFc3QPb36hjr3mJKAHRiNqGlqt/MxgA2uA9rKI9uxseRmDyOHmV1goyjZQonVsD0AXUFWgFeHDq4YxdN3jyPXDsv/AJH8Gv4KONNORIvyGnTFRwrKF5tyjl5NkFPBOw1T/tcykX3MtUQaawDPZH21mmXSBfgq2tMExe2sPZA/Q1dXajWQ5MPJE1HhACAcWoFg0SgM6hreExpBtfLFNGkLIJK3emDcOCzycx5xEBvcKzSpyIfWeXZGDhKzgGPANnWEM0RQ8EuIaR3BghkeJxQDbo+pUIUiYpQaabqBgG9XQ+CFmkFWtJ7NfJDTYLVCscBHY8OYQtr9beXYpoXJZMUuc1cvKxHXJbtOmxfpp4gAIaA+oH5uN+cQ/hGkD4TL2olWENs/NBUfUK8ZP5Zl311gwWMoqx7GFQYAV/C1OeKmKBz1fdCUgKQ0iNwc2S1ETGgtd4cI6Rwx+NHMjys2drJxCS5lGf3OBkpcAWsN9KZOUFjkhtuy8BC+DgyPJaYtcvWofsE7XqODtcEFjAYOhLbHFOLwQxmlIYbIeEbJuzUC8L0/tjWEzCcPnuGZTsPHI+SPBd/euBX9RKeH0KeC/YvqNRDIwx7KHxEwlA+KPg4hXEtC9rhgt0uHd4OojUqe9qZO2Y4/lX/KqBGcDIHRuQJwck0E0HYJQTN3BbycGfDAvYjWOQHCdPxBiubVG5pbEeVY8kEFrtveDlTpu4LpLRk5j0+BYtMSsW0qybVyltYxEYCA8K+nNHmKeQGzmi1TvdywMkNoeA8n5HDN44fxGKVfUtHA/MKMJAEREciOxOpwgLuo3K9m1xD6QciGMIjoaR5jnkFh8Oz4gXS+Dn5gDNHa5/Me4QAKbigFT0XH2CgrfAS0JoVdZEyHCQMKoCvkFxFQK7aoD6Cph3peVfLx9XGq4AG6+VBi2yxvl/qV5qbRb4uAqkB0EtC9w1UN3Zov6jF9g7HvydnMfr7LYyJyvxKUj0qkzTsrkGVNgTEBQdIYThMdxqV9oBLuEAaQ0HhP/wCyssV3s+T/AOLBQpsFIVCf7cJClyCklgtod9ZSkMCgr4eMnDtzUaBQfQaXi60aI5tWAnCsTyh9wpHwtRtb6A+E5m8+yXkUChSWgBlXgM3M7DmoWebst8sGUcs6+0tPcbyOpyfT+HhDJ5hDzKAL/oIlImxKR1LdnNurR2nAMQACZHN/8mD7bxxHzw9cjmJ3JrieE0AMnOyM7YMIvZ3FgdwkFrocHCZITM6KI7T8hk5IagBA7I31Dfa0IVRqWtBQqq0MBeDEFAFaX/8AgO+Y2NVvnoHAMBNlQKLeQUyl5ayRSLBky6SYHtMuSJKJGilIvHA+NPEYz44eo5SPkgZnzG9S7gFAYSyB4RyRNQFIFB0Lp0DTmJBw2+4JW7zL5TCqRENhJVBTKwe9oJQnZJaaXbuGJFqlCbvPZFShY5B55fECWam83IOWmr5iSixhSMh7MJw0Y/JotQda3olmspTZqoNDK1AHtdR6s7Vj7dfnASPza3sKv5g4cg/2U/iUau2oD8AIeKBs2j4ciPiFNJx85QRZ7XC33VqA1k0w0geMOpAA+DXJDAgosRsR0jpuDEClI6fccFyGtJ4E087IGOy3yZQjk5pEvCXMX3zsKAL53LQ4DmvbF+hM3RlejZlVl0L0lOvmViFaKy0l4OZfUuc6JjoRtu8EAhg8/wA4l/xWYykFwvACBKRHY8kCipQVVXBfPW86aiEEbvX/ACdQJ+eXHInk2JkdQvQQ55wU1S6MR05jjK0PJFQ3CVDhRparTqPbwqKqbOw4o04ZZww2gLFBtUyHyx9ie1oUzigSgYIrU24Hu5SxslW7DP5iNyCsOFU4Q3w8kUQtYKb4Fp51O1L8FqwEtocicjkjNDJ1D2jjZkeYTK5u1RQUpByJhOSVAuNa2m7PKM8xiXFsZ7U1+Ze4gC4BTfQCnqMgMqqoGQKC3j1LeBRyKoCKuhaaIMaEZ1jy6+oFkoVpoMtHk2dkXSJtwIynhvq6ZWJBYlpAFWzRmYcMbieCn2X4hAPkra7KHxBOHGtHB8fw6NNoD7aIJCeJ/EJAXwbT8issabhSz6xHIPFE/cJgVe94rFK2OSUP4UKDdlwhkDHRDRA7rZ7IpKUiNIqtFlFp7dcMCFUikmzoDlcEQSkAc7QsovgfcRg4sxkpXjwUeJTLBw7xTAC976QAXu8mKnS+fPbKgrQQh/Fy5Q3iC5vxEW2XAJCUaR2QqyW4ItqHJpB0pUET/gSv4dOYcUYRHY53Hu2lR5GQluMTjEANOEKaVtTq1vUWLCiAvbZpyU3KuJzXeWjzaH0gFlBW9rP1C4SDRkMtfBCKsqvbw0d0cuzmWfLSxMiOnHfcHrDRWgzoHRybGMyz5kFbNH1UcQr7w0aBvAs7Gk5JYDAqtjxLGz6hXqZYRsEli7DRyDKyTCIRCKsbA0OeEsRdZwyWUnIXKqpoYZmTRvdjbXxD0/aZeheDzGlZ2Bte15YsNeiWwyJ/ZyYhBqXONJEbvZkSBd64IwgKAoUVjLyyrjQKtBlXgh43jQHzoRDodjHlYJYtlt348Q6JnRH+2GmlNgt+O57NBc/kgkyMEAexIh/LIhMl1rw0ylbAAd2WLcvPIxGDwqdhfybVpyS9GeRDtA+4jbfBAWBts2fMzZJoWVd0Jq+REzg7Mo4SigAqyucy8Z0l+rgjQw/69QSjdF81UfEBKqwKK8tSxQOHZDmBgeSeyes9IpS5cuCRsg5VaBanAWwi+S9TVtRbFAmmA0paINrrADRvZ/wP4cZYjvx0+x6jk5eIsV1gB50PYvOWP8EIgOwpn04cJKTqrvBeThLEyMwRTZsAXpLJGvWOYbA2PYkJQbeVVUnCXEKdAR09Na8Jkl1421Dub8HfB4YLMygLE0RGkDhHJzLEKCiBoFIcJHyGOQ+GlJcVDzGCu3UPCSwA/uI6JlgbGdu4o+JgplCLUA0JoXgfBpxDQyuyWphE4Gng5IuHfNdTIpWQWWzA0mtuhmjvRyyzdgtAC1KCafQZgQwo9A3d+V2rlZlnCYTpjWjLq9Czg8sEBHBQ2exfGoQFpW7D21e/bC9pU9r5eWAJXHUCpQRMoXos/jiMs8G2AEYsObhAy7GAaxesha2M4MlPaEULgjeTGzbre8jSTzd7I8gLQi8goxlLlNVQHWfuXb01jfAT8xhlIrYiGRPuKVW6jUMANK41HnLRZyvV5hNsF6xplNY83T/iLLfcmPsufSlQ/czgj6bgwgMtpSAbePuO+Prb+kDXzUJwyxk7C/ceoLqgpkHkAFngA8sDEw1UDQBgOAwcwLfizl0eQvnkpAbBY+gfDiP8EdSzqyylBDw00Z0dB4WaB0IDuMKJzAD/AHLyzjMpHWgKWuuqd2tbKhFgWSJF4LByrJyQGLjeh+2X8hhVOwcrviLkgi0Y7V+Q2cws02qwpexHY8jhjuYlXqXN9hpOhsmOkSpc6WrseBY8Qt7YVkR4laGS1Uttbbyy4hTIMFeyjs3Zh3AxFuKPI8rhMQRuWc5jxZsoZaoNlNI8Jw9YcS7as4aKbEdJz9INbQ2dlZmbJIdMsDsAQB5QbNm2VWnYub7yhXQpAO1aCAWFBFWcUHV8L4IQZMOUlqHkXh7CC0saCkWh1YV4aQhFAAHARQtPdzjXt/MsRYiUA2KB5K6ILBjTgHy0+iwdL00/fQH0MfAFsQPjE/BAQR0YD4Il7y+YeEIa1UQHFmPceIgtIfaOBSKdKnTLMP8A8/MfqVeb0feN/hGsL0A/afqGuXcp8D9y2o5/LlmAe7V/iALScf36hmD/AK2pw17f9JE8b20chT1J1U5UfyrBxTyLRVS7e3a9gfiFE41So8AV8sHyehk9hD3BfmKuFDQ+9oD78QwjKXh9i5aN0UeIEszXNCACjlXEaHqiwYVL443/ACTcAxQK6pE+FAxZj0lkUT6B6sgU5u2DpH+UfFAIgbw0VeWkvhnyybvQoQOzULotDXg2Qnc4GSdiFI80fExqS2laB/JpldrCBFFcImROEhMpVXFeBWDpvyEMaTLnuNtG3npiklnfJFoaKSUOkbE8NkyJzFotOxPTYy2BLVYPBwdLO4KQliOzsrcTPeHcCUM0BpHhOE1KhmsuV0jh6dMdHm2FLQvptWRSIgYNNA1ZXA5vcD+RTAuaHNdW5wlfDzF7E6RyMTNlaG1adVg8QbSbdtA+mniCVwKeefzCgN1LhhU1VyIH0Le4aoogKbwMY4bPmGaxAoDBRwHECIXXuB6yjZQzDmYeYrOmPEAKA7EbEemI0HmqzykUDvZ1EuCCkZu71UVLPqzfFKPxcyl+jo+gB+YqrzyvucfRSf0iCLTelPxmbovr+kn4YD/c1n+j5gG09v8AtlGQe8v3HaQ6Rf0ZjJ5Hh+6RJyqz6rD9wEaz4JgB8hviahojT1tC7FwXt4iyaUO3crS7xKhjCInUYJWCAcUCk7gMJPjiiEr1I/g/jEziBulhQHIMJwl+qE+9tNLOVj2Q1VvYT+J9s4RYbW3IZb1aEMoluVC6xgcgYJepG8Yhjs8wSPW5xd1eThOOoaS2gcomPkxKk7UMF+jy+40zlMtOKGw+ziX5FMLciYRldwaJRM33DZscod4ZInMIApcuvMCqa2EORLEgCUZKRLE6SBC0abT8HpsmcQW8tyOl7CWTo1f8BAXw0+I202ckAuQjyZjYEdg5wfp2QBesWJwrFIcA3zLlVhTsdKAp4lGlGkpo0VwQkJ0mK+gZZintUoAgCmFcmuaQBtlC1Y/PaLgAge0j+SV82w2WR+Fy8GYeAKaqPHd22uV3GhfxAgf8Fi9RK5iEOo5SjVOOB0+DGAXYABGHFCqkbXuCvYtf+WxMtuHmAz72riIw0Hg07YOiDhq+igqns8RuCMbD20kPefEoWNalOhQvhp8QGxQK9hQfAzCSIGsU4W2z5j0IKhk/Au/j5jfNq2lVhcD4a8zMoZG8lUA82nUXMWI1ptbbOVK9R8Jgo4nVdlXk6Ii51AB1OGHa5cCPNccKCqFUAHKgWiwW4K1SrUBAwXWMQLW4A6u1BMrmmytkBq9hKrGOS0wOazD+CH8OmPhevablGsndU8keEDlHyHg8ikqFc0RXRYr6hp6EaRvpjmnOFlQUQmJkEIiUiaTxGv0HUOzN8nbYxEGjLCI6CRTWWmgNU/h2Q3tydL5TQu8YYbvGGth4CefiFxSsheoJVvSZIQIVZ+0IYX3dIUB8IE1YmOiw7ht+IwOxpMB8JkhuUoAo6Vj8IXQ27Aelfgx4j5Cea8qGPmomtI6Dj8Rkgtj3AJyJ9Qc5VbJs5T2IIwsKFsHYNeh3Lybrskc3aQ5ooNVEF/qFsfUIY0fHgkqPgjOUAHtixwkqeQn1x4g7GjR28EoBYv7YVLlk4LLj3RPUbNn3H+GmI2DFLDoUEVHFlNaZnDRFgKs5qMKkNkKFQ2pW7EcDSZO4+E4HmO0CwsYftLqCG4X7Zqej5lDFVNinQ8nIUHLEOrqaXgHK/cVUqw2ha0AL7p6ji4HYdXaJoZ0eIKEPUPJKi1y0eYxmkBXmBPLnFfEPWQiODtLT07O4E14FoaGEiJigatg3DS7gYDYdGjqVWNSi30Ig5WjO2N6utsPCdB2uV4g7vebAlCHbg4JReAP1Tn/lUSI+xD6YhQ9qH4mP5QTMRGQS13aJy+PZCW8WtGkSKqUGpkeHVrr6lu3OWK8mLPyMM0YVX2o/kNcwTeptCpmkTInZO78lHbsfk5IjV1ZwHeMnwdkCO1oEOxMM2JWMF6y1KvDQ6+Q2eovSHU8HoU/P3FavIKvkv5JeumQ2rwSvkIEdqEawVZQc3UtCJA3oqVnvIxAAqgAsuXyvmFNy/EhZ+SLlYLXgI/hiHOCOkV/KEBA8t9l3fzMj2NpO9BLAXT7OCN3L9st/F/xf8Mz9eAD5aIWBDa7gqVIXNtK0CJlQQ0YBo1Qo7FIyZBTUt5ZsGuA4IraWWy+Ageau4j1RYfY2b+MnTKsLesjwwB8vUuLEKZVaCFDxVwUa7m3xgD1fiNgCmAqq2VHLa+ooK3K3XFpVeC2KkFssbaaSxhW1JWyW/XUITrREaK4VYyrj8OiNTOxfoPjJ+yCz3sfgQfsWB9RgAfBzMHU0Qvjc41jBzNVorSQ7zZS6uhHn/jcv/mglMdWga1bROXw7IcUS1B5IQZcA2dmxJdNhlh7HCmEcMZcn9itrt9I6eoCOjaltyoafJT3Hzw5U9pgT2V2iE9NybJSwNuQAiKYJZQ3VoqbRdcSySc4SPDX4T3LxLj4gLvxMN3ZyLJ8ZX1GaOqb8wP0Rd5QYHnSjZN1TT4lmRl0Mo8WD8RNYsWqkcCXEVFFh0K2SnEsbPX4FCZq9UgP8kXtZ3Z48jOWvTNcvTf3Km/cp/uJy+4D+50v2T+4cPh2f0CxyzOLw/KBNQQ6E+0H8EtaPbfAgX8o8cdsPYBXxTE03VqRqhw2eiALTUbNdujy/EWhKWmqwvdML3mbTigsjxr+viUD0ST9J/uohZ28r9rJiLvb/AL/1qUoF0rHJHNkSEFIqqYdAV+PUQKPmyfV1GS4Ocn5lPQrQH+/mUgBRxUylGSie1z8Rpp4EP7Bqn4HuWzsEAJkCoHAG2B0Ao6pY+FnX/YfwglJZFvuG8guuU+yH6K3Y9PImkckIBGkCLwkAxm1zXkRMo4TJC30VspwANnhnuCeMsAciJYjEdRQsSyFhuxSC0FOatTy6R4oo6aspscjeMJtKgJEhQwNUZwhkZvAA2VsashsbHZBcJWEDau6O7+UBwhtn5Qsv2E0PGw/Y1r2EEunKH6SR67ukL6EI9YOg/tD+YfnA/wBoSjW/6BTEf7C+aj9mX+sofvJf1c4y9h/UtYHw/sgB/rnmb7uH+kMTQBxf4ABMgk6C/tMRXa7R9VUL7VzavllmAbcCrfNX0uBkFMkmAIoXWD5gNgQAWLC9VBaF4xcMjUIEKQMFGgYIA0QqgEFWFJbi81iCy27EH7RlGJOwf0/7xHGPoRTbXqFGaQGwOaD9pCnD7LP0KwVLJy99IBAUZ4+bwuFFkYDGfPn0ETk3Dmehuvipjz5DLyt8qkG255TabQfK0Doho/7eH8tckNFe+nc//jPMSdIUg4VZB/8AyJAs4vcfhdrWm8hpeybvSa1V5clPqx5IlEEGt3ccnksj1qyuq3gugFMUG3LVk7ayLsq1wqZI3mIj5aBMJiyVaioucAUt7HaZmY3cnyHIAABaPGSOFbkQL6bVZpbrTC0dpCB2NgTrA9wI31TmJsBojmgIG4mF3nYoC4EzxAk8G3Wgc37jfJpEniw5TW7wmX4VKS1Ts78hH/Yy9ZXv4RfqTmOb/NhhuvkSHUj0/wBLLS0vf6AEr/Qi+AVGu9lbuSwTXNXXMCzIDAK1Yig7bYt9sGCkojnq212y17REIlWqijswaEGoKA4rKjUHZVuqR9BI6QOCjCZrcGRe3MiywoLgZzmLoR2Cfgo6pVwP4ujNMnR/gqO14/8Ae1MWL7f7ZlUf6OWUi+mv9xFDZ0/0FlO2ekufIguHAkAd0P7SOnK1w8N1npITv20Rbtdr5bf4P+4/isSsQTTZYcInqHZxFTAFGsHy7rZySzP4iRz0DI9jsfUKLq2lM2Cr/DLG8YnhiCEtyfaGEFzW22LA4HXDEg4tIYyIlLtCj2ieK2DuZANgXF3TRJeHxBRWBOg66maLZHEsK4WnBo5ITDQbcbk02HYbThla0DQgMBylaTJsYFAq0Dq2hKg4zb2Q7YrTKTmlLS3RSdQllaMARyWuC6oeIIfpVibL3v4HmG1CWbPKQHsqG1eeUbLG604qt8w1w7Fq+Etnu4AGpg6nsCeAqNUQIfDvAADO34S+ggoAaFtD1DHNxfss5DpJ3DZqC8oNbRq6CsxEUwCFOqhHZe2AYkVArq9aaHzL9rMh1gUWq4AwcRFkN5K4VRpac8GiW+CUcJ2IXR1d2w0Rkk7gIKAu26dKlpkUaEjRwGynMrK3dsoGdhdqYXBOMypiJKB9kyL3YP8AU/3L+pnmfA/qYIB6IVwQlw/g/wC+5f8ADojzaxriCyHCQ+g2cnwnU9nZBDDgSz08icjmXXAczUe0f0xMIOkH9y+bHZd7u+inuPLusVswrYnhTPE4Di4xQiEdKE4YPt0tTZgJF8NWYSXHqqBduxSmDOzsYnBDZdsPPMhacTYLYGtWhYFe1PUGq3SqAvSFWnHC4hOOAdABgwoL5ycMr+G71bCGFDhCzzEBGedBuxbRoG/DDIfW53OKEFdRAYlvCJO+f7IVR619stVXgo8QrBYWOYVKMsrcbIJC3iGaRRteUoeolbSoosAJFdy4IXXFlVGLZSHbPUsv0HpWzipypR3B2ZLm2cWr5Vzyx1QlBA3gtg9pljalVsldL2dm86qNYDMdO5BAxwaiqjEZltupK7q3xB0/RPYXafVo8QjACkGMVf1DX/K5Z3/yP/E6mIlmZl8IiAv9Fc+ZfjzAJ3m35cnmNoGOrgIi2wXfDsnNLUVPZs+Zc0cTDAOx+j1XHWpgRnhLPg4+PiJUO6cvstR8RJMECXIKg/JLM9uqpyACuhlxtAD4tBFNt78wDo4m5I7BC30xEJhBLnItXw34Y8Lo222PYiAnYwVwnMg+wUX5TqLKIK7caoDaBtDgAsF0WVDW2LstLW2nFN/BR5lcZCi08jTm+m7mGCQk2sthg808EBG8gko0pG59y6SzpBbA0Bc81zDlMIB4WIQchctv9Fx6huvyeYiq62WKvapdxJ0sVMHC0YOrm8LwdL4Nf6zCAoGAFA8EAGsBWAIWqugNrGmKZM+A9xW24f8A4F/yxqtXAcovO3sfZYvmZmwiVtW3pe2eoyxPf8CwPkjKx7yMv3kHsgV7QN+RhJbnb3v/APsAUmP9/wB8TUJ5Jyw8n9RTFJ0A/IP+1BJ9MX9iMNSjQB9KkMFZwJ/YYmV4GPTAAh0WPQAfXqEcf6ruJsfItnSinxCuQHb/AHSGkDsE/Qf7mBUZyqfwn+5lkTfd1+bYEAA6A/3+pTUla/3/AGpa4/1/v+Zpl2owd26Pn5l+EYQJ61Hd5hoPFpsXvCs6aPEpQpYcY7Xpa9zn/wDFxXErOJSJ8oZPIkbdEd6A0Xu4/t9ViOSD5yYvjZi8NgiAFN/QDZKwd5afYllGKOkfoBCaE6T/AEWL6/jlHckJiOhEOnv8/wD2FcV7+f8AfmIYX/vcrlo/3/f3E8x4F/UAWny/j1rMGdoy/VAT0Bb94j7Y7YOKMPTkT3c9B+BDlXR7Zs/KXX3dSunB7jboG7yKo5VbX/tP/abbPrWfFEWDpSF4LoHzOhDjz4D+UYQA0f3pxEQp8BPsGBiVxaPq0g+UGj+6MBz7/wD0E4gO6fpIHz/BBLBmB+b+4/FCH9rNX6v/AGMxLR4ofwE1fOxZ8ihH2LeV/kYEIt0Ar2oSjTgqz6L+YULePTyWr0pHJIWX7sKi+bQyIAAAoDgrj/8AMf4dx20cIfSRZtndh91cZVc8/pSWAj00Pi0EHxr/AEjOB3H9EEuftGB9vcLt3fGNN8ITxQ6L+7hV/wCm9J/MIIXoZ+GEID+vzxrCQrowPgnqETX/AHn/ALK/76lf+Q//AAK//Cr+KlSpUqVKlSpUqVKlSv4qVKlSpUqVKlf8qlSpUqVKlSpUqVKlfzUqVKlfzUqVK/8A8L//2Q==','scarpa':'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4QB0RXhpZgAATU0AKgAAAAgABQEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAAITAAMAAAABAAEAAMb+AAIAAAARAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABR29vZ2xlIEluYy4gMjAxNgAA/+ICKElDQ19QUk9GSUxFAAEBAAACGAAAAAAEMAAAbW50clJHQiBYWVogAAAAAAAAAAAAAAAAYWNzcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAPbWAAEAAAAA0y0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJZGVzYwAAAPAAAAB0clhZWgAAAWQAAAAUZ1hZWgAAAXgAAAAUYlhZWgAAAYwAAAAUclRSQwAAAaAAAAAoZ1RSQwAAAaAAAAAoYlRSQwAAAaAAAAAod3RwdAAAAcgAAAAUY3BydAAAAdwAAAA8bWx1YwAAAAAAAAABAAAADGVuVVMAAABYAAAAHABzAFIARwBCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9wYXJhAAAAAAAEAAAAAmZmAADypwAADVkAABPQAAAKWwAAAAAAAAAAWFlaIAAAAAAAAPbWAAEAAAAA0y1tbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wgARCAIAAgADASIAAhEBAxEB/8QAGwABAAIDAQEAAAAAAAAAAAAAAAQFAgMGAQf/xAAaAQEAAwEBAQAAAAAAAAAAAAAAAQIDBAUG/9oADAMBAAIQAxAAAAH6oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiUqt3AqZ2mEi0oYynV+8/YU3sBGoAAAAAAAAAAAAAAAAAAAAAAAAAAFBT2tFryW+6v278EzDTMppq834I8mQva632XNTc+u5R5FNgSAAAAAAAAAAAAAAAAAPD1p3AAAAAHN479XDrRSbLmPY8e0uuWv5rYe69lZY5jDDPTNdcmJvptZTajVz91257TXbqPKm3vQEAAAAAAAAAAAAAIGNRNcomc7bihbZkdEy1o9Oe3S+U9rXo2CLAAVdbdRvI6a/Dbq0c1NvKz1/LsZPNWG3PcR6uJCZtyseD0ds+HIx19iy9M6VujfEz7t3T8Re9/k3fmvaAkAAAAAAAAAAACmrLqpIEmv97fHnTeauKaWWEn2l42qXrrbZaVGuu/QKiwptvNK3mrLzj0ixt/vJvExl6k64U3T0ZVK53axT+WFFxd/VWFLaV5tmOeHZjAr7Kvz74FpVTfT8K8seep1+6crd10nhIAAAAAAAAAAEHm+o57Lokc1ayNebkbvmrnt8vrttZNxvv91exbXhDkUvIy37eTs0yMNc6e1c/Vx7wrissda+YSY3PpEx9xtMPZz1zvE+RH3c96Xpebv8rTsXnZyxIUyNXspp0d3+XdYWM++fJbej5iuvTbq+wAAAAAAAAAAANFZb1/PtRararx78+Yv7Dq4KaZnF7PJnxay75+iZnXbfF9e3kRZTDf5i7s8Yk2Hz6aKm3purO93UdzvzwJ8Ow4+6rqL6J0Z7mevh66m8o7is2WOHunNpjSo9t4NfaVfZzdVaU1z0cPlB0FNTfdZ1VqgEgAAAAAAAAAeRZMTG8KJaV3N2xI8/CvRokas4znqpbPLCdqqlTai04Yk+YbuzmRd+qZj1drHa0nRc1a+z4smZBl+b60fZrV0wwz0U2rberm1WO2HvYosnHWYFXftjoOY6Dr8qRWWcOm0e0rLOYCLgAAAAAAAAAYxJMbHTTq3Y8u0DTOg06fdO2p0zsHzn6FvTOxr5/LvVXFXO5VlsjbdObbh7j0U0eZ44bcvOjZe94lpJrMeT0pnlbnjrZR4uPL17vKWRva224Z1p7p16aWQ7Ox3yi2tJK6/P6WNJ0Kx59fPmnojUAAAAAAAAAaTCJKrODplafdGGqJnpw3339NZejx8FaVNy6ts7RvzQZcOfztm/UrnI88dGbHHXhemhWFD7Xldno2exp86+h0GnHt7Xfw/vLr0PPbold+k0bJOmVfYy+fvnM53zZXprOr53pfT8HpsYVjjvXzIm2cpYjYAAAAAAAABX2FXWZdbYRPO6Kxhjw+htw89TOjbdPrefSWKXz9sWXJ9356qwyyyn1nlauLNesDRaeU0o+W+ic92cc265Dq9uOgkx7X5/24WNhvrnEprTD0aT4W2brNTun16ZmXNTr13dH5xevH0txyPXWpBxz0ItUGdGhGixNmhTQJgAAAAACBlo3818tG7Dm0ptUjT5/o4e+ovJ2Y7/AG/JpW+sx75WFdLx1269svq58pczKc9DHTFpKFqi0/n9lHfNe8j03b5eqRHgeT61/Y8f2vZzSXNwMN7yl5ToZ6JVrKs7YZ+UnDaZTYU7ZtjddfwHU35LiuuqXPfy6q4p5sj9HGvPXFRcIkiaAAAAACCV9lE3cGufnuPPaBFsa/n7cMNmK9njuh+55GNfB5W1+323m7m3qJdi0yg5SdMtevZoi+rR5jTo019zrieO6C5mdPn1G3KX5vTyULvcOXfnbuRryioqOw5/1K2VJ0t10ZcR083lIjoqjm+vi6hgcv1YfZJHL9NPJC9tYlNmvXri2+xo7yY9AAAAAArLOkytNh7dPBtN1+MCtsYsbRcvN+sy6udXepx5cZ9Nh115T23w5+2pidMvn84l7b5118nosoy5XR2E7TLnr3TGrWfzMLZvyy+n4ftZ4d8fbA8b04+3ifpXp4e2Ffy+WnX8fQSLdCxt51NveXuNuuHHSO8ytFPeVNXrw9dP5npprpjWHi3mQAAAAAAaubsIXL1b90HbwdGyVCkxhnh6wtClaZ3oY1vsWx6527YMitsdeqKtLw2yFeTz7bZM8/JtdE56M6+oT02XAwMt/pEX5p7G0vsuB6j0vA6+DN0+P6HLQe881nib22icfZ5RdDbdXPW2urlunPrKmnt894Nb08RpztB2GOkR+uqLPp8i5Ud5TYAAAAAACo05ysdqbKTE4O/ORF2UpKR3JG6RE3+phQ3dJd21ebYl86nke15Xs5u738HK5uroYW6efP8AfLZ9kydtlVrVweh8yty8bt/Yv89fQrD0PIpLidT4VTdUTh31Ud1xvdXvqbnr50Qo/WaYvV202bbKNv52Npl0/PR9tdqWl6qsjbd3Xybsu7xO6VMjHecAAAABX2FInbI16stNsOb5S1HlNrOPt2aMNXF1W02Fu9bz6+8qbzOI8aTrgjabPopj55X1vYxPZ9qxJcisjOVhwlPn197TQ5Ubauyky9eDZhzHGy7it4yw1z+kaYtp5Nq6LZxb61m6dGnfG++YXPo815xXWTaa8V2XMdZXXZ5Z5W5KXblVRpf6ecgL9BHoYnRyfS7Ph+otz2ArcAABW2Q+Yd5zNBn1/QMvPIy31+yZE81X9PXc3XaUl3w97dVb85acqZG3xpyi55w9NJ9DfV3ZzQLKp1Rp7jee8/Tyk3o6W9La3jYzzR6HtNs15S111UadBhzOmunY+8db68d1jVWvn7xIkzTfWD5b7emNfkW01ylSamjZzeWqumx7pt3GlVp7Eka70qq3r56fn/R3/vRwaZ1TjZcCYAAA5+H0NPn0cN30Tiq7/R4sCznDyRhCtEXjJV1j35ydWPDpbbK6Vrnlhswoi3NVl1Yzs9+q+eMeHItVY7KCadNz3M0cbXGvdf8AJ3apsnXfCvqulxz14+q+kuviq7DPdblj4e4eb6UjKNs6a1EC1ideWqy928/XAjW/O8uvQWOF/p5+ndm35MMvfZePUvIsvCyruY0DWLl57MAAI0kczj0XM59XJ91W1LTqeEkSVq/suS7Guis6SvctBN31vJ3WuyLJl5qk+zTHboy256ypu42+VRItZuHXD02GtFB0NnZRjXz1FtzXurhtDXp6zGfTahruvrV8IvP9Ttxy9kbLzvSz807LXS9Oeld1BdRbZdPNr5dOPd7qy1zzYJZsPDPHzy0+4+6ZarTnZF4uhNAHntYRaXX2Ma89o7GorbmI+W6OqD13yj6BC9kR8Z48dFgWo9k2Pn0bMoUim27T76rn5oTXGptaRpO6Wmtb8thWc5hKimVnUU6radWbcK2WGGnbHGJO21tzfP8A1D3bPkLq2hXy0RsJDSNCu9tdaHK+i2w0zI2xEzbXYTW49q90RO9ieE2HH2J8hy0z4ja038uqtbYAIE8cP2VdBW6VTeI08v00iu/zrTdWFOyH1/ztOXfb8dTmnRsZdqQ4FzhF6jKVV49srTpzz6MYUuDpjEx9mxpv37NUTri3nLRS22aeo566rTzPq85jmmuLJM4skxHpr7G9ual5w9IsMa+XOeWPvtsvc67JFllX6k26H5XSfjqrq7SfPclscdnkTtvaC/nIJqAp7gchs6fXFqTonqNXJ9j4nk+b6PZl3/PfpfN8dev1zGttYw2bYmy2XrzGYgU3SZY93K6+irs+uF5jBi93sr91qS6jOVfDoJsKbhzS84ue2Ehp8tG5qTOzHwe+EyqrGDMVnrG95erRLUywwxmMJOrSbduj1G/OBsJir1psofu+NbG6or2MQmoAAAAHnH9j5FuVgSfcu/5x3MvhbPrGPAd3GOcffV3xkeel2cLfF5Wn3KIr9VrlMc1t6PK1KDZe+RFVtnJrH27M5jz3LKrW24xbDTnitF3Z6ZmXB8xOL3z9OtfN06VFKdebChx6DUtUTfIJd7uNi126KD51UXtZ/ns8QAAAAAAHnKdX7E8JvtOcz7qWs66BOvSbfmXWWw6DKv2TnawtU6ESXF2TG3zFOLZ5ptnK9h5KyFXNlvyrcIm4zhwK3vdVd7GsiHJkxOGGeBlr92ppqHr+mtHxqL9v9PhHv3TUt8W3/YfYt8om/T/YcFbdOnOJM89nEAAAAAAAABAnj5/B+nc9Xq4ubq0R02uuRnbONL3aWc3XXEXGumlon7q2RObZnDJejOMTNWvbFscoklMrVDko37q+LMWe2m1LW8DKbGm7ouX6hzBNAAAAAAAAAAAAAAAAPOf6EfNYP1eBG3E2mvm2nZY8VPmOh0wZs5xtN3mig9vUaUC+1Rem03vkXpfLv1NLsutsxVSZFdKdu5uqieuoYt1Fr7ookyeAJqAAAAAAAAAAAAAAAAAABU0PZlvm1R9h8jT4Xu+1QJt8s2fQoqeLy6jWnnMei9i3NY9TtW43X3u5Pz6X3kqI+f3XcbWfOX+aeb0TAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH/8QAMRAAAgIBAwIEBQUAAgMBAAAAAQIAAwQFERITIRAUIjEVIDAyQCMzNEFQJEIGJYBD/9oACAEBAAEFAv8A4YturqHn6zBn1RWVl/2rbUqS6+0yuvvxaHcTpKCl9ySnIrt/2atmyK35FWnLYt3nqEBDR1V4htriZazf/Wp7Z/etlbebxW3CxlDTiR4qChTKIFdi2D/TvBF2VUMmtGhaVtF9h47TaFYybsl1qyu9HP8Ai81P1Lzxv9VT5WMuQrMVXf1UvuB8psCzrJEbqA1cwUKh66508eYDlk/OvyEql2TaT0g88vVsnVqiZq77/RsH6rDpQbo2RRXn12B67q3lb8oDN49oWW3mV4tjynGpSE7DkI8sacpgWgZX5ubaacbJ2xa6eCgEQ7ceU91VOnFy+MB3HzWD1kThwjLuWdLVuwba5XZ3F3ZriYWJalBQS43BJnAQSyWjtFbhmVuVCkMv5erDfT8w9bFDxXj2Sow1jf1CKd4E4EZXCKwYfI33MOxEZfBVauO1dobAV4+Lk1zF2RbbOAx32K91X2b3f2ef3b/Jx242U+i78vUBvg4pAsurOPaGltnfDfceDIGnEjw6WxW91iOriF1E5K0Y7APyYzacYWG2waC2xZ1wwbEx7palmNbjtuK/D+mj++R90zbTUvm7mlWQ8pt5fk5n8Qjmo2zKDujWN68M7AH5HbaLZOoN+gbD5WqLXWsdgoN9UFw6xXx/u1QSbdoribAzYZNOI5WIe5jR5Z7Zf7EyKTkUDTK9rcd8cqSDW3JPx8n+PehgJaXVjOrs3WzGb00v23m8J2D28nro5RfTOoBN7DOkWhorWMJavOqq5XrceA9yOpbk6jk05S2JdQ3Za+1uV+nqSfafY/a0MuG9VLcqqPtjgOle+2KfT+Pd+0wl1Z5KeTX0VagGS3EtreB4tnGFnvsqCIvMBu5lfbxf2PhVa1Lo269nUSlZm4VF4xa+lpzftD79W7ZlH2r7RoZZ74v7WMfT4bbZFH7v47d1YRxLK9zy3PV5KdPreNj5NUsu2lS9Kt3PKsARDuF929h7H2h98obX4lnC77LR7J2XPJ6YqYlvtE1j+Tjftqe7RoZZ7VdrcU9vCwf8mr978cw948YRlBHFlm3Zb7EnmEeeXoslmJZSK3DCowRoPBvc95mD9M+zNzqHsvtf3yo0H26v/Lx+1Z9+XYwtHaN2vxj6PC8frL2t/H/onYuOQMMPsgJtIm0AleSyTNr4FDB7eA7Sz3lq860O6UHfAMT2t/f8B+3n1tZmqtmw6hgqsM8sxnk4cRIMaoSntXU/Urlo9X/b8c+zewMsTws+xfu5HkOo0DiyEzF9VdG4WtvBTGje3gfTZhdzSEen2lnLkG38P/yynWvP83QIMymeeSHUDDqF0OVltC2U7UYwQY3pslsHv+O/tB2YnYust/b/AOt2NlZNO1+DkWsHX+6P5DdstIp8AYPHMHHKwm2y6RcA2SBGykrNlhJ64nWTp6vYll9KCIkYAAxjtEpd4iLWMjNWs4PJb5Z9v5F32KY0bvOW0uPoqG9ky6nzcp+EX3r/AJFv82uCA+Bhje2o++O22Xj/ALvFXyL1434JPlAe81JOrh4h3QSyJVZbK6EqOVk1US2+/ImOOMSwIo7x/tifb+KzcQ3cfazHtCY3dcXu1ziqqmk2yuvgD2VP5Dd8qv2MXwPtyjHtnDehW421nbJsrJXLOLa/xB1nxG2DUbt3ycmyjB+xd2iVKpa5UXJyLLZtXUQtjw0vXNOp3GGdk8K/f8Ww8rpaO5PcNG8NP/a1l9sXH3A5w3LxSxOsndx2nKbichOQjMNy8s7q3tW/LwT13+SraeSUR8ULErVLMakVWswWHJ5HoX2EYaRKkqjGV1DKYStuWbH+/fY/i4/q8Lo3v44HvqdXVdMOmDFoEWmrbgk4rOKzgs6YnSE6Inl1M8qk8om2pYdVVeI/LDDjjp53r5xLkeEch1OStTa9ox6gd+0uzqao+dkWzGwLbD2VdQ1PnNJDUeGR28MdtxLHFa9V5XaD+BlOVprAVT72j0t7+OF75rKk87jifEqJ8UqE+KJMjP6MTUw0ryHeB3nJ51WnXMOSBPOJNUzEsrwLOGRWxVdObarNyExlxrr8yhKey7AHuL8yiiPqjPFqyciY2IsrqVJkX149eo6jZlSkTDc2U0OLKr06lVbc0duk0durlDG6zZFSY0pO6/Wt9eSexb2P22e/jifsuA8twKyXwVnQTeuhBMqgX4tGNXXFhjNCZvGMMzh6lPexu+CN6NerZk/8dsjOta3apWs55GW11DUZGLxErTlA20ztUSiW2XZVlOnXPLsWzFXT6ntsq4490sHSv9xVd5YaYhamam3OUjZfrUtyf3Aglo7+DHZa14Vp3uscs9LLkRsTILV4mQIuNd0xQ86TCdMmdCeXhojYxMOK8vwr7Bdj245oxbrKqMfy7OhYWYdlbDDctRp6iVIAmq43Xx8IgJ1VRLcnJzDi6KZXi1UgzJC5QUBEvzFsvxbustiB0XksZQwTsrJkNKcZKj9bLYrQ6BVqO8PYy8eO3JpjHdtSJGlaRcas6L4lgIbqxPM0R8yiHLqnmKzOqk5F5XUqtLnFjjudhNvBobFQV4Vhuq06lYBsLHStcrWqllJytQsrRUTU86Y/Y0WdWU2C1IybTeHINYx7bMiz61/e4dwvaw9xD7MNvCkb3TT25V5CcDZi49do1DIM89kwXZdk1dbalBZolLNEwCZ8MVo2kxNNNjY2nU0wR3Wtb9RNswGMGzQdxfYK1tcViqq55TjV1+F+RXjpk62zQUX5RqwhuirWmfmmyV0gRNNve7F081wY6A1Md49atPK1b/XLb37y+K248HG/hi+1zcasQcax6g9Y3fGSCmsSsAQ1C+jFU12LKd+LWdxVyn9O6iPfxW3Gz8phpuTXXh28LaBOXfK/dzrrKdWptF1duTXQuRqlthvxLrBpoTceo+msXUZOVKdNpqiIqRmCizUaUh1d3bCew5H4LHiqnsrQndaj28DH7SgbUZx/4yDamoxjDNo42lm6zUkXzNFVrHoZDRcVwBjLPL0iABZvN5Zk01xrK2ycSz9O9djbX1a8uuq2cuFVWG7GvDVVT3fFPnMfDKRUCx2AD5lcd8u2NjkxqwBavCzBvFiY9/IfgZr7xvugMHawHxuG9Zmon0U/tj0E+7MeSM1sCbxcamKqp4vdXXH1TFSXa1XH1m4x9Qy3ha6yDHJj19NtMcMmO5erbi3FbB0AIQBDeoi0m8ooRbrkpS7VmcovVCTaXfaKbXjaY1op03HrHSqgJx3+uRyy7V5eAMf7f+3ge9je2ceV6yzaL7Ztxr03Dz3qapuaG+uqWarSstzMt8fzWVkyrF5RMOuLRWI9aQogjMohcS5lZMS3p2128CQHUEoxb03bs2TqNNOZTk1PTkakzRKGsa7FOO9TcIivZBTFrVJbfXULtWpQXatkMbcjLc4IrulF3I/WxT1JYsdN/Dfdd/Ty7B95Wd7zG9WoL4fab0UR9HuDb2mVYLtEwUVRM/H8vbSS5rpyCPLGeVqgopECqsLABaXulWNTUkt/4z2LyG+0v9E1TT7fNV4j04mJSANhtWGtmPiVUiyxa1v1dN98rInw+swYVSy2tFlihlUPzxvNWIj3AV27t9PNO2IVCRW3jrGXlH9g0c9g0xTukwh1LyNvC7tKwHU4WNFREBM3gbm4xA824CFgJdqGPXLNWErysvIfExOl4E7DK1bHplltuXjJ9rrvF9MNHAmkhixrFaN199pdnzVEyeWn7Sp+QLqJxd4cLlFw6Fg9IaxEj6ljLPOHJOJd1qvpanatWMrRhwitvHTeOOcsBUsZvtMUbYtr8KtMHGhu6xojcG37MZzLTpAxTAZlZlNMyNZsab35TV6f6cfT+q2Nj149ZIUZer1VzJyr8o9M7adkNj21OqeDLv4N7Y3fLvyratSvyGy66EnFRFw7as7HwOMWtUEvzaKY2dbZGTLuj6YY2LxAdkbGyfMnGvF9X0c3HXKx8LNfAuVtwy8YlnZ03DjZb6mrFnqWapZxpwztUrSwQntYCRQ8vO1etOadP0rO8wLc2muXZOTkCjHE1DB4zT+yV1G2L6RkaklcejPzjTou0XT8esdCpYcagwY9WxresIwZWG832Dhla/yOQ7bXRBwXl1pQiohO0zNXrqhycjLbEwlSBFE2lm8aPT14mlZRNdWVTbRclw+jm4i5GRiZVum21WK6Oh3rs2nZwQ1ZrqrOVMy3r5dTbRWnLcHwf0MvrDdNqfI4ONKaXseqgLOIViIlKYuUG3hx7LZTj11Cy2usW6vjJH1Wx4czMMOZliDVL1mNqT2hcmvzDezd5/YTcBVWWFVpp4iq/JTHVLGzXuoerJw6wkDEQNvHcLOlbZExalgm02l9HM1ZDB/oZg6eTl4yXoj36Tbi5NeRXYgeBmR7LecRAi6plCiugfq7cYjbQGe/gZWTW4CWoMWlDwE7CWNWorqsYJQizcAZer0US7VMq814ltxpxEWdGWoFjiWVhwrWY9uPkrlJz5eHvATvZ6q9RVrtP0+25RUvMqnGaovJKm3UWApVRY0rrWsbTb5ba1tRXfGPz2oLE2ao3VLYtlV2nW4GoV5a2+oU1ipc3LXHU7u2HSoqdGxx/SNAfF15LRaVbfeMdoN7VwVp2JCjI1WpJZffltbjGm/Hr6cqabjYPzjY1tk+HbwYFALYGMwXAxVnlapcGqm/hvGazHd7brhTXxDmXrywKG2TCo6YH0DCNwgOMfnsRXW0GguAwzcIo+M26X2ES8FcpZSuycWrj0RXBitB48N5S+0t9rD/AOox8joPlPdfdThEyrHVJlY4sShpRRa8TFrXxZlUW6hjIX1ZI+rXxtVy5p+TblAWWUWq4YcovqnNVU84qBZj+tdLr6jKd/qdXpN85AYNWa7rba6JcL7ho1lgzNSXbKpXk9B4xl3j1nlZWmU3qrdTAZt4Ou8U8p+rjsW742P04Wh7zvfMfFWpvDJ1Oik2ahl3kYVtpr09RFw6wGqAl2MlgursxbcbKrz1XFBsZL65WwL1kc61WtOUwT30n0Ytc3m83m83m/y2Ota5X6sxrmDfNbdzFT25hfTunEcPLVFd+vP0Tp7rZbXvFO0BV1uqDBjullT48QhgPFh3Uhgw2Ln0lyWx63tapQgEzc6nDXL1O/LbExucqrSsLt4GPtDLeFoOmZBfjmdCm8ur9KyDFoaNh3rLFtVcexEmN6cdbOMXIE6yQWKfmbJqBZ7mCH1V18JaFsrx7OrT8maf0NU3uy6UWtJl4ovmazJTrgDECzEs0vPrygy7zuXRw8KRQ1JegPEf1bzebwzlCdxfacbT9NyEuoLBBlao1hxcZIcRsfMrO0RgwVtiG7dTnPL2PBjVCDsPC7GWwva+Oedbnp7QNaIXJBTFM6OGYMKlp8Onw5oMKwQY1wnQthr2hSmb2bdEE9URn7kNwwuy/Jl1m2nL366OLE8NSC2jVW3yfY5eGVbS9WFkYcg3eByre8ZJYEuFiWUQEEeJ9M6a5ONi4+Vi33GzIsrx1Ufemor5nCqbdd5X1LmqxFHjtNpt4ERlDCyl6RRZVaN1EAt25EQ3JP0mnBJxm3h2nJZ3MZWhNbNYtjE9h6HswNxd8t1ZR02WC+2G29pstcx6Vsxs/CfDlG1uPqGBymmaq1BUh122XkawCCCu8G6R8ZLI5ao9QTebmXVhl9RFNULAQAq+HsTjbqKKzfYiqir7fRycXkaLU5WoOVKtGexJs7QnZlG7sOM5bT1qnmLOT9XgOq03rM49MbtUDwZcNuWV812OYbkRvM0CV1vkNCNxdjHDb02JqGALZg512n2Y19eTXtsw7slnInwJ7WYaPLK7aYLuwsKt6Vsa4lqiBLm2FD7ZeT6M/Hr6NSwdh8u/y5WMLZXatAZrLCqoI9rLETrK/wCkFZjCtar+s050Ii0l4bTyPCBLEhvStjztfE/kfOyhgtaL8uVQcVlKumfhLctb36dkYGdXmIwBB9t2UA7hiFAKvOREtpx7JZp7iXV21pRYBatqIGbnVW/6ti8tWR4pn9/RZgi9XlOj1g9/RgBtit0wytbFHRnX6kNOxOQzDeuNeRBmYyKcotD1LIibBmSlNNJsX62VQ2GyMHXKxUuS6m3Bu0vVFyfAembKxYsGsOzKeR5gTbaB7BLBVZDhYrk6XaJ5HJSDqLkddRBlgQZwgz1gzq4MyqeaqnmaZ5mmeYWdS0xzaIOPLpFyW75VK5VHll5LQRBXdOF84Xzo2mdG6eTZouCgi0ARUhQIt2pVJKg7thp08b6+VjNiNXatiW1raudgPQdN1jaAhh7yzmzJW1yjpCdWxGCjivIwllnOt501E9YnUuE61k6s5VT9CbY04482pm6ic2hNhhTebV1TrcpazAOXWdOuZ5VLa7azK9jOEFc4TZRDdQkbUcNY+r1x9Ty3gptvaqlQ+LgkN+DmYLI9NwsB7jNwFeYmbkae+FnU5YDdNHstcjG5jdAvXLHo7FvQEd7RZ0qzyTfuG2tm10/Um7zk03abtPXNnhIE5Iw8xWpY7VLj8YnOcxtnYbXVWaPmLG0/LWNTck3M7GCpDFori01RMYGV4eRK9NJlNNdK/h52CLzzZbGl9a2LbhtW2n5N4xKshYfM79FBHurNatbaRX0ZbYCV5uVXyoazrQVIJbUhnfZahxs51xebMyAKepB5cImKSOpfuLK0VaU34F4zcn3FjI/LJ+Q1oZ0q500E2/JycevJryMW/EgZXVphfsvWGiLbVGt3NbY5N1pZa+o5BGPGu60WviWIgay0+X6cbKWdBmCg0Q5HUby3Z8hq4iq02e0i3pgBYE5wh4cmpQxe01D1/wCFl6ZVccnHyMaY16oVIcCbbxsdGnl3rnVyVAvUFcrHE8x1JVWql7C0K28icdQ97xQzwvSg/UI69VaGs2xrrFVcnGSWZWPPN5Lwo1kVYiTEsGTk/wCJk6Zj3nI0zKoKZdgZM1JValnia1MOOhjYaGeRE8rYJ0skRlydh5oDfLn/ACuX/NM6eSYMdzBiJFoUQVgTjFq3l+Xj40svuzW0lQo/xsjGpyRdou0yMW+mVZDiLn2rF1GqJmY7QMrTabTaFZxnGbeG04QVx2rrj6lhpLNXaWX5WTKcXYYtD3CioUVf5ORgY2RLdDSW6RmJLcXJSEopW1hBl5Ig1DKE+J5M+KZE+KZE+J5M+I5M89lmeYy2hS54uGYMTaJXTvVi5DynTUBHb/PKho+Di2RtHwDG0LDMOgUQ/wDj6z4BPgJnwIwaKRBpBg0pYul0RNPxUKqFH/wn/8QALhEAAgIBAwIFBAICAwEAAAAAAQIAAxESITEEExAiMEFRFCAyYQVAQmAjM0Nx/9oACAEDAQE/Af8ASycQ9QPaDqItqt/d60HAi+KXMsS4N/besWJiPSaz4YmPBHb2lepuYKiYRj12OkZh6gtxA7RbvmBgePsrO0esPLelZTkTjmDLHAlfRY3aaNMXmIoxLrAtpX12TWhhUqcQeCnEW2A58FinPg1CPK+k7R1ASt0fY8y5MQSqfyI03AxW9aidX0mdxCNJgPglLvuItWjwrEfyGKczVpGYt2TiONsyzzKGglc/ll3DSr8fWpOIMMMGdR0WrdY/Tuk6Sg2N5oKviMuPCudYD29QnTW6hLfxlSZ3ntP/ACExvEn8muqnMoPl9ZJU0zNm5hoX/HaK7IdLy1ZxF5jjUpE6c6HxLPwlI8sbiKRoAjERbUEvdbayso22jHAiHI9RIDvtFbMsfQu0puLNpaX/AIz8kzCIPC0aLZjKyl/8TCJTXqSGpSYOnrHMs0Y0pH0JtG4lfqVDIirAuN5d+USjB1mWnIg2rEO/gFnXppfMrbyCVpqn07TpxpBUw24O0HctMFaKPMY9J7uTCInPpiVnBgXaYh/7Y1w+I76thM7YmoTUs7yTrMXDadONQxMkDAncPzNZzM/qZcw+TmWN/kYlgfcTGDnwAJhGPQURYp28C+bYgV41CrB+4TAmeZ2AZ1XTaKiyzoHw+DOoby7RItZiVjGTHsPCxaWc5M66ryjTKKioz4DeMcbCH8fSqORHbAzKt2Jmsgw9TZjE1tMtAbIvcHvHZmGGg6YBtQgPsZWUXgSxi0rsC7GNb8Qa3hT2nUsa0wsps1bGYgzD96DJhGIBKjidS2ElA5iqud4ETHEfA4ioCMxnxtDYfabczqNWnyTprCG0mAxLmYxamcyvp1B80awLssDKOZa3cXTiNWtW8DBtxM+h067x65jw6hsjEqXCTG87mNobBF6plXSJrYwK5i0mDpiZchpuwYhyIiVg6p3tto13xAr2GCjTzFwJ1PbdNMrqKeijaYrB4V3mmFcmYwPBs5iU6hkwog4lQr05huX2i9QPifVEe06z/nbVKhpGIBmWflKa1PmMNmk5Es6nUfLBW77mLQvvH6UMnlmHRsGY+4czEVsSuwNsYE2nvHODiYzCuDOOYT8RcmLSWnbRBljLbdeyxKGadSrU4Kyt9QzBg8xm0ptDWxOTCipxHtrCfudwniDuPBTOqD0+20R9X3adQzCMQGJ1BC4MpTUZdVvEjLmWAniUqW/KZVRgRbig0mOc/kYHA/ERe607DtzDpRsRRmDjBgCrvGs1TtE7ymgBdUcmBwvMfqQRjECgTH20v7RlzGXEUEys9gZiuHG8ZMQS1PcRSY1mJ53i9PggNOyEENuInWIo3nVmq8ZA3lGqs7xWDjaNXiJS04GJ0zeUqfaX3b4WZ+zH21W+xjLr4lQ0nEubEVvdZXcrjB5jDEJnE7ZieXYRyfeWdWzbCeZotJ9521HMNIYeWJY1L+aJdW8P6mCYW0kiON5iYmJjwK+/iJnQJXcV5nLAiW78wjHE1ZiXezTniFcxRgx7e0I+X5n05A1GVV5XIhSccwXheJa/d5EAAgOODB1DiG/JyYbFM1LNQmRMZmJzD4k5mIrdveBlsEZMRkmYthSV2q80Zj1a9jK6Cm7Rjk7zpzpYpL7tPlWMSTv9zIDDX+52z8wI0UEQHxfn7MiE5iOVMVw4jLGSERDK7nWL1KHZoGDLzNGI3lfMbMImJj7Ss0iYmPDVF+Y3P3o5UxHDiFYyzTgwfqavmZEN7L7xuqzzPqBDapncWaxBvMeHMOZqmoTWIAze0Xp2PMOisfuHf0FYrxK7Q8KZjpMeB3jCFQZ21hqWCkRahAMfYbCs736neHxPqB8T6o+wjdQ7epX1GNmhcMNoYcT/AOQiFJogSaZpmPAKYFAlh3/pAkcRbvmeV+DCjCEuPaC2d0QMpm0wJt4aWM0qm7RzqOf6odhxBe074PIncr+Jrqncrndrnfrn1KjgRuqb2jMW5/0n/8QAKxEAAgIBAwMEAgICAwAAAAAAAAECEQMSITEEEBMgIjBBMlFAYRRgI0Jx/9oACAECAQE/Af8AS0rPGaBxa/m4GmPu4pjhX8uOd4sv9EMiyIffklFLkk4o1r+AlbPHRQ4lV6My97MWaWIxdTGaKvg45M3WfUCGXWt2N7GogrjfzqVM53Gu1GkrtOFtonDQxP8ARDqMkCfVeVaXsZMcq2OmlUq79Nvjor5sjowZvpnKK7ZM0Icn+TrexqbJSp0RXkROOlii5zoydPUbRjlTGtGQsR0j2aH82YsxdVp2ZHJCR1ebxR2JSv3S5MeR6jVvRmW9nRv3UzqMSMK95lyaY0RiZl7iMrRE6R1OifPzZP7GUfi9jyy/7bk8cciuItmRep2jJvEwSqSMq1RsxfmZn7iJmxyb2IYZiwyRii4Ssn2fyZN9j63HKjHDyS3MuFRjqiYvyszLTMxuiRHZmN6sZxIz4rWpGO/syZNLPI6s/wAib4MermQtUt+z+TNk0ysnPcc2YODLn9uhGNVRnV5CPtY+C9zo5aoUNVIyyNRkVpM8drcSjBGtvhGtaPlk6R1HujffF+A8f9kFRKFys0Gg8B03/GzNszLN+R0XJPcwJ6akUUirIxctkSjpdfJnnpJ72u8I1jRJpHnRs1ZSNVHlo6fNqnTOpjaOngnmdmSO/A5Jcsk64Ev2bI6easySV/Jl3f8A6Rf0ycdLMUdUkiWyo8a0ngh+hRSVLs0hxT+iEVF2iWZtUZ04y1RJ9TlfLIyvkwvXEVIZHbcwY9TuRONP4sstMRS1qiT+yb1HSRuZM1tIeUxyt7kp0xW+1sxKN+46vEpK0LFc0jL0sIpbHBrWm0KLe77Rk4uxSnkKrn4epewtnZl2ZdHRLlk3v28d7mihxT70zVGPLE1kx2jItMiXUz00KLm9zDj8fJZqRuYZSjInNS+Ga1E4aSW8RnT7QMj3E7INUSaTEyblexpZLFf2Lp0/swNYY0Z46/cjVtR0aWgyy07IjvsRx0NqJ5CGdaiWlq18Fko2Zcbjuh7siqSQ97IyFLY3fBwOVnHInfAti65MSjkTRlxvFOmRbW8TFc8nuNlwRnuOLcjY2RrMWmf3uSjXqaEUS6dOWpE3pRCZNb7GOf0Y3Rlpbo3fA4+TcX6RQ4xFJR4JY3kW5OLxyojzaNcpGiu2TKo7EZJjRFaTzNid+mS+0ci/XbJDWqHBwE7RVGOQxQKo+h57dI0ah4JWdPrxbPgzwjl4HGWPkx5LPIhu2dVFtpoxKueTnuhP0yj+i/32qxq9mSxODtFWRVdtaolJsiLDFO+zo1CypPcyYlljsSwTgQv77ONpEYlFFFerklGxbclC37PGvo4ExkIajjYT3M2TTweUW/B47IPRwa7GjQhQNBpKK7X6+R+0q90J/vs0mShRZCeknNS4EZ1cbIx+2Re3oTNhMsssZp7r1NWbxNpF1z2ZKCY8bXBW/Zq40adxRNJRXZd79FD+ChpxLUj8S+2ko0mk8ZpNJp9HBd+mzn4nEUvpiXpRbLLL9K9FFfI4+qyy/RRX8miu9l97/nbmn/Sv/8QARRAAAQIDBAQKCAMHBAMBAAAAAQACAxEhEjFBURAiYXEEEyMyUmKBkaGxIDAzQnKCwdFAkuEUNFBTovDxJENjsnOAo5P/2gAIAQEABj8C/wDRicR7WjaVqNiv+Fi5S3D+Nqm0gjMfxu1EMghaJgtNwFXn7Iua1rT0na7u9VixFK1P4lNlqG7Ni1gIzc239yk12tkb/wCM8Iivq6G6y3YJIvdVzvQ6Q2Kl/itcBy5N9odF/wB1KKDDd1ru/wDi/CoZufXwRYb200t3aKhUM96rRSXJks3VHcuUbMdJlVNhDhs/ij3s54dMdyEaDzss9MP4R6e3NWve6TaFfzPBylOTuiaH+DSDhPf6x8+ZTsVtl3vNzXHQOd5p2xbpenUq+S1RaCk8DtqpcfFAyC1jGfviFcxw22yntcS4w3lsz+PAdMuNzRUlWS4Qeq0W3/YKb4bn/wDliTVYEP5VyMWY6EX7qzHaYTutd3+qcv8Aj/6/orcLG8dJOMM2Ispf5RERtl3pb8BiuU5MZXlc2ZzdXRSquQorlwljqTLSO78c5zOdQBNbDnxkQ6zzeqK7RUdqwc09y5B9jqmrVLhDeL617VMXen2aNW7o/ZW2OsuHvD6ri+GNHxYfopwuVZ/UpXOGGjYg1otPdcFMG1Exf9kK1OCy3K7v9F+raDmCm4qbCXQ8sQgRcfxkaWSgR8Bf2qnoTGq7MKotDNq1TvU4LuLP9J7Fy7bPXbVqm0gjP0RpmKFawltwXJGQywUuEwhvvU+Dxux1VWHa+GqJdSK+kjSQyVOcVtKn6UI5hwWwp8PDnD8ZH+Ep8F/Mi1b9QrBu905jQexDTULPesirUMmG7q3HeFyzZjpM+ymwgjZoq5o7VqkHQ4EWXDTq0K1s5aqm0z3K/vUokMEKcMlj9n2QETscLit+mWmCcn6IcRsp3LneCrVX/iY3wFWXGT24+RRZE1Yzf7mix1HBHf6dVJus7JqtO5M5tOsta074nErVY0di13S3le0B+GqhGzElOySWyv8A19BvxFTxzXOtDaPqp1HiFMd4ToUS/wDuqLHc5hkfSJyroY0GVZqsSJPYZK1atwsze1TxQP4iL8JQc3nD+5IRIRsxG5+RVuHqx2UIPkiHCRnUHRLTVShgucuWda6raBBrQAMgpXnIKgDfiWvEed1FMMGhwF8qJrrpjSz5vNWbwBOWaewWA1hlKyhwmGLNZRGqab3J3XAPpPbsTDsTdBaag0UjeKFS/EP3aLbOd5q3DNmI3+5Ffy+Ej++0KzGbLyKppstMsz0VYbQee9SvdkFrHsCkPSfDvaDdsVqFVuLUC1M3HzTnZoue2T+kFFGER2rtR3Jm9Qj1fTlkSEzTFG2a7PxB0zFHZoCILL8D9lY4Q0RGKfBYtnqmoWtCLh1aqtDkUGe9e7aVZYZZnJU9QD0hLuQydRFuDtYfVM7UEGNvfRWojpkXAYIpm8KF8KHpRW7Zpul+0BDcfxkjctWoyKBF8p7VKc96lFb9Qps1fhKmzlG+Kp6i10TNbVBijMeKHxHRC2NJ0s7Ez4U30mnMSQO3T8qh9v447mjw0Xdymx1VKJdmv2hl3v8A39Q4ZhAqI3oT+6f8ehvw6W9iIaJyaFzW/mVbIXPb+VVi/wBKrFf3Bc+Ie1c2Z2qIw4TTXDEaAdiYet+LmNDtyinapNE3LU4t+xr1tVkp8J913YrLr2myez1ERuTlHZmEwm0SQJ6y1XHtqrUpyHuqYOjcnW3ATYL17VqoSdzVRkU/KtXg8VavBu9yo2E3xQaYpM/dYJIcZrHLAKLDw547dAQ/GTCfuT/iTocJtgPdNznGU8l0Ig8VwfhLRLjBIpp2re1Rx1p+Hoy0nrCa3tTg1rXNa4jI3rlA5h2oEndJWxDig46l6rMbwnC0JqE9tRLJUHoVVeTb4lSYJfVWIevEyyU4rrT3t7t38AduTRm6eh0GGKNOs7JQYEIzZBvO1BM3FR/l8vUQ3dih9yjDbNQxEE22XGR3qI3JxUKZrZ0xBkJpuiq1BJvSKne/pG9a51uiLyq8lDyF50QYjjKRkdB/ETVfRO5QjsmnPNzRNF5dVxm5SGhnauEHrS8PUHZVQzkVvZ5f5TCz2jLvsjx4fCii9WYVWC60FzWrmtUWQZKzVdq1LszcpnXdmVNxUmHi2+KrecTeVqQnnbcEXOs7lxsS73AjD/lmz2YaT+Ga3o6x+npjMCSDOm6Sor1zgmazccVEObz6grcoD86d40Rjm8qoluVCmuJmAaoCVHapRaakFTcVKC0vOwLXss+KpXKOe/wC5NjW7gplf8IvPS0P4urQ2T9+kHL8M+J03U3enFG1QgSZDJVaTvcvZNXsmdy9mzuXNb3K5YrHResVeVeVaZO0b6p4HOh1Hmg7Aq1vPjokHtnvRBxVkTfEybmi8lsKfzFTILzm+qkLtmirpnJq/wBPBkM3K3w55d1MFkAjD4MaYvTWuuiV3H/GhrtstFk3t0WnKZ1divn+ANnnGg3oNbc2npxTtATXvdIL2ngV7x+VUY9UhvTS+C4W6iqpCd3qkBy9me9c3xXN8VVniuY5c1/cuLa11q+oQnc6hToZ/wBvV7EAg+I230Gm7eUC+FAEM3VUosR8TwCk0BoyGjXiCeQqVKBD7SpxnGXcFqCfWwVL81aiukEWt1IWWamuLB5RtWJrxinNxNyDkIvu3O3aD0IVPmU44mzBmHamxYTQwTk4C4hbqevY3Bmufp9fUT6TiforJU1RVRpiuDz9w2VQTPqGns0Mij3xZdvChP8AlKY8XModk1Gh/MpxHBo6ylBbbOZoFJ7jYybQIseLkLImcgpxa9UXfrosw9eJ5K3EM1zO11Am2i1wOIVqZaxt7h5IWfZxDIgm5366OpE8HKtyMOKdVomw5jJNe73tc7zoh8HbznumdgC319e6J03eGH97fTJTG5BRNkgnNa6yxnPd9Ef2cRnAe+X08V/ty2uR9lXrfoi0mHUzVXN7lz/6Vz/Bc89y55VH+C9qPyqj2qQDPzIca2U9qcH8mx3SvRgzmyINU7VO51xRdwezDnfxcwp3nMrlKow8lxo9pDv2hUVpzpBWOBw3WOkp8If2NXJsrmdHFtNAdZ2X6oMYJNFwX7NDN97tqrR7ecEWm4qy+pzzWsJqyyTVSKxo2MTnVc917nXn17rPONBvKbLmjV7FW+7RP0GNzdojHrqPLGKQ7vUOtHap0DTUqsRnevbQ+9Uis71SIzvXtW9657e9ckJ9Y3K2daJ0jhu0NhQzyjXWtytdLz9AObePFcYTq+aeYGrBNxegYs4zutd3KQuU3uDRtVmA0xD4LXfxcEX2U1jBZaME6Fwc73K1iE2JD9qB+YZK03/GimkECzCGPS9fDGWsiHYqRxp2jTI6fhb5/wBnRPpOd5qJaZxkCJz25FB8DhFAZycjzZfCqPH5V7Rx3KHEZFiGG7aqkqjVreCuKo5cm4uHSwU3co7bdotPMmoiDqszxKdZ5412oFvNiVB26CUP2mNYcbmNqVTVh5vbJ3cp1c/pO0Wozw0KzwVnzOVvhD3Ky2mZQawSaFxXB7sTmq1crTGWWG+1Ra8X8oROtM42kWPOsPEaKhTLJ76/gIh22e7/ADotC/6hTwPoxHZul3J7sggM22hvCmFVvguYqMCIGCi8GdvanQ3jWbTRVSYLTlOMbXVw0Vc3vXJsfEOTWq0+E7YCZAInk85Wkx/eokHDnN3H9VM0wdvUOd3GBRIk9Zrqbk2I25wmpxXSVng7bA6Tr0YrrTiKma1hrKTe9fRS9lC23lVm5ajWt3KbjJSBtfCrMJgbtcmmO8G0NWQ/BEnBCd5qdBCIGHkfQmmZyn3p+2ia7FtUW5XbvQtZIPbe1MjQiHWxIgIcjEl3K5jB8SlxgHwtVXxHdq5gO+q1WgdmnXiNHaonF+zLqKDF6Oo7cVblS5wzCdDca4H6oftwdDiinGNuchB4HFjO8gpvn23rape8v9OJg3ge6uUdXIKgkq0UoYdFPVVA2EO8qcVzn71qqi4t5s4tORRZE1Yrbx9fwPEtBtPvOQR076fX7+gW500Qxm9AIdWnYdBa3DnE4KcN8mdJwv3Ba0V3YJKrS74jNarQ3cNOvEa3eV7S18IWpCcd61IbWrny3LWiPcqhbCnMdc6hWvz26rt6kPl+ymO7RRGt18hcg582swGJVloAGxWorg0KXB2yHScg6ITEO1S0YBakNx8Fyjw34alXOeesV7NnchL2Ljd0T9vwEX4WjzXWGmeVfQhjbPu0QW9uieFx3Kt4oVHc2+2R4yTWxCXQ7tyzXKva3eVyYdE3UT4sFjGhvaVWK6W9axmqhUY3uXNb3LmNXuhXq+qrzShEw5r/AKFbCq1dj1gpjFMhgytmU9ibCLDxcO4NwK41rxxeas8GbTpFWuEkunmqeyOPRWxare0rWd3UWq0Ba72t3lShhzyuTDWjvWtEiSO1Sc5zY2E3UKsRBZijDPd698U+8bt1NExfloO5Ddpd1W+f+NHwgaJFVw1T9FFhRqQYvvdErVfDLOlNNgw4r3MYJUuVaKlXbVaaN4QiwvYv8FyTXOOxa3Fs3mZWtGPytkq8Y7e5eyb21Wqxg3BTdIKo4uHu1j9lKHCaOzQD/tOMiOiVMXi4o5YjLamRcIbpncnR4DeMhxK6uCdx9oFx1Ie3NVw0EQwDD6Trv1VBM5lWnuDRtUoDbZzwXKxCxvRbRVDjvK5oWqpFSaCXdVBseAaXOJsla9jerL6Ow2+si/CtWjdmCkb1NZO80c/Qe7N3lojPzdptYXHci2JWz4hez7FJjQ0KmjkRbzy70ePNoGtgc1WWiy3IaKmSrEmdi5OGTvVmEGjcEHRnGLFzOG7TJp4x3VQiWhxc5uY3JDJUvUsPJcjEfDGQuVpznPdmUGtE3m4KzHk7VtWRcpnmojg4tdY3LjYzy9hxyU8QqKRNclSHTrUWu/sauZP4qqQoNi13NbvVHWj1VYgwTO8FzpSWtSI3ntyPq5vMmlzR46Op/wBVI3+eiT6OwcpOofPTC3T76pz8hNbfQ+G7a1UqNBsSsi95uXKOt7MFLBVUnOm7ohSgss771rFzlrGqk24XuwCssG85qZKLYPKv8Fyr6dEXK5WU2z7F3N6py07PLRXoU71EiC8OlLYnFs2wW+JVEWvE4TqEJ0GCC9t+7epxnzOTaBajQ3do14gnkuQgGWb1rR7AyYFNzrW9apkV0XhAtIh8Lbdk5WpScKObkfVPhRLnI8D4ZzWmQfl+ipUKgmzo/ZVNMHaLMQW4fi1Wp24WDwrIvdq962IN6RTRonom3nC5bDcMjknuGAmoLYdAZCfYuLinlBjmpA239FlVQ8WMhf3oHPFGMwU98ZbdyLjzVN82w8sXfZAASAuAVmEONiZBTiCTMjQLlIncubNezaqwIR+VEBtkOvlitVxiAYG9Ai4raiMB4JsSHzm+Kt8IYWxccExkFljg7fFVRYy7F2SssEvqplFsHlHeCq8gZBTcK+jqtc7ItwU9RkrjaTovJvtc5rcdqNk1F4N49Vwljr6Pb3S+i4nhOtAwOSDmm003FFzLzeMHKgMhe3Fv3CtNRMPtabiuMhAhrPdODtFOaKDTt02vdPO2bUQ7tX7Lw3m+4/P9VbfEdEyBTn2LNq4ZBVqVP3Tfs2qonszGSzgP5hOBWqC5coZNyWqFrva3etUuf8IXJQD2q5gV7e5a1g9inxFqV9lyk0ltv3HCVdG3Aqn5fssJKa46KdwNwTeLM255qbzXAZrl6QTSyDjtToRvBQzUtEjfkv5Y21KmRbObvQtAlkUXPCEPhADIhuPuu3ephRvddybvp/e1EOC6fByg+E6bfJTucLnDBYNefyv+xViGJRMZ+6g1tysM9o7wQn6Yb+T7LNpwIU2w2g7Bp1iug3C1eq62OsqqTeUfsUmagyCtRCe1XejNtHeaDmmUVuBUjquxGnb4FPAvlcoD2VaOcnMh1acT7qdEebRneVLpDxUHhIvOo5Aqt/mpuPFjxWo30yyIJhSjEug4PxG/7+ocxwm0qxE7HZ/qiCAZrjeDHUxatXVfixWA0Oc7A/VWQZnFxvKkKxDcEXvNpzr0eMbahu72qZ5Tg5udkptM25+jIo2r/e++l0RziIQypNcY2rne9kpuMlKEOMd4LlCbHRarE6HmuzCoqqeC5MOf8IVzWbyteIexe8d7lrQ/FUghCVoSycpnWZnlv0VVT2omCRI1sm7sVkhrG9VDJDNcJZlrhFB8Qa5/p9VIqX+xh1f09RJwmFJ5mzB/3VVxvBtWIK0xQDxZjFoLmqzD52eSi2iSczoa1Ew6g3swKMXgXzQlShxHozuIuKs/2NiMr1CsXUtI9E4Kw+glOwPqtZWe5WLj7hyOXatejgZEKcuLHWvU3C2c3adYyXtAT1arUhPO+i1ITQr2jsUv2mzF6JbenMiABuQVNFg9ioKnAKcRwhBHM4lPB96GmTuaLR9a2G+40DvUEGoViCbUPEE8ztVpxm7A/ZcYCYRFW9JRoXCKveLW+SB6TEBep3tzy0W2GzEzz3qvJcJ8/uFYitsvwyO70aX+eh3FNESG6pZ9lyPAbD8zgi6KZvdeVQSGgtY2ZudO4K2deKb3m/TZHKPyapQ+TGypU4rifiOjmhU8lUKYwucgyLJnCBccHKwx3Ex77N7XblysI/E2oQkcVFOE5KyDaF9dHyK0fePl6ybyoUMzBcZyyC4qPzvdd0v19Mm1Zgj3ul+iscEbYgj3yKdi4yA4vii/jPe+yN4cL2m8KDGHuvE9xUB0sSEHNKm29Hi7sWZblMFSd35Li+Fi0zB/3U6vh54hTHoTbf5qumVS43AIgzYxpkTj2Ky0BrdHKHW6IvVmdiH0QsgqD0L9FnnbBVcjCfZ20TeOgOMWGZtcDfvXJvnK9rrwuXgTOYqpQY1nYVSy7tkjahPHZNRJuAkxQm5N0VV6o4elK1adkyqnJsBmb71agAxX/wA2Jd2foi4utPN7irM5PNWH6pj8x6MpytEN7yoHA2arTfuTWMEmimi0DYii54USHGbYi4ZO3KG07VxkA0VnmxeisjmpiTYuWDkRc4XtOCotSrOh9kYnBTZdixFrhZf0T6bHQ/ax73IBmqW0LVNxkBiVxfBMff8AsnM4TrcdS1kUYUXC45jRI36JrkwX7rlNxDdgqtYW/iqpCmm0JtiC54vQbwhlDc9tx+ysuInk5apc3cVR4PxNUnwWuGw/da3By35fsqRC35/utWM/8wVIz/BUju/KqcIP5V+8f0r94P5VrcIf4BcyJF3zPmpMDITe9TiExD1lKGOMd1VyjmnZ7o+6L3i06IZCslEb0Xn0XNbzrxvUDh8NpIbSI3JBzTNpx0sgSBc4h24DFNmDZlKeE1NcbwehvkPohC4VqvwdmqocaZEc2IPqrEUSdgcHaJihzCDY4kcHBa+vD6WI3qh057FMVb/d6/ZXOsxYdYZOIVoQ/GhXKvtNGDeatqkb/IqHwoc+HR31QOiUMTljgFOIeMO27u9QQ4TBwXJN42F/KdhuWpCiw5dEr24GyI2S5rXDquVYcQfKqu71/tnuVAFSfeve71iqq8KjSVUtYNqs60Z2RoFYa5u64BCDYLW3uxorTJNazEKMCb5P9IxYYnPnN+qtQTYnlzT2K6G7c6XmqBjNpdNOcXEuNXPcncc2Yi1IKLmzdwfPFu9Nmi5nP81xPCp2BSeLUC0gtKkRbh9HJWgTEhZ4hTBmDopdkrUE2H5KUUS8jpmO0Zq02rfFqkXxJZTQwCqq+94KPAdzX1705jr2mSs3MHOKDWCQHq+MhasXzXKz4zrK0xmt0RSatcZEHVtTWvF7S29ElkL5mKT+DQAfNS/ZoUsSHGi/dwdttCXBm1u1kDxMEOymrDQy2fdkqxQH7ApuGr021mgyEyZ2rVc62fEqo13e9grNJCpcohlSy2W2/wBO3C52Lc1KLybsn0XtW9hmgXtLIIwN7v00SKc+CJ8HvLehu2LMFTFH4HNcW8TZiz7K3CdMeStMo7zR4rUiXlhuKlItf0Tpk4WgpwTZOWC1m0zF2i0P8qnNImFYh0xLsk0s1gb3YoHIqGcwQuEDrT70GY47/WzuwKINA2hzC/09OtgVrmb+tetTW2Y9i5TmH3Z+a1HiyMCtfkxmVNjtbMFatkt6Ssntnip3MwY43qxzXeAUhrHPEqYM3HA4K+3EyYpxKDBouR/8Y8z6iRE1qsaNw9ExYQnANXsHu7QqVaVW/B2SpQ+Dlq0eL2qqlF1gLnC8KuuzpBUU3GQU2kHcs1rNsOzuXJvDhtomh8J4lOt4T8QRJSY2QTpZKEestkg49ir6ybzIZlWzqQRW07FGLYFu1aaHZISkz/jiU7itaK35TMqkMz6QrNdDbiplvGHpTUmNcTkrRfDtZe6pBtra1TcXWsKGio6mZopAknvXJQpbXLlHmXRFAqCStxTJvmjwh9OMub0R68xYInwc1ewe7tCBaZtKIImPJB7CaXOCEOLqxv8Atomyn1Wrybz3FTIBfOywYb0OOhgu6TKFcm8ROq6jlKICw9Zas27l7rvBctwftlNcnFLDlP7rk4rXbxJDk7Uui5PiPgxGzaBzVfLeucO9YK7x085e0avaBUbEduYVqQHfM4BcrGhQRsr5qcOG+K/pxblajutnAe6FIVdkiwytNudtWRWrEcO1Ujv717dy9se5e1Pcv3iItaK8/Mrpq7RaiEMbm6ilwZvGu6R5q/aOEuLiLlCabw2v4AxeDNtQTV8MYbQg5hmCiCFbhVb5IQ+FmmD/ALqYMwqqAIfO1nVXKmUjcEWOYJ+asNdbBwNUXPhvgSxaaLk3w4ngVrw3jxUptOwrV1fhMlSK7tqr2HsVYbD8y1uD+Srwf+kKvB//AJr2A/8AzXsG/kXsR+UKkIKgaFz5bmrWe8/MpyazauTa5+4LlXhnVZVxQa2EWh2E5zO1CH75vNyDyZNcSB2Kj296ofQqQFrRoY+Ze1tfCFycB7viotSxC+ETKtRS5xzeVZaDEi9EIROEEEi5guH3/BGPwMVPOh4O/VUvF4N4VUXQtV3mrDhNnQP0XJu1uib1Bi+7ZsuVqA2ee1B0R8zhK5EABuas8/KQvXK6sPvkuSiOEsCZz71VsN7doVYbmzxYVLjojZ9Jqlx8KeTqKnFO3OXsf6l7F3eF7GJ4L2URezevZuXM8V7o7VWMwbkSDGiAZUC5OEwOzcpxIhcT0fouMcbJGGARivkcsJBOe+pNzTgFChQyA+1OtwXMhv3OVeDRPlqtaHHb8pVXOHevaf1Lns/MvaQ+9e0nuWpAiu+UrVgNZte77KceMT1WCyFZhMDRs/CcbCPFxx72e9cVHbxcXLA7tEnCatQTd3plscY24g3qzCfIfy4lJbijJpDU2Ja4zyKkBTyVm7rdJTOu3y3Lk/aeasxJQ99ZoljbTfEKmt8KnwhrAdlyLgSztov9wDpcYbK/eIk87a9vEd81VJ8eLC+Mqy2NFJ6VpUdEe3pA3Izm6d9q9XlrcGlcXDawy95uCrU42ryuMc2y/Czgph1qGMHYrX5ov2qZALQoFmrbRr2ejVo7l7NvcqMb3firEVsx5KdY0HpDnDepsMxoOxxVQuRiEbMFy0LeYf2QMKJZiDpqTmOBwI+i5d3F5EY/ZHixNik3W2NU+EVyyU26ksVZDG/FgUHTtywdcNyskOtHCSmBxam1kz0sVYsuc/oyWs6XVbzVZkKdDBW4rrbtlzVKE95h4k0QY1hBuAVqJKI/wC1TZZ5rCWasw5xCMG3d65SQZ0G3KB8Z/wCp/gdtk4UXpNx3hctDtM/mQ6+CdjDdWbcFNhDhs0VVy5F7m7ipPDIg6zVrwXS6r1qOdBPw3r28GW9WgRE2E+S9mVU6veVImbtt65J5eeip8IfZHRatSywZrk7fF+J3KUnM2EXqdnixuqVZLGgbDJa72krk4TneC1AyGO9cs5z96po5IzhQr3Zn+C2rPFxOkyitMHHDpQ9Vysl1o9GIJOXKNczxXJva7TUK7RRasR35iqRXd6kXzG2RUg5svhXPb3Kdpk/hXtVWM7vWtFiH5lUKg03KRdxkToMVl2pC6Dfqo0rrUvD+Dyjw2v3hT4LGI6sSoXL8HMumzWC5KOd1612MduotdsRvZNUit7aLVcD6zlIjGb3KjzEPUauQ4OBtiFSiRXEdFtAq6oX+nEmYxD9M0GNnIZ4/wqcaCwnPHvXIx4jNjtYLV4qJ22SuU4LF7Ba8lXVO0SWpGd2OVIz1z/6V7n5VdD7ldD7ldD7lez8q9p/SvbxOxazojt7lzQtZ0lJs4hybVcnB4sZvp4Kcd3GnI83u/iGsAQtfg8I/IF+7gbiQqca3c9UjRh3fZU4S/wDKF+8n8i/ef/mv3kf/AJ/qv3j/AOa/eXfkCrHi9kvstbjHb3qkBnbVSAA/9FP/xAAtEAEAAgECBQQDAAMBAQEBAQABABEhMUFRYXGBkaGxwfAQ0eEgMPFAUGBwgP/aAAgBAQABPyH/APgO3/4Db/8AL9hNUdF/FK9YFodcDzpDS1oln/22WxDdXgG7DRoI6ftGQF1yvdiW6p5IfEbKZ4UYIXLfoe0HrpDPWNBe4q8P/s5itA8I468ZxEJfjpKa4S8GI2xdkrYOJi+IxlY20HbWA1WbuE7/AIRVguXc6aIBMOP/AKm34RtVHUF+5K1HrSpCR7jMyCUT8R2R4a/OsvgXz08xunY6jo9pauPnvenadSZhnU1JzKYr/wDqaZq4Tjjue8AfEzSkG3Uz6ytga95or1g6/JUqaFSm0O7SuBh8zijiPX0e8QpocK9LR7SjeJH0Pxf/AJz/AGLRmD7HgP8AYt2tk8Vav3hCzavR9Rz98TAW+xg/Vlw2UbHCMKk4B6EqB1ig/hjMcPSV5e9pAyXILP1FtgMhpfqMRsNGO7bDtXheg95ztwWe83y4GTUvsn/lP8Nv8rEaH/CidB0zzhcsPFl4MSynXpH2m/uveNUCUPu9NELZP9Ou7hE028Or9PEWNuq3HNyecomNtmeg+Yo5m6cicneOVmCOf5HNnlHUXVqMiuHFYzbu3Ze2hELK/NTMXBt3QXHlte0qLXrGv8lOHyxIBcJq0+P/AE7f41TGQchaF+sCgqirYat+PMFMXu1pf7nLo7kmGXDgyfuCfPSiu3787bdpct8Go77d4ZIK3NP9BVRsXmvA8f0lMjANQ5D4Zgx7HdxvVS96ZoPhlFt6hYTtHMmBVcX7hX02mSL1vbgIGq2QGWLjefd5gOcnjlFqQ7yxQIhKLl7/APSHeOVvocejHDsLH/2JuGR1Egj/AATB9YJgywlVl7X6y6mNVycm/hie3g+P1BDkNn7JmldaGfgdow03E8m53hdC0DY/4mGs/Fk5DZ9zFArpGf4lC2/U/vKEFq26O+pNqfS+dZrEOL9msuPrGQfy18SkOSvQ5ssBbyK5Vjo8orjC0MiOETD7lH4lfn9v32JzlPPqefeWH/m2/wAah9qg96xOl/d7seZdf0MzFKukPeUweUH8ZLIaOid5sn0nzDW8+BlGVtX9RZh16ud9RD/G5X+PX8pMHCcMywwLwupuzlLuzZvz4ghSY2pbWtHtAJOTILvF6TQbjXn9zebyynikr9IK88GO6xBDwv2GHlDp2h4rhHLUdS/E1aYcCnZEg1Twbhc23nzz8QV7QEA508MCtq+ev52/8O3+JsPrUskUGmo7P3ZmC2prZ2HJ/cr7YpOEu6L2/srnn+IfyONXMtCukHd3WU/UWQu1ULqmPeYME4/OT0XxGNB40QjXYn2kp6wqkrR7PLEiRhnnL4xDlOhh8zQULjPoj0oDue9NTZ2k93726o1g+LP3zMGYJNr+Avondp4suCaQEvCmC8CB7QlbbSByHme0EhwnElP/AECy4+xFuDpcHiuX6IxYCuTjyv5Kqf3G5cGNOGzARmOcILZqQJrAwbFiXFV3RtzXQIL1XGfLqw0De3RHVkdi2On/AIq3wfuPjQq+mZrq8Ut8sp0i6uW6jT1lisJzibsZ71DYeWcTbtj1JyRY5r1mQw4JfH1OzNJ135xXuN+j+Q8r3XT49Y7DMpz/AAmyc2Eek5il9I76H4MWjbow05PNGPiajtn/AHn+k2fP7SzEBZoa8DwYoaLN+xuS46XrZ9MwgnaOocmCgqI6tygsUVoW+QfLwmUOvxVxW7MNaNdjq7Sv0iftgBQBwMR/Atw4/Gs78+LJ7+kw/wCZ7c+Ubqsqx4wwDOIzwS/Jb9PfZ/kO9VGZSGga7XD5k1vJF9phiuM6w0SCCCuqYF/qWXfkfuqwf3Nrn9z/ANBocSpSyyUL1aDhw5kBQhoO/NC6ncTPc/UCfqZzJ3Ujr41mUWDYpWX48T5exp2iNEaevIc/aAgKJUxwod/hMxjgX5y/r4jnXPfrt95wOBXQdns92e2esdCKp1q3pWr6e8Ii0BojTnCa1D1r3jz8SUSaYrz+Bjtge5/J5P8ANXMfvPN+D/x7fk/GiEFQoy6KhFbM3jnmTv8AuZqZ4LoEzzpSHq1zIUrV8avTSWQ6ePHeAVTXIszQSwMGyGlDGDwfZo+8DaujrOeK7YPueJjyB9Y8Jgdu74P3FmhnrPeTLlfNjAcA/BlRlYVwEqLnn45PmCXNB7/nAej1h74en8/9DqlZwg4dYMwTBPKEJtV8vmapp6niKNW8/wBWZHCdmMav0zCIaaBNHh2+zylaR3aXYQLI7UwRpOeaTol6zj8vAaSoclvJHl1mq6fWLGPP9ZgenvqxmEGDG8D5EvxP2GfmPwj+oW9sEEt0OQ+I8OJotagumoX7QKNRP470EccN7hP95/p1IbhjpPmPxg/PHXSfQIpaa1aUcV2JUXD1tPtCsmOM4RiWZBj10NDu/r4mYLd1lX3rNphKMTi4SreP4HOaujn5nQW+RJf+MrFtQDQumnwy0UihXe/DWEcgeH4PW+YmhuLVosNZ2W579xgfp9Zul1oj9Xsy/wC7rDQnozjexFhmtvb5ebHSGs6Or1Hz+DqgvqX/ALz/AA2/xVOXNBxlubfifVYHcUspxgSaA1r9x3Fu2n7EuFKnnWH38yxkKvow/wBg6V8hHNtlyzDFrDGWDYfDEuD6jA7Yi6KXb/swdqrHD30msX5qsCpTRWdXC5R7vJZuIkwLdG0bwZYHQg1n8qAbdTN34qelt3mMg5d3qd52sbTqYOIB6FHQcM+j+D6oNNw0/wDIfhmsEvjxfCLVB9MBcxlOBa+H41wHcw+HWNYCXxaVB5CY84vaeogLiqWEGarmvrFUaXxV3lx4jGPI/MP0yoWoBZer095dJVCuGZlpg3m+lwVtavaZ/wBJpi1VQcZnOTPsbygDvPZw7Q3VWmTsTAK7oXNhAN7p5sGYL54OH99oqCaQXA0jseP/ABbf4Eq2/ALZB3xcTIkx/FEHXflU1zyu02LtbK/fSGAQAdT3mPR9k7J+Ah1wbxZ/I8UvixQ5JrLJ53dQ1YZLaN6rk/BFzA5rP6f+QWAGpUvpPusZQ4m8BThOpa3iCnCNk8L+u0A4zoHQ2mKL1uLdUGX8EtFBrJfyTIH8R6zD9wujerxi64rt0B1erLH1cer0JGVSkeLjn76f7j/Db/DgCPi+T2/FTZtJVrKOT8Uf+KNfEqzY7DL7RrVvpEmoJYDo8ZctrYjCkbevOPZDDJ+ewawzzLY6zuVGhN8IHNL/AE4n4CXml2MfEcm52Q/Q4loQKrDj70mEC4uv31mgDLemINQOstOOl0LDuHoE9Kt+kTWk45POsAFardls3L2KbHKCig8QkKhY0C4OtL6fjBnHP37vOWFnp99v/Ft+WK/8wwfL3hqwWwZfi/ww4E+HP7hFGxyqe9aZpHcLg1Vpyzh+DP4QIfzYhxR3nP8AKc5nPR1z+IqUYjq6La1xNRHiw9mZY3jpD5l8yljLgI1acIGHooUzbN1G6HPQyesMUrQ/4k5wPfZpLgwcGBLrepg+7jMZbYM0N79LeqcsboBNImkNXkcoS/hvpr7Pwr9Z7/2vP4tWtq6mz4+fw/TB5XhLDCO58wnBGln/AIP2KtggNYKdCYdUuw1JrRPw6TH7Uf2DEaWZzLo3xEdHpOb49glmq8TAvGjbJ8B0CujzSP2+2HKRU1n2Q3Hwmoem/MQ19d8wZuE1UfhqmQyqX3HpXiKr9GCQS1uhrxNa7MAIeSrOgZuYdNxTm6hr3gGY7NEMLIn4xhd18TmB6X0JVKRxHo3ZncuNr/yOTeuxW15HMzEQyoZZ4mn3nMKALTcdyUNgMuDsw6Kr1ODuefacBnrtez7v41/tuCjL2PdmQn/ScXSEDUm0hrTiNes1/VP+8uDnccfThNTMrTOBTj+TS/hsPadN7xFxG98wGbHe4FS8xS2Db0/nrEne/XiEnVGArEQFyzG35x6LGTqMflKA85doHq0el+krTZ7W33nDHW6nqD01O0a1cYBz0fic5bqpeo+wbsRA1hwkrWKvqS7nWmpMVTg0vWH6IW0cG8dUuye14DkQ+yh9DeGvGBMyuOZl0c4cnM4HAfrWvxp+rf04+48YggLWEdyajBbs7uZM5CnmJf6/FDINzla+hM/xf72UvpH6MOrHtBhPxE/HIsucYTHrv63F0D0r+YdzbORq6baavMlox01E8t0QNJch9pyMccVvMNFa+/M2r7v3OC9v6jro/QIj+BONnb+5lPYfM3h7JCrtNxSJZRVs8JUGYSl3NENu8PVIU1Q1PntAYaRwWcxNElmxjka8xshXW1YgPYlcK09TZ+8IlBt/Z37sAoCnNbzHY92IidKCr76BLFUddT1cS7AHmPmKUjtkc14RRo9QNDLcUA2VzgqDRcF/TB9w5gTTe08esowC7yXmMEK9CsTAcRWPq1ONDvf+8/4KMPeHmB/To16xRw8up99YILp5TDcT8dIw9DL6EW2+863TwBHzX0R9nmUvRqNkfw/h+GaAHepoQ6mJa+DBleEi4v8AI5d+rDFo9E/vtOmS9k2hmXHCXNK63+ucVAKNZwGp94RrzcSbQIUcjb4Nz7wJVTcpvZ+/7K/F2JMcjV/5HFh0dLpogEIDQMVHRru6Jc6L3pC8fQcDpzh9sMh3oZ+xGjuL7xxQNE6cRB2lojqtx5xBKSLlmcIglwsrgzVqPDVw6c+R/vptt37Hv6RGZGEbwlb6bntMRnJ0ZkpXk/HMRHvh7RvAp7h62+PaZt6MLeJXBx4JSFqaFE7x9CNq1XtGrD6CWjx1YWQszU23O0IF/Vua6PWcI8hcdg96lNqnVlUAYdB779pRDzzh0P3+D85arMmtD6MSyMu6O53I7hj5b69mPIlOicHeKzYjBqsdETvI09MH3qJhNVqN8jQ7TrOvBtXtLilyLfEtrdcviPqU3cofuDw++4gsqwPoOUdOwMziRk8XprMv2dLuy4D1rC/EtEd/wPv4/HuHvN0PO+6BX+w/PBOg7P2vEILRzQdw8lniAQ0rI4Y56koc4wdgOg/azmcvpFO2PUPj1gC3DzLRC+MX7p2xMz3GY4KrY6OnydiaeNWcL/T8SgU9vxNHjKOiBodWX+gjB/febDQMBoEbwIsXY6nPWVEDYvUSo1jiGbIU10bwG9wz/TS3kmiVrr4bH7xJhz5+PWoRlm+x2qJbdBK4b7ar2mc65i6GhGsOsdqQjA3DK7NvGGacAWvbjDO++BBNfvmh+YXRnJXrKcRxWpZqfATrgxct6iYw8S+JXv8A+IdAC1jLfInPz6TalEOXTrtOBCx5D9dotnOXOOVvsldeK65fMqLl82MMfB39IBVzdTT7yim8yleECg5Hp9z2lg2bJxNz7wJx7wV5NfdJQScxT1jhvM7PoTET4fKs91FfaUbfst56cYjzMQawG6fjCi8psV9JlTl+he9esDWP2x2/cFyoc1Nuo+JjzNDsvuzxY1Adm09CHEs6uSmKHVvMrcH15xQvuL8Phelf2EX9DvC6Lm4y7IG7pLTyR2edJcd+wzFebEwEHSNdhbZyeEzel4nb+9ZhjyVfJy/8Kgc0LR2lfUhoucGNrHXWl+7R9cZZGXKw4T3albalfOngZjyUXVbeh4faa0VUaXRcPVmX11Bq6TNc7iuq7wh8srF4Yz/zDKK5B+GZrpSTjxzGe6sE9f7M3OeWo96hGro6yqLwX3iw/Nbyk6rsN++veNLQvPg79DDQTjwPCGmo7TQ/dl3Wmsid2kAjV6HPeB6zh5sFETc6d4i+5tI/cOQ7aSmKV0lIQpeTfFzTAd3DyzCr7B66TKvoOCBb22bMzCwFb2j1eln/AIMp29Yoos5nM+/P4qYqY1p4P/ZdKtIsudxPF+6mCicHHya/cxKgpf8AfffeNw13c4+JZPdDzfgPacekWp5SgrZtmzjAbxnM8THPclPLM9FkdHjw+sVa10Hgl21fiErL1gf4TzSvBCgOw1B7fMdGhk6wwvWFiIiuqS8fDo9ThKa5LaNdBkHk6kJK2ZDGis+NQFvoesSux6LiVv8A2WZDqsV1l7Q4PL0P3ERDQu668oGUqVbVcH9yhBhZ4CPvvL7MatDjWfMaMwQcSgolK5KLQI9sCVZ5lIt0Zfb6bRx4j/e6qC4DYbT7xlmTWFca3Qxo3i9oZMFILTLxeieUNSoLr0N6X8/hQjoMFy+J5bvjzNarvg3emgnecmCwY6TX86uk8MRSwdesIODkdF9JgGRou5udYea5St3D7zlW5T3XfSFadS9KC7fle642esT2m5fT8oB4FI3YDdmRsOI+rz0gYmdT5nSYD5wNzk8JUpWbgTfYt1js5Ma6r7gFPvfaLQuzzV+v3ONBz5DjBCLoB1gGVVzgCgKoum5yQJh9MtdDaJwHdUQKfxuP2YEtVs2ly2OMxL8uYLdMdo68nBmFmcUWOuPaxzHUhAVupU6aXMJWFrYcv1/sahrYgNnjg8pceY5PObLb0haa4O0WA0EwA7SvV+C4zb7APe5rOcaHS/4S/wAvwClbBTx3eNfMyXMHfhP3gxfF1Y8QCS6AQdkJVb9qMdf8QTP9sf7O0SAg0GiMJsBziVBwM41746gdw86jqygKM7XQ+fwFi11irUNtB3hxrkfJ1b/xmdVYYrJNdgNPvCIyctPp6cGI1izhbdHSEULGvX6ik20G7HXNA3F6PGJFlU6VFdHa6T9ys0HbHwraLZybwLoRA8jL41lGqOJ08awcqzgUeWbTfG0UoeUKhlmc1Rin4QuClTxG7ifeMrDQiin9H+vN8I8Cl/MC7HDmYTndZr/Ew9Rpw6JQhgXa23kyn/B4dEsMxIV2zKI6t/X+kDjXFa7m4MxLixErM0seQ6kohdmjxm1F9YWty4BqstZvF479502gDFTBxEGeA8rLAB45Rr683EXPoSaH2V9C2b6Wpqo5EBqsrzRuYHeLhe3j+QTnk6O/KZgz0vW8uH/Iw8t+l9ukVMOji3/RwYEgWmo9TL4i8U+/SmK6VMGaWcTb7ygIAoOESC5o0H9RVbKN4HN92msHG/U1ZRiOSPWYLkzLPKRUeJ6Ph9ZYtvntmAqNtmA0vJ5n8glIZbPB5QhYy5qWp/qxdFqajsxCLqDJ9PFwwtZkSJ1QjU5/pMLM9DR68GE2Oo7ywT5fmffrKFCZ4Dn+/aB3tB3V96Rq6NGCU659Iz+pxGqbTNlNBACU9vnBQApn1D5HePrRR4iPr6HDL1fZjJjdmivHrL3uYedCMguK2usY7dbmUf3/AGXcEcO7Yc0I+DRbAjgbR1OD1lBbGwAJcs0dUO8tw4zV21gZX8jNdOpmk8hc1OOmLrgoNDshVIs685O71ip3kGdMNH46SzBxDXq5k6VNsHU+8CepDLNUpvSrw80JkT9SjnMGDyriu7CFlBKIUYs0d5VOkUhuZz5YJpKGkq6QlKylTuyvy0hGyK0o9aLhv0l5Guy8XFRraNS8E/1H9um5fyQMJRwZ6jlyhqx2GRIig3L1P3EwTr+fsfdIhVEciaMpIz9xoyoj1Qwux0Le5+MAsv7vvKYEvJodn4OYbuHx8B0mCBdBs3ucn9w1ZBjQAaN7CWsA1WHljWYRKwlAaEy8C3p1XF8OPaIOwwrTcUIraL03CTj+iJr7lp5htE2118fuUqo5FHpLUQcVTAM9jzF9FsufCf8ACZvDwI/FOGqOzHmx82xxnX3DjFHMoZDUgaBTqjhx/SCTa2QBW2bjAWepNMbsrBVWDi3muo0dYyKtRWrZzf0mQOl1NmGhjONT1hQkLloC17S7kOL7TQip3W+mhBy/KJYwak5PE5M0QoT5XHk+v+nhCX8Lbfmzslje/PXrKy23J90ZYQvK4MoLPOD64SoNz0X6f2MrmhRp4vxxh948cq7rzlhivx4yoMaz15y1Lyajs85enDmDzjBZTCTnm3N/1mZ1xi+s502EnA0lcMloIHGM3yreVdKnLZ6fvlNKLvJXnjWlxzSgjSyG2nzMKn6vma4bd2wQrv1nVNGb4yt6ygaOzDbVeB+oVjWZTxuc9ptCOV9ziS+Ma1db3Oc1yr9v0sbqgi2o1Lr8km2NfvGVe5GocTDeHxyqQFw+IffSaCNB47et+YsAUujjj0TOrgH1UfUF6uq9XVjwQ4pUr8JcGG+owRoUvh+3PjBv/OnMaRIANbv+lgmwKR0Yvc7rOOfEmaKS016nEi8MQrjyfyWlc4L+p9mby8otbQXx0mas3jY3IfTXBrzfcSvq7mTZfwLf4NuuPB4ws6PjwPzOBG0QWnerWJuutcAhsXjC9JekVAHFl67iGB3m7JzgK/ctq2bY2n7zmu1MTbKLkBu4heTWHnSLX5C+CVphcCHvMqPqbSpW9/7nqltv3jpuytxBb+Lv/VzhbJpLKTIhTkaa05PGXafbfcVw/svUepkspVUNoRXis+fScqvzfHrCQ6XcPElp7Dnxisv/AEaoCBY4R3hPJfd9vEP83d8xUtqXU25ftKUIfa5QwFy5zPVja/8AII07VZJELuOq0n/ZsJXGxUaANdehwYb5IVXEr4e0tdA0mzwmKO5USN5bVanmWLYLqnf8ODLckxGU6Nsf9j3rdca3tKM4oS6/aA7TgbSq1PFucITwsvifs91QgrUE1vhUFwLuL8Nu8XEddrtofm9CebUeXwrJDfGkd6jmXfSSruHUKDlB5x4IPLgS/O5gRGkefZ/UA8+ILKxVs1rGW+ukLIWFKWs6BD97y76P1NvX2lyt4Y/yuKRfwgiJY4SFEUndaDw/0GSIUjokr++yW3JzKAO+GL5N+sOKezW3F4HKKE5A7t3i/E+/CP8AZgfJySjax7uqALITEXUDgNyUnDNTSv04k+fhzV+ap+KN0wrOg4P72lbK2Yzr0ef8gJNFlpHfg7c2Ll0HCLWqr4iBpQbTBhp2eDBbuALr8HE0ifQFPLbt+XSvU/WVLE2PqSzPeb6QXN9ip6iHMGxs7I2BviawQyWssfWNwdSF8it+kdsAy4HFa1ymyA+tqSndob6RreB934lxFvFjreUZo7frDT/C/pfEq2n4X/Gv57v/AAwiGhxXgG7K0lg6EPbNQG1669P1k/zp/LWGnoduaUAPp9IbsVBaqy/P4SsUrWKnMmMV7wU+/pNZRf6S5EU9oBaV6GNcFPV+m0zJHHn+4ADBkGFcR2YdQbk18Hmek8efQ5m/UglROMX4GeFE0/64MBGvba/7yhYI4ngQhbjiXtC40wrPD9toVMNAisl8temZTUJtW6nNn3dsrIBEtPwpUar6zRCxOWEbekaqNQ5zzLjJ49RuZXpv0lw2gOXg7jNr8Dt51lgtLd9+jmbf+VnrDdKkxR5JeFEw4lRtm+ur7w8riNRDlJqQ7wR/Fy5zlC8lX9IlG4MI7aHdlmwnbQMtcDr/AETygIE0+uMxpSSnB3/xaxstDYAfmJWw2vo8D6QWIaAfimVhk24PE5SiEF0zQmV8Qd7FaeIHbTXfHB5TgtWt15nEmxw6CGW7paf3uS1B5wfXGE/CdyRYrq26adJThZmwL02ZakHXU/5+B+D/AK2jhl10eP3hAThMKmTcDh7esD6icBz+845JnKUEobWle/1vEaJkWXZz90IxGrkbD95ygBoTtCMShxBbGq15Qsp/ifdpLCF6ry4mcVcX7NISppwMfioXb9MTxOTMtIrLbpuj0xXT4YD1vh40n0XOZOjEh9BHb52I9Yu9msR7Jk+Ih92KUfCT4Zf3PvPzAtaORhB8d9guXdb0nqqeN9l4wEpCXNuw7aEubgbaDq6E1yA6XyMIoCZTq8HLjLragxzz8/4pTXoDZ7QjGBmp3xyt8EKcSwaP5XTSWXet+HeKoAorq5q+NVNHgZlyfCPWFVGjonK8GDRo16R0CcwD2fDyhwSYD0ODy94gKZW3OzrQQAO2zydpf9gPA+Yabhly4tXRTfYxU1l13HhAgRG0/THYhmzQjjR1+6R/WijEH569YtEyKvhNdK0vI3857krRWkcLrwczmafi0cdPHc3eUGFeG+uMCtPwllOErrKgQChqUWMwo3c/dfaLGzUmn2/kuUM+o4mQONfun7sj0uaEzvPeXpPkQ+JQJoPRQRv5YXx82V/SAaD0jbfaq94EvjxWzJerspOKcJiqVpINshaOXZxfmZBgUcff095kmr0lv9H+SchojXk5+8vtPmgtOPA9JS872YhldvnsQPxJUa9jXEBhYn7Oh4CIc0ueTxHPzCrsKuKhhqrb+4LtYj9TiQaiWJkSNq76rL0frxDyIbr7p69YTNkCZEhQ8WXG26MYdxNMLzPkmans69BnMrrMzEQutxSaDgzQsajqcP7EtF2sUslGhKHc6Gq9o4de3Wx/PabHDHkKfb1i1ab7RUFyR16HOERxgJb/AEH8XeM7HXz5x274HRfANn7mFeR3VdFbyiImmyed7ylOiJP65QOtNsa+syE2C7Doaj1KDVC9Gs4GcCqOsHMt9JeSRxqOtawMB6ARiaG7Xt1w4wLQb5W3QMoB58Xs4q6/SWrcmmp73/Jgchba7fomrFqOvLKCZebqLy/zddIstp+rLVvCPdoyrqvCw9iK9K9NdrNvdCCgWOoxUCtPLzfBtCgiGsT3hGMujyMSqtzbc4G3vXiuCRaJxuHVBayvdP8Ap3hMwMur/TmTREHX+xVGXWzPjeWnNnPhqRPMdTCcDznGpqOggWeLO3L38SzhhY2cYMFwbPVOQm/HzOaI+57QVW9HZfzD6sfFa/eUF2/4iyWfhf8AhchEnUlY6LXPMXc5y/5dF6HzCrwWftp0h9Wvoz/t3iI9Bt5RYdGbJyuKjZuffT+zHJzxf5LMvutDXLZgyOuabVxmhXcV6nh0mknjuhxslZSu783WO0N82jhekQGfhzVyvQhEgLejPF4sFf6FaAhwS4/bPIP8U3o+kq4kFKC2Jok2aGhr/Et74hqEv7rZ9T9kpQ6bVKIFyMLx+5M27tDt7h7kAlCOiZI9AG60QTB91dQ5fzw+Yrdls+hmW2mfMYmoIIGBeJFegjshXlLaFabp2yfMG90dufwmPi4wKK6y7HLMGXL/AM3hT1SiY6Hgwvpw/kDkUw7HgeuvchEXnN2HodvaBiHhUHeE5Z6/IZgS0X3vtPmbd+izrhWhLt3KpQdVhiaMrx4cespRGiuIHVAzQrcucT7sbh3wzfuSGS8bN4u6zcr2lKn/AE27DqIGxpOWHcVwDdmTjU4bdHXXz/vU6j6WriQahLEyM32Jz5iDBC23aD0dI2OjnyhLJS+5tBmVq01/Z7yhmZy7Vb4ezNAEsfFHo+8XBi3kEaHvow1l1NH6m7hzLeSZu5dh9RmU7rR9IzY3O9Rcp47BsH3qAtQNt66TedokasmNqvvN2O0K1HyRW6Q4E6zjeSc56Zlkoe9X7hhV8EC3n9IKNsmQdL+CUtebEpOm71hVzGae8zCC9jiOkLRVetT0Q1DaPygP6T9RTV+z9TeeP+pfjByaj6i1Mk9/M08/hSBm5SGPLDQ+WVMDdtDobR9Jzu3/APA8xG5P64hBdMkOE3hvRigHVo1/iPyI+r1hgSFiZGUYDDOPeLlvWe3vMhtfrj1fuYcC5d6o4jrDgMh1T3GEImTf8P5D4dZeUEK+kMt554YZoeog+Lz4TYdez2Z8YM9yZbnRcv1fL8y3oeEE/Whs+DOH4SGivYI/PCzYP1bz0dtD0qeuJQ+YDz+g8uJYhdDLOFzgJEs5jWWVDdai+b8dyVtVVaQJAWidmC4TjErwj6xmevQJpPQVgvPIP7mJr/cWDOdwgLh03XXYOsScV63+X+4/wKRrafNOEL24lYy8E4xlUK0+DtFoV+flQZ1+MTCl2cjg+feaQQqmg/f9lymttvllSANAxTxuFeXtA4dY0GvE1d+xAlTQxw1K6v3mAFNwUvhrrEwFKgvz4ioKnULe8F0db/U4ngWWde2nzPtftP8AjH7h/LP3D9vR8wt+5nL6yfiGZ7kt9440yX+CU1p0C3rbtAXDUtvwENFXXbP9f3DkrCt7o8/1CrtEHOxji/JOJxxyDZ6TRuz/AHI75wPYz1JDiPqyIOp5RrPdEBs9k+I5z4A71ojtP4A9LTHI/wCo1nJa41/8lNIsEweB3Idea0eK3IpSmOcuF3BdDvKXs+BGeO/eGDh5L8mgy5U2UsDqZy+8Di65R0OnH+zGh4q/cL206iqcj3npiT0uEvgbaUX0JBTATJn+E4sbev7iDXDg1p8V1j5swDLv8e8s09bGeFwwaxoq+Wst8j2OjtOcGgUXIN2CrExor8esEoraG/yB6KaX12bvT0iP40yX6l+s85a9XDXKBoBi5Tt48o0LLs5Okxo2mLF0sixdf6grpTK7Fwv7tDVsvHPJ5QbVWy9mHg/wodSagesf8lDQDoIA0/8ATX3rnFcR2ZddHMfJv1JW7xiCZlwcOxRzF8efBiZAXV1fdicLOnV8qceJvVvLp4oiAUuQe/dyhZtsoZR67kAdfwOd7QPAmeh5+kHY7ToO5pHyhxYDjWrBJBxmvYEwwsQ73+5/eZ7aExzbCm35lqKTggddKl7OXyv6gOXTdgczYioLUL+De+cszJyKdB3YNi6hkXrKyu8zfJj5cpVTlrhKtuLGVATa2miOuiBhdA93GVHw/wDhgndf3GGWbV7FO+oj4tzdW6cJzX27jlBQuEVAi+yX8i1uCUWdSXkPBceHMWveN49XGZUzuFPIwf2Sj2EerpXEB5h0/iWSJvj5Onaaclsz6nzM4uEOerNFhijTKJu820HJ+5pW8Ra67s0k1aE9Q4QWG4KTXfaKON9TpXCK9OKyhWicFiICrz48aRMA8aTdcVquKgFJbzMrHILzz/8Aivrn37d9mIyDyHtv2lXA61L5gsc2qnpB/AOZcS5oIwrb0n9AuNuYdMTZroU/qeL6DEPaI/KgKjw7tiVYnRrZHc8QPibb9I8NNpx71zNPZpBDljcaJNc5r3dCEa7L2u7eUlqkdh/8eu321Do6kYdH3rakt2u/aYyQjNOJr4czHcxS474U9Jo75ZvWZjobf+JFcIqX4SoN0gmJwuel1DMBwYz6uIjHXZ6E+7v2CLZUcsonD3js/wCJz5wrVuv/AIdv/Sz0L14MxT4g/ZLZZ8l6mJo84tSKh305pk689xVM2a9RA9Vx/wBT+5/1v7in0+8X0GXaToI6n0E9Voli6euWEbMeJ2hIv0hhTxX2Mwo48gUPrjACiv8A55VcAJc8w7D6qjkxD1j8xnvSjYnqk5e8f3D/AJX7gMDavh+4LXsQHrexGHbrB7SyIeJv6yiN4BX/APhT/9oADAMBAAIAAwAAABCQAwwAQAwgwwAAQgAwwgwwwwwwwwAQwxwAAAAAAAAAAAAQwgAAAAAAAAAABAAAADwAAAAAAAAABz+i+OwgAAAAAAAAAAAAADwAAAAABAAACQ6Ot4zwEwwgAAAAAAAAADwAAQgjwwAADyqZtkkW4YtAAAAAAAAAADwADwAxXJiwzz4xUB2pbS7DEwAAAAAAADxADyGEmTcn/wAYWVvhvA/EJeJgAAAAAAA8EA8lLL7q4x0xXStyF9qIrJVgAAAAAAA8UA8TUcLQGLc/kHguAwP9ep0hAAAAAAA8EAcSM06I8azvmhPD9cKzWyFJAAAAAAA8QA8QMkFGfKy5lEFpugRsalCKAAAAAAA8QEoMAD2c+USTiDwAGWO8m0xFEAAAAAA8AcSeYY7/AHA1vgN/+o9IEiNbtXCigAAEPFPPHuotdpomvLEMoK0rpGNzwSXGgAAAPFIMdRLDS2S/mRZx0rvyXNayjkAvQAAAPFEznnEeJEk1q6MzVRG+DSCzD91YAAAAPPIKs5BzfnRWygIsikbZbNMYxnnSAAAAPPHWkI4kg0V8QfA9ulA3+OoGzxoSbAABPFOFwYz3ATLzlQ41zLmWNek8njfR0bAAPFDkNNVua8HP5zT2tdpqP/S9wyM8hZLCPFCDwQJU1YwIMpGd150+8yGU+fw+SRTbPFDDSWUECqBk07YEyfUzLMbYgOoMKpOivFNBf6G8rHiG69vRBhEv6inAH8hG+pseIVFASONTJ/CDGCf3lpRE7Odp93TnXyKDgVNHNuh8wTWGAhN36dHB5KWBYWVOuDBGAwAIAANNaM/6npAY4xn2T/57cp5hqdDFSQAAAAAPO3X6REOf5T4Mx1Kxq9arnl7aPAAAAAAANGNOhCplBfFbMSx3UiwAMAAAPAAAAAAAAMMMS9hcrTFm7wRHjEgAAAABPBAAAAAAAAAEMIDA7eumjuC8XwAAAAAAPAAAAAAAAAAAAAAAAAAAEMIAAAAAAAAAPHDPPPPPPPPLPPPPPPPPPPPPPPPPPPPPPP/EACURAQEBAAMAAgIBBQEBAAAAAAEAESExQRBRIDBhQGBxgZGhsf/aAAgBAwEBPxD+yzOsXhXLiXWPP9aFDr4I7zZnVwa6XbQjyf1QhFn/AC3WJxuB3q29m8DIbQtGP7xV+X1AicjPuGN5fhoCOx7mU68BjAXawE5VkcAuMdUDDvJ+7FSN+T8jfbxXiw9PhJyWfmfrsu3Mu7FsFi+5Gn1Pkl5Mb7cWQ7+3Lo/E1wfIE+GOgsRzrZ9xZ3M4PYBsjZGSM2Nw7I/yhDmWY/GupJdP26H4gEw3mbcAYEIZwLAlnGymeknJe5XQJ6nl7dw4xJDmxPq2g+Dr9gV4tD+S67AWHYHLVBOp9sHfuTGM8gq+k6u5zQMIjZBTW7V2Ap3BK/LQbkP2H2Q1MNynaGD31EcfUmCt+GCP+IdLd/zCJGccLI7h0WylygkEH+5qF5Yap8J+w0PZ92PgloCIV5PLQZwINs5m0LFPtrDjg5ZhqhcTW4FOL2RbacbdhcUfrOvxIMMGRO3W2jmCUIyUdSHllAGQL7JsHjYfBhKwB89xjkjwB/5ZG94ReAgYfiuskWP6NLgjcSW0Xy7RsJfbGP0hXAh6IdAydIPuLA/9RE3e5POYTU3V1TLyDBydzsmj6ZNLysdchvf5nLHXF/JYsTq05GWMjR4udd7jfZjxsuSOW0brxlv6FyMdJCPTHvG34blnz/3EA79sfoT6Iry0OP5rkWrLwbTloH3cak7HM/0uMjIrNCAusP8AciNMlhcyBbjV8nQOXBjZickicsnt5QdQR2zIjXSF9/oJWwPUP/kGcyFOQ+4LpgLELs2whN3fcleRMg4OZ9bVpRniSDveyFg5W43qbkmyvfEmfoRGRn8/A3b++QRCxInZIK4Mb7j7xWGON2PpZPoyFvYEM0B5aHKEXXBPxMueMIPbZ3rGFA21m5+R0E4mWjzeGMRpk1J6yfW+BeWMOqZNEE+7uoS6EywwufzCVFx7BkkmC6BAk0YXhzGOZomTFcjXF5lhNfaA6fiOOwBEqy8WXHv02OeFyovTZ/5gScbwCVhmHJvTCtj0Z+5fdkk9xUXEsowxdLIcty2Idxv8FwTBf4nNc6Oj+ZZQzZ+n444oTtg5kQJdBt/OHs64hsjAeNg3nLHSdX2ouiCZ94XJmsSzD2XKafFCderoBx9yGOL7x/5aPptd2vy/gHOvjU6sINXdnnHTn6uhURcWxkGoBTsYhD1+4nL66g//AEgX7ldo7S5D5sGeLpXP8wDfNt5OJivctsFq1agE3B8uTkgE7ZzOZaOe7QwTvYHG8P3Kf/WM5/DPzWABqyfe8dbh5H5Eyp7KOFZyYRgXAM/mhuUYlC7S/ktffiF4jHdnTyOOHwcOxEt2Ym5J+RY8kI4epTR4+rjHhnLmyCYnTMbnHUOSkQ68hWHMoVanVrawXPjcg304gep9q7B2dO4UgzPwDiPQvdaIuN3qQP8AmY4bkxje9PqDwzbSGmFyZcf6gBXt/AQD4OGc6yDfuPSScSC21mFx5T1v56ItARNqYxxGScdrh1ntOJfCJyZb/KX1y8Q4A6sjPRK9IJ5tOiRwnIcLiu4tb+hDYVjwwdJR6tnHUcdG3qusi7l2BbOZCse7fbj9253zD4cQes0BD9Eexguq+BEZuWry/qFHSf6ltncjm046gwgeHPw6JnqwecwiefEjuBKduRbT+ioapTg7b5D/ADcsc/4u4UhwkL3dRA7CwWh0bHDDJLtzav8ASu5Qu+bxNp3QPIHyJx6mwrpktq3+yf/EACQRAQEBAAICAgICAwEAAAAAAAEAESExQVEQYSAwQHFggZGh/9oACAECAQE/EP8AC0WEI7J/nUYfcLDPjrJomfynAvK2h3DAttseEFPKXLm/wGIIlOQvUrt+DiZxtzg6R7WRyiB2KD4Zm5G21kqUf3sNhCCfJ5nUxR8Eh5kwLJ3g3a8kOpqNt6fVq+11p4uyXM8TvmeP28BsHwT2k4fgEHz6hMHCew3v0O6dS4MYLl56SwM6ey3snsey5fEGjn7tYMMdPgIu7Dp3epUcswdYH3WQgnjMDbmtqdlssWyLYaeO5Hi1PaGP9yA9I4/UhleRltwMTHjTxJj3Jlo17JWfdxCOMjMXJtmNgbnG3dZAW3N2DX9okccV5tOMfKwPjgHgbdy3CSE46ZRhP1cNxKj8+ppwZF1bZcFswWqcX1ENdR3d/wBjH4MWs6ZCC8Q7WqH4zSIuT5vCfB/UrdsuBlyWDyWFw63/APpaHPh6/XoNjN4YUl83WnkkGcZXYU33G++Yu90ioPTY2k6GAMMx+B4nXbB8hzEMEJot4z40Id/QuM68zB7TS6k3iyz6udSC4DqE4O7KfBKFllxciePiiXBHEnkDkG7b8qUdtwZmDv5DXbOfz6NlrvUQfIcWiX9iRxELyNt19ogHBYeoHi7iAQ5LVLRGPcLkKke7Ka9kA55ZbzaUJo67r439GglorsnEPZ3ABLDfU+AjO7m3My4SMgS5thTt2UciagEoVOlsOmh7ALTXs3px6jTmy91kJbyZ+hMk2g5DpnogBY8EqHFow2HcmtYQ4CdziU7Z5sH124CTw79y5Sv1M1XD4spvVs244tInFyAfpPQyqHF6jjHP7tREPuTlnAc3tLjoL2yreN2SvMJCkeZSvOavcCOxtnUa5dgJHghATiIkv6/PlAMTiG7C6F/VEhLyR9kDojXhYHnlkGEmNmvBt/0kclBB5kn+hh98fNlakHBl6k4V4s6d3mwIHuJYQjx/I1c7kPc4h3D7LcbZ2w1wGydRrmTRjbwSIHRO7QYcQnu7zNcsgqNPfwMtHGkAzO4RFt55nc9zPPcqcQPd5ngsH4n2DPqyR0WBwRrrGf6irkt+GyyprY6EIp3r4E8jzLWcEuQ1R/gk7n/UHbuceWVG8oUIO8d7QRNG0/HXmGDlPwEceLvgQBKtuzSO5I8OEeeP9yTtB4JDtkeLiC5L7nODS2PraHVvPV3Pm3bj2jEdw7+H2hhRFDp1ImZM54yeVjcy38vBPihwNpCdterh3lKWrk/FT5eIXs23uDLB+DwL6Qefw6tt1lpWIG8RMgcZ+R1GLYp1faIcWF5xh/42gzgs+CUuXJIX9bHqx6gNizPjp+GQZAMZE4sDTuFxhjyQv7K5BbD8M+ebeZxeI6PlMfGhjnq1LVu3NjC82PF4/NCYymkAx7sVzGrh7n0tHcB8XM6v6Rnxf0+CBaeC5e48yANmfq5tzzIO7fD9KbxOOlwdkB0/GWZGS9fBuXLnmy+/hcW2zvudeYB+wHqBO7Ysgzn4cpmz8cr73Efw8uoSwlWrq34F5l93Lgjg/jZ8a2/PNi8x7QB1/hP/xAArEAEAAgICAgICAgIDAQEBAQABABEhMUFRYXGBkaGxEMHR8CAwQOFQ8WD/2gAIAQEAAT8Qf/3qlf8AiuH/AE3/AOmv+Fy//wANf/bf8XLl/wDC5f8AFy/+V/8AuV/FSv8A8I/9HH8FXLSF/V7+Io3vnV6aX8QyudP0pY+Wap5EnpMS8QZX/wCwa8k2JaBlKwFszYNB0F02OcraVuV5iglHatHwCQyfEH+gE0YOgL7wMLrJK0eXhPDcPh+0DdpQvqvUUQDti+VPyYg3/FSjr/2n/fX/AEOBgI8sQE2vDbOzqKcWj9A6DwDARAEDlUwI4xjcyu3GBdvdiOuZtviD520/CepQS2qvsKh8YgHiDIuwZGUJ1TK10G08XcE4vBZb4MvmnxC6CjCNjOMfxWP/AFn/AJzqERTeeGDzSQwwV5w0nhMjAF50yhy5iNeUfkn9R2P4gYSZF2uxwj6j2EO9Ho4fNzBphorb0cPzT4htLqoQl5Vif7c7sEC/tL+WXYTwt/1Nphs44GXTWn/lX/4NfzX/AFZbLHaQBbwYF4yjuGulgIs4agPNJibrhHCI5Kc2OyZVsB+BcoW5P2i/3AA3ELKI2Hp2MDVQ6NfBo+JdtT0/5iS8tO/CE+tTYHwX9gPSIGd/IEe360UvPKwfLKeSyXie0G+ZieP/ACcP+ipX8YgMoA2uCMeqAv0N/wA1KOv+bEbBovUPA6esoi5UUGgB1kPQpA6obU6KN1TVZrOGHVgpEAbEciOxj3f9KX9QXmJvsg0SyCR3Ly7AeRl+i4maE2hP/iBllpf7EIPJqiydlZRwiTZsNmgwgNPtxAlIsBl4AHxFr9c48jygWCaWelXLQXlJz/5OH/Qf4X2jP6JzXa0HLHBPISxp7B3ddwvh+aPiT6IuBHA35FDcbAB0iK6Ox4uzxGANRYV8OXzT4hEURLsbH5/hlf8ALMCy2OkpGBWSbAg7Ay9jfDEDpSGiqsBLKNDDpiS2EqClH6440xCpA3QOIPk+SO3ommEBaOzvyQK3A1UKQauP7MIR0BFDQC/AJVbSoAT2H7LZ5ydZ+wcHwEzIAdoFfOpp/th96jJmyoKcO7Y9OrQ4qbLrL4l1lvtf0wua04sKnt4rbBxjMxEOv/WSI7kZvRzWVc1HvzqjLR5FsAYNCXyJaMLM2ra9ltYv+pmX1hge1oyeWYe1Pt0Ch7E8yjJgKaJyck35NtzuhN37pBJi4Bt+D+FIEFBEH2H+alfzY2rs/hf8y5i4gm2oqLG1GgVyrDAuQjKTawyd+4lZZu4dQ/JNdMSW7y4HxofJT4lqymA+8gSYcIbXrqUDXocnl3GNZR0KFqvAMq6IMJiCpS7Sb+PLtYSMQ1CvJwY20dR2Aqky0rKMfB8xofli/tuviNbcLXqZTsVGpuTJGvceIuUQoNXiwsXKWjtUI3dzTnIcMFCYNsRyM3/6T+CcYn3EfqEiqFTCAv6oU9QMrBgXH4ii2DzF8Q+xP6mzbMVFR2D39hH5Bmhi4vtbT8viUe6gLo5FLPSREcKP85u3dXxDymm875Bb4FHcA+dhA7Eww/lmQ8JDaTJvzFFEpOILfatJs6RwPD8RAIJSCp5Mt+bs8wRfMML/AEXj5E0NUGjyBX+2YQr5lIeAIPm4W0vjFPp+Ezm5DVVAEEUWrikxdTUCxukuQ0HLuOxouuAVeX/+EELd3Tvlgm9ksR07gN+kYWencCzw1KaywfgSKBgwJ0DD8hTDAFAWaBIXQC6jkP8A6R/FMbG+rf1LVhXDIfBep6I+TsPZRb00/c3bw7jjGwpe1v6mSgC3xASVeI2WtSvpBE+I6KeqfSKfk+Ywou47DqyxPGSChlZwTtPmSnzMCVxNff6ITzFKvAUesc+JcIpDov7S4q02qmfJiGo4hEPy6iYgWDLdNCxoPI0ljA0iHl0w2eXh+c+YyAKUhOTdK53C4qOEPsMHwxSghw/tueTWwP2Go0NG3RWhDQvivcKxeycGUzmja9jAdrCx+It75jMWksl3eA1FKmmzPuLq03yn8sathAfDF3sjdABahLpxHE4OvQL9MHFlyL8CV+blKRTRA55rCeSvJ/5w/gnixCvnETGPGL8mqeLBmWdihhxOwWzjBltd1+XFPImR5Iob4Pr/ADhu9tXgxBQRscnzC+YMUjNbOR0RGqDptj4zF5JsH3EQ+aQSekqdLF8wew6wexpNpPCZ96hCiHGInVphiW4N2l/ISvohnD0VzYKQI4LOGdkUav8A+GDFGSrkQrmlOIopuQKV0GPbcIB7Diehk+SWBYN0sfZ+mGSNCjhHg6CX7xDtEB4uhTw7PEULw4f6is8XTHSXDTAChriWLyrgQeyvif0RCqadenUsmJAgAaDbnBKqvk2jwH7XAQsBRrpEwy0uHaIAGsebIQbWV4dP5P8A0eKH+cU0DvpQwOVb4UJY4IA2xQNqs15ET0xZU3u02tnjmBZ8KiopM9Y7Mk3nLpPDkgJq0eT/AOQC1R24jMCLyR0QG1lGpsqA6tV5Tvgm2UL8IOK/Q9QGDsDA9ETdAWjOLC6+anyeJ91UUCM7J9IF8saoFhuT5sYlNDowfiYgGJyZl8CXJVkKLQUFxi6lGJ7hbqO07PuMNmn36EUC6AWfOCXtMBCSq1Uy4SvUrPhC2LAjWRS+ckBX0Qa8BpHv5lbdzyKT8xjjTw7otkVzwP8AcVb6Y6nkS4bsl4OkRitGfn1BMn5a90v8z2P+k5lodR7wJ9MydW9iq35bR142w+0f+/h/zP48qH+UAKMSkAVBwTVGk4djFK40bw5QOTYnsYmRi28g0NVk0MkYErRfJan00nJLXI5GVqqNW3MdFJau5SFIqxaENKlDlyyut6yvYbCd6NBNmOFFXsdB5pz4me0i22J7f8B4j8CbAB9H8vQskuRzxHCVxmPoKVQVplxVUpxACwB6HeeQdsPEokUC0OJRf/ZTOtUfTQfbcFHcXGwq9gOb42mU+hfJa7VmDrMtPkT8XHX+iRP7lC7Xf2/3AHqj9R2cyxjtfJZ7jWnJsmRZavAv/MTvzx1aH4ZRuaf0/wAME7RV6c/LDpcVD4/yf+Y/jyi/bEZLyORhp7lyJ6Nd9hydPsY8hlsA9hqnsaeyFgYFFp2uFO6PiMPvlvB6LT579R5oPG9mn4wyIe7msCkG1wSnJtX5DlzoeLR0xKt4cj8IbXhgzBZDdB3yryvK5ZandUyodOJQvOJQPPMFo7GYNQ2vDklL4SvNg+yDAmg8C293hgr6nHwCAeFaO4G26PzYa2m1fmoWxYkiQqpmqU1HYKDEVg74t4leYa/hi+ffaH9ytXX5z/iMo2L+CApeHDEdNOSWVbYQGEh6agENJXgh/MbrufhIajL5/kLH9T6q/wDMcP42+mKfo9MVCZIAUM8zfxQBH4Zo9F8YHd+vtKmYAGxKC06UxUqKc4La9lQeuth/kMTcoiLAmld4eSYDC1BTaqtkbtSl6lyccXrI0iOkcI5Juecn9yoPWYh8zcQ5syQjZVDvEoYfTK62W3y/otKiqBb6GR+EghClD0NXwwKm6b+ySwulPzf9x3HDPKn8MVEWA5E/Edr5oMCd/wBt/UUuHA+COr84iqQfPMVFWiMQN1K7ysozTXtf4kEWD/jF/cNTqD5o+i/zByNo+W/+Yfw69EbujJ5lyyBY9+JkEUlOnT+Lhn5rGdYam9FXeqLPK/qpeBnfb8t+ll3MBBT9jVfMM5VqpSdU5PJmDU0whoCubUvNjDINjqEA0lkWDqHd2RF5tSixpP1HCAqX9yiH5iO7RfoU/klBN1hyA/FEsaI+if7lg9L9EN8so/OMxW+56k/iYzsFsATTK5vxCq2AcvFcDKQbAF/pggLRHQr8icI+n+1AVof9DDK56l2S3jAluV61UiWW0NPEUBElIFhaVwRq0RRsyWn8W/7gjF44P9Dv/v4f9Lz+GWXZkiOl5Vx5lllbsHPkiWQ+EX8Mr5paXqv6kKLY1oA2pANW74IOn7R/CBfFxuKKoKNszkTkiCwqF7cZGCfqq4CgPrCGWwkdqLvsLioGw68P8Nhp1CoHeXxELq3/AFBEqCzgGPJT8Q260R7X9TOjeEAMhRhMQdyLaHZrZ0eZY7a0YZWsCer9webUVYwR9x1V2g/H/wAxwCYAUSC7an4FWPwMUmGz/wDGjluHKD8pCGQ4x/ysAa3Sf7AhwFW7SPrEVh2SeRJKOVo8w2TQGxOaf1BwQTQod0BtA4D+I9hk+z/5BM8AexE/X/fw/wCgwHrWKlEhsWtP6ly538n/AMhvmyh+z+4rJ/1GGJdZT8rDECHpVCDgLVAXSClMSVZDksw1Uykg5NNinkoX1FHdMexH9zA8P9hAl4Ap77+ZmPUsOY16hFf80Bt5uoEUeIJwN8mSvxLq1d8i/pl7ZDyUC0VhsWoMGBArQUQNqkrE8AVeUrFee6hG/CIph0NHKbIb1jCjfkCJsrSF5VsrHK1DManAsSjYW5vEP9GoIMpbrhqpVC1dWy3BB4xdC8roDavAZigisgEvDsL3l4jIqbVUnLZXvBwR8JVV+bssFdGZb7eLulvEKX7VH+A14H+JQDYjFYf/ACcP45RPM4X1ctVeTcqJ2tw6FwlJ0m4w0Xe669Ql6Lh8MuYtsOkokGjDi9Q7/IMLaLgQ2krKVFkwAOmrtSII6D+VqI//AI2X/UX+5msVNdRF0kAk+ZksjxGFz8xGZ5fPMy0p03pxZ+SXk4b+Rr8x+eF6vfmFCkHDIipssUPeHxMOgOq1LEm2qrcYv4jAHvFNspxX1CgGxuUXanxiXLJAT6a/NQB2giBsKoD2yiA3KBPjfBaPMNvApqybAFDxTzAHWve8DPy0RxbiXX9AMcErDgl5BRXuC76gBQ+6tvFoKAUWI2PzA9a/rP8AEL+TL2Y/8g/hrb4BtVoDyuCWYpaU1rWaiA6aSOxDdJLUcPEcbhNPcLyvyCJAI19wf5RZPnIFh86hzIuyiSuBBoaLioMcvb2yktjvwLgs9H+D/UXQVPjv5lXZL8Nyujp/c1mWcNmYA08waDXcY7KwfDbAt8KPiy/xB4L5y/6hPhX8dTDQNXwpK9FEdmrBQcbhM1B6/XfAooWqNtPiFWp8H+UCWiIsrhB2+YiK4qzEoXV1ywgntXpplUy6Loeqy/GHbCjsWCWeKz2bfMxwespdAbYuVrah+HIerfMMgtIse1tPqGiBr5Zgx6iRCmmIOCgWXBue0N0xS9FC8Rrbmpy4J6/EgER6ikNin9StrgB96f4V/wBnD/mqKOZHRdoPtgZUvLklqUlYi9p+o6Hu8XDKXpg8iZyWqFX0vnf4LSDUByRY4/EE+wQ/cQfujUyZ7mkcBcQoVbeLiSzRmzETxRiKA06h4fRBG9MO38RC1KPuZwLweIgQa6Jt8IjxUUGxXsx/UMvwy+EJBfzqERhBsRDvEYqLl1fPDOODiz+yUgVPIRscVdxW4Pjmil/JUXhICRVkGtOO5SChtVjx/wDJXB8KifWD5SX2t5ph6xHpZWvKZIQ+xPbCr6kL+1ag8xkvgPKwnRQ5IisfF9kxwQTIAAAoDQB0Er/QK7iTpFjoircwLWAB+cP0kJ7kezD9bjf80df9R/xH8aSyG7L/AF/hqBtLw4+ZhOUs8vUo9jBqWBDTuDR6hIbUB4X92NDYcStDajoOIQBnd/hhCdSf9VrGPAkvVpgQni0X7GUNUVj/AABEOSez+jGFfav7uD6+o/1Bf8Z/iWb+Gv8AEau17P8AEX4fk/xHlG+T/EtChGFAcDg+IlFgPmkUfIRAzSP2gSvhiBZXfKqVWoVqtAdq6h9+00fQOfiExaA8JT+4mqBBhLq3QbMuoLe9HoQB6Zq+ahIabs5eDRggAygADoCO7AbXXyy8OfuulMESuvpFLwBi3wXAaVg0B4qUV4PmaZqhgI+AAjp9bwg6ens7eI8NFKbBLC+wt8/w6yyOg0X9ECJSWJSPI8QaNK7tC/m28n8K79RgtDQA2q0HcbJ3wAB5tV91g7gqyYMIPmmvqcf9h/LcqU77bD0t+pScCfgA+wi9I35IxOxZDadt/wAAdzfGnafcprAUnZQtrbVAupbsKIzFr+i/dQRd+IjcPllBwDTkZPSxzfFOMZxdb5gZaHTg+6hMtaRn21N17n9bK9r+GXyoIC2fS/tIbZDsChB+qP0UHeTsGsxltUqFdcQ6pcL6YkdV4Qt+WIYnNWPaWP3iJDa1VATdGgcZIkayaIaGwAlmkl4TBYKHgPkrPU0NQAXwVLwrJkCOUzzZOkLr5qNcxgX5A/2srRVlUDumaruKS6Zq+VNp3g8wei8pqadFUHgVCyvBeV6Ayr4iZBui0fafoxBvcAH1lhjEDXJYfA4fEC+pJ0sJ5ER8kZEO+Bz8CDM7A59k0h2CmM/1TXw8F9z4gIlmmGsGEuwJ76OmBEJtqog0PN4WA2XC/u9KCoxYQ7qjFS1vHun/ABX/AGH8iNlYOsx/lRejp/1iCHsiueag0ihpPmDNSsxLKj82S+EfglgRrLy3Rv1LQbpYF7K1BUEOLB/AyhgzhhhKgAtBYnwyqBuzdVouuK0lHh8Q16NEo3QIsTQbYvV+0A1nu4mr7lPGvv8AcQpyYh1+TfVD9RhmkCPpnJg9QCr7QhNJajs2n0tQt8t1RCuklmrpLkGt1gS0HkynWJil9DS/Fw4D4zn5yVHx7jeloG/gum3LWVj1Ag8pkR8/uIPahCvKuA7XBFNB02PHZpR5o6IUBTgBQFGgDVTH0aTl+Rt8HzGTe08G8HB4Mw8xTC3eQcvghpidQdET8xAtKxLJy4VeXQZZeu/Rbi2reBT3DiWSKoHirJ4CWQCSAQLEKRORumDk630VWePHkzLkVC8xX0DDQeIbmohmkb1kDtgpQFkdXr8f9hGOolEqwKyDEXhW9wcDZmvPJLxekxEUbOIgLM1Uq1uJiA4Yenouorn6WX9oW7YR7soGXoqFNFthMksAAjarUi6ppb6AQ1IFKfkBH1FFgAIrpsceVQB6BJMC6ELuoIGE3T/sQBaPlP7gcArwD9rEO/gioz8n+aXqcJax+kayHpX6QN2vDa/DE1ohK8I7DhjiCrkEORWb674l5gigpY6YJS0s4i/6NB6LwmniNLekTNL2pLR9kQwrAUm0MqLzRGB1nLfKqxgrcnT4YjsAVAK38vC92ga8LQZDK1408BHVCHcOXlwy3E1rfgNr4Ig4OWA9tPCG4KwTYLvhCj6GPyRj8Wrr4qdjlzblgs4qQFsOlaA1thy6QZrtXlXKu2DjAw0EDEwS71xLNsGNtGE7DI8kTUiKYTkR4RyJpzEicElAwUMA0nDkhwqAAANINl5r1hlXy0WvgASvRLloN74VR9MdpRFbDRdAB0AQwf8AcsJDKtiDHptMaQusUqB9ghgbyE6rgX07PEMgeyVp6cHzCqcm/wDP8CWXKOZCvkkMq2qve4N7Y/HJ/Ut1HQ2JjfsB6htUO1wBZ4ckuWelr9n8eX6heG8j9mcGHR/uAUDs/wAbHCLpT8WYxQfNH+4Mwz0F/cNNDv8A+0Dp2ZZ9RBX4t5YbVK0Zvs0l7LXlllaqu1yspOB1Ihou0apnZg1cb6dSeWvuFXFvFVNMJX6lAVirh/ctWdMDJOcAEdU1YvW9IPl4a2ymEC6FoSOFtIt8GB7uBVagAHQFVMtUEgfLGn3e0nwpb8RNUFWoc0TZNDdbYEA6VrnavK7VmdUzgh4V64XniZzVts0c2/EYWjDVatTsdPDmXGiUaiaHAcJK2k85lwdmabP8kIvfgjROS3QHatUSxYkBjVQL2btGFA5jv/uVhKT+Qz/NyMDSUPIlJD6Xc/ZWPy3C7Qw/0ywHoXx0/EG9IfcThePUTEo1PsgD+EFVvVlyiVPqJD7UAkBtqmBIygWrIoQHgQ7JYWBclZBlmGYzstlQ6vL1FIQMlHNeRgAjC9HMQoMpqDWNQwi0t8n5lyCLpV+4iF5yKPtqCD8jX2lQ7C+0/sSgCGbBA8tEaODIG+WNvFmKUi2UVPbeebepbBsCjoOg0Hgg+dyqPR2vRGHgba+h4V1nzLHWQHgx6kp+4CwA6GCWcKGTsI4UBegtD448Qi1bKC1VoA5VaCIMAAwOhKVeGqLwQWtXfFuKyLOdnEtpBtBptasjloeZd7X5Z0Zm/wAALV9RtW2C4eQ6+fqBwrkG+gwCXLnXmFRxY0GtsBKjRfO1OLXast+Bh0aU47PPEq7dosPQWr5iziMMgpFaHwSs5Q3i3Cf1EbFLucgoUQWGB3LpIKdW16KzgNc21GyBqC9LPsZl5GTYGD6SQgAUGKNf9nD+OYbCU9PY/iRnEc8RZduvYIAfSxJ4QR+IVR2RIs8T2dfEu0MMnnsgyXLW914BAFxVe+RJ+YGWQngA/JBOTAnhVnzHt7woK/KXCpELu32BI2WXf+S4KtXU8j9EgDHSTjRKJ9PpgZqZoXhrfXXiEomDPLd15hu3nYPKmA/MoDUzaX5ML84eJaEw6AA6AoD1LGI7EDfq5W+zEatWCg7YTCXAZ0Db2uWX2AUU2LQoBaNTYYoelgPrceokD7EXHop4gVBIOAWA8N0vUAlHGuqty8QGIFcpdBB5Kojw91tBLp8mnzBzcWZr8G1vxjzKX8cI9RtOc2xsDko2VB1W6KxGKBlF2chfJGJK4Gw6PPniCDPLnuWhap2y86bR2fk6PDXmEb95bHYWj2ztzYafez8xIKbF+TEtD2wfbiCWTgQn4MXEcAwcoX22A0liX/3n8MLTEcAWswFih5V/TSLC2zXqPQ5C+g39kqEhVZPQfiVhRvAz5P8A5D7QmnOzzCq4Iq9UWxseQ94u/mKdaWXxj+JYIpAc5A+V9whFiE7yo9agytny4I1WtvbLHIX0SmtZUm3Vvs0g3PUhz4u8mTzCxqtcei1FpZhhcuVtLB5YUwXsERTqqD4hMHtpt8qpXyzA88CX4JFpyHJd/Jlv4Op+QIyVh6t/zClYHbj8sUcwAL9FsScoCDO0HInVyz8ieAXwFRU9owb9DltfqEigIu1ZPYZ82gJscUJwqCC7wI0MEE67atqAFVbAsvmCrVWn2Vv8zCjVG7bEeG9VE4HJEDHVD8JFetgjTUqCuw3VKmd1b1nhRb8VG9s2DPstr8xEVZVAe1xDF5inF8uh9zNLZBwPjAw5LHKlH0alQE6AQBcLnoy/2IDQIFoDaF03k4SjHxGRXDdFu1+HDL/7iMpniUC+A8uAMrHaKpoeFsjjZuCaNU3ASqCrlX6UJGEjnZGXZi+OoBw5nPR+yX4XNEoFA6DB+pWbkqeHfuZ1sOH1CtZBZ5a0+ioa9hcKHACUnIoymwKAysORlJ7DSgEEqwL1DKmCuvZXBFoCZaLFUvTiWwngj8E3nHzKL36hqBN2H0sLoRcflaCHaCOQXyhbGECdKX/RLksuBP22zImdg0/ELZDa7f7Yh9qBqsHJ/ZMTafGDA9Ooa3L4kfQNPEOsC5TXMP0dTPxrTApYUdj/AJJf2B3RP1UdpF5yL66JyQLSciBD4czVEZXHqwyxijI3ChfrA+Dnt5hUZy8+AGV9Qg+qu18g/uMluVdq8gaEQwiFAKPgMEdkGZTRHwHOYl0oBT8H4uMC6igdwIqDji4YwwtSn6CCGgZDV1aLLiUDCiKB4TCaSGIfxX/WRgOshlbOB5jksFA+JD/eEbJiXTNhHF9T+qRO6TZ6SyClkM6iwtlz0qflDteIaMqx5A/qKANAEwhdEO8C/DmFW7tfYMfLKJ+CVdlGqVrEdwCEACiDAopoOOtQGO4EdgWCuEjy3hQS2tFckeeL0fwn4Jlm2TgWgQoGb50jWluFVeKCNyqLZ+1sPRvyX9zboc0fyyrbZqga+CXqJ7rFAUw0W8pcez9KDUXD5qnC+TEoVoutUOn4YBKBJgaEDNnBwkMEMQqxNiJ9iSs7VAyGAnVhDZiHwEAyI5s9yhIalKHHhaB4ygQmwA7SVWDPdwjtgpozdmqS9OXiKJac3yPrw/SU4FF7V0OFqyqZz9DJD9Lo0eYdGsRto928xVobLfist+LlMxhk6fLlfFRop7Nn7VrGbHAA/V3CgZvodbaX4jB+wP5FxfqHRsgqJ2gFX3MV4gdZLakUyMYzLd3tTs55HD/Nf9RHUeFui6gTy2K8cJQHoZHdd2cjyQegc93k7v8AMCcZ0wNioTstMi6j8WS8XIZqbpSbHc4qEHl1/AipOJT8lPhE/wAyEy64iGLJEdIlJ8whY3EbW2/pbMO26aMIAC5AqDi6MZq/KJ+SRbrqzzGkmVxRQDBDlb6uUVrlcvbl+6mTSgg+B0p0xqIgaywct4ps4i02lQ02V9HXWEHBmxh7YD5qYYMB+wFQfmPtvof8KUEmz2Y+yhF8OOUf2mVAg0frCGi7JAHRrngNw/yNWvAmD22uo5QsBTyoVfLKQDANBgPgju+KHVyulsPByQ2tgba7O75NJiDSBnBpn2WzhzDmgDC244G6PggOfiFwFiFqqsTFQusGJlYqkoAwDkMs2cMtIMsQNFG8Krm74lOBh1hQR+LQaWKKs5TwTAOAzNgPifY79EPEMZ7vB/gm5TwSDq0tPnMFWbK1Xyu5irDkL+1jERarAD8EL6hLBsNJ5Jhv5Tt8JQ7/APkYhQSGmkNh6RlVUfqCwA7I08EMyOEulttkTlZP4r/kf8LxoxI02lY+5SIFBRcKCVwYTkzKcASwOB0HkfxHKVHITfb2PIxxqMvKgNovPfJzMFNgRwjVUy96qUPcDDRs+YgiNJm4uenL3GhgHbX9QdpZPCh+IVptauaJcFgHz/tohAMB6AmVGxE35grbUtqZ9bUNjNBAHiW6s86JXsAMvgigo5SlDCRVmkspxBCkbokqlFssTaC5qH5jFmdUUQVE5ntQH2x0PcK/sxFQ+6CfozM75qoXZXAByx8OoHO7MAfkwtMxcIBaoAO10RvV4XFvLwfFy/b2tRtVqoS0AIIekgtWCYR5Ejoqs2SynYnK0kUcVyxdnSeX/Qw7WFMJbQk9CjxN5SiIPAAAfHzMYhBDVba4AC1dEFjAhpqqOamUaF4hQuQLQIZPASgNpLR3UGWb6ltHhfmaQwHhMMbTCSjIurWoVwPJyMuZOrF9AVG8SZDe7dfIRVYjaP1ZH6CJjX5F/CtfiGmuAh+gI/3Qo/u3KXdyfzaJTn1ky1uyLkLsokKkFXVFkp5cJYmv4f8ApNgffSMmuKLRlA4yNmciPIxmFC0yr2bt8nHqXqZmdUO7WfabIWtsbAaRNImkmjIgC3gcFrxgeGcjw8gNqxYcmzkjiZJp8dMQqgWfBli48c+bFX5jqVXsGj5cSwtpPfF/csNhk/uUtNJslDeOTxzKtLTYVcfa5PEAEAJZAlie4xQfL/UWEtcqDSbCcNUDi5sZHYrT3bHaTxLqYU0AOlBqZAqwN/h+ZWxC8lfIa+Ynl8fqjRAm3ObK/GAJaUEFYA7HliLsRGTkE+g1ywhSwaT3F/QYOIQFLUAHauCWp4Flrzs14+5fo3Fp+wy+24jig1Sa+IcTigai21fCa8yxXWxi1t6E8tOIWamAIAQWinaOVyfJBa0pNi+heX+ljhT/APsF5gK5EBHkCFdjVykQz/TcbZthecWlpaM44g1tMoUB1CeWg2rCPlfw6gNwvAtaNAlVnKWCYTqZQXhFfgPEX88gF+VMvzGArTthbQ+e96ouXJYaxrsGWXBcbrKeLZlynZVvouota1kPqTi+yI0+CnIaRMK1Zh0xSFh8bSXKrJsckKyyreCR5rY8mf4r/maltlAFYmw8iDXOoBFK0BhBXKhvvAxzAAsIiWImEeGGq7OkW7txSbfpLEs9YSXVHgcZoXELEIiAsHIjMq2sS0cImA4TCAdNaFpaqYDiuHmCzV7/AAt8DcEIaCg4Ao/BCowonzvhafMCwoH72zPpv9z+9D9xFbXDJEM0Dh8OmO6aNssv5H2FIrX24JGL2ArSC2kyORdsLSDH6O1qhz2Zl6pYAAekP3PxD0socG9JVWdURuSS3EjSt7CZHwiXmYtI2e128OGDVAYBVZbeIAKMjZu1tfsREbqCg4A17jgmvJV5A2+C5c0myovGa9uZTCXLa+2oRRpQYrfQEvIQAt6N028Sqe2Nv2EZrStDWUovTshKpURAcNUdbdw/xKHJ5HImkcjiFVMBKLA5RytI+yKIAb7HgO14dmmUhNmaFNY8XVjwwQB5AirNWDnqz4YkUppZcFXlzlX1cL2C2q1nqWCqlMCBNDhZw4DLMfe22qG02pyuYrABVUAO1dEWymTU3nl8RGxtN+fjFKwKFc3QPb36hjr3mJKAHRiNqGlqt/MxgA2uA9rKI9uxseRmDyOHmV1goyjZQonVsD0AXUFWgFeHDq4YxdN3jyPXDsv/AJH8Gv4KONNORIvyGnTFRwrKF5tyjl5NkFPBOw1T/tcykX3MtUQaawDPZH21mmXSBfgq2tMExe2sPZA/Q1dXajWQ5MPJE1HhACAcWoFg0SgM6hreExpBtfLFNGkLIJK3emDcOCzycx5xEBvcKzSpyIfWeXZGDhKzgGPANnWEM0RQ8EuIaR3BghkeJxQDbo+pUIUiYpQaabqBgG9XQ+CFmkFWtJ7NfJDTYLVCscBHY8OYQtr9beXYpoXJZMUuc1cvKxHXJbtOmxfpp4gAIaA+oH5uN+cQ/hGkD4TL2olWENs/NBUfUK8ZP5Zl311gwWMoqx7GFQYAV/C1OeKmKBz1fdCUgKQ0iNwc2S1ETGgtd4cI6Rwx+NHMjys2drJxCS5lGf3OBkpcAWsN9KZOUFjkhtuy8BC+DgyPJaYtcvWofsE7XqODtcEFjAYOhLbHFOLwQxmlIYbIeEbJuzUC8L0/tjWEzCcPnuGZTsPHI+SPBd/euBX9RKeH0KeC/YvqNRDIwx7KHxEwlA+KPg4hXEtC9rhgt0uHd4OojUqe9qZO2Y4/lX/KqBGcDIHRuQJwck0E0HYJQTN3BbycGfDAvYjWOQHCdPxBiubVG5pbEeVY8kEFrtveDlTpu4LpLRk5j0+BYtMSsW0qybVyltYxEYCA8K+nNHmKeQGzmi1TvdywMkNoeA8n5HDN44fxGKVfUtHA/MKMJAEREciOxOpwgLuo3K9m1xD6QciGMIjoaR5jnkFh8Oz4gXS+Dn5gDNHa5/Me4QAKbigFT0XH2CgrfAS0JoVdZEyHCQMKoCvkFxFQK7aoD6Cph3peVfLx9XGq4AG6+VBi2yxvl/qV5qbRb4uAqkB0EtC9w1UN3Zov6jF9g7HvydnMfr7LYyJyvxKUj0qkzTsrkGVNgTEBQdIYThMdxqV9oBLuEAaQ0HhP/wCyssV3s+T/AOLBQpsFIVCf7cJClyCklgtod9ZSkMCgr4eMnDtzUaBQfQaXi60aI5tWAnCsTyh9wpHwtRtb6A+E5m8+yXkUChSWgBlXgM3M7DmoWebst8sGUcs6+0tPcbyOpyfT+HhDJ5hDzKAL/oIlImxKR1LdnNurR2nAMQACZHN/8mD7bxxHzw9cjmJ3JrieE0AMnOyM7YMIvZ3FgdwkFrocHCZITM6KI7T8hk5IagBA7I31Dfa0IVRqWtBQqq0MBeDEFAFaX/8AgO+Y2NVvnoHAMBNlQKLeQUyl5ayRSLBky6SYHtMuSJKJGilIvHA+NPEYz44eo5SPkgZnzG9S7gFAYSyB4RyRNQFIFB0Lp0DTmJBw2+4JW7zL5TCqRENhJVBTKwe9oJQnZJaaXbuGJFqlCbvPZFShY5B55fECWam83IOWmr5iSixhSMh7MJw0Y/JotQda3olmspTZqoNDK1AHtdR6s7Vj7dfnASPza3sKv5g4cg/2U/iUau2oD8AIeKBs2j4ciPiFNJx85QRZ7XC33VqA1k0w0geMOpAA+DXJDAgosRsR0jpuDEClI6fccFyGtJ4E087IGOy3yZQjk5pEvCXMX3zsKAL53LQ4DmvbF+hM3RlejZlVl0L0lOvmViFaKy0l4OZfUuc6JjoRtu8EAhg8/wA4l/xWYykFwvACBKRHY8kCipQVVXBfPW86aiEEbvX/ACdQJ+eXHInk2JkdQvQQ55wU1S6MR05jjK0PJFQ3CVDhRparTqPbwqKqbOw4o04ZZww2gLFBtUyHyx9ie1oUzigSgYIrU24Hu5SxslW7DP5iNyCsOFU4Q3w8kUQtYKb4Fp51O1L8FqwEtocicjkjNDJ1D2jjZkeYTK5u1RQUpByJhOSVAuNa2m7PKM8xiXFsZ7U1+Ze4gC4BTfQCnqMgMqqoGQKC3j1LeBRyKoCKuhaaIMaEZ1jy6+oFkoVpoMtHk2dkXSJtwIynhvq6ZWJBYlpAFWzRmYcMbieCn2X4hAPkra7KHxBOHGtHB8fw6NNoD7aIJCeJ/EJAXwbT8issabhSz6xHIPFE/cJgVe94rFK2OSUP4UKDdlwhkDHRDRA7rZ7IpKUiNIqtFlFp7dcMCFUikmzoDlcEQSkAc7QsovgfcRg4sxkpXjwUeJTLBw7xTAC976QAXu8mKnS+fPbKgrQQh/Fy5Q3iC5vxEW2XAJCUaR2QqyW4ItqHJpB0pUET/gSv4dOYcUYRHY53Hu2lR5GQluMTjEANOEKaVtTq1vUWLCiAvbZpyU3KuJzXeWjzaH0gFlBW9rP1C4SDRkMtfBCKsqvbw0d0cuzmWfLSxMiOnHfcHrDRWgzoHRybGMyz5kFbNH1UcQr7w0aBvAs7Gk5JYDAqtjxLGz6hXqZYRsEli7DRyDKyTCIRCKsbA0OeEsRdZwyWUnIXKqpoYZmTRvdjbXxD0/aZeheDzGlZ2Bte15YsNeiWwyJ/ZyYhBqXONJEbvZkSBd64IwgKAoUVjLyyrjQKtBlXgh43jQHzoRDodjHlYJYtlt348Q6JnRH+2GmlNgt+O57NBc/kgkyMEAexIh/LIhMl1rw0ylbAAd2WLcvPIxGDwqdhfybVpyS9GeRDtA+4jbfBAWBts2fMzZJoWVd0Jq+REzg7Mo4SigAqyucy8Z0l+rgjQw/69QSjdF81UfEBKqwKK8tSxQOHZDmBgeSeyes9IpS5cuCRsg5VaBanAWwi+S9TVtRbFAmmA0paINrrADRvZ/wP4cZYjvx0+x6jk5eIsV1gB50PYvOWP8EIgOwpn04cJKTqrvBeThLEyMwRTZsAXpLJGvWOYbA2PYkJQbeVVUnCXEKdAR09Na8Jkl1421Dub8HfB4YLMygLE0RGkDhHJzLEKCiBoFIcJHyGOQ+GlJcVDzGCu3UPCSwA/uI6JlgbGdu4o+JgplCLUA0JoXgfBpxDQyuyWphE4Gng5IuHfNdTIpWQWWzA0mtuhmjvRyyzdgtAC1KCafQZgQwo9A3d+V2rlZlnCYTpjWjLq9Czg8sEBHBQ2exfGoQFpW7D21e/bC9pU9r5eWAJXHUCpQRMoXos/jiMs8G2AEYsObhAy7GAaxesha2M4MlPaEULgjeTGzbre8jSTzd7I8gLQi8goxlLlNVQHWfuXb01jfAT8xhlIrYiGRPuKVW6jUMANK41HnLRZyvV5hNsF6xplNY83T/iLLfcmPsufSlQ/czgj6bgwgMtpSAbePuO+Prb+kDXzUJwyxk7C/ceoLqgpkHkAFngA8sDEw1UDQBgOAwcwLfizl0eQvnkpAbBY+gfDiP8EdSzqyylBDw00Z0dB4WaB0IDuMKJzAD/AHLyzjMpHWgKWuuqd2tbKhFgWSJF4LByrJyQGLjeh+2X8hhVOwcrviLkgi0Y7V+Q2cws02qwpexHY8jhjuYlXqXN9hpOhsmOkSpc6WrseBY8Qt7YVkR4laGS1Uttbbyy4hTIMFeyjs3Zh3AxFuKPI8rhMQRuWc5jxZsoZaoNlNI8Jw9YcS7as4aKbEdJz9INbQ2dlZmbJIdMsDsAQB5QbNm2VWnYub7yhXQpAO1aCAWFBFWcUHV8L4IQZMOUlqHkXh7CC0saCkWh1YV4aQhFAAHARQtPdzjXt/MsRYiUA2KB5K6ILBjTgHy0+iwdL00/fQH0MfAFsQPjE/BAQR0YD4Il7y+YeEIa1UQHFmPceIgtIfaOBSKdKnTLMP8A8/MfqVeb0feN/hGsL0A/afqGuXcp8D9y2o5/LlmAe7V/iALScf36hmD/AK2pw17f9JE8b20chT1J1U5UfyrBxTyLRVS7e3a9gfiFE41So8AV8sHyehk9hD3BfmKuFDQ+9oD78QwjKXh9i5aN0UeIEszXNCACjlXEaHqiwYVL443/ACTcAxQK6pE+FAxZj0lkUT6B6sgU5u2DpH+UfFAIgbw0VeWkvhnyybvQoQOzULotDXg2Qnc4GSdiFI80fExqS2laB/JpldrCBFFcImROEhMpVXFeBWDpvyEMaTLnuNtG3npiklnfJFoaKSUOkbE8NkyJzFotOxPTYy2BLVYPBwdLO4KQliOzsrcTPeHcCUM0BpHhOE1KhmsuV0jh6dMdHm2FLQvptWRSIgYNNA1ZXA5vcD+RTAuaHNdW5wlfDzF7E6RyMTNlaG1adVg8QbSbdtA+mniCVwKeefzCgN1LhhU1VyIH0Le4aoogKbwMY4bPmGaxAoDBRwHECIXXuB6yjZQzDmYeYrOmPEAKA7EbEemI0HmqzykUDvZ1EuCCkZu71UVLPqzfFKPxcyl+jo+gB+YqrzyvucfRSf0iCLTelPxmbovr+kn4YD/c1n+j5gG09v8AtlGQe8v3HaQ6Rf0ZjJ5Hh+6RJyqz6rD9wEaz4JgB8hviahojT1tC7FwXt4iyaUO3crS7xKhjCInUYJWCAcUCk7gMJPjiiEr1I/g/jEziBulhQHIMJwl+qE+9tNLOVj2Q1VvYT+J9s4RYbW3IZb1aEMoluVC6xgcgYJepG8Yhjs8wSPW5xd1eThOOoaS2gcomPkxKk7UMF+jy+40zlMtOKGw+ziX5FMLciYRldwaJRM33DZscod4ZInMIApcuvMCqa2EORLEgCUZKRLE6SBC0abT8HpsmcQW8tyOl7CWTo1f8BAXw0+I202ckAuQjyZjYEdg5wfp2QBesWJwrFIcA3zLlVhTsdKAp4lGlGkpo0VwQkJ0mK+gZZintUoAgCmFcmuaQBtlC1Y/PaLgAge0j+SV82w2WR+Fy8GYeAKaqPHd22uV3GhfxAgf8Fi9RK5iEOo5SjVOOB0+DGAXYABGHFCqkbXuCvYtf+WxMtuHmAz72riIw0Hg07YOiDhq+igqns8RuCMbD20kPefEoWNalOhQvhp8QGxQK9hQfAzCSIGsU4W2z5j0IKhk/Au/j5jfNq2lVhcD4a8zMoZG8lUA82nUXMWI1ptbbOVK9R8Jgo4nVdlXk6Ii51AB1OGHa5cCPNccKCqFUAHKgWiwW4K1SrUBAwXWMQLW4A6u1BMrmmytkBq9hKrGOS0wOazD+CH8OmPhevablGsndU8keEDlHyHg8ikqFc0RXRYr6hp6EaRvpjmnOFlQUQmJkEIiUiaTxGv0HUOzN8nbYxEGjLCI6CRTWWmgNU/h2Q3tydL5TQu8YYbvGGth4CefiFxSsheoJVvSZIQIVZ+0IYX3dIUB8IE1YmOiw7ht+IwOxpMB8JkhuUoAo6Vj8IXQ27Aelfgx4j5Cea8qGPmomtI6Dj8Rkgtj3AJyJ9Qc5VbJs5T2IIwsKFsHYNeh3Lybrskc3aQ5ooNVEF/qFsfUIY0fHgkqPgjOUAHtixwkqeQn1x4g7GjR28EoBYv7YVLlk4LLj3RPUbNn3H+GmI2DFLDoUEVHFlNaZnDRFgKs5qMKkNkKFQ2pW7EcDSZO4+E4HmO0CwsYftLqCG4X7Zqej5lDFVNinQ8nIUHLEOrqaXgHK/cVUqw2ha0AL7p6ji4HYdXaJoZ0eIKEPUPJKi1y0eYxmkBXmBPLnFfEPWQiODtLT07O4E14FoaGEiJigatg3DS7gYDYdGjqVWNSi30Ig5WjO2N6utsPCdB2uV4g7vebAlCHbg4JReAP1Tn/lUSI+xD6YhQ9qH4mP5QTMRGQS13aJy+PZCW8WtGkSKqUGpkeHVrr6lu3OWK8mLPyMM0YVX2o/kNcwTeptCpmkTInZO78lHbsfk5IjV1ZwHeMnwdkCO1oEOxMM2JWMF6y1KvDQ6+Q2eovSHU8HoU/P3FavIKvkv5JeumQ2rwSvkIEdqEawVZQc3UtCJA3oqVnvIxAAqgAsuXyvmFNy/EhZ+SLlYLXgI/hiHOCOkV/KEBA8t9l3fzMj2NpO9BLAXT7OCN3L9st/F/xf8Mz9eAD5aIWBDa7gqVIXNtK0CJlQQ0YBo1Qo7FIyZBTUt5ZsGuA4IraWWy+Ageau4j1RYfY2b+MnTKsLesjwwB8vUuLEKZVaCFDxVwUa7m3xgD1fiNgCmAqq2VHLa+ooK3K3XFpVeC2KkFssbaaSxhW1JWyW/XUITrREaK4VYyrj8OiNTOxfoPjJ+yCz3sfgQfsWB9RgAfBzMHU0Qvjc41jBzNVorSQ7zZS6uhHn/jcv/mglMdWga1bROXw7IcUS1B5IQZcA2dmxJdNhlh7HCmEcMZcn9itrt9I6eoCOjaltyoafJT3Hzw5U9pgT2V2iE9NybJSwNuQAiKYJZQ3VoqbRdcSySc4SPDX4T3LxLj4gLvxMN3ZyLJ8ZX1GaOqb8wP0Rd5QYHnSjZN1TT4lmRl0Mo8WD8RNYsWqkcCXEVFFh0K2SnEsbPX4FCZq9UgP8kXtZ3Z48jOWvTNcvTf3Km/cp/uJy+4D+50v2T+4cPh2f0CxyzOLw/KBNQQ6E+0H8EtaPbfAgX8o8cdsPYBXxTE03VqRqhw2eiALTUbNdujy/EWhKWmqwvdML3mbTigsjxr+viUD0ST9J/uohZ28r9rJiLvb/AL/1qUoF0rHJHNkSEFIqqYdAV+PUQKPmyfV1GS4Ocn5lPQrQH+/mUgBRxUylGSie1z8Rpp4EP7Bqn4HuWzsEAJkCoHAG2B0Ao6pY+FnX/YfwglJZFvuG8guuU+yH6K3Y9PImkckIBGkCLwkAxm1zXkRMo4TJC30VspwANnhnuCeMsAciJYjEdRQsSyFhuxSC0FOatTy6R4oo6aspscjeMJtKgJEhQwNUZwhkZvAA2VsashsbHZBcJWEDau6O7+UBwhtn5Qsv2E0PGw/Y1r2EEunKH6SR67ukL6EI9YOg/tD+YfnA/wBoSjW/6BTEf7C+aj9mX+sofvJf1c4y9h/UtYHw/sgB/rnmb7uH+kMTQBxf4ABMgk6C/tMRXa7R9VUL7VzavllmAbcCrfNX0uBkFMkmAIoXWD5gNgQAWLC9VBaF4xcMjUIEKQMFGgYIA0QqgEFWFJbi81iCy27EH7RlGJOwf0/7xHGPoRTbXqFGaQGwOaD9pCnD7LP0KwVLJy99IBAUZ4+bwuFFkYDGfPn0ETk3Dmehuvipjz5DLyt8qkG255TabQfK0Doho/7eH8tckNFe+nc//jPMSdIUg4VZB/8AyJAs4vcfhdrWm8hpeybvSa1V5clPqx5IlEEGt3ccnksj1qyuq3gugFMUG3LVk7ayLsq1wqZI3mIj5aBMJiyVaioucAUt7HaZmY3cnyHIAABaPGSOFbkQL6bVZpbrTC0dpCB2NgTrA9wI31TmJsBojmgIG4mF3nYoC4EzxAk8G3Wgc37jfJpEniw5TW7wmX4VKS1Ts78hH/Yy9ZXv4RfqTmOb/NhhuvkSHUj0/wBLLS0vf6AEr/Qi+AVGu9lbuSwTXNXXMCzIDAK1Yig7bYt9sGCkojnq212y17REIlWqijswaEGoKA4rKjUHZVuqR9BI6QOCjCZrcGRe3MiywoLgZzmLoR2Cfgo6pVwP4ujNMnR/gqO14/8Ae1MWL7f7ZlUf6OWUi+mv9xFDZ0/0FlO2ekufIguHAkAd0P7SOnK1w8N1npITv20Rbtdr5bf4P+4/isSsQTTZYcInqHZxFTAFGsHy7rZySzP4iRz0DI9jsfUKLq2lM2Cr/DLG8YnhiCEtyfaGEFzW22LA4HXDEg4tIYyIlLtCj2ieK2DuZANgXF3TRJeHxBRWBOg66maLZHEsK4WnBo5ITDQbcbk02HYbThla0DQgMBylaTJsYFAq0Dq2hKg4zb2Q7YrTKTmlLS3RSdQllaMARyWuC6oeIIfpVibL3v4HmG1CWbPKQHsqG1eeUbLG604qt8w1w7Fq+Etnu4AGpg6nsCeAqNUQIfDvAADO34S+ggoAaFtD1DHNxfss5DpJ3DZqC8oNbRq6CsxEUwCFOqhHZe2AYkVArq9aaHzL9rMh1gUWq4AwcRFkN5K4VRpac8GiW+CUcJ2IXR1d2w0Rkk7gIKAu26dKlpkUaEjRwGynMrK3dsoGdhdqYXBOMypiJKB9kyL3YP8AU/3L+pnmfA/qYIB6IVwQlw/g/wC+5f8ADojzaxriCyHCQ+g2cnwnU9nZBDDgSz08icjmXXAczUe0f0xMIOkH9y+bHZd7u+inuPLusVswrYnhTPE4Di4xQiEdKE4YPt0tTZgJF8NWYSXHqqBduxSmDOzsYnBDZdsPPMhacTYLYGtWhYFe1PUGq3SqAvSFWnHC4hOOAdABgwoL5ycMr+G71bCGFDhCzzEBGedBuxbRoG/DDIfW53OKEFdRAYlvCJO+f7IVR619stVXgo8QrBYWOYVKMsrcbIJC3iGaRRteUoeolbSoosAJFdy4IXXFlVGLZSHbPUsv0HpWzipypR3B2ZLm2cWr5Vzyx1QlBA3gtg9pljalVsldL2dm86qNYDMdO5BAxwaiqjEZltupK7q3xB0/RPYXafVo8QjACkGMVf1DX/K5Z3/yP/E6mIlmZl8IiAv9Fc+ZfjzAJ3m35cnmNoGOrgIi2wXfDsnNLUVPZs+Zc0cTDAOx+j1XHWpgRnhLPg4+PiJUO6cvstR8RJMECXIKg/JLM9uqpyACuhlxtAD4tBFNt78wDo4m5I7BC30xEJhBLnItXw34Y8Lo222PYiAnYwVwnMg+wUX5TqLKIK7caoDaBtDgAsF0WVDW2LstLW2nFN/BR5lcZCi08jTm+m7mGCQk2sthg808EBG8gko0pG59y6SzpBbA0Bc81zDlMIB4WIQchctv9Fx6huvyeYiq62WKvapdxJ0sVMHC0YOrm8LwdL4Nf6zCAoGAFA8EAGsBWAIWqugNrGmKZM+A9xW24f8A4F/yxqtXAcovO3sfZYvmZmwiVtW3pe2eoyxPf8CwPkjKx7yMv3kHsgV7QN+RhJbnb3v/APsAUmP9/wB8TUJ5Jyw8n9RTFJ0A/IP+1BJ9MX9iMNSjQB9KkMFZwJ/YYmV4GPTAAh0WPQAfXqEcf6ruJsfItnSinxCuQHb/AHSGkDsE/Qf7mBUZyqfwn+5lkTfd1+bYEAA6A/3+pTUla/3/AGpa4/1/v+Zpl2owd26Pn5l+EYQJ61Hd5hoPFpsXvCs6aPEpQpYcY7Xpa9zn/wDFxXErOJSJ8oZPIkbdEd6A0Xu4/t9ViOSD5yYvjZi8NgiAFN/QDZKwd5afYllGKOkfoBCaE6T/AEWL6/jlHckJiOhEOnv8/wD2FcV7+f8AfmIYX/vcrlo/3/f3E8x4F/UAWny/j1rMGdoy/VAT0Bb94j7Y7YOKMPTkT3c9B+BDlXR7Zs/KXX3dSunB7jboG7yKo5VbX/tP/abbPrWfFEWDpSF4LoHzOhDjz4D+UYQA0f3pxEQp8BPsGBiVxaPq0g+UGj+6MBz7/wD0E4gO6fpIHz/BBLBmB+b+4/FCH9rNX6v/AGMxLR4ofwE1fOxZ8ihH2LeV/kYEIt0Ar2oSjTgqz6L+YULePTyWr0pHJIWX7sKi+bQyIAAAoDgrj/8AMf4dx20cIfSRZtndh91cZVc8/pSWAj00Pi0EHxr/AEjOB3H9EEuftGB9vcLt3fGNN8ITxQ6L+7hV/wCm9J/MIIXoZ+GEID+vzxrCQrowPgnqETX/AHn/ALK/76lf+Q//AAK//Cr+KlSpUqVKlSpUqVKlSv4qVKlSpUqVKlf8qlSpUqVKlSpUqVKlfzUqVKlfzUqVK/8A8L//2Q==',
  'gioielli':'jewel','orologi':'watch','occhiali':'glasses','accessori':'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wgARCAJyAnIDASIAAhEBAxEB/8QAGwABAAIDAQEAAAAAAAAAAAAAAAQFAgMGAQf/xAAaAQEAAwEBAQAAAAAAAAAAAAAAAQMEAgUG/9oADAMBAAIQAxAAAAH6oAAAAAAAAAAAAAAAARIS3OVdNvbqi3uqCQAAAAAAAAAAAAAAAAAAAAAAAAAAAAiwlKWLXZ0jld8T0agt7K5A6gAA08rX3PoLF5m/xlAqsq7/AMrfRnb1/D/SL8vosxAAAAAAAAAAAAAAAGnmOe+tfP8AqIsuB3QAAAAAAANZsra6Plvzi7Xn7FfYY8d8/f45mFLbV/UTut+c+7M31Bzsbbn6uvpufo7kS4Np522DYVR1nOy3bO1RY1Pb2Xsj9893nyXW3+WE8AAAAAAAAAAAAAPPeejrndNbli+hw7z5t9iuw7xo8oAAAAAADTziwx6IGrdp87aESAhTa6UG1prfqKrbvgy0b9NltslQbKSjn92+urTJkCRbZa6NGPFcOfrkV0doPT84AAABr5fkKrfoGnhvabu5kcPuPo2z5hZWV965ro7qchMAAAAAOI7b5vXrkwcouP6DL6pwvdbPnwsyAAAAAAKW65WvudIQ/P1ao5m0BEgAadcryVZE2R+41XlBO2dSbfmdtlnmGuZE7/d0zLXo3sM/Mew5n6JuyShvyAACHCZWReQquodezTl1bvLuXVdye3oa7rnRKgxuuegxp56PoN18W+s7MVgLawAAAKrjLKPi9SsrJ9dx6H0i+0b9/wA6E8gAAAAAOL63jst87BXeZusUffE+gEQloE6XsaTXEDLDXoROi012u3XIhWmbiTY6N+XlAaZi1jxYhM76rtPY80LOBChNq4ntN+FZaUuXTp52ZT6qMNsjdXZfzdezBsaN4gRrgnio/V8xoo87bhrKyr664y505boW1gAKu042HK2MWBWu6uvi1X/bJcaTpoCQAAAAAGjjO64LJon0l483dRTbBMBzPldZJRJeMAk0nsPV3vu9N3qjkrvyfHXJbtFtE+WNdDyV3VTsxq5yn1/0PbkzG7KBr+fdfzuXVe11DfZtOlYwarNNVIyTXbbpMUNy28dAAR+M7TiLqsrOsse+b7bnVZr7DpeJi6s31dhn6HngPnP0P5LEeaWuOYthVdm6+iDqQAAAAADGthacRM5HNp6xFYNkpGzhua3byJP3WzURbemut169+HXdtP5GVFPUaY0Ui4b5yyNbU1uiJUWGBJ6zj4luX6OrbK7zwRzkf2Tk11sO7hYttRa+6EWEGHIlJY5cyeQImweemryJsNXNdRU7M2ixr8tGe08j7PP3YaN+jjv6PPqrX2PHCYofn/T8rzGECbWo9+pfLfuDreOgAAAjwkRqfRRbN0a9GTS2a2e6qrLip6npZXISt3fR468gIkx1myp2wiVX5bqIkWMHzNzI1aPOok6ZltqqqIvQU+i7z2bmi2nZr/LCYAgcb9B+Z5tHQY0U3FutY2yv5mZjXWETG02SJgbJEYlxY+JruKrxMlE2GzRYSEQ6+4pU62e3vjs7k9byBhL5pW+488xoMqKm9+t8J3cyEgABGhGq9ezDqyjGHWESB5okCHV39XaxyjRLo21c6LHMPyVHmMPM7Pvin8+hdLfT8v6LultVLcZO6wkhzBxHUT3NodVAAaOQ6Tn82iTU2enBvo9d/T9RErbbbZXH6PgO947yI9VkiDFnGWO/UUeeFhK0PIRaeVD6YWUGbbT9JHp+Y89HEcv9fxiPh2H2jfEwLY6AAAOV6rjabLGH7j5Po+vHM+vPQ89DyHKJqwiXcDBOenT091fLdB3cvVlqLcupCQBhjDaJAAAAAUdFbxseumstezDuVNtGmKcj2111/XdZz1TyJsfjvTvixi1pN2JhYV8890Tsyvi3NPE4WFfaX5/oQ9PzQAAAAAAPOK7bjKLd/k6F5W/wc9MchXRrf3pFrJVLZzt04dVfVynT9lI15o0kupAAAeNMIUrVKz2xtMa5dQ58bLquQL+AAAOfh9HyebRYbIeGLb7hp3V2NO4adwAAI+3UV1zTXJU7bEeUN9z5rvaHqtWbrh6HngAAAAAANewctj1eNFnO6rXTnvrE/Ljuoru1n21/N+k6RqoxyO+AAAAAKqZol5rYe7bDsbt8TXDyzhzZ59FvAAACss0OP29RzebTzUqdKybI73CqzLTXSDGRDnG8FVhbxSDc1NsFdFJldJjy1fSqvoPS80L6AAAAAAAAAAAAAAAAAHnsWJkZQZ0MIk6BHUSx2eV9R5VfvJEfVNRtF9YAAAAGrn+lczyGPY19N/L4XUXNo0Q5GdN9VhMz46lQptcYZZeprbHZa21UHYWmzfgC6kAVsLJT6uV65bCnvrFZZ6OAkAAAAAAAAAAAUOibulc5Addk4ks7bVydxFczTZqqsci3gAAAAAAAAADCstkOc0dUrt4+J3bjvjri5dca9hdUAAU1ZTM2PWy8F9hBwR1n4Vd0nc0VZoq7eR887LZTYi/kAAAAAAAAYmXNxOc69K8zh1k7+xrqPe5scKywd1l5lWcx2Vly/UR4gKQAAAAAADGiTfuJ1O+7cDMR2TTucAAAAAIudFwocpuPlatmrLpPSy19j625kKaiebpOqpfE9Ouu9sTuruWnd6NISAAAAAVtbhbmn2nKQbqe9oINfVtk01vUVfSxtN5piy+hzaBks8dumOqndjZc3VXUVkBT9FatvfggAAAAFXRuuo56q9mzRv0RZss9EBM5w5IjfT/l07nn6cIzAAAAcjEx0+VonatXQbaJ3sbz0ccnyORu81JjLj+u5Tz92iwqJvm6p/a8N3PpZgu5AAAEZGVJA3aMcOLYRdeKrtfbIgxpGrrmtt6jp/N+wr8NFjTpk8l1lHzFhI3Q/Pp0S6ebv0WtLPymno5OndZ5ATAAikrDloiy3pNuPVmjWgz1s1iQABgZ11hoT2fTfJPrPGfIKwAESXy9bCHaUPmapl7js97y8fJG6UPOf7x3Cylo6j8R3fzvDrmU/Xczgs7y00b/AF8odAAAHM9JwFue0suVvdeDyNVyLKsbfmpcTf8AO3XOcpV9WbPN+qnVs2HTsn7IVorpavqJlLkrW42W88zf0VhXbY3FDfafLDulFlfMXdlA5WR1psL3XTo6yDqmoqdW7TMgAANO7wibcdxX97wthzH1ERlAAcj13L0zhXWcHHd2XkPH18O1H8sr37Ig3YYEQOenYeN6dxy1vT5e+0u9O72ModAAAOLpt2O7yOhrZVnDKps6mi6ZVyoXiex0GuT77PjctL1e02TZGM+j3aTfY48X850MHTx3dK6LNevdl1co082eWExq+IfWvkk6PfTq6ws+c6iOdMqovJiA2awAAA1aiVFkVqc8dltD6Rkc4wAMOF7ziM3UaTH25b+jM/e8nDyRnx3E2b9Yi7eVz3wp+3f4m+r7jiPo3o5w1VgAAAchF7Gjsxc/1HMO8vS10i5qu5u0yra4t4er2vvyVJq+J021d1Xe7mK/oYef04k+ttInVjtdcYdDhnqxB3WBzfzD6d8ynTjl46tWlWLiRnCczHuKPXnoAAjSRhB27E49lwXXc8dwIzAANezVDi9MrLxtk+ZRW/ueZuGmh5oo82jZXpfjelhhGnONndRZXp5wsgAAABQ3WUc81VX0jnFy1x7uztOz3fz1v2aIMWY2OUKtr6Ln7bXfK0YTLbNO5CJqu9ibAd8AAc78/wDovzidGDOX1ZChdRTp2IlxDPOpup5ipug1PdZnjquKrIUHp6TDoixvcfTyeSI2iJ+2IE/nEAABzejq67L1yXtpT+brmaJGfammeyeVnzcqn6r6zp4kv1swdgAAAELdEr7xwk667I6w09ZkPfqz1RY1rYxNNY7tHc7qudOu6hzi3oJmDqkRKLtuGeETaPPdFAAFV8u+ufIJv374+/q21o+g5qISok91si6pExrykjRlnqNsyv3V9Xdfow8nfC2yNntedA0WEKJ7nq+I7fnKDgABytzz2Tvbxljb5rcfOxqLq+N7O0mXRzVzMW8h3AAAAACtssOeq7f7Mr6gziziPty9kEwAAAArLNz1AzmIB3yAB58Y+0fIpu07dWU33/NdDQudN1T2TrKLZViJwmAAAANUPbML/soczjMDkBq2chXO2t6Dk/Luq/pvBfTdvIa6gAAAAAAAAAAABphua4PM2SFN6gJAAAAAAPmH0/5+s5v3zzrTd1NjCmI0qLuibCHsxRJ8maJjUAA1DLHqOqivmeoyc0ggADnuclwPNv6Cg8zo6ld3ynV+nQF3IAAAAAAAAAACJUacd2/RHtarOcs+o12ccRe3VJx1D67kMJdk07t2YJAAAAOQ6/Un5Dp+nYzfw0eRXzY36NqZHnuKJszndsrWNAmo15dd03NfK9TsRSCAAAAOKq+95jBbEq7DpeOrGYejQEgAAAAAAAABhCJB0x8WiD0OVrZz56aqQAKSj7flMWiyueA7nrncNdIAAAAAGHFdwTwnLfZKFb8/wk3HVvNXHc2kVc90HqKgQAAAAAAAAAAAAAAAAAAA5m4pctse7ys4kNdIAACusYfM0kuumYNHQj0cwAAAAAAAAAAAAAAAAAA1G1y9NHX0Hz5XFifr75HczH0NV2k8gAAAAAACBDm9N5X+Vt6beeriCQAACusY/M0ftZeYNN0PRygAa6Om307rSfxbjR9DcV0t3n2A7pAAAAPKSOrxzfvNnRqW66rCeQAABzUJdDF0z1sX827NzfvR2PPXB6e75Su7mOzqqHiz7Aob7uoAAAAABX2HNVd115A34dHRD08gAAAChvaSnvVpr+uyXSR6OYBGk0EdcjJjTsX0MIV62eCeek6j5ja6vG7kX+YAI5I57mNGf053sNn9TPzFzdI7PhrnT5PYjT5AAA8KPnZHP82TusjTtnnhMb5nmjPojYs76Odq+z5vJurvpvxz7HEh1wAAAAAqrWnr6rJkG2x3249DMAAABH4+xrvM1bezwz20BdwAob6JHXyjtvn/AE2P3tWyVScaLTTUa03OEHx1cXnD9Nd53XQuU86q6rhqm+405ECnfPR5MPHviVhAtbsPbDZ8+AAqLfnoUlPbVs9dtka/PSI9lXb7WSY0Sm6fJjRzN5TV3c19h+XfUa7gngAAAABW2WHM83W2LzNfUNO71MYSAGEM+fk0GS6P01b1XPQbs4AAinyDZEv8X0cnnruLzbANk8adfQQY6jXFNOiyNcc9czxUT6yeiPqtK6Yw24anN/7Buebceg5n6Lp8jYL/ADQAFXaD5/RXtXzb3GzmOn1+fIltFN0L1vvo3Qdldx3HoJuOfZe9KOAkAAAAABykTpoXnabKXyHX66Qu4GmHlVDjYdHi3u5BuzgAAOR67guL+a6qtmZPbgm+vXS2EeB1XcU0HZMaul5n7Rd5/F8t9s5zvP8AM+j5OwzeveQ85PN1HIm7549uK1NNB9Z+RfQL/P6gaPLAAApuT+i0sdcFbxvI67mNxOdlXaxuYTzc1cCTXdadnwWUO9cV0s82AmAAAAAAIVJ1FVnsqZUXTkv7FQw9dHRc97HzWxum129/HnpqpAAAAcR13z6vVigV+P37Wp2e9V468dydWzKUafsnz36Fp8VCmrMnwxI9x/RMoc6Op9hQ5R3ce6dsTS9txn0K/wA/oBp8YAAADGjvhyca74vnvR55Z8aKrLpt/GjkcetpIa/YFtbl662+bfSe84TAAAAAromxY5TDlr3nMl2m7resiedu96+sLeAAAAEGdEieLhWkHH9Bzujo/ONVLutYJG17rCeNWe+Qjq7k3fMhMfMI3T1GP3+e0XtNzfnsInXOhYJz7Plp81/T3Cd3s8AOqgAAFLP4COtHmHT07fJ+xFmrDPCJ00V7Tc3RdkzXZlqe8+f9Nbj7UdVgAAMcho36fOZ1as+You20FrSU+1Y95wHRx5PSD0MgAAAAAELmO0cW8BD6zmc3saGnXVulIWtNn0XI/VdPj+jR5YFdxP0fh6d1XGn6cnvU+N1rnmts/PY6z1Y9R3n19ebPng64AAA5Dm7On4uu7jn7vP6UvHT51xs1a4/PcthXTz5o2092GN3vI/UOqsx1wAAA1bUIU0Of5Xp+RweyqdsePX6a5gdDHzdyPSxgAAAAAAMchyfHfXYlW35is+jo9GXcGvwgmAFXaIngY3Q1+X2avn53du+G6rsF/madxZlAAAAA4CB1nL82eXNTvp2W6txiyTX7NXVO/RC02UZ5yO9nnGwOqgAAAAAK/me20ZruFsLmRTdzPbGrMFvAAAAAAAAAAAAAADmulR1o3k8gAAAAAAPlv1KPE/K5kim5stNddKT75ZXUxynT9RInjDMnkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//EADMQAAICAQMCBAUDBQADAQEAAAIDAQQABRESEzAQFCAhIiMxMkAGFTMkNDVBUCVCYENw/9oACAEBAAEFAv8A7B9haIO44sO/bUdG6FuP/irF6Sk2dIgLkJDBD8arBX7M4+3Y4UAMKn/Ya9SsLUAwtQZGRqLpzz7YwdURimrbHqYYrB1g7mREDExE+DmzJJSKh/8A0+DzX/BYYrBmpsZjNQuBGmW/OVvwnWwAmMczBAR8LI592BvxMeUSuIJGovRlewuwHjatLrC5jLbG7gpDt5xjSYSVCocfG1kogopXCqFEwUfn2rHn7JTM5aP20IOGm/gGYrA3Ms58ID4lEFArEcmdoBwHj54n/sJMDRqiirjrAc7Gpcs+pDPEomCjoSLiInmpYqHGsFQwxli0VO0OTXfmlxaSz87W3ymlsyrJvYeHE7IX0k99pitfxWyM+U+qycQIfe0eYyHt9MsDHUq+9qzT6ZyLYznG+/HBE3ZDICI+jmioRiWtrxvrHbMhCC1OtGfugZ+6pwNSpngkJx+BqJdbViZvDSnhpy+tqX4DC89ZMeWMDhPqajeSjjNb7GRsZRtln7NPHd9pkgsPt1Pby4+xkZHKVTya/aVI2lqpJmkxz1LtanqnRM7HMvOHnnJwbe+S2CyATuqzcViNWURRMTHdSfUnHln6cXuff1R0qroVCVY4ty9Zrg8QrpQ6fmFHuzaU6ft5NpQ5+Wz6zZjfAEVxJMfiliuMlscdAD+m7Oo2PK1JiYzfAAzyRaOcowZ2yHTGC0ZyS5Clzqc6fqCro9vU29GiMdOmZwGOPctFV0tO75z19WxjO1PtBRy8HzstFYirCzg07JNgdhhK2TAIGJ8C+2x8K6yoTX9bbClSy4e2ovJpzO8x9qQ2DpFjFYVVc4SGjn+xIgwGiWEUrdRsRaq9qyS7t8qpRllDsJZ4nj0u/px/KIpLt2J2Xyxm3EPjb5gDBuzbEKGMSG/jWnecefBelp6971HbHdksLHNhCvhObAT5mdpyI3mt4koZyUThp3hq+kR5Hvn6ZZ8vs6m7oUFgK1LtmOOs88NkbVZAq/edOyaH+Ow7GxqbBhExPoOwAZ15yPpj53I2ccQqbL7ZRikdRNUo5Yn+PLDuOKZAAkyJlpu5adW8rV9FmwCIkGPwmiGexRaXzBszyLm0ulGLXEMXECPp1AOVbA+lEOT12raMr6ih0+v9RnuLPpjN9594rL6NfvPjdNCd9Pn6GEwahnassg9A1oxaBDwYzjjm8c48Brh0acn71A4ISAFM80ypnHBKCxnGI3neZ4Do9bqs9BlAANpnWQ4XCwJCfAhgoOptkIZOdOQjkQ4uZkPRY90R9B+tD+66/wARiDYUb6uUry7Xq1FnV1cy3HDL30xXV1H8Cj8C+xMxGNsbZMlOLiOdWtNiW7FgUD5TtEn/AHCXROHU2ySNeC7lHOByrXK64RgB9Gqlx07pRNaINBpvgeEkTghkccwxJLuZeHTHf0v/AIfpEfWjG9vYVwbeZSJgLGEDRnkPiZQIgUkvDnaM/TKt7H4FiOhq3qJgjnWJmdFhZsMMmfkhEpd+4QUK2aMyWTO0VF9QTDKbZ8DqqPGI2mndKouvYVYD0a+W2nFGyfrhoicjqold+JwlCwRWIT6jYIYDBLLUnJWVyAprdQVoFOJd1DYjjm8yNj+GjO9Lx1tvS00vhDDLfw/T6unp3dmYiDv1xmxqbIiyxrW/1IZ1CzqTm7Zzp2Jzy+CpI5MzOWI3T9Z2+KJwsULlkl4ty8fw0WcJcrliVF1SKBg2yeCMznCByenB0TcxHj+ov7F0fKjhMT9cJQznSNcxaLBID8fMe8TvGPATlSeJWE85sAwoHYYmd5T8simSnfGfErSp30/x/UJ82lPIi+mQPKUhCldpzlpGbpHheZPJUjfl7Wpnm2BldazLUdQs5lm8+mfpWXvDhBczyPEo2yI2xqQZg1hiWVwMeo5EC6GBIkUinK6os3gpVgwRgY9FysFpKbZodsJiA8pJe0eExE4aInNmhkPzkk8jLC5MYQeR7RZEiyvy4thOAuSzpQIZETxZtC9IEh07x1FnV1Q44k2dgzRldXUuy5wICX2LGQtSilpT6LMThbngFNcgaYyM7x4zMRktCMO6qMmwR4PCMExifMxnmYybcYNgjxde43FaauMt6eJyDZg80Qdx9ddctiOajG1nV5C+wCcG6qcEhOPAgEsJETnl5jNnDnNudRmdQ5wAJmCoB8GfZM5E/Dp8RY1HxMuIVy6hF7y7w/TCvh7Fy0NcVpmTYzf1TG8dIcagSjpmuZtkuJtHxJzix5Hv7Z7Tm+fXw/2jTLjsRoMYnTKiciIiPGzXXZCxWtVwpK6FT1OLgnSw/wDHGmJg0bZwkCjZtg6e+TBoJN4h9LXSLEM6gPHcQwZKcj6ZYL2iYFc7szS/8r6LmkEJOgwJk/HAyRaXX8tS9dhwoTUAilh8u0TybM8FZMzM4a5k4ThD7ztGVaFuxlfQ1xiKyUR+BqRcaFX4NPlhT4TG+OGBsZzmRj7RmJjHlIBDzjAMGT7CLCjpjlMfCZ2hzeoXHw0v/KemYiYmpWnFqWvs358zfeXacU2GMZER4yyIzmTCq6M9uVdPrVvxNanbTXES6iGkXjcni3wRHJvSmMhrRyLMZ8hmAkRKxG6o5bbbYpgLgrEzkLJskMjM/XNJ/wAp+Bpk9Q5neexaZILKYWHgRQOD1HnV0QiyvXVXH1kUDgmJd3Xv8az7IXG/g9cNElGGSZRlJRb5IxOEmMJE50ds2zjghBYCMhYDnVDHjuH/ALl7Zo0b6n35zRf7afafQU7R5jfCcRZXXICbObslkRgdR51dEmcSlaA7EztCQ54SxmBbskAJuTunta7G+m/dXWUbSMThRxnwlYzgrgZ9To+XU+uNSZMFG8z9J+pT7aFG938CwM6feMYZHp4jnGMvP6YchEVLdaKrokYlQJDs/TOYFlf7M487GO/iR/D2LKoejTzkMYEhO851Q37JFA42d1VPr4z9Mn7f08HyvwDATGaTqs+aXkAJxIzHibAXh2GMxWkW2zX0esrBiBjtjHXPgO3T4GTBEliMeBl1iiNo7Nymu0JNZXwl7iaiAqhTPoYyFxLpxDOoPhb+9cz0an18bbOERO8sGTyomK9f8KYiYOhWLP29efto5GmJxVSur8BXyy8I+E0xOxIksiZVEe/bIYIWacaS8yMF0fbJnaIsFyKIfPlziFBwjxsfxVPA7O2S1hY4d8mds0yj5eP+NE7+BDBQS+MAJtwRgYUznOT9Kn8PcYsWCemcJM7CsAkvw60RilQuce2V4T5kQNkeFv8Aiq+0G/cPbdU9NSxbaZRohV/49gJNdZcrHwt/ZEbRM7QhfJXIhwyJmLHgHffUQ/JoMXhBYDOqreQgxmuGCkYLLn8aB3CK8bRG5J0zlIAID6mXFAfn1RL7RG2RwrL6w07i7MfnsDmPMhwoN2DG0filEFB6fWKS03JpWoya9yMKnbOV6dY3CgGAIgPr1OwQ4qeiHWghDpLDfbPhMaSXkcvIcS5bh/Gfe+b17qsLVU8SOwzOIRh3bCARZeeJtzz/AONYtFDZefKIaVoeTIk0rnzRlnXbGc1uzqMCbTjUdmZVYo2YtV/xNSuwEB8lYMIZiwGNmCPCkYgZ6TRiHK093Xqf8Syzo1z5KopUALnYYjrWiTTWvIjbwfXFmfXLO+1sts/T8/H+FPtlq6djK0f1LWivCtHimuOSeQwhZPNyirEDoYG/Qsaazpu/BmdofqtdeHqlgs83enC1C8rEa2E4pgNDttYCgttO1WarlWGYAEIOyYjAx6L4fA34XsRWflazOmkoxaHdsXa6JHUEzglBjmsEXl7cQtNf+4bG7uHLPgCuYQcAEDDThYAXE7XvkzMxp12TnvOctI2NUxgvsyKAGOosMKxOEUljAyrYZTOs8LKe01kOtqYdkp2Yahm5YiNozfOUZyzlhTyh39nVmZs6l7joTJF3c1CwwnAlVSDsDkWuiwvMvmyPTy/OCBcFpF5OVCsbEbtbPXCYKLCuqJK6QKCCS2uHQ9+ksua+266lUtvOZkKmZ5rXhPmckpn0sHjOl2vJ2e0IzNWs3ZLvaED0l7+u1/AqJOzeZEs0UeV7tNaCQnUueV2Qhlh8syS9xrSvIbEzbKcIpKHRsmj8KrQ8gL2G1HFqKm8DvlyPhTtwn2rzHGlWjjX7BkIC7UgjGOdYzgIDLojCMi7JDmh2pfW7Fh4IAROLcAAvoDzPw3jNpzgWdMs6WQqMuTutrDTXVyazT6vlUdmw0UJrpm1nMmzFH4SqZpqv660nlgVYidQnaA/lsKjZcyk1zBNy6vi4C3iw2F2DZLCpx72T+CwqTqqOGL9T3qQLdU55IdSemO5lhrmY7EltONjcatiatuJ3j1gXmNRmd5YX9PXr7I4RGREDnLafQZQAO+2B+ASOlYSyGq7Ouz/TWXwwWxACToGCsDGE4ua3y8ctl1HpDmAs6qyGChM9PFHDIaPVCRamCIjYA8ikuiI/eM7TTni/0WHrrqfqrWyVbq4UEoqjeY4xvEjIi7LI9uWB7jMb5oFjrU/XU+VqFrdaSDexkxvn2Z9I345LIzqFnMsulPSD5t3LE8m6Nv8AtvYmdov2POWEKN0uKIiBJxTUPaZ2ymW1iyXBce81S2Y4OE1jlmNji2umQZgv2byic5ThbMzbaa5ZU+O96Nftda5iWkotxtoWUpbDeecOMN+/sTkBkRth5pj/AC+o+vU9nuvfwq/yPULOZZvPquN+PT17DYsREAomkkIUrsatYlrBHPhUsAmy2OC1m0oaKYXM7RbkRLCQgoEdplnJdD+Vq+cARKwnzt7wSi5h4DO8gU71EdBXi04WrlJl4Um9J14Nprs44ZmUdvn8RfR8fJj6ek54ithL0yJ/p1+2oeMzEZ9c4HnSLLWyVH8xl1XBNNXmbFWsusPZ94lc7Ot7wtICkWFGdeOo62E5ViWu8J+Itt5pj02zG0yMTkAI41E8knK8acHklJYlYnaWsFx6NYLhpg/SPFZdeor4SjpRDJiS9bPtgsL7frgxyKgnzOoeuVxVxlc1pOeL8jbIhWQQDnVzqThHtFp280E8Yv8A9rR9tT7Wp1JE0pmKkMISmYnCGCE6kTnkYnFrgIyyzgNZMcBRESXKzflm0MsRhyUzWZtJpiSNIznSEYoBzb6f1BP/AIv0aezi2wPBgzvHZ4ZP2/7Oekv9OhEUPWYiY1BE2iHJFVvVT6JnaLT94QuWmo2Ns2mw09HV1LnaePNFf4qrR4F7xNA4YrgONmRDmzcnkWLRO/wgBuJuUIhN3LaOUh0ixgjzXLlrlw4NdjpGIGPT+of8ZHvn08fpLdnITObe3ZMt8GOAzPIv027bsNiZXpk/0lkemcbga2CyPA2iGWLGKUdg3sJDeZuhNF7srpBCu2wfLMs1+Y8C5J3hYyzb55YFb3EYjw/u2DwGbPtdn2yJ3xiVswFiuOzr/wDi4+jR3gESUWESnwoM+Jo8DScYwJCfTv7yhvEymMXG0MLn4UndDUOxYpsW7rjg+2Q1Zz1tsOwOS4ixFOZkRgYtFytaBH9J3IIZyffLAzTD4WC1fA0zECbGxlaGcScscOTfkDxWivIGPztSsBLArBKw8DMpbL+GC4uXq1uN9LD7J98R/Db99P2jCj4inrpCZGUuiRkVTkjGTnKMlkZTb/SwMb3o2YRb5H1/033Ci3r0+xff5erUV0UG5Trk0V4NJUY9nQeF9M46+M4uCdlVMV6/bsHHTIRhAL6uMgnU60wVfbfDRvkq2z5WLEZwA2wuIwyxLMqoiurxYwupxYLSD5zJ6xerVY5acr+P65W/iP4qEfb/AO6S6TWBvmxRnvnxZxKc6ecBjKpjDAZsFj4hn3wR3w44ln6bPlp/YtF5m/eb0kABGyLRVjbqEcR5SVfTVDV/Z6+6K6q8dt2/TVC5WEBszqZX4wtlaJPjYjJG2WDSiZFSxwkKLPJoyKaIyIgY9DF7lzaRyY8mx0Y9VoedZH8f1yt9F+9cP4y+pjyjqGMQws65Z1zzqtnJ5zkLnIHbOoW+0znCPBn2zn6Z+313n+XRMxSq2jlzNCT1HPQt4/tNfEVlIjv24jiyIUnkQRXGfBzOmIzyHtyJrYpe+QgIn1qjjP1yv91b7R+0/tSPPFhudb3HtM+2fp+mh+T6mGKwVysuuFztFPw0U+Xq/hFEFAoAS/Ksjw1H64n+atOxzGzD+2vPwAUTfR7T2jLfKlNtuaqArI9Vh0WzEolZzuiqvq3v+frI8NXwPZydubYmLH1ypPy52i4PtY7ElEYoG2SqaQAZHt69WaXGfmtuFC67Y2raKO9/8uWBEmQgM2vavYXYj8D9SDtZyPvH7rP91lX7T9mM9rsRuEhMemTjFA2wVXRxjAAVj2LZz5uufRKwwrLLUwVjQQ+X+TNhIzadLLVroiA9WaTrsSAk1EEtML0xx+a736lDelh4Jb47+XK2O+lr2tpZ7b4yYzeMk8SptkqujjGAAgPasq2uQp2cfKRMTlRMV6/5FtknduGEL0+p1q8aevcYgY6S93KFy/23EKAb1tk1mqPqL7jAFgTpdOc/aqe16k2gclyPK31sfx2/7sS2znPhWqusZW0hYYIwMdyzXCwtir6cGtYYVChCJ/HtviumeUrT8+2NBUT9PVapkbmVyJy7YAffIYIXaH839kbMRzQ55RKmzzdlbT7D8raUhX/KKYGL7a7k+WsOGpTFE9iTmtqN0usSt4X+DqmnhdAqNyDraO4srUUV/wDmWD56jesQWaaok0+zeMF1ukxaNOty/wD+AZYgWXWBuisge3bT10bWhVp1QlM/47DFYu1TfGnqLsKmwpmkY5B2UZX1iwGU7yLcfgCwqjph1yUr6Su1fdKKpiMVtMsGTPURQI/uayyNRxFtD5/Mfc92SO5W5LBGweeXsZ5e3GSfCWVwPGAQM0rU5aXeuPisjjMroPOLnbesWqISEaNSEz6tSb5689vSjrswmQyEWXJyrbVajts1JEF5u0WRZtZVvi1vas2Ovj3wOKrk4lVxCPAY4xY2kH1pRkwDlsXMTo9zzdbu3Ug6ufU46cpIh29ZmYqvaHR0Yi9VhkJRoe84/wDm8ZnkVPUfi7FrUgWbSl2deYEiksiZjHTL1ULEW6nY1BszNtvAaaecrCAjwTG84U8pywnoNtjuvTG9DU+7qJf1d1/w6QogDtw0ri66x8wlIJD066XHSdIniVsdm+gogh06/KD9LmgldrUHX8AYAPQM8Z/T5bH659sUzmJT1XVQ4h4fXIjaHF8OBG86iPKnOxRvwHu3miAtr9EdNtG6e00wEaz/AC+IQx9v1a4PLSazOnLQhy59pgJnJXkx4HEENLVZphOpNUKbSXJnU6uFqlSK72t1Fvr0H31L16szp6c/5NWoPzojaPBEeEzyLB+AN5LFf25xyHu3qxOl4unNPUpYdquf/kNRZxePuPqtL6tatO9fTLGXeKzO0U5LDmeRYt/u09yrxDL8tF0TWqDhnyywMBdXGyMKxEELRLI9828Prn6cH4/Xr/8Ai9R/iqT/AFXhtvP0h5e2KHeXzvNo+Fd2yg01XWvd2+2UVQNaUU+Raj2VNmy+8MLtKoKEuwQwFmJnnqM88+3NvCB5ZOUPc86hSR5f/nTYEFNZLMjwEyXld/V8P4laArpaX69TX1qET16YFwlc8gxEeG/Msn5a4x5c3XWZotaVp7pjBi2tXWzrzSlLBav1EUCI2GNWmTZYii1x9iy2EV0zJRVTwWXvHR+V/pa+ZxG0WY9tOn4XM2H/AEB8lWfm3ArRGSkZyYmJz65Wn3WO2ar7VQGADsQvy1qyHA9Ms8J25TjvsxUe7S5G5s72GClWl0psn35k6ltkOtnVV0EelrQUNt4ElNrpo05RFc7P6mZx05C5Y23HEPCVFzAYEZmIy1aDFFK5pae+6p2jWFi0pRFLaJ8LA5P06c8kBti499RdLzqth9fsalU80oGdXGpkMo6jKsTZS6PeZxlxaI6pkL7ELinphtKI2jv3bHlkEv5WnOZFv0GwF5dZEXLzRbmlblR7X6o+ukL+O0fI86ZbMspGZe08b9qlwGOnZdFXQp5+oA56TIbwmyUCDgLw6Q74r7rrJCtA+36bPlpPZ1CgFvGS+pPBL8KpvkJdGdDfOsmvhHYdiOojOrZnOtdHB1SwrKltNse7aQNhT67QUkDQmpdI7HhLBmNNYMp3Hzw0a8ZHt2/1QPyqrOFXDuwEs5tyI44woCFhPKfrUV19S8Lq+rUrz8o/lntEiPMMVYAskMj2y38ysOfpf/G9qY3h2k1Gz+0TGPpRXFyhLIIVx8Z5CCyUFnzV4ixByxUienW4uI7uooKxWbNhg1VkN2zadXl9iLDtQhchSreYTXpAo+29y0L1W4y+iq2CRYdLiEYjJ+GIIjgFwMzO49CeH6bVzseMh0nTHsE9KY2IZ+KVmxUrcD/B/wAodCV0dK7l25CZa2ZMRI5VWwUxHgQiWMGAY9e41z6iVP8AJal37gnVfAPtR5Bc1v28pxSxUvt27K6iNmWsn3xqSElgYBCmlg1RjJnPeSSrhlgunX0mv5XT/HVE8dZYrcSjiXHaYPbI+0wjjXfzy7PVZp+q7dzULXRhp7YpXPEo2zj4T4N2KcqDxVqMcp0ex5ih2n8lHExMY13GbMqsM0Z+3fsoCyhXJJMCVl4s5yUJKcAIDwFXmNR9GvDwNg8DYvnG0xI5IDOcJzpGyU1+GcY46RcJNjs2XDXQ0y2SHIkL28ZyfBq55OXAIWPEHlzd+m99uxM7QDQPwSrpS13uTOqNyellyeDkMhye9arrsqcDK0Ej2mNvTBCvNBQQ1/RfR5qmouvSw1QWSEhMTkRJ4A8RxpisNFpEM9nV2c7VkvjqBA4Gb+Ez6CLqm8+ARttoKpCl2WLBmLDhlk5x5CwyPeb87gPzNG0M96v4DtPjeyy1WzzETktzqznMpmnXm5b9VgPKao0OB+Gw5yGM5jgGTioaV0z7Tp5ao/2etnFkTnLN8kojCeI5JRAmUtwzgIZuc1as2rAxAx2GGK48wvwsN4Y/5Q9actn7Jjhoegfx/gzG8W9HA8NTVNhOHPHNMpxSrerUasXKqimykAIytEKsMtsrULVnK2hJHFrBY9u2PS1e2qTiqUPBAkIeDl8sjaM2mZY2ByZmZUs3MpVhqp7jl812jgiJojldJ3LGqSK16UnpU/w7CF2F2qdmqelaf5Xs6nUPqeaXNaup11tHSkVe/rVaXVq1gXCyuJkJvHOq7OTZzhE4bhHDYReFSqy0VWsusvu2FzM2IrNIdOp7+YrU10qbLDv+Bc0hFl6lglf4Gr0/KWAewYizOeYnJcycncvAYkzqaVvgxAj32KBkTp1WcVUQr/qPUD1WdIsIkt14LV4EGeL0+2zE6OOJStI//wB3/8QALxEAAQQABQMEAQUAAgMAAAAAAQACAxEEEiAhMRAwQRMiMlEFFCNAQmEzYHGB8P/aAAgBAwEBPwH+D6D0RX88RPPhei/6RaRzoYwvOyZEGcdBEx3IWLptNA/gsjdJ8VLh3xC3dqOEu5TWBvHU7p8APxQieeAo4C7lNaGiggqWYN3Ke6KUUSntymu+1uY0oGNjGy/Iv4HZjZ5KFVtqHxQbtustoNAVqc+3UyIuXoNX6ceEYCOEQRzrwbMz1lDVjX5pewwWUBaArUAq+lYCLr6Yl21aWwuO5XC9NemVuOUQHcqSPLqwWVm7k+Zp4KecziexALK41AIDynHqSpHZjfVkNpkYA25W4O6a6zWhw3TmZxSfE5nOlkjm8FfqXdnD86g1OcCcoReDsERYVdJ5P6jrhmgndZTGbCa8ORaDymsa3jRJym9JYARY6ntVahjcDasKwswW5TAiLRbl2auECisv2pcMw7tRFGumH2QdaLQV7hpka7NaslRh2X3I8I89D2GxEpuHAQYB0EYKodc1LP0zBOxDWqKYP4U7yGIknnrhxZorccobcoHsPcGNtHfoedccSArRdKyiqRIHKdMPCMhPUGuE+ZzxR0QBNvynjZUmG9A6zfA9mMboChrdKGp05PGiteG6EWiKTBtuqW636V0n+HZiKa69BTpWtTpi7TScTad7eE7cXpgdSy3uO1iT7e02UhDEfa/UtTsSfCMjjrcfpc8qhe5T9PCjnpNlB7HCnlznb+GOU4UdkzmkXWnDfZHYVrDiE2chNxIPKDwdD5ms5UszpNFLIe8IHFNwrzzsv0T/AAn4aSNZ67l0hM8eV+penTPd50BpKYzbdFrGnc0hTvibRjtObXbw+D/u9NisJuHDT7U6gct7o3J7Typ2ZHkdkAnhemV6buwzhSYgnZnQGtwon+qy/IT99uxJPl4TcZv7lh8Q31mhQ/8AFX2vUHxHKhbfCHy9yc8CnKVseIZrDCUGDpXSRmbcao1iZa9gWZZlmWBd7yP8RT+dJNKSd39U/MeUGU3Mt1g5y+GNz/8A7dO9ji5Quq1me526LfYmnLz5KdzoEZ8oNA1yNo6WjKLKcCTZWUL0wsoWFG5KP+asQ8NYs5y2V7jum5kVgS2WBgHhN8sKdQd7V6habITpyeRspm5m2FOKd0Y3MVkrhc9h4zN0BSH9kleoFmWchZysO3JFZ865HF790G2bKZTpAHrFvayDL5KAUE78O62KPEGT9xGRh3IT/wBxuyERKnnEftpOcXGz0h4voftHXdaGqYZoXdMo+17AoI/VdQGyeb4UhN1qniANhB3hCPMqAX/hZAOVBJTVFI3LYCkP9mrOQPcaUsnqOvrF8e1IPbpiI4PBU8DoXUekOHfLxwqbG3IxWE42dTm3ynw0UGoC1VdIwvifaVu5emdEXx6A6Y2ZjSdC3Lt0rSHJsu1O3VwjcNTpS5D7KOpo/sr8KVtu2WRemvTWXq3jZDRFx0COhjsrrT542g1v1k+WhgR9oQePKc+1Z1tNG0XBE2bW1amupZzoi89Ajruk42b6gWmqQ+O+ASiK7EXy6DWZB4RJPOiMIDwn891kOZBzGc+EJh5CEjXG3J0ec+3W00bXqhBHpS4Rk+kXE86mPRcB3Y2gD3KSTf2caInu+KmjydgOLeE2X7WYBGX6RJPP8WIb8KSQEZRpHKeG5f4uVZFl7IF7IOIbYGoc7p+UM0Q4XNynfjfpSwPi51NaXcL9O9OaWmjpAtEhg3TsQfCY95QlF0URfYYLKlvJvqZzalLQ3L1YMzgFHtLXRzA7lYrA5PfHog/Hl3ukTMOxqpfkIAG5hp4Ce7Ob6fEL5FRnak/Wyr3UmXJqiZSkfnPVhpwKlB+YQksArOs4pSYVjnEgKP8AHhx/xQYRkTkSAr6fkD+ydAUnwPSMeVIfCZsMyw/kp+scqwW00aWM+1K/w06BuhwAvTrYdHMoWmmmph3RBLtkWkc9AcotY6SxWnkUnMINL4hfIo+45QmtDAj2GPNcKRpad+scV7p8tW2tOGFyhNt0o/xFwHKBaE59rFTujaMqhxr7DXJj65XKDPtTfSx0dMB0gogFPizcJsFeU1gbwiCURXYjeW7JzWlpvlCIoMDRZUkln26sJG90gc0IUwbKvKpVfCxr7kr6QNbobhD/ABZiERnC/IGo61iymQlyEDUYGlPYWGkRWob9IQbtSvddJz3O51Nq91hC3gLIsoCDSVNIImpxzGz0wTw+MBOGU9BspsOJx7lNEYXZTpaLUUe2YouJQ6Yk8BO41wxGQrDw1ssQyv8A12IpnR8KDGZ9kHrMF+Rm3yDrgpchpbOCyfSApT4tkI/1SSGR2Z2loRHhZUBSe8MRJcbKedf44C0csYtTutpP32oMa6PZ24UuMjYzMzlOcXGz1BLTYWHxJLfapsS2LY7lSYuR/G2tpTJx/ZeuxOxB/queUXV2IpixPxOf5WnvLv4DXuYbb2QaV9MwRd/1b//EAC4RAAEEAAUDBAICAQUAAAAAAAEAAgMRBBIgITEQMEETIjJRFEBCYSMFUmCBkf/aAAgBAgEBPwH9C6X5Ed1aBv8AfMzB5Xrx/aDgeNEkgjFlSTGQ7prS40Ey2CgmfolwCa8O47UuJDeE+Vz+ehNppIUeII2cswUuIDdgnuLjZQZnOyYwMFDoA5qHfJpOJcoR2ZpPDUbvfqEVyofgnNa7cowfSDQ3YJ8gYoSXyA6nyhq9dy/IPlCdpQN65DQV2ohQ7EjsrUTSJvSFD8VSc4N5T5/9q5WEZy7S6ZoXK9ReoFQPCBLeFG/Nqll3pNpDsYo01c6QmRF262UziDSKpBu6iZkbXV81J0hJ34Wxb7U5lC9DTYtNfkNpkrX8aXRtfyvxmjs4se1A0r6Wtyo4PLuhT2h3KdAfCqlhov5HriXEDZWJBunMLU1xbwnSOfzojFhO6RTkGj1PaJpSva8ZQjC8eF6T/pDDu8oYdo5QaBx0c5o56X1a/riN0RSDyFsVWiJ7MteVTQpS3N7UOUONA1PxDWp2KceE6Rzkw1urvcaCQOU6Y/xRsoZ6pQxy/wDScylGN9GINC1sdwjudkQR2GNLnUhtoGmaZE3ojc4cL1Cg8+VaaCeE2E+UIwNAbWicp1eEw7q1IK0HpSh+Y0VpmdTU42dAFrjYdGQucmwNbovXiejTRQ3Uh32VrZbdL6QfPsztsJza62E0eUyBzkyFrdQbaJLlEfGmdtrNWx7WGHu7ToGuTsH9L8NyZgwPkhG0caxzuqrhHjhR1pItSQWnRkdgbqCLIN/0yhuE+qtN2W9KMb3rLQU6AFOw7hwiwjnQyJz+FHCGdSQOV6jeUMUy6QN7ju0qWVEL0h3KtGFh8L8ZibCxvjQ6ZrVNKXu9vCAkeNhadGWfIEJk5ZsFFMH9sBWrVq+3XYe8NCd7jSgwgbu/oQDsVPF6D6HBUFA3fYZHfKdhTVhekeVe/QlWrV12K0HVMSVgoNvU/wDFlWVUv9Rb7Gn+15UHw1Njb5TMg4Rkt2VbXsphleQFae6hawuIcXU5Zt0TppV25HZQrMrk2mjKFmKzlZisadgP7UdXugABtphbmciwZqavYDSeWJpU5IeUT5VoRMDswVJrt0zjuHRMNlhm/wCYBZCsqyBZQsbJmk28JjU0UK0x0xmyL6FBPcWRktWFY90+couTzm5VbUt0HUUZFHHn3QFdB2joxF1awrss7emY/S9yxMvpNvyvKwzRlvU1/hE+Qs9J0iMiLq5TRmFhPa66KYPBWS+ExuQV1HaOl5N2OVhsS2dtjnpPimQ88p8jpXZncpsZdwFGzI2tZJHCL91mtOeG8ouJUVhq5G6JDV6g0DXNJ6bbUGMc+TK7jodMuHafcsu9tXqSnl5QbXCa0pgytrU93hFtBZTlToy7whhXHkpuFDV6aAro673Tq0DXKzOwtUOClzhx214mShlCiZmNJ2F39qigDeUGNHGtwsUgw+UBQpedTm5lkGgd6SQMFouLjZWGb/LvueG8oEHcfo3pndbukApndlxQZsE6OWXccFOwpPDk/DvaKYo5/SGV3YvVeuaE3YUcLnFcdyZz3Go91DDt/k50YmJg99LCzGQG+1av9bEOFVaw8BYczjpfdbKEyep/X6tq1fZJoWVlY6SiVxpddbKASepfjQ+SkJ014dqJpZwgb1AF3CEQ8p7WhZDyOzM4NZZWGoybDVMRlpYZji7PfUp3HQGlHLex0PmrhF5PSF3jTymtyiunJXATvtDXLeX2qAP9T6GrESh5pQxCIUOpQ+lSpUhIQjNSfIXDRD8tLPl0efCYPKduaUvgIa3CxssmR4MhXOiaW9mLDQ/ykGkq+gKPKK8K+hUI08IOBFrkr4hDYWU45j2Zomg7lQvD22Os+JynKosNuH3pf8UeOlFAJjQU6IeEQuFaaojvquk19Iy2i4nlX2ZomvF1uo3vDh4COIZRTpHTGmeFBDlb79UhFLnRENtFLhQ89gupZys5QNoaia6YlzS2lh4WZb+0yJkfxGuS1mVq00Zj1lFOQN9Wvy8JrswvSU53gKurENW6kfXtajwsK6nlvYc0OToqVKlC3z1lbYXCvoyMuQFCtJ6X0AtAUhqFon3FWsOLkvtOjB4TYiTuuND2bprC5CMDWUWfSyFBn32psPn3HKGGf5KjjEYofoEX3KVf8W//xABFEAABAgMEBgcGBAUDBAIDAAABAAIDESESMUFRBBAiMmFxEyAjMEJSgTNAYpGhsXKSwdFDUFOC8BQk4TREYGMFonBzg//aAAgBAQAGPwL/AMw23VNwxK7NjWD46lV6N3CzJEDZiC9p/wDCyzRZHOJgP3RNXO8T3IOGKk65NMI9qw/Tiv4bfSaJdHd6ABQxEcXPlMzP857SI1vNdnDiP9JfdexYPxRFRkE/3ra0b8r1KIIkL8TVOE9rhwPXL3kNaMSpNmzR/q9SAkFUaujg1fnkpXk3nNPacFBEYyhTmT/Ii95DWjEr/awxY/qRFa6SEf7V0hbZcDZPudhgMSL5W/qtuJYHlh/utlonqtC9UsuQnfqm2bHZtopRh00PMbytQnTH26m2ZuNzReUDFu8LBcFsKy411dHBvzyUhfidXNqkbkIcUl0DA+VTFR/IDL/p4dw8yqrKh/FN3uJc8yaMStkmFo+fid+yswxZb1KqgUyqFHBeV30K6SAbEUX5FOfF2Ht3mfsu0hOa3O9S0Uf3lFziXON5KBVFaB2c1YhbuLlJuq08qHCAay1OU17Nr/wuUnaO/wCi6N0J/QHPw+/lrd+JshWXD1VFK9zimMHhEvcC95k0Yrpo4lBFWQ/1K4deU0DQ8QphUuyKATDiVC5q1o7gAfAVWEfQqR2TkVOclNxLYX3VmG2mqt+AQdG9BkoMvCwnvJvIaMytlzon4Gkr2GkflW0yM3mxUjtH4qKbHAjh7jDh+GC20f8APkqu9EZqC3Bu0fcSP+2hH87lfTuCWk/NbX5gqlFVqz7JhvqjEwYPqpi9CarfNdpWXyCn5TIhHyXqxCFp/wBlbiG09Ai5R34MbZ7swdHl0g3nG5qtRLUV2b1cq2lvhbbGuU2W4Ts2GS7OK2O3J96saQ0wH/Fd81MVHfaVpHndIagFHjf2j3CxD9rFNhqbDbcNXLuKoic0VMGqdKnBTxc6qYwborPVYG62fzTfiElbjGR+6k3s2fVSbqdwT4p/iO7p8XHw81tVealUWzJVh/JV+q2XLaE+SoaqTtpvFT0Z2xjDdULZ2YgvYe8jOxlIKCz+46p5BQ83bXuDvLAbL1OqTe7qrL/RykbymlryCcMEel2XNUm7LcSmcJ0CEgGgYuVp03uzOsyXRt3nUUOGPCJdxJ7tryipWxDDBnEP6KGIkS20bUhcplTQaNW22aps8lsm0FJwkeKoZhZFdJBMnNqCFDijG/n3ZFoPhQ2YFdm4OGTqL2blVpEzemdHuSp7hGjYxIhKr3dL0CN0o2rkHvaTDC7J1clLK8rPmp4DW/8AfUZXmgVo7kH79ezBBiu+G75rt4tkeSH+6JgsDeWKnO07jh6J06DNOsTs8U1oR15KhW02YXwm5TF41R4PldaHdRn42ZBQ94PlObb1UtiDjQoUcJev2VXKH0RmyVD38Q5NKhcz99QaApqnUzVBrlkpCpQa87N54Lo2CUhMJ7heLijPeOoarIIB4ozxVXTC2ay2W8Sms8V7ufVFqrjutF5U9JMm/wBNt3rmrDRRZotaV2gkrNeKo0j1TZcyqdZxxbXW6rmulMFpkqyjs40Ksk9HE8r6dxA0ceN0ynn+3XzUOH5Wy7+IPhKhcCfvqbwV2KM7upW4Xa6XqQ3iog5FRIktt9VaOCaE+E+hBoVKNdg5ZhUUyFcviP0C/wBS8bDaQx+vVLnXATX+peATEun4Rkpt+SrrqF2ZVfst1CSBPVifhKCKHIqTRNSePmuwidIz+m5EDZiC9h6zz4YLZJo1FQGYA2j6e4xoX9OJ3NVSiHhB+afkZgIRHUhy+asjduUnOHRhUuUWXmXRxZKcB1ngbl2rC3iLleHBbMNtpFs+yHtHZ8EGtEgLurHPwyUAf+sKbDJWYwsO+inDKqqUCsuFdd3WifhKZkU5N4AomUlO4IOvTI7d5pQIuPULjcKqLFO9Ff1I0XyiyPcYg8MZs+vUrsWF3Fdo4N5VRa0euKmb2lEtax4vk5SiMczlUK1CIcOCkSiTcE55vJmgDcKkqw++8at2RzFERDiu4zQhvgjoxixWoTg7qu4kBQfwBVVFNhIVnSG+qnDIc1GQkevVUQhsxEyrpSKtByJLpcZow3bTZUcpzEkATROUA/AOpFzdspjMhqK5JpxebXfTJkFIRLbsmbS7HRyOMT9k2LEiTfhktuBP8JVYMb8i9lG/ItmA/wBaL+GzmV2scng0LZhgnN1dT5XyTHhPb5qqG7+0qyKuFFbhVPiaqUdi0oQm7zr+SMF9+HFU9U15EqqbjJbOy37rZC23tarWjPd03wCanpMOw/79Rv4/3TOCw15KcIy5KUdlriKFbDvQ367qawbStEoOBk4KTxPiEA2bSqzcVaN8qLa1PUD8PU0aBxtn/PmiUdQaBVxkEyGLmiXdzivDRxX+3gOd8TtkLtI7YYyhj9SpvtRXZvM1JoDRkEJXDBUxuTT6FXq9X9Yg3BWi4K6w36rJUW0K5qc3E5lZHNdqOkZ5hepwqqZBmtpPhvn0TG3A4rZgM9RNSaJdXo4k5cFEgRZxYbDZtYq3BNpmqmuoVFQ0+a2m/JYT46qaxZRES5VWyLIRz1N4Jygh4kZdTSHYQxYH+fNS1whgzbPdW4rg1q7IdBD8zt4q1K3E8zqlZdSYVyLfA/6IT+aB6lSqvb81JptFb7IY4KcxPOanMLD5rD5reZ812YL/AMLZrdEMZvU47jGdxu+S6TR+yi8Liui0hvRxfvqjxvO6ncRowxiFWmEscu0Fh3mbcqEEKTt7IKs28wptII4a6hXrZPyV5V/0V63lVyu1FDitpQ2vGwKyz6hcbhVFxvc4uKnmgNUaMcTZHcilqI7dYMV02lG1FwybyUhd1q69k0ycttjfQqkOz+IqsSXJbzncypqilcVkV+iliqQrAzfRdvHPJgVIIJzdVSAkOpZitn+ic1k40M0BG8FCh4gV673ZCabPFxOqi2ZsPBHpw07H6qcB8+BVbUM5qUarfMOrZAU5SU8UxCWeuSBcjaoALlC/D+nVdE0Iit8M/opRWOhn4kVZaJuuAChwzvXnn3Doj7mo6TpHtX3fCMlS7urMDdxetnafi4qZ1TBpq4qq2Ycm+Z9FPSIjn8G0ClBhtZyHuMc/AVo8ueuqpjD/AFGotdtA5qXGS2TMaphVyUiNpZBGRUNTOGqZXZ3eZPnU5r+1Qfwfp1pETVdHhfkC7OG1vIS7mHo/gh7b1ZHdGG32bd458FYh0HUorDAXOyapx3CE3IVKnDhzd5nVPukb0+60UN8on8kLWOuETcQRrbzmptBbxCvDua22OH1VHhWhenS1MRtOHJdm31cto2udykU/kv7VD/B7jpMc+N/dbO+6gQhM9T1LEJpe7JqtaW+Q8jP3VmDDDBw7ipAVHA96/mFDHwhTA1yK2fkVWG70qpuEiaaqhUMlcCtyS3n/AJit53zVxPqsGraQE1PJHkv7UeEP3F7DeH9aZVGyHFcMOKm7eKdEwbst12IDC93BWtMf/Y391ZhMDW8O66R9SVciXXtorUQnkpzJZiD3UTgR91Bfm0KSqpa7lMdcpvrqfkULWCKtcFxsrSHZNl7iY3/bxt74SrTDPrXBXKy07bvohWgUoENz/t81PS32vgZcrMJgY3Id3K0FZN7aai3wzmdTuSZy7l8M3OEk7QtIpEbdxCkVet7uqlGSb1XqfAKNF87vcS14m04KehOtQ/6T/wBFZ0ljoLviH6qcJ4cFUa9twClokF7/AIpUVqM5sOd89oqbwYrvj/ZSAkO8JduC4LdCtM9QVI35IubjqsMuxKl3QtbLxuvF4XR6e3ZwituU2G2w4hDFt6d1KqinrZknzzTOpILhJNgwxN76AJkIeEe5yImpmC0H4aLZix28oi9vpH5ltOiv5vWxBYDnL3AsOdNb332sk4uErRnJVeTzVWizm3vC1wBBwKt6BEsf+t26VY02EYETPAq1Dk5py1ErhOSbI3IyIv6zeWoyFydK/gm2kGtE3G5oXSRax3fT+T01ScJqYiOAVXGwpBEYjVXvrMRocMirWhxXQTleF/u9Gtt88Kq7GID8JvVWyRrfqEsURdhNXzu1zOARs3K7eU3bxREFs83YBWt+Kb3n+TyCNrWBmVIKZU7jOYK22k8WqyxpHEoNHuHawmk54r/b6S8DyxNoLtNGD/ihH9FJzjDdlEbJYObmK6rWOtwUiaKzAh9I/hgrWlOn8DUGsAa0YDr2BaiPHhYJqUVsSFPF7aLodEkXCrnm5q2o+kOOYdJWg7poeIfePVbNHi9p/kEltsJ4hSlZZxUhd7tJwBHFT6INObNldnpMQfi2lR8F3MEL2TDyetqEPzBVexn1XaudE+gUmAAZDuGQIRlEiY5BBsIWR90WxWgtVjRmmyTMyqqh35SjIghQ4kEVYbzQFbUOnwmanCeHDh7uYOis6SILzgFaiQ4cRuIZeuza98TySXbxjCHkh/uqRNInnbWy4RG5uFQpnSf/AKUQhxwA5265tzv5P0GjgOi4k3NVn/XC3kGBPjaRZ3ZAhTbss85Xndm6v0Wy155BVZEHopm/zNvCDIjpg7rs0Cw7tZZpkfRzZc8T5oRBQ3EZH3XoIBnGdSmC6OH/AHOzUwVMgzU2iQ1bVy4J0Od93ApjzvXH+SxInlE1Dr2mkG05ytvAkrekejP3VNlqqLRVNU91/mCdCjCuP7hPtbwoVAZfZatJ8tPc6p40Y2ILd6JnyQlgJqt+SmBILZaXSyUnNslbTrIQeHdIPqFJ223JykNw1CiQXUtm233KqkwmK74P3XZw4bOe0qPH5FtdG/m1S0iEWfE2oQfDcHNOI7wviODWhPYyCQ1w3nmSgCIQHQxVCNEuHs2/quki3KTaDqiML2X8lCfg7ZKIIsPOIKdAjQ5idq21B8Mzace+lEiC1kKlV6RozcwqbCCMxqbDZQxXWV0TN1qHEIuvM1IeZNhw1JwmFIKblsXKG5Cp4IQo29g7Pv5xXho4qWjw5nN9Pop6Q8kZXD5Kqp9FshVU23rpIO744abFhGbT3cWJE9ho1wzcrbyQMkQ72TKu48FbduBSF3WINxVb2H7FGea0d2NWqLA8O8O9bomjGUR1XO8oUmb/AInm9YlW4TZeZuDv+VajRjBbhDh3/NQ39LFeGvBk9007iululcnOYZHxBB7c5oObc6qIFzVMLkoc76oBwmnPhiRbXmnPbe2RCa7MT7yzO2/ysqpM7MfDUq06/Ocz81RUoqnq2moT/wCni3/Ce7/+Rh+MPJTiKnAZlN0dtTe85lWR3Gk/jKLW8JlMbgypUV+DWy7u1EcGt4r/AG0F8TidkKNGjuDo7/L4VK4Yr4jcE18VwbLw3qjz6yUnjlxQhnlNFRXeImSDReTJNZ5RJGWf1W08h3BEO3hQpn4kJKN+FOOahA4NHc2nEAZldg238Ro1bTiW5N2WrbIA8oopQ2qp7ksNxXRxPawqHl3NqIeQzT9IIEMRBIw5zKJaJCGLXqnRXY66fRUB+Su+ZWAW98lj81F+KKfumljbxvZKUMF0Q/VWb3mrjx7p0R9zV/q9NqPBDwCIgtnK91wCmXz5CS2XT5o9IKtbMKU5ZFVM1D5qHwUhcUbVxvRcKhop66rRCmFM+JoUyOQRyXRC9x+issqWmcs0HtuPXtRnho4r/bgNHmf+ytRXOiO+LBTNTxUp/K9TlZ5nvIcfw7sRTHcRnu3IGy0cVMrjFd/n0TakE1Unz+auA4yW11XONwE1Aab94qyck50LwmozCbEbc4T7qGzzRAmwobpTIbTBNhsEmjBSLvRUTXNMnYKt41NbgFEON4TVUKLNTCsuwxVBMZq09UwKk1jp5kSVo1M0Co8HAG0PXqmJFdJoUoRbAbmd5W+ltPzvUnKRvGohoqtrugiEWnxLo3b8LZ9O40uC/wAZtNUTOSgQhcNVVWrVm1UMwqLBbysTM3myjkKaoxwuUKfH79zM3IWPZQ8c1Jmw0XuyRqrEIWjjwR2gTlJGdCpZjU4m80ThhcrTDKaIN4Rnum9F3h1WAqsaqU5Ky643ojIyVkqM4XAAdXomnYhffVNh9FMXrkpEyHBbFFvWu8KYfBG2T3EOFBH+5bW0PAExpNp1poJ9UOA/fVf13uwYLI5ouN6LYZm7PJNgw73fRNY25ol3JgMMobd8/omtYKmgmpN3GozMmDeP6KxBbZCstEzcAs34uUMjMqT2hwyKpDscQrJ8JqpH5p/4VxUsMlstrxXGaB1n5qUIWohUvFeT1HvNzRNOe69xmdfAoPCumq0HfNlfOir1iclEjj2sV1T6ocIgQ/D+/UqQqAn0W78yrwt4l5o0JsNtQ36phFzaFGFaDJCd05rYFTe43nuo3m6QzmmHjNCV802HgLzmUXYJkQNmGlEtVs3C7XElcXFU8KFrxjVUK4Iubcaqed4VDRWQaYpjXCYUmNA6sc8JdXkpKbjaK2RIdyEUNTB/DhbTv07h+i6R7Bxmx/6KIQ+02U/koMTC7VVVrzWyPkrtU3GitYmjQrbr07jJQJce7dHhibTVwy4pz/4jxNMmZsa8GXJTaZhEG4qhVXKTdVlu+blLBZoMhmQhi/iu3Ba7lRHo68StokqybkDjqm40To0pNub1onMffq2Dce+peqXq34nuJJ7iTwC3IqM+HswJ2WtnROhHeZT9kD4hQ9WZXwYDNGJEuCaZWYbUA3cb9SnRfDDEvXu4jRi0hQj8Mk7kSpA4gIAuqr0S0TKBiGy3NShNlxcpunxJUzRoUoc2M82JRZg9urpIYm7EZrCeRUoU3HIKUaGSOFVssiE5SU42yzyhSFB1n8wqKR1zF4TYg9VIqfdUUyrRUbRjgbQ7hwF8kBiCQV0w3bn/ALrpYdQd4ZqbTrle7ILa/KpuuXRw5WbM6hUtubk1tFu9EzN16EOGJNHeOd/AeZn4SiW3FXeOf0UrnWlQzHzV8uQU3VKoq3Kf8Fu6M+KkL1opF81VUW2wFSY0Duovp90FxCBJomunNrtRhOufdqk643rh1pCpU3SZwKlirRXDVAiYE2Xdy6Nokja3oZxUorIjDk5qc7RduHizJZOHzXtitp7j6yVmG2QVqKpAUTuAsp5zee9oQqoxIPs8YZ/RNdKhE1aAobwpQyPwlbiJiXn6LetHJtVJ1GeT91IXq04oS3YQ+qk1SdrsMlzKIfvYSxQERtmfXj+n3Q1M5LlqbI8Qg/G481JWX1Co+S3xqv1RSyjwb8ZKeOamhO7JFEI/NQYmJbXuXv8AFc3mmtO9eea6N7W2LrXFULlig2C1tBtKTptdlJWYFSfEmw4Qm930TITfCO8cA4WlNorKc1biEqKwVdhxUOWAlqz5rEeqq5p5uWy5noVRbTgF0eiC07z4BWRU4nqdHDvzVoydgUHuIshBrLgZk9fSPwFN1clEHBBNkpO3H3rj1alVVnBwkVI3iiJ1hS9FZ8jyO5DP4cCp/EqbzqBMazedRdDpbTaFzhiuxaZnEqTZve64YoQ4zQ595PFb0X5qUJsu8dZvQoOKLRUZKTBs8FsK3DcYbzfK4q6G71kqCE1T0h7opywVGNHoqw2H0XswvZD1UgJDqhzTJyLBZpeV0b/mrUOnDrxW5sI1cU4fEogQmm5z1Oru5rwrch/JXM/Kt75BVtap4oyF62j1dJHxdxMVeaNGZVavNTxKsk7TB9U/SCKCg5qzFYHBfxJZWl2TAOOPuAoJk3qTbyttpPEJznUtYapymgc+8cWC01yc6KKuwU69w9vldJcU8J4RGRX2UlpDCK2Zocu90h+b5dcveZNC/wBTEEm/w25DNV3YQtFT8Y/VQ4eIFefucjcp+96U3456jyXNRB8SKaRep+ZiIyJ7zY2YfnKbCh3DrkuMtEhn85QdcJTUZ/8AUeGqAw+af8wf8bQf8+Sqm8iq4qIMVxTeCguFxmoo+LurMFhd9gg7ST0jvL4VTrs0aHvxfoE2FD9mzZb+6kMaLRW5zenG+wz3yRe2fNFzjIDFTbCiubnJHozdeDh7jo0TMFv+fNZhQ+aE7k6ZwXFEZFQj8YUTuLMFhdywVrSnWz5W3Kyxoa0YDudMi/02BjfVAgTkmt81AEQN1gsBRovmdL3qRisB5pkAOkyVp0sVYENsimOM3QmRPopMcOaiaQ0WQ/YBP3W2LTvM5GFMmGWzll37H+R6op4z1Nn5VwT+ab+IJ/LqXqilBYX8cAp6S62fKLlZYA1owHd6TCdQaQJsPFSMJ9pWnSOkOEgPKgxlXuoEyGPCPeWaOSRDladLxKw0ADJWn2mkO2HC+SnEe96k0SCnYbPOSLIgm0qkZ0uIUSFM2Witd5WoFJYYFNeLnCfelsRoc04FexlycQiOi/8AsVMzfAwdkmVwOpy+Sf8Ah1HV2TJjzGgU9IPSnK4KTQABgO9sRByOSsgmKzBzb17J8zi6i6SIbUX6D3gvNcgrUaKQcmmQCbCilzqTa7xBTdaf+IqnW6aA4NiXGdxXRvM3GpDE2C9vR4Ny9wLXCYOBRdo8QNb5XC5e3ZP8KdDiizEB1PIyRUwyw3N6Bf2rviu+X8qm4yCsue4Yh1kyQm+E5uc0XE2ohx7mNboIlQVs1JoE21vSr7lMbMVtzlYfAcZYtuKnHcIYOAqVNjNrzOqf5Z0cT2bBalmVwTGvvv7pz4jA8DAoRGFrHkTk1oTocT2jfr/4B0bQXxMhgmnSoH9zHVCbEY2eIJr3boeaEIwjMUtBOixKEiQH8oLnuDWjEqWhwHxviNGrbithDJpkpvitdzJKoGnkVsxI7PWYXatbGbm2hXZO2sWm/wBxjdKDac6YdmpMbQ44BMYPCJd297b8Fbe5z3yvmnwIptFtQeuXOMgMSuwhRow8zRIfVbejR2+gP2UocQF3luPy99LdGAcRe87o/dW4zulcMXXD0UoYc/kt1rfqr2/l/wCV7NruVFKMx0M/EFMbLswha2X+GI1dBpVI2DvN35fKZuAVqPEcXZNMgEIVpz4bhOuHeOY/dKDOnhuhi5yMQutPdld1/wDRtPYQtqLxOSDGAfst5SjMa/7rsndOz+m87XoUejO0L2mhHeWYVqO7KGJ/W5UgwoY+J81dAd8wuhiMMKNfZOPI92WsMoAvcPF/wrLRyaEDErwV2uSskA2s1bgTMPFmXJZtKsE7Qq1y2/aso7vi2I6yL7WSq+0zzBpXSQndITS13glOyXbXJWGgSuUaH4GmnWiRDcxpcosR9Xv2indQOJLYg3YjbwmwtLkHndiDdf8Ase5MLR29PGF4FzeZU9Mi9J/62UYP3VmGAxuQVSSqLZppEPbYVDjN8Qrz7kaPDMi6rjk1BrOTQrV8/wDJqmu1lqJ+WoOb7OJ9HK0L2VUPyxdk99o4iexv4TUphRHuEg80HePshog3bQnNf6eK948sjRWYYkOtpB4S+qDc2qefVLXVabwm6PpTpwzRkQ/Y9YxIrg1gvJRbBnB0bPxPVllG5dUELTIGDX2x69xVRNIN8U05YLmbIU/lrkLypBSxOt4G9e3mFwcJqE7Fjh3zWFgiPeZNaVbtAPHlaKKJDi1c3Hu5RHATToG9I0ITIlkhrTaJ6+kj4ZqDEyVPQ67xrIdcjC0i1Ehj2bhfyTYkfRwGHBr5uC6WHEbYF5yRsvLwMWMJCMbpQWiksZ8lbj7MFu7D7jTPws7iO74ZfNNA8DE0ZNQGu18tRd8tUz6ol2OCgfgCsjxP/XvocSEQIjM8VKKYcIfE9HoogiOO87u9J6TfFG8k2JDo9uKB68WH5mkJs10T/wC0q2clRGqFarbQkmWtyELZRZGGyfopmcQ5TWTRcBggfMEzjqpdqp1NNiZvs/LuIvp90/8AChxbrAGOqyLzqmrPqU8i+VOalgxqgNvDdt3p3z3s3kDvRHCZdiUws42uXdRpuLYbDZABlNNdafZxrVBziXkZ9zpMPyxTJMs7wKdwVUB6lTzoFdTVHdxlqnPFBQJcVZcJhSlJuSpyC+gWy5Frx66nxD4WzUKe8/bPr3EdgvsqGfMyRTHHwmTkDqtZ3ai7O7XW9S8EOp55KznUoxn78T6Dvi1wmCujh9I5/kBuVkaO0NvMnVTXsuPXLnUAXSQ2NDMLRvUR2jyDjV0Mn6hAx6NnM5nuYkV1zBNOiOvebRK6Z1/hRUvEp4lfC1UU1F/GpC/UytZIBvgC2lSiljcFwav8vRGCmUyEN6M8NTWtuAl3MXRTunbhfsrXgdfwK6CIfwFBueqWeqalg37ro4W/ifKrLbvuV00YdkM/H/x7hHc9ri2Jc4Ca7NhymbkyGMOtN5knQ32odsSBcKIQniURtKoRR7Novz7qwP4jw1MhhMaLtdLs1IKqst2jwT7Tb60TYwLGQ3XTvU4URsbhKyUWva5rhg4KZM3G/XaF6EkBK5SUzcEXtuZuKHFHjbPuRYNmMyrHJzIrbMUUewrzQ/qF2s4jbrQvCnCiNdwxRcbzqIttt5XlYwm5neKEOE2ZPhxK6XTaf+v91IXe4F8pm4K1GiFz+dAhCtFzHCdcOrtva3mVo0WYMK6eE1wCZ0g5T7vQx8RUR+VFIXDVN2yMypNd0jsmrZAYOKBe4vJNApulM/RHMqDC8rQNUfhI/VB7d5V2h9VKcjkdU5a7IvcZKWH3UMeUkfXurU7EYXPCs6WzZ/qNuVpsp5tW/wDMKmkOHKf7rtYkR/NykyyDk2pWy2w3Mmq2Hw4bsw2Z+ZX/AFb/AEAWzpU+DmBf7iAHt80NTgvnmMR31h/ockTGjtsDGSMZoDbWLhN3/C6GMBM3EazYc1zhhNOiPM4rjtEpos9nFNlzFuehJ7zRonliS+astvcTPVY0VtuJ5zcEXR3l5ywRs4UX0CD3710slwmtHhYWrR5DXGZ5mEJpVvDFTvGHFbLvQoCKLBzwUxUaiR4arNH/APYe7qp2OjdmwyWxpcUc6q1H01/ABomVtOiNZk503FdkwMGZXjd9At1gVej+S8QHCoVl1HYZFdNo5sRhlirVzxR7cj3xYzevVgwX8VcDGA9GKvRvGQotGb/BfUjPggG7LxdJCK15Y472RVskueLuHeGJGcGsGJT4cOHYg3zfvH9k2ZrijDh0YN4qTbghM0CHRj1KtEzfmhmjmVpGknDs2/r1I8L+nEOrNn2VDQqWC7I7PlNypsxMWnU7koAN5Fr5970cMWo2WDeaLrVuLi84clMfmKn9Ss9W0JotYZFFzKOF4TXZpj/4cXZf7g/SGyMN9/BCw0y8zkyFMzZUO4rbjTHBtUGMEmjvHRYpk0fVf6vS8pw4WDf+VVOMMymg0Nb81vS5BTdU5mqpmpC8FVvUR+X3UKGd6U3c+pEyitD1s3q5TYZH7raEuIuWzVDzC4qxE9oPqmwW83JsLTJNwEQXeuXeCHC9s674Rmi1p/E7NCYpgFM9WuKBN9xUviP3TBwKYXb7dl3d9M2Zb428M1MXarLRbiZLookW1GrKVwTtHfeLu/fCiibXL/SaVvS2HecfupHqcEMAqatH0bwQu1idXRdJwY+w7kUQuKkVwuV1eCo8+qDg67EBfdWZUTdCiEuY4dmcuHdPivuai957aJfwXAfdcesW/JEneQCd5dxaSD5h3M1surljqcAezvAyTmsMg3efkuznDgZ+J6a5lLBmFC0mF4xaCbEFzh39iKJjA4hWdKHSwMIoF3NWoRD2qvVL37ralO0iL7WObZ5YdWLB8wpzTHn2jNh+rigqqQBUtVp1yOl6QJRXiTW+Ud1BgeFo6R36I8KKWXcT8Au48VTeNy4FW3XxTa7rbbNbznDimw2b7/oM10TaaPDv+I6ioRxYU5vld7iXaK/oHnLdPopaVCbZ88ptXs2+hVAsFIVKED+G3ain9Ou7+hpVeTkRrwV4V4VjRmGK/hcPVCNpZESKLh4W93pZykPoj+Jq9ZKmupQxVo0Cyh5Zqqmb10Q3b3HIIAUA7mbzJULjyaTq0uN5BYH+eqhwxhU81cpYlCfiP6qLzHuUjci7RT0T/L4T+y6OM2w/CePJbTvkmwoDZxn0aEGXvNXuzPXdDude12RRbEFnSIWy8cVZCsMq7FyJc5Aw4VhnniUQOkvdGOVwVmG0NbkO8izuitDgrTb1SXSC8KTtc5yktjb+ym8zKkKlTKEOEJuP0VhtTe52Z73S4WJdP5hCZk8CTmlXoNb68AoWjswTZ3u2vdCyM201WYbHaQw7jheOaMWMbekuvOXAdyNL0Uds0Sc3zhGPD/wot0cT80Q3BWj2sbzu/Tv+kh+1hbTVk7JWhNr/ADNW8x/Oi3GfmW80cgpum48VmeCyHDV2dGYvNyswxzOJ77pIe8KEeYKzpDZO+KhU+kp+JWdGALuC6fSRs3yOP8h6SbmT3w3xIMhNDWC4D3G00di8zHwlb1ocVuD0K9n9V4R9VtOJ1WIbS9+QVrSz/wDzH6oBokBgPcJRGNdzXsvqVNkJs/5o6HFbaaVPRu1h5YhDpIcSGR5mqjl2cKK7k1ezEMZvKnpEUv4NoFZhMDRw/wDzx//EACwQAQACAQIEBQQDAQEBAAAAAAEAESExQVFhcYEQMJGhsSDB0fBA4fFQYHD/2gAIAQEAAT8h/wDYAGrQc9AnS7PwDB6soD5pW6MOh5/H/i7Cww2elxTEmrRa/vpAvFC8xkVraVb7WG8NDT5P7oHHBgzHzERWzc25/wCzvMaCy9p7kir4TTO1PgiNciF+IaYei/JLVs7HqXO6wr68+MFJc7HrT8RDIg0CaOPaBWmk1ROuyGI4j1i03LjpBWrKNL2GCJZp/wAE8YWppLROd2h6GsZUpqXqNSkANL5ev8Nn6RfVoS8OcVeuv0qPqBau738BKI2KziVXKdCodbrszAI71okdkQ/MLn3uPV9BlSCCVgH5DzecWmY47EbMnopFAtcSo/N9ya7VldXwqn9h/uKRtRkRxqv9YZcQsTf+etGYxcr8mEbsV5NDhAx66vSKx1aev4/gkFJbsQVe1vR4PeGD+Gb/AEUgWTiBCbQJi80oKiXCmJk12c7hd5pEdnp7l/KYzg64dSVm9y8HQ3lPMckzlhL1kRIAFt+yPsA6B+WVn5q6r4KaB8zU1kz0Lz6R/AuNHzGikPBX3nDWSy/d/PUXLi56zJwNhowTU9ooDDEDQxnsfwBVltW0sCM1b/ejcLYfXoCd480rkeMfuSlFfRQrM5FsYINDO8NHOao7lRVyodLtNTnSYa+4LUatAb3Bebjr/SBAB0isMtWa0dWIUexND0ewJ5ikp1SiMIx+y6Tn/Z+Ybf8AFftHaW6vnOeBlf8ABy9741hbkzbuOURY2nEY9L+6/g76dl+AmjacBKimx+tbUOYTY9hOsbYsRlXJTS3vRTajVxjXV6nisHeNX1xK2qpsRgqKlo0HU3g6zeQy8uppO1z26pqK9V26Q1Tizp2lCZKO/wDj5eTH9Eas+MHHQ0PSdlySHBO1zaJySoDjuZO7zsdnd16oc9V+CaiaJ5rgzLv+3/teABust84N7v2/gHPZBerNL1rrz8MWaeQKwzxmgA6cpZBNC4eMFWtdvAxbCw9mJnLyOJ8DuceXGAz6Xvk+8paQBIwS8Xd+JSzv4XsE0C7ykzKp0P18o9ulDitJlW5O8WOVZMGWyuM1wTul7RR5IuTHRuacjj+Eb0eBxFoxtjcsO3K9CVju07cTzM+16o4+844J6kItnC8M1Ky++ntX8Cxa1n7ftRmO3PHylYu0Iuu4mTU/bvHxd1WbhMxFLlw2GPXWb+kNxuIAysOTGf6gXpgVvYlpOJfEqepONQuuMUu8s0kj6nyK1baZHsZhfUAej7pM2cVA4D9uXG5FT3uYoW0MwfY9YtYRzLmZuuaZUPSYpk+FD3YGE60ajCzXQMRScOAwnlhzIjcK8+/tPfcD10iOHpgv3I5QMRQ4OMbuXRfl/AsXkJ0iWXlq1LW0GpLwONGIt1onXfALxKSg5FMOVcYbVA1Y5XjbrXPN4XL7oZQ3J6u/7+PrtxvDs9dEO9ifXV8TkmTUnixSrGut79awC1ct4CNEcFFt5uaX2gw+njmatymwHrHo7dcYQvjNnhBiAqDtModDoP8AnlVG1Z1HB8xqpeSoTDfqFwgup+SGJTQM3FjHzjBjz6s3HtBXPX3eCCSN5eUDXCAWhOX0XGbGcRTQisXr4ctQCDt24dZikNPYXAWLTnxNGSvGwTI/V38AYPArtMOFL0VMcE2Co2FZUG7CQy83FfTlYmsteU1EOje5/iIggYxoR1FCNnqxHpNeXs7H4juuZO8KKgCTjsgkV739QU21ek1Jt8MQjbxIP25gkbb5cvu4R5C3me2H++0feA7eCtLxLVBaqIIW16Tz6M3D2lQ4H5QWjjEpKyGDZbVXSL9ieKWUwamozHZ2ZuChoO3gRrKdQX7U1BaZeMQWlovYj0z2zXBPzLFM6sUiz5Eqiva6PWbLLBspYmanQeIx2BodfelLQzjd+k41OXQhAMO40D0lnc77iYYxx8a9dLiocopVq5UjtaUlq3pmuh9Ip8fgntpoecdcwpRdASmt5aiPaXu36Mya5+n5+rcqj66/dlAbWvV8Lqdpiq+xMvt/BNnqp2/TyTbVEI0urdj+CurYRhwIeUulrX+9pYKqFJW2xYbwpNKW5awnHh7wFBbcmWtezrKM+4UYPkDmWtZ0xLCLb4rghUhUDY+n9oLx946AOr2ga99mFdwapQNXtEKKRmUHldxk6h46qtw+n9RwlrGtE7T332jUNFPxAwA1WA9OBe8O2Dbhix0LPH90h6GLPoR2ht0Jrph9/DGbs1erLLMB3P8APf8Ag7CgPU/x+svGTMORDHrpL9icMnrCkjFjyoiOIOzKlCxfiVmEmuHUz1CZnS4WMBbKr5ZgDaLucia1xZx8GrTBEveLL3in/U+qSkM3NzqfTRP9y/tK7wD2iAoWQF9rO0t1IXh8uk5cyuc1E+ugvliNLMdULLNzGIaHXDPH/JR4LArTwU942fFqKvtNAoN53ZoyIPS+85/fH9F8HDXvr7XDyvvq+FhwxfJL/Mp/B7HnMhBusog4Cr2inqVXszKSEl9AcoaDc5NyrRdzL9G74at9kb0Pqsq+zKL31U/eao44RDJMhNK669Emr6D8Jddvf6dphWuK8rwxs1mhgZgsHmCPZ/CjSEcvgmYi70ReArZ2KcShgc5i7cTf8JjMEfdYw0HOms6wZsHo41t9HtvxGerZ4G1A08NptymTq5q9poz2RNH16XgWheErb1oAJo5i1llSl6azVw8ojvoIdrDG5X6S9Qd7pZR22e9fiZpjiHCXpdogQd9I+iv2noN9HAdQ8iOeDFUte7GKkncmiSz2PL6iuazRD/XvPtEEmTGHFP54j2YWodMtTiizq8AwPtNdw8Otvi2qe/0m2cSJYREOZDYjVA6+kI0ZN80MZKe7AFCiZPH0GEia0apbK9kNDqTYE6LqSx49zcl3bZe0ZzgcI91fmA81d5+6R1lAA4B9KOpax1DHU0cYfmNTX4bTErUvFaeJuBnB3WOrEccI580jC3pKZSsaQMPqTQBVuXSiGku6h2XHK4CB3TnHIzPUdYudaavg7ZVmXXSxjILDTwtr6KAyHrf7F5wSwjjsVMfXf2NPevKahG7PSRL6RtKoW+3uM3jsi3r4iarsqDEo4Y05MYC8bimYFaI0Xj0nMTP0aIHWaE+2J9laesxRwFi+stNp6qywXZ7+CPHkGBWmuDR6kYX6EcD7bExagHceoTDwbOnR4Xbw+g/3yEQ0n3+85g3Wj1N4Nj3wf3IPODcj4qrJrTX/AO9tOeWlfjoBNG9WY7M6qjvP3lEuV9IBExZer0TTLPFz4OunK8abVKkqqvWXZiStxx+gNKKp/t9v8xqvdcee9NUzqzl8N0y/byQazq1i/Ep31ht8Pyi7X5fUFQsgboveIwDpDNZwVkAHK7vapXI3/aiaqDgagMycFYWKZgg4XzhbQcFjs/GylXGd/wAJTUWrQC77SpU4r8NfaapnSe7M1+2eYSEGx9FFw2d+hhQiPuCby8D5LV9/r5xfshqfoD7Sva9Yyb9mKSvcvtCOSaw/V5gWCP3zL6OBbxQA7wdvpFA6vg0FdqLHSy4p1XLUvXwqPHmYYdyDB5A4+s9e/l9DkpgshrFHdARwUAr0d5cpsVCimwFrE2/7rPkN/RX15TQeMHtiX68lUDMT4RhT4iV1vEsZJb4Va4aMovJmBuw3I6FHKUi78v6aygW/tbzrI2R7/wAHoEeuI02Fj+vWAVp08AFASY1oSA02Rq2KkgZt5j1hGjiHgtHSWrmAXEoQoaM5YIugbxPvQEdRPy+AIgBqsqA2N2n9wo3UGrpDV6Z758vqZCDskUtLz/BPZT/JUvkquLsfvGZfU8pCkbFujG0cY+jEZSlXNCtlF1yn7ErQD/s7dv4nX1PZAJzmVpCmv4hwi1+ifHjQef0zUSeTNqfJT6zR9JKe0vEFdrr2ZcZaVFMLalB11INDWriERdNT6Tbn9NJZW9AdvCR7N9/CL5S+P4O5ZQ6H+y4XfyBHSVPW9/jGY07j46o54ToLlp1lXzMZ7x0eoy9XfyAvWGLUxyfNXc+WE4KRdT8aSDyZrqjqnrAkudiGaMAPWGCaeMXrRvQxG90YlzQoN9V75z8bpimwTUwvOUu4wYnMGUSy4yLJwrP2Vt+f4GQx7Y4TsQWDt9IvoEtZodGOu8A3Rgt5XlKkzfzXdi7s0rMfKCHTq7Sp7j+YIcNh5Nw8IRp2g6BKlQdk1Juzrc2AY50LU0XqQIIlmnk4huYWr0+FKnQk0lNdeCXrOHOkzwvn9VHCFoT3XgQDkNxEYiuobLlDS4IuTWUctT3/ANfwajK2RESSxdjrERpw/T/lQFsA9IPCkcnGJalGJRgcTB66JjelHc6vtBhps15SgtaJQS941jp6grwFtR+Agt4pvPJag6tw5wgN1z9iegRgRhV1ljKXvDJjydvoSFZifJ+jW6Ru+GsekNXaVRrhsnb/AH+CTUlK3j0t1qfKN2z+12joQRua+eJ19XZl9vRTjtYvhx7x4Et9H2QSINA28ywWSuJNNj6QdjhgANnsFfaIZl7igW4IxTwANDyswMuEpbl6Na68GYTAxkmuFjaAl0Gj6CrkuAi9ARlRo14lT3faMfRjPYfQo7msTJqDE7gAJldMjxd3+GyEHZifMD8MS9DT7xdz6X8T2NP9plesB9X+Bsvdnx8GVyxpTnoaYl3F0cBFL5IJXPaztEATI+WWJqQsYwuXLkg3OnX3pvu8b44czlYXM05WCPFW/lEC67DGUat4eKDrMYGfAsb5VwAJq0EMg7QuWGMbWMvKyZ4Hgf8AGUC1ogG0Jy8KsBLcC45qXL96lTaIbWG08KK2RqL2UPNTouxZLPXm+XtMJQfsNYVS7yfRNXd8cRPgaJOqW6PkRUMV6s9fBVFG0MsvBql3GwvLV2mI+RLQW8nz/aBZf4AcD/jonzd9Ycal08bJtBGAGAITaBM1tWDaafuh7QevOpVB0AfwMvyEr1E7BK/wmnX+u0T5ht/WXCuOKRGlmbmuz4HXYwmdyoYWOiHeB4L7nQjd7zHdmkxAKD62G+VodeEC9nqS7mIsojVj+7PgWfYJiCOALo19Imz5zH5P+ADv14SjSXBsYnn3nUwTwDT+MpQNhcrziY/CKN9rxo+8x9rmkRHurSznS1f2hfRH4CCCvQKPIR3+HvvWECDyt5l4y1IFPCXGgQN2OwziwsRFhrMqr1HGOEAtkauL219J1FM06/x05gh67F3MU06XMY8wYW+cVvvjINBe5jf9B2tYbSHhV/KbjWLtcnl/x6y8W3Hz/EJU3LPTjNpixBU0B4Lr0N5mx3V2i56QTUlcW80KbdP9uE4QjcHLyYtc1IWRaw0RXyJCk/iiFFrd794Q1rgav8S7h5O80xdESWyVMzgsZ3mKLzxZVkBFg2+DoxNiu6Y/4ps5tpzjyHmUmvxDlIyFaf3MTUav883Kbt4ukA9Q0gCgBy8MGw6BnvxIY1g0HtBkszxb8HvACGqTn+cREC80dc/w0BcA3lkmBu8kCUtSCTWtBqxJTa9+ETG+KXGnMCQYrxZQVyrdGMgE1zQ1Sao6Q8fWPHifwgRQBuxJM9jZ9kXwvOr7TXi7fvMrS4IfDHDms/uJok2S/M12QLKLfgPthGzRDYVjXpAw4ifq+EuCm0/fmEyA0D6agfnb/wAxiFPetyWhaj5hLGPkso71BslsHnULP1ATNjggPWHGvRLHwMtQ35ftSvtCd3jMeckbSivQgnvXPX/ZjOg1/uUWQ2GxppaVLpWGnThGVdGFjgyuETv92nn5/Ak1tekQz+lPufac1HcPZ94e1B2I7B2TgDrG7d+DNc/aPMnvwCPB8vOph2eJOBZQz7ylbfezNDY5EIgoaHgjiTmSvOdMoQUUyxmxz2JaZXP1JRTcnMqO90V8OPyebTaEJWEedxY1WK2uan6c0yC+po9Ye/pkDzgdwlIHJZ49ZupHdhdnQr5TZBUi265m8Fp/UpTdWSrajbvmHqGYbUPA4EAKU6udww9C9XmPQz2LHXY7xu44Xz9D3iF0er9ymizeU0aD1mtz9KepSlKkr5Plm3URx/aYRmyucaEK22hua+r7Sk1NV5y3F+vAf0sZ9kkFTjjeo4+I4P3t/wA8tgdbqCHkVS92a01jIHD94Rii6ijU10Ay/wCy1D0ksPFePrK4PbGkLRNGxpCeKiHiMEAgYwSoH2cP7jDLGCCibqtzlzoNq6t5WYj2SrdMDU3jBMaMyi3i+GWJrQi6iF7eSoG9UoIBk/ZXv2Jgv30bsoDglpBaAcWahPkJZUO+V3gxQ3Gt9j5NjlXQFq4BNeGEDm7EJDeOF7r2tlMtVn29vBwW4OcE1D6oJq/R8wXSvY+Lhxve/EHuuwgc239bTEdoez7QAe5A8A4PlAO4jmPKaZ1fXlE9RztEoY0kfV/iLdg1xD3u4garWjrF3j2bq6xLNKAdoGhUC1qXmAO4Xuyw0DEFg/suKyZMcf6EqVXAJANMykC6I42kNaAa/wB1iFTp9JiaauK60D4ATJKdn19RnNenGLY6pnsPukYNWB0dBoekNYcbKVY0eAuFVAN7F8kBHeWXW8G4mQdmrifue0Akscj5Gsrorc+0ZtRljeK7OPhNP4wOctVcjaY54YwOg9E0hn6NYJLtGupPzQKhZhUd17K+ZpaweVdawR6ZgcDkmhQg+C6JoS8EtslC4+oGw/cTpjpwlQhuI/vrFD4Yc0GsplxDfApns1hiGdEW5dkS4GbCuBcdi62lFysuO6ExK4CsqScCJyTV9JGvfcic0yor7HvEbc29iutPHjLbwgDNWrzj2T08nEeEFa4RQOGArvHtc9vh+O3kbFPWhv8APtGltVdYWmivg/M0IZoRHAWRriftC/WdpSwVi2ge1xXcdAmuoWrbV9rmc5b58A/bAqEdk6W8kGQBlXaHlm+uJF1KMn6zLNdOjvObINhzZcrzLgvlcRarr+CVIqnKNqzLduuLyhcCr6L/AKgaK6DzI145UM0vfWG42NdDLpCtE3KlQWXOjwubivSbdBwExshUJmeVvQ1GX0I/uav6fSnMlz3zvBzOexhhSefPcRX0UcsBTRcYaWpu15IspiX0fWHet4dmzLvaLuf7Xr5BaS2VXUftHjdJyrwjy8GHkRSFNVfqP8lDX7RtdvneCCXFNP7QGbxXwbrNGeDydn/TdiuwFH4ljRKgwcefWFDaH25OcVWRzRDzjxmScZD44EqtmrtUA4gwrArbGjETWS/FuMOXOIAucs0nRpHsb4m0VRziirRaPVvAB7zBrGgt0l/cKvay70gK25wBva6p+jUDL7SwFsTmw3mY4C/ngaLcyvdFLMuXpfk6eK+jhFlxY4+icJem6s/VuvRYwXp3RLOIt9Sdx+gQoDzahfsJQTSnY+Lgmp9C4kJqwVnttvM0qsvF+5hamAOI7xrK0NhyiwZ8qA2agr+yBVrVyma48iOgWqBxdpqGy+8S4mIsuAXWulS2GpwlPKxRUqX543IlnpjA6yu6lrmktCafMyVHONzKHRGjUdzFyumy1mWS+NeJY/Rs7SgJ5H01lv7zX3mjNHhnU12gcwXFY9seFFXvIPIFrlN1tjtPYS7bM+86GTH/AMts+tBKdIQRtbLO52YKAacZyGAFrbvXwdUL1NpS1dVYBQnRUeCFeBL2qC1WO1HsM/L8TdRac+crTugepEp1NH0fL7meJGo3LOxsQDTchiixNImbGCnexFS0NO00DVe0q5KnT3HDnMy2US7LGSNl4f1UKsfuJXRlMFRqFB94Svdda9otj1RolBvrFbMdpcYLtNFDrb8/qqDiPshoQ8baPZ+jKF8nUl8npMVbtKumpAal7TjKLz0xNeQ7atQsgqKIKtxYjLPn01fEuDGB4J9IIgBlWDc4OU38Xlyl7BmeR+YeEt6BUdO0u4NW6S839X5b6yI7koZpR9TEoG53WIZED4swGtjfWVlvviAC2lWA2dGeBMuBwvtHprPMMbSh8rMOo3exwhGKwep4KJB7P8xBgA11CU3ffXeEOJ1UdojHD6ReH0bL1gkwNA+r9nxgdBZSkKfEUNQsi3eK6pTcnBs8q9WX3gs+d2OuGsBwJQRntbh+3r5Go7YdYTt0ODcYy0UHDbs+I9G3Dt4nOZuuJonXxey7k/1LtZRoNDrxZnMB32/uBGNVLN0mHBmreXYjwK3y9hPdVBePmYsXGfX6REI7hvNa/gRhw4ByveU6zaYit2eQfMDLeKtvrAcAlFKgGVdpTbsTJ7kpWJG9jO2IgWgOcAWhOUWtLjWZVA8jyjfLfintpkyBQBF8YZiLXg+BD3xGJwqaYzoXJzmUZWj9TgB4BAKv2WlhV4FtXjwiGzTkOMaseMu3HaTj+/JJrUMo5h4yo4hJ+YcjW1Qi+V/EvjeNwHpmFWKeg/aVPU6IR2AVCyJy3/qARA2hNNC7v1jG2ceh5qlKeAwAqiOzNEs8Jn2RCIpC+c1jFXE/uWTq0wpEgAGrv6S0LZdMY97nf1EAOEM31fbwzZyP9nHmc/r9qX0yN1xi1MrdcPHDNRbBK8RAahtL9dS5L2RX0SHKnMV9AQF3I+8achXSJRVr1IBZwvCEe4lNPszXLqILRfWUNxiOyA0lFAUpOQw+C1uy+sKFDRWn+0wDvK5wgwOmXi2Lu39/JqnZRxWk30MvNFaWjTPdw2mzHeK3k+kwtLg73tczZuFb4gWRFWKDeXQ7P3LMkBRfF3fM0PjS5TYAAaxzmnSov1Fi5MzhvXyQiBSWQdADhCHIXJEVtd4oWAjgDBOHeZYjitRlU+H7ma8HPGfoqKMLVtKjMGDEvCA34zUNyB+ul8z0zHfSiHVNA4k94eoI7Yzi41fusqWvAORhvDQ3jrCXxwvovvN9cHDV07sqpLVXOAWTO7TNNdYKVL97cZyU4lWd0Wj17Br93yaCz3laHaOg6niPlocHf8ymNgBdeMZRAWB8cZbkne4ecamnjxcGBXALuq/iOR31dV6vmW8LhZlrVrcsGcxcqK5ovVUBBXx6xBqgZdQj920YAHiqznKhgdoBR3IT3DDF9ropG7F9XzDAuAH045vfjNQLQ7TRXQy0YANa+hhk+r/RqI8eSxpa4TVtlD0x+Jny1TVOiK9q7Mkw21tBe0OjT7Q/Z/ecM+kO8HQg1S6rLF0E05w0iyLeq46mYDt4H3QVnmR8uF+fItCt8+SwO9Zxd5w+j7vxMI2H5jP7znUqW0zlIDZoEbCLrqXf+BegADXSadaATVhSp8G7hU9lfgyfUqVril+Zf1FpFpD6AhuirQXB9aWUxW9UjHKJYdyf30mUmNK7D3lTlEV3lQtTWIGchHLUi8tHo4w2qlGwrdj+/rBwW1YrYHDfoWBTqvWNPePfIa+sHxQdTL/DUjahgippbp9CCUl/x+tL1N/eYwcMuC7n995hXZUQDUtMq9Kyc4vZEqQoY9Kh5OPfy7nIl+PGPHbjDVeO6rx+paMzR6B++kAJbqbEZvUXoZ+8Shpl6Gf+haNPhKjXGvZl7W4XME5F8GOR2PWcmNxxiDGsPU17LIOXKU1dYfI1lzMJTrWOoxobWpo/MAAFBsfXYWnpfVlMdbqcYV4qV6f5ONt3v/sttcG+an9/zKCHAi4JPXKB0wAX6txyS8AU/wAFz8jswlEUjamF9SIOIZhTcDmauccXGPnk+YuRQ7qnxCIZpGT6SaZZd0b6DqZQdgXe6sI6KAoPJcJzyk/pmLwKqFHCqmxvNEldjWZhwnQ/3+Vy74mIWzx55bjAcDtpzlfL/XH8NYCptWELUBOOcO0K9abV6wBMgTfby8+udQ9H9IGLesxDIAYeDhjXWaPeba8jwm08cwTgnvPSzAc9PiU4krmS4lsnDTnQWjvaSj7e/wA2EtCAUHl3LqW6U29Zb4EwY9dIXHojyHjEgltHFZwDheLv/JxojFTydIV5GtoRs4uV/R/cd0pWh61BJBwBtPi+34EwaqodAFO8rNnyorny5QG6cm2HpAwwA7+bq5IGxi2j9BhjxZKuz7zJBv4TLgWMDNF47nGVx6X+Jg3gr3Jn0EY3bgI1ZOIrh2lXd+uu/aVzf1tbwPisBQea35gNVxIDwIA9wxQm/fKWUNOUJo8vz/IPtWnEZovtv5xmKaq3Xd3J24+D2gAAUG31EKLo0MpuzutDmukT/iJdrv8AwCxGpDDKkd3z2Mcoeyn+YdT4HGMQ1U+Sa7sCOKLWAiuR8r0NZVlHcYdNEACjT/kqSBqsoebp1GWtBkLp51UqSSmtUcA8lExYvTG00i0hNVuAt2CLnX8IQh/m3lBNjXqdyOrct/xT3lWN/cP/ADK/b56cb94TFANPXlLgTNHC9vK0JRFdszDkCBy0igQC7NDx/wCYI6P8TBM74bm7ShGjGb7BM0VLJ9F+WD7VcPB2igUNwJKP8pbo5+n/ACNWtCUEW6jhe9vP1mXqW+8dLY2Sa4qStpzj7eVn7+a0mwdwZ7fwQU3BQ9Y5Q4OC6wlVgW4+WKVmjqYJVLt428OEVCC/qnP1+ssZrUoCZvIJXuiAaXx+9LOIPFh7s/zbcMbUP3co24zvj9BGbBwNHrM2G7v2nBlIbo81owI2DEPfSMJdv/2KqTdhf9wDV0I/v57hyOYY2RZan0n3jwYhe3v8zReaeUsmmrE9WqhLi1egcvrQeHDtQIEQ7CZbv6Q8MNHQdGas7tI/L39Y1OaP7s8tQFcEVV3DSHX8kc7niXoH3gC+hPlzE9T0Ww8dzy0T7a1j4D8t4aGwbADnEhVtpr8fMLYPKsTSdC3QJW2t3eMw+MEFlb4lkGq1UfrSUFo8eu6uYnE9fHg+dRqcE6uMa5d1rnUWa1l8Vt5lvAApB7FUIaU/1M5VF03ePq1Swdi5mizbxVju3j9HIJsfmOTH2Pf2HI8lYGoNfERexvP3DrEgc0CJeuMdto8oXXbp7ptBkrQcNx6+S5wdLX8zp6wSYVyHXpEFZLF7vFKDq3fG1WmB13fDgq46P37eDiKdx+mvzMbbXpuekuA4+9t7151fEqvVz+0FoAdXhHnXz8OPlrRbNZalsc9bS7U8NblnJNbct5836mG4fUCFwRrtLPZn9IgGoNGPiRbafrr9QOVuBpel2/gICILZ9KaoG5T2nHgH+vIQFVBE193lOB6ZiYH2ANX5h0CtujxpRqFf3CPQNJUD+E38MPtvNmg94PiVCbR0SW3Fr6PnbV2R9WC4yDAOi8xsCihKsfLqwccusoNedpK5xL2aSr5H11Rt7CMUDSl9GAbHGQUEpJn9DnKJUbj0fAexeowUTqyOv9mPRevYCg94kS1hrvvSU1qx6jBUP6TCZ8Fs3Kt2MLg68WABQY+tWdqPbyEOw2Hs+8/YiidTb8EqzY8bbe+Ojw4MOOjwAmGsqJbPwE/V8JxYoO/nUojg0DhK1k4GZZ5Fg6/jy7lzXJty+0sHwL4isClLr6/9u8gcIKZotBB0cnnND0XUswgasN1t8RLFK2YF7ZUIPkDb7SnRpJF7bt2D1qIAo4REVFKt7ke1rZY4M6Sgi9HVnLIHidIo1E8AUBrLdSCX9c/I93f0zJjTOUWaJ7J421l7CAAGAlR/Am/hkGhKc6H9BE4WuZYPdi4Ez0JmFTpaf6rzjqwoOVsaKWAbWIiRbV+XlB2vcxxXWZeyh5A7zIAw235JNyBHeFuWRxtLRM0qGWVgY6zRusLuxrBQwnTdaBGhnN8faZhmz6PC5CowDhACjcGYUs/0g1QacYvgswN+EFH6OLKAULruMWzWa82IQL4PBrXKenaPxo5mz2ryHEWkhxTP2hJ6dy0Y+pvtD+YJe54YV8nR4PCPsQLaiGXb3YHVWm15wS3vX2/d6SzU3o9iEy65euz+fOCkKkd4BsuTHHFdiLFCal6kzEas7PrZCla8Ig6oLnxpDH+/qN4qBjF3yOXk6+R662jW5vVzElJofeGtukpl5r5y23InKYLTF/UCgAEOoN8zEKXaE2RYgUThv/cLWARuWyMy9WZhW8CEalxjNY/QzBnkHWbjWvdRKWgC5zRLLq7av/IYVGByPJ0LL2nWLOuz8yUGq1N+XWWA/oQAAMBEWfJ4X8qYN+aLxT0h4vPgQYmF1bnjQ8qy8tX8AtdLrFcJosugoHWCquuvF+qhcODivKEbxgjnwlnRcMDkwJUou18vKc9btGv2mEAduBCG0NDxaihazggLTILaCMN9wcUbHpYIxL2aXu6quv7lzoav0jaes09JNGNNw3yPilbIphwrHyyvQNENFObzgKw52P1WTs3mi+FeF7eTr4PLPDpA/wBswOUHQHaqNAGnTN1jf5mNgMhw6msHCOxwOHg5UWh1OhmNCH6UNpZgWCvU4sI4mwf1XKEAAMAbfwCyhaeLEuvFoM7RFZh0rv8ATXZjhEqPdgNj9VOEpP8AsGZKXpX5baO7elSxOdBh3mz38KqxxWpYpwGPl4atWyxwFZGbJJGtIZDoY7ziw5138KeGT6Imh0l43hCntj8+0Xp2ozCcZzd4PI4k0g5TlAatWFhGtfn338oYC539+JLm9gVvrNULiKZYxfhWzEgcxg9l0qVq9PTb94llbgv6TLW2t1htWf06QzIQf53XJ2ZXcjVx1DznbJmw3QiE8229oyg4kHwOWZig1499vEZANFoKhmxnkdIVEtkaPOI7w0SPRYAAFHl8n3Oz+o2mNLhmBcXg3vYJbudRaoAUAClcYq4hRusAHlhwZkysLs3fFXuePEcLuSzgD4/uBQasdfGUyPlOMSGZ1dCXwNpuRg9AisJqSmQKKyl623ZqdlT28sEAI6jKjf6LtHSRyk01BwGTgcYle3fREwe8dnWmz/V/ojtPfQ2jupN05pe1BFKaj2PxBuro6ORh2t/zoKgAQjvyg8N2Vj10ia9G7wPF3YATqkF16sHyhOksXl6QiDIeCVDVGQVaG8PkSk4Og8zUcpAYGmDR0xsixQcDnEocAN+UZpAa7ytWMlrvBG/d0v7mdq3fac82GBcGkrbivyfZ6/RZhgPYcTIEvFd2Ju8KRYJS14wGDjr+IzzDVfZwl4YUA1fPCTJ7FiOGq97r+K82tJjoOP4RSJsexD7Rlua7kyiLf1ompCucCtMQWhHMnDIRsyi2uL5Oc4tjPWZmo/7Pj+BjSAN0rlEO3KMRneLMWJ6kZpeatC73KtxweZyix1XAmgNOBOy8f101NVwMC13o8+swQLdqy+k1IF1/MzKVG7FAdCXqj7CALyhNFrR1aSu1etMv47fRSq+KY+0PgGlysTRLZkekU/nCjLrOnNywWmk63ETj9vxl4NMhsTGGw1PlxPbzFqCOrJxEyJc27ldY6XyXrApkYEiVBZ4JF8rDwZbemMrs6AnS0D+nNIza/Uj+q8ugwGvgOZ8QmoosTwG/Jt25rsSgRSjVcD9uOsN1v7nn1RFT+Y9rabPL+RHuhs8fCg0DwIymvDeURoG73h3Fx8BJz6zsfvH6Tr/0P+7xUdoSmnFFPWMHwRUpeGEUvDiwZWjgaaonWLxTfmCG7zlLaxVILKRlhJGu13csYfK00DQ1XYg78uX60CbNnrrA69WsPBWx0eFEHNTJEKQ4t4Jk+0MvOWL/AEjGnCd0/rybpXjgXGUBGugdvBs3H5c6SwD/AFoc4rFi6Pl1rnrMTiOnaWZoBuc3xR567PLDC8R2Y2RzG6O3XSKlpyIxFQR5/TsifSguemNj6TW1fo2e8YdsDrZx/d/C7ayzLIFCV4tprU0gOOkAht4Kloe8zawX72+VVvuh0+6Ni2gOb+kILWn9YqJ0xbgHWLevg4LZRH79+sTGcN+UGDQ99mVqze3Q/PfyhCimjudGIEdo113gbNYh9b9bzXU6+P8AmPdpwOEMPI+Zkux7Wn4l08jo/r/BvuzkFpz+4qZ8dgsd9u9RyaOpOS948lG6HgETeXDaPD9/aABRg+oRJhpwHU7xHdNuZ4p6gnDHef6U/QrS9BAyyx+zxefl21uONQ0u7Y/Eqb0+xNzROiLZpcRwF2axLclN2zEo8Rr18pc+w4ywbl5coR4H9xlglgqA2PJGBLjM/ac6HhU1X22/n2S6zJu4r9Zi0XLLtW5xQsgNu38IBAFajKptb8L7JVL2gcVvGfiwjZnaPywYv16SRfS3oyxgv0tmVkzve0Q03W25EEcsLdZoJOPdVqyjB/rD8wmfaDR5lUw6omPzKyqCkNzlzmUtD9+WJz4mxkZNy87rd6evftKKpabB0Jafh+suTbPb54cXlB2VyNfNrjayHIKfUi0RmAR/EK0LwIXGuraGmwbTgGCNU09u+nt/EPqnHbmcJoTyDJw/ODQA8s+SZAviP68JhZnFOpwMoxh/TZYkHyHTo28+hufFqm5B1OHMlanuUwOnmQr2nK+5+0deXv8AqxRbxTv+iWQPKym78r8poYlGNDQsOnFmss5fV5+cNASsvY68JiEtKUfvpF5HZqX/AO2cstSG8R/X/g2Bf2+jr5zGMXYfwUepeT0Y8oU2BzXWW6Wdf1I7fqnRD1YfpW6ehADSFuAnbFoSuLju36fMHJjAUH8CrA5Lil4dPzR6gG7lPX/qCAHkY7oJsbX5oHDRuaQV5LdKZ7mvP2sPAhq5Cv7pyHuK/wDvH//aAAwDAQACAAMAAAAQ40888844088088ww71584w840808888888888888sMMMM8MMuYIfcc8oQPx48sccc88c88s88ccsLss88888884lzwmsm29B0GtG+888888888888888ro888088k8i2z/qXCWKlArA8MM08YmW6w888884soko8sM8sM+GdfvPIQdFFrNnccs/c5QUg2L8cs84Gvk88888881V6/wCtLFyjjGZnfPyH5WNfTqJuvPPKvTPvPPPPNNEUkc8Gps0sMr4/NILOgnM8sugI2PPKexfPPIFPMMate3nNbmmYqHVePCGA1Pe0m6J365OCtpsLPDCk1rhL7bztR0otyHHvLO1Dl3w97lj0fr6JuDDLPOvX/wBd86LFoMb7/wANe888nlVwx6jZyaAe88fG8888xEPPLGH5gHj88zw08884a/2wqoRSacOH880soc88uT7jo8Lc8888ll4f8888RT+9d++b3/f5888888884vEgCsc88888lrNT8888viY23z2/z3Vk888888888088888888s/cwFk888888f8DsL+q+U888969888IUcEQUkYw5ZHHAQgQwY4Q40w8hg03scwTNojkW48MMsMMMMMEb5YumMMMMMMMMICLUMMMMMN3BM8zfG880888z4oO9TufN9888887XDsPs00888y6Mjpqo9w8887Y5Jz6bbt4ke888i09f8A/wD9zzzzz8RKjlCAb/zzzy3j+vn8Xrfllbygk87vf/8Avfj888qWuM8/5VX888sOhmqzy6C/QUt8clD0/wD/AP8AfEi888Jd8khgnF88wwwuxXfITQjSIo88jl8E/wC5207C8NOImAwxsU+cPIEMPvzqQ6NKOPHHOBvUIndl7KAbEVMEAw/PMd5OAPNJacTLEaffPydOPA2b2gZHNfamnPPPPgCV/vPPPPPPD/xPPHPPPP8AxzywbdKZ/wD/AP8As1zzygJzzzzzzzzzzzzzz773zzzzzzytMT6JD/v0hzzzwy5/zzzzzzyzzyxyNh0NB6wwyzzl+K6aSG43zxzyzYH4zzzyzzzzzz6qdjzwh3zzTzzzx05xXzzzzzzzzzzjzzzzzzzzzyN/xzzzk/zzzzzzzzzzzzzzzzzzzzhb3zyzzzzzz2h/zzzziTzzyq3Pzzzzzb3bzzzz8l1rbfXzzzyzy60zzzzyqvzx0D/zjzz3989HzzzibXjPxrbzzzzzz1Xzzzzzn/zzXN5KSxixDP7zzzzvK9XrI5zzzzzzTrLfzzruPzzzkLi3dz2IC/THzzzghLfyk5fzzzzzzwX/AM6ay8888uy+7q983our68888oBwmNa688888csvZnINcs8c892ayM+uLzQtk88s8MtvhozQv8888840n1+888887gscII/89c7+/c88888XUb4EN8888sGjPF8888888r/7yL88u12imf8APPPBnyS5Wv8Azzyy60fCLzzzzzzzyy7P/wA8+fau988888J30XMAc888888I8u88888c8888c8c889d88888887/AETVXPPPPLPPPPPPPPPPPPPPHPPPPPPPPPPPPPPPPHPPPPHPPPPPPIPPPPPHPPPPPPHPPPPPPPPPPPPPPPPPPPPPPP/EACoRAQACAgEDAgYDAQEBAAAAAAEAESExQRAgUWFxMIGRobHwQMHR4fFg/9oACAEDAQE/EP4AK0QQuoip/nAuCaCEI0KuyuQV5eYFxy7mHERvX8F6hcGFj4WUg/DoFQAzMxgw1dEy2JKAVAsKTdcSgj6y/DZ6fHYzzA5/3GRefgkRxOHVh4mogccFrhdiAZjSUO+4S3BANsV2nnkVod+Q+X1/WB8Esg4+BvY7ogADsqMuMxtUUcsTowOyC4JUBRMYEDWXMT1mPCh1CXca7mJ7moA0VFR5fgElzA7lq3UACEXpeYAXLfoBWiI85iCkF13hgDcdy6l3hhiCMQ3NM7CZeqD4Qjn4DqsS4FdEvo65hjg3E7LmUiiPYjBiwGxmg3CaFzQ4vVAJse8w4Y+wvVUdAr4AtCBUVBNMo5lmswOCoBmAKYAsqACccreIBzFylP2jIujse7Mwqb8zA25PvBHs89Iqq4QG03HpDS6cYEO2r1N/NhNWRw3CrAgWjooQI3FpRLPMQMswQ3DvLxHSOZtF9cnYmOvq/wBiRbgunrUrp6wcRworL0UHaF4OkAo7PHLvSCyKJvUDpc9GirvoitZhPj7GXHmU7QIfCPg9Sfr7dF8Q0nVBhjtut4mO7FouBy9N0zF4RVy9bVdd5yfP8dKlRNiV4tynDKiozUp7xyTFfBAU8wD1qIWvE5yY4wdomEdOtQHrOfabPd9o/LORgIZ7ScEvpRV5+FsMyuPQYrBqbl70GtOIO8KKCwAY7RVZHxf+f8nofdwdF2XE9DH8MCBagIKyJRbEd0agXJOdt79C9fJq3s3bPiKU4PHWrlomXURMPxThaL0LS/vrU1f5t/Tf9RTe/fH+xnOzxf8AYX8obAzN/DFozXwH4+kwz2NBAMGZYi9C/wBTinsc/SM7WJm/DdHj49fX/IDY3u+Y3sX7yr2P3crI0detf3MaUOT2fg6RDniRZma7gtgrOZgo88v+HRFZTLZ+p6+saMM/AzDjz/ULAY9ItJtx78feUCt/c4g59B4Zz/rnzFdPmgQ8NRnik+o/5Epp74NvMB1KQxAHJ3EpZ+Zf5/v/ADptLRrWlQ3XvADrtAWxdBq/r7+kpBGhW/iXS2bbW/nVL+ZmXFzef8mC5pY1Cu4xm6zK98D6H/YlV76guCI8JqCBfaNTNGnsC4TcRb8v2o254czAYHxBDcD940LhVc9rEXLBVy/iWXhCS80/SeMULIo9wpP7gT2DGJWokZPo1HD7j/kINB+J7jRfvR0x0AYSnrKrvtPPZ4TKuaPvf9RXFRHEMAivMbkHfyNRaLYtt9rHjPFJ+YHzF+x7egxNjgAmCpeDHh1EAlKD/UR2JSzc/ahgrU5wU+UQbnocoZgwKe4LiDbx2VvMwLhGBbUNzFepCwgZXwQV4GpmDjuQFuMFpXuDaCekALipHJfsk5bc+SVIlLxpmeoff5cxE+n26/m6JZU2dxiNau0DxlMcBjh6K4VyXUAtfL5YllZlu6vXQCGJaqU2iNjUNaWhYqv1ICKv1mG67PyS0JYRw3EqX0+hPuh/cI05Mw8xCUxKaexjEfDpLFG/aFUYJhBWr3FVuGD0afL4l8xd2QfLCkICsdKunWblrB3x47HmTjqZOpAtQIVk/MuDBS7LW48s4CNiYIphe+vh2Nx7kvBWe5L+sVWmux6Ticpp30Fsvx1RVBUzHxlXqaQiKn4DqnnptHUJfVxlhsZR212Ulkor5orb8VqXzG62+6BbtziawPpM3hiJWHupoPXiHJqaQjnGhbDMZTcu5DEFW7X4oRw9yWoSdhwh4gUTn4G4RrrWIrWX4hW1/FUs2xDQ0HbUF6liqLxX8UTPdF8RE38BFSJSWRbbe1gHSWg5XXZXKWua8HrGq9vR/wB/2KY47l6NzDdH1JTmntRS/QnWpnF/EAMDAGYlNPewg1ASqvTz3FrwJSplz19UUJRvIx9uhdG44chydQVohxg9P9g4Bf741KVVYlAtfr/XaBcxbcC2iAQVhsHJBm+/B4xYNvnuS5vFxbErr6eJBJtIpmLgjeZZaWlTmv6/MXKv2f8Av2ln28XxN7AJYwb1BAd4/J2bE4nTnTjQDKWbOYsh3sAupcWl8xKw9lVuPr4lIe8rsCgJcZvBGg4CVeCbRAsiouMkRm8o41CmcvJ/H/vYNZiDLTLHmPYgPuwoRqcVtvwKxBerisVvQL1MX9EoD83bXXz+MxAGo3KopZKNENFlft+1NybavW4QqEDR0QVpAH4a+vbXhmxiilLVv0QGjOUi7fAUA0RAQwmr08zi6wslD891wANw3dmbq35gmWxjF9QiBxEAmtx2XBpNwrjZKp7XuFNTzIFbghd5g2MS8Jc7haumHGOfaG4g1Uwr7sDjzBD8r29Im4g1cTzgljIq7nordhX0x++8ew0wySyxKZi8PiLf/fttZhn0cUlsQgVyQ9xriWNgvDZKD5VfAV8P3XiHuF9cP+Ms2VEpYPmfv7o6ovzH9n0/EETsY12hZLmZo34R/ue3UTDSDgwZbHUODtPWNcRuf7gr+42vAT1Zf38JI/tPrBqWtf8AYge16mNxKSLvjw/5yQ+z9ftMIqen+xVbe6wlKtohzFYFRV2swsCLeXvRlKkjwxG3+BcCmKrb8C5AOpiIRXX/AMt//8QAKREBAAICAQMCBgMBAQAAAAAAAQARITFBECBRMGFxkaHB4fBAsdGBYP/aAAgBAgEBPxD+AgWzUQAs/nKG5hkwbEZ9X2Wxnjjx0A5EjUtf4O5i1ekxObGc4NNzgRDGJzieYICM5dZvjGo6QBsPMYuorL9ehbGMze+i7cszl1peZjkgwsP+xyiAorEIgBnfiMx7sBtjwEA0m4xAFnoRZeiNwwzbLFvZbVQQI15YqDZVLcfNFVbM3YKGWYgyy1WxY6KguHH1hkq/h/kz6lP37iW5yQAAegoVMqInQF1ESDMqVglUowErtoitgqjIJQdCgWwDiEbwhDT2jo3B1MZI4KXS1Ns7HBDsbnCWBRXoWX6Bb0EagLRmVf0TRmCiAUITOcFgk+z9QEVg6SbDUWt1NxvsZKmj8PtCzJCmU6+HTfoBsy/Vr0INyieBNwuE4VBrUUB0sXlmTZqPtGneY5hOpozGbmpjx4fpFG+wh1/XMCXRUsXWamaunMZt2rWWanPTGwZgDiFdmGW9RcpoCB7YHTdQWHHuiZyyK64MZlP9D/ISgzaHZdz2l4qVDQgoHQjNOxayy/BqI7etzDPH0jVXMQ2oBdzS4japwUANdQVnYQZ8RPSNB5waJ0qM/X16FNxdSugx2Yg5mW7EVEwOCVcytYm4zADB1pdX3rHy/vpkmI0ZbVanuJcDDXMtxiEFj0UFOIjrqBxG326mQcTK7e1QlS2AU6Itq7VMvhxq8dztlwllzj0tRiWbQ8pErVzUu82uUKTyiapAAo57QFMPMnv/AE+PW+I7ZUGgZnuZ/hpBQjQUpgCRqIz5i1rGfF37E6/jRpcN9Nex5h9mXz1FtRAyickE2Y9W0Gy0tKZk3iBXpo2Jv4fG/OZY+7sfpia2EqbDyH3Z84hMfOIV7/cTA8+nkzEEw6MMkd+laVXegtzL0v32+MGDt8cH+vQ1CxnxGj28kZ3gQbyd+H5cQMBV7Iwum5THDE2qWWe8LhASugruZ+MLJ+uX7Ht0UlYFHYIY+IjU32grRM6+vlEy7zNmj+4JEnov4gUqIg4iJrvoWVXENdgoCHakcdmWNwNDlo/7z/bGXSYjxEZKcy13NvkMbpJA07VEIEpr+4nOMdoLPn0UV5mkQsZjrCwHDmU0Yr6gr0R2A3eIdbNW/T8w3Q8opuBcQFNDX/Xf2Iy0bZQ+HbkdmeS3+vzCFzULX0LlnLDty/f34xBZMMDiJmlDVRtuIAo6HPR71ix2GkahIdNn0i0R4Iz9ot5tYD3/AMILQu/Puu4nDnuYpaITBeky5nEQxcF5yGuYllhg5lVjb9IfYpH0Mux1EvAGz4kAp7jx+OgVK+Ab/EYP9geCJEKru3eSGNv1iL4lVWWbH/zmOXWZYoXDFWAQXF9m85hDx2PVLhjY6adtnao2vInJElUPjNgf7ENVliguO5BrzDs49vMUCZamOVNokyBl/faHwn9wBR0oveuJns1z57N5zOYdlQckTgA30Tt8xMYZfLSWLmsZsd99CjKodSU5XjuAUwECuzbpzCG+5Q32XNuI90xPrFDc2WoLZZ6Bvow3Oey6j49rv7YhglJ6rKFpNTe5xDwoxTCjWVzKPLmt6g2Wegu4bjvpdR8Yt9xUdjAVlEAFHprU1gVw6+OYIUD83ZkXLMDDrn0RYiPh/GVXVv8A58IquL47QmbQtKTlev4qOgHom2glSymACjtKZtEeJvPZwJ5JoO4NumAs7VqO1B/KYQIsQGpvvQBZG0vPOcdwk3KS9xWuqoWWb9EVkHyewMJ2TLY627cqiBQi0XFZASOfd6HLpbL5fgL9u4AsU17y0l9RYkptMVOm9wAFjjBmeAQF1EToV7DNfTjTnR1GVKPQIgqYMVAeL/z8wQWdVrMw0t8eSI3k3i99i1mbLC+58Za1AtIaIIC4BwTcFtSm3tFVkpCZ+NFIVaS2QK9BrYhmvz+IfGjXRQyxmB+SBdXkO10mYSC6im4JmOtypcO5IWo+M8pnHalwWkN2kMUEZygCCPoKHYEDgRxkgkNnE5jfVHoIvzruExdxF5l1gl1Lrcov5iXiJTmJ5iGCuC297RDh4oQMWRWd1S+jB5fbiYvnlcvGi+5usQWt6BMQR4BRR0S4lCMaTMVwFDtVRrgAjUIds27hDTP0+IApE4l+3obSNnGbSsv1yEypnuKsX9odTtW2Dm4yqx3iAKIOe1usQcmXg7/LHyj+yv0s7gyi6EAFHVBKZTlM4YJ713imNuCAkBWCBfoA76jhn1/g+AFPopcROlof+Wf/xAApEAEAAgEDBAICAwEBAQEAAAABABEhMUGBEFFhcZGhILHB0fDhMPFA/9oACAEBAAE/ELly5cvrcuXLly5cuXLly5cuXLly5cuXLly5cuXLly5cuby5cuXLly5vLly5cvpcuXLly5cuXLly5cuXLly5cuXLly5c568y5zOZc5nPS5z0568zmczmX09Tmcy5z+G+suZpQBrvBl96d5a91BY8uQBQddF+JtXNfGv5R3PNHkLOlzec/hc5l9eZc5m+s5nMuczmczmczmcy5zOenM5lzmXLnM5nM5l9H/y5nP4aTP8A489OZz05i1lcS190mzuH/gb9oRT4IB60fwYBC8AKYJ4qBJOitz+/O0VLccqC/DFDLW6d8OUD8EBjKLJWDIftLBULXGCreLriXOZz+PPTmXOenPRnM5nM5nPTM5nMvpz05nP4bfhmVKlSpUqVKlSpUqVKlSpUBFvQJ6NTwTNOx2LlKuJpwd73wv7lxZt+zl/G9/pA/cxauFZ+ij8q1Qp7rSVKlSpUqG7PCAP78TV8sC+xv4zKdtArx0IAOxHC/MZ/lAAAAVQSj4HwPd/3qXl52pPfbxEMAhY3Rq+bGVWujKhfoWZ2p9wmoosTeVKlSpUqVKlSpUqVKlSpUqVKlSpUqVKlSpUqVKmM2ZAP9tE2UQV67kedfBBHl4gjtbmBmhMqAN22oY+2VKldLl9bjPiXL631HhNaF9zD7b8TJgeEOzFuA9zZqI37llfLb0zwaAbBr8HiAK1LalPsuviejF5vMXAVHB/sS0zeKa+yUgLCAXyGKnPmbfbjCdhqP+J8dO80swO38Gx3XBLTRFX5n3LHao5qHFfkf7/sIOzAC72Q/wDveMAALW6xMvD19A7rb1q/UzA79Hu+OlT6NflD+IAPrB/2HzF3CLMjZ/zx2hCzJWB0R/G//D4/C58fn8fj8QEUAbxLl6xtW7x28JpbWmwChKCbBsTMYrhGX5qoIteqFA/AfwufEvpf4dpcuXLlwvSUDyzxcdrd9y99W1RgOMuo+66r5yvXEUmRutKjVh5Ldf1HqorXxFAbaqe/nswHQzrRzTtxiXWUzFp3bOj8MRoWtk1p2RrX9NI/DT1DWCmx+t8ZWh9UoqjsBWp3ZSIXC471+V7o9xVD8u/F4DYwG0QEu2njT+ZfQQpP4ZdQZHIeHfu6unp0VtMX4D9G2/g02ltr7pd3oVA8BuuwbsYWBAUCaCV+nmVjsY/SueZjp0gEJs4Jddcbjweze7ly+l9Ll9L6XLly5fW+ly5cuXL6XL6MyqnqoZHFntIV5WSqhWRM3ZFYNxSpfda/7ECbh7q6Hi6lGfxYF/UuXLly53/8l2GcwD/VUEqb6EO61DQHeXLIP5lAFEs6GN/qMDxGWmh0Tjuynyhf8EZGnhyL06n2RExLrIKhpetwSFFIxSqHxbrLWEiVdCG/JVJ6ZnFQrR7vb1t3qgFs41bnjX6lYPeN/DrBZ0FuD7h8yzah+Dby1Zi9eNL/AO+5hlLL9Qo6tMlewf6oZcmi4u3le/8AyGOB8G1/yibTf8u3TfoDWsGHtdIXbugnwLfMR0B3P1t4XliHzabQ1r+DIdY9Dj5Onf8AK+neXO3W+hIWqfZ1Gjbth4Gnu5YCmAbZx/MvAt3irZfD5fhc4nHTicTicTjpxOJxKBcKmx/f3eTRWKHk5lCTRX46XL/Cy7MBCX2HD6qOar0A9A6V509Si64sK1P+QwWFs5P+yjCG9bfv3r79kDIpw20Pr1rNULC29RNgXfqVI0AXe2v3NfWFx3gocBPcc/xKvU0dQYBvnFujCdZdATBfuqfqNoTyy1yHi8waRpoed/xAROhWPAaV9Qr8GajDcGFrfaDnQPsolxOJxOJxOJvpOOuAyb23YPp0HHgS2t2IKeWuHlNsZSqwD1RD1fhfpEYNdkpUEZ3P3cL4OQHqmvqUCJ8R9cr5YsmYrJPAK+QIK0LXYncZxOJxOJxOJxOJxOJx0QigDVYlktmdr3Xqn4TiIppb+L/7NJI/zHieJx1fw4nE4/DiLI1KdVhwm+ykKgp27tVeVz0DUMHPS+ty5cbUFKwNOz3IwTQUdhoD2zjtASJRRr2A/dx4pJhOCbJzrqfUV2AK2nStD9OsrRSvsaCFEVINCTB3D4XEMFBgweIWUpV0M0PV/cRSc+8gJ72QPc8C2NKNV4vvF9lV4PxX6W+ofOd9y92XiIOOkKsalOmF2jMw9d8R9/j46cTjoJqz54WG+c+hiCllZXsZ3zl7yoFb8B3gSliooXt5fqaZTdH6Zi52y0GHU3tQ+MkxG8kp/h8Q9WGciIk1UEHsXN8x4/ZsD3bZH/K6RrcC0YeV9nyFnTjrxOJiXOJxOIZgV56dMnrLiHivnmR+04gG1vPBvLMFHTN5cH8zTYny36DicdKlSutSulSpUtzA9ui1+LIQFqBBFY0J/jz/AOR6KF8BcKTRq5rPfw3MuudA0vi9vo/Ub2TLFiNvZ8fEJLqxplqzWsG7CzGcNBY2d9DHb4gDNHFDSY7Fid4I9aSwtTWkAQoqDrfQENNZ3MxcfVaB40gAUABjoWQtAtknfUg4E9LtUULlxj2ylFQJsGXlt5ldeOnHQwGVhfQuXxHCINt7Z2oBSpU7rQC1bUyqJvmsviI0Xf8ATH1Uabobu5V5Vg2S9/0iGAdwMcR27g+P/kvQbZ0Of7Y4GOwlepYmLf2j7DAXVT1Fnhqdk1K0rDcNIwfoz7A8V0rpXSutTTXSVbEB9hDF2OaTMCNMTwy5qYxvUmuF51DTzAQCTBVl2LlFZGGiSj66VK/8b6rRllH/AG02Hq7ihdNa2/8AMzsoFqv/AFRNg6NV1W+NT3A5MbDv/wBvSMBnsReM65q5VBCDgCuzt5IKIK0arenC6w/L9i93TTVXTeNg7FML/UK0I4HxG0SlvU8F4+ujLdL4b6MvglBLVZd+muqUvsfkoGdI5TlDBez4Pgt8S1OprLTy5+yR0VhoOUbmru3HFUEdO5SweMl1tIFQY1ADWhq6V55hraoIrbU7FTGhGV2CLxRKq+FHxb/J02iuTu4/JpC2+sJG5fgPJWZYUVNRLc7lZ77SnRZDydmAJqB+Z2pA3pprxj8y/wDwZi4Ue388HiO1FTiLedkyFNkLD3t+dy34mb1LxCvlOMGYcvKxOLarkutCAUEIIAyznb/zfwfUQHCYBTVj2B+p52gU5VzpTY9wMttEWqR87YmZtVav7/CqKALXQtXfa98ygpjktv8AURIpA+sdKAaGfb/yoXRQVwWavsLYp9DYiAgd8a6w0kyWqp2fG+8ZQKgdAUY2oJYW1Bw3LT3voS1rd/L0oxgVRgexrdfEFdMOdE97EDLGpgivf8EZLIDXoFDxp7vxKU+7e6zvVBfj8OYnOuR4QftcG8wZyFaHzLxjwdYFrbJrwgYl82BrrALAql2q/wBhFOoJkVK1HVfHMqdm6vhgt0Tt3bZRGapt17ocvqoFWRLvBSGddXTLDLlyG6/kPjQVMlhc+rJjwP6li7VvwYMDisWNNPCUPZ4ieND7S4IXMN5fhcPzfiGmJXWpXRtGjGpjz41wdeqfFmTXi+grnDBcRVUwZW2UB1ZG6Asqbf8AhcZz05iaiI5RCC1R9q/lGMaRRyR+o3TRNR3yECb0tBbSt/cJlSV3M5r7c9upJoJT5uKUinPayTqXj151pQWWjHgeO3RBUhg7e5mfLlXdjnoyvWja/JxC5UPsLQeaiCrV0a3z3hUpgEIeVuK8HhhrizuWfHzGlUaGvg7H/eZULGVh/UIJvjeBC4osu3tNA5GqDjvX9XBBOP2F2dj50uZIUmY0Gvjbz6689LPBPsFrH7oaFpfYDK3vmYTBhv8AD7iwZvgmH/s+c9HRhVX25jEi5pVcmnxUsAN1yeVoiakct62917+Zlw4aSlTAdi/iazPC6WDr+Io6DeVHadw/Uw7K/wAhNT/YaP8AEUdaDS2v+/xE+L6FWdnUmKWqxx2vs8GD3KhHbPzHZ517hOfxBRp0vGCucXEF1weS/wBdCda9H6l9UbBZQ5eMDn8OZz05nM5nM5jOenMSzOSPtP8A2RRxmy+mJcuYmJiUFh3/AIiUIWrfQGf59QvdGdax0NtKvWOoB6Lpo5Xdsbl9gKxSxuj2avfySvIoW1VNDomZU4F7H9Rwtk+JdnjgC80Bfmz4Io8MxyBWnfX2S4ucjf2j74hYqu97rNP3AUvmRP8AqNPRdCK8vY/+Qw0nQveP8AcJjHlUAUB05m2s3ldNX9kg3gBDsXKztbEqDdGX1dj6gW0YaX6Xb/ZgBtaU2vTH73z/ABtKaAsc3gSuINnLXuuM9EEzXZ8xezcbh8aQAAUAfH44WbI/KZeb6NTRbtr9TjUPpAQL4BEMvmB0JqH7cwugALqRbl7Z+YgQxXMCNHe9t49TFeKmEXtu7ixe7G3hL/Cxsq9gtfiYTVedlPxlOlmHa9eYYvfwf4mtMV5dvOPEcy/w568zmc9OZzOZzCUPAve5y8/jnosaDXI1BQXpontYfLDf+3Re1sHAyxaCnRcKrkpPGsQCzX8ld8FwIorY4t2b+YERKWDDo4pDD3iDdFakeyNI+HM29fgj52CdgzcvqLl2W/8AvzAIzcU69+4q8RHEP2T++/zEsRLHvGWsdtveMfUsyFgACYrdf6+oYh6Ho91au62Shc6GH7Jk6c9OZQ7OFwa/AiOAJqO8uiA65z51PuH2jlX/AHJCtG7Nt8m3Et82aWT1/hj0yN2tdu/o6bS5v1aFegV/uzNn/dOL9d5qD/ooQBMmucbRvoq6JQppNr8NZUnrNANoOceYlSjWLnd60jlCKLyUU6FzrgiLNgmDRQOP1L/nOpi7bo8bX2+YFAAA4of1LobbL5qPTmczHwQ+96ipQq4PBb9svCuk1EsMeu0o7aCcswTX4bL8FDzOZzNumfwuXLj0PhFtIPaxkZd6O2KfMfAM1sPkV8kWhTDItle13d573cBAMw+5qu+IYjf+WIfoc/ufcJ+a2AvaGLgK+4h8mjLy3/EozO+2eDAfVStMQoGAg0gkGmzJ+pbdAEJt/YCAdIo9or+Ig1g9h2eYVgOFdgG7QDGs1zlxX2POtb330T1HtS3rc8xHcANtyvvSGhEW8eA8/wAepVqJTRu4mYtaoiADW27jQh1Ytrr6ers+3xBRtMFaH8QLBdhP3A2fDb1gKR3+70gTCcB7GWVvHi8dLly+HRvli+AD6SIQAK00SAELCg+Igmap1galjf8AntCsO3zDysJMas4+1Dh9RTM86H4p14uIiiIjSaVCcuhbxma8w6prxvq/UY5oB6cwBYBurDraquhL18Gz4iuOywG3b1rBFoiGq8dqmagKAJI0jhyERuyPGpchuzepjskrgzQv/L6RKSEVXJHPnB/sxcxPp4/5GUpdYaoX+iY0IkOe6/4li7H4NfxLl9DGfokD8Qy96nr/ABUuXh+8TNKrX4IeIYNVQB81K/eJAP467S58flbFtGt8A1XwTEttM55KX4i+PMJrrkfgJSB2gi/WDgilAcAD9SykuLKHNnnTEyhSz1epo3Fpx38wZ4nu73rv6Z/kH9TWuHE+5L8VFaofJDyXjuNn1CEhKN7rAMuQzWICxiVMl3eMGc3llvVW3de6uYXIGgRUBuPhOvDZGVRciAVVu0EsybWw3PH+8wfpDr0Bvuf7Myfg8j3O8Mg2w/8AB7jQp2GXmOBoL0JWh33QIyDRFfNmUY/ZBOJXQjKuL1C0TD3Y+9tWEKabCkd/ekC73Xb4u56qyA1QF/8AyXDILR1rw9aAT5NIEq8AWD43J2FwFg5zXITGL5S/pz+4rUehRfOZh40wVWDxKFdLk1HWth89riUoRvShsBnx9y00gF96iWqag/x2zH6UbK1i9K7VmCEQnSu3DiNUfpP1i/8AMWlm27sXg7RLH0kuMyFsaCf1BTgKfaV+5guFGbN9EfwsV5CiAftAitpB90X/ADLmboHv/E1K1re3/Evig8DG3y/DXTj8NyEDlewar4MzUF9Ak+E+W3xGyNq7v0eiiaXU7SitK93PUkZYDopsu2JQ2C81S3PtjX+dRGCM26e/+05hOBbMdh2W+nE2Ioel/h9mYIEoB3CvuOEHiqlvaivOYYomqzflg4OYjmnDV5XMxgbYI+YVZL+v9Qxo+zDmw4P6Y6Hf+tCiJiMeCeL35SZnkGUeBj5uUc/ih4yxz83FbMA0Pu9H1+8xQLaDfxEJt5zfTrlHH5sGitUmulvtCtF1C/ph99qjaGbD7Bq+7PMuBbr3fpMQJG0Aoty7BYmpdbx4GnBofNj9QA+6BD8PWwXPeqfrMARgdiCJKHu/TSaAI71+kuUq/OX7jv4tdE3aoUJcQsUDv9a/cdsOZQAAAowVLG7o+f8A7LOEteqf6jZMFYrA6+qlEk/4I0jteQdjyz11u3wR2C/4jpy67uq3cqgOIMfl/wDktuULb0f/ACahIM6GA/xKzrWbUB9i/D876Eqys/5hu7QgHH0caX8sfLKmzjX28fhfRoRcJLgg2HRLmZMvR/p8krQBux6rM1zHkF0MPgJLGVUYc76yP0R70J/dt+4EV5agrlqKuh2o/veVtoxQqnsmpKLQc7D5HtEoGDQS+Tc+GIAQ9R18r+II8PVg8EZvyQS63a+WZygqueWlHmU4JUC26u++SHAQSEUBQcfg9I7rw3fYgrVmcmDcHkvS8SsAEjz/AJDGdutzebA/TJl+G275gjB6Z/FZGapRi79MeJW1wPYcvf3AEnyDBg9zJp/yB6gLMnimfmEXnRaORhI1oNIVZu6E8lVDJZo5M6/giUI6mwOK9xCVmN9b7MKAFNvc0qICKDh2x3lxBQoBgsPs2lAbGelFeb0f9/UTSgoOVcuN1zM0KTOpGmmummkZ/l//AAly+gEARxTDEA5YvW3B6aPOwSrzUNGugNWy5ZIohvr/AIhBLLGXsGbgsgFTmlsX4uuPxvpxMg5Ruth5Wg9wajK0WwNu7v8AdvbIPt8/jf4IFAGVXQ8sqla2YHsXV86fTKTOMr7n/hEBPqrcrzMgBRuwnaoiQbk1eXvL2qLRv1/HiDBE3Ut6ad/UAQQq5DvuewpguoN+Ld3yQOMqkR7NTy/hxOOnE4nE4nE4/DeZOqw8H+UaK1Z7VhAELhp/M1bddZ4AAgxi5i6uRv5iWCJkR0hspALw7nn5lhE0Uqrpnxn6iXRQFsoK1MPS48hV1oq/3FMZkje7D/7MFWNF4dx3NZdqhtig4j+sKA5b8azT6H6hOOAK0XJ9TeZ8bIoPK7RiIdU1l2NfoQENprkFabBrPlp+4bft/k5nE46cTiCwrNoeIxdtVTCTdpTmPgnE4/DjpctlTbLczka7KPlYKfPx/MvrcvpfS5UndsjY9u8AEHZ7ex47u/76XRbVS+BZ2wQ1IHdvjNS0l0tBvf8AYzVYpe572/QdWZ69p36bdLmfzsZqPnP9XEaU1RRC3zDhA04ql0m/RsRHWymZ7p079pbJgV6s/updM3rW53Qw8jMal7fVMfUqZEZQq95VwRsapM5+z6IUooGyt9uWJwGwGbrtCY5UmmmL9TM0O6XuMQGpQ2h4W79pZinQeuaZ+UhJ+NjkPGi/ljkS9RNHyTDyN9CXTf8Atf8A2e47/efxZ3memf8Awt9aE5orD4BxE18l+fzuWFhrWnSaqin2WvoGfc0GTzNlz3v+upGpsG/9RCbtLFO62PKhNuqaj6UfQekmL6Z+RTK9sx1xN5iYgxMdyJ4AoN/hiYmJiYmJiY6MAbL6v8QDgQVV4mn7yJbX8Rw0ldMbu2DY+PfmY1w0FTwDP2wnSuE2PsyczAHBKaUqm2a+IAA0CpveYus/OstHwDk/uIE4Q/uNKJ7l/WGHV7BfVxnbzquSFFKUVc0p3YdQ5sH9Y+5kRHf+j+7lWkXgoX2+oTA2HrtNg6/2/wBzJV320upY+4/ZjExMTHTExMTHXExMTEFIaslQ3gq/6D8RcCUjx+NiVFtEHEeQ3jYl1i8Btv2Nz/eVdOAanh60P+3DWAd2Lp+NAdJqJlyq/dyyss7Tu2C9R7mB7SNKo5aZ61n0B7h1929vdd3y56cdOOnHUH9ArExlusFig07yzC9GCdxJrlQfZ7e5STy1QPJDXbYIsb1Hsdv8G1tFifhx04nE4iqF2Pqh/MTLCl7NH+WNw9cd3xC8C99yXlCVZ689ACATTJdxZsp8j6MfUo4qoKuvX5Kahl2BhK0xkP5mXuP30CJpKBir2dMUR/yhhypfbFZl2boeSKcjYBWqZuA8qSt4y6SrDHqrGJ4nE4nE4/LicTicdTHiGLkW07XaeFrQsh1UsBdxjIUNnH4JYjWcaTAmrrjmEhzcBXMdkowOph99jzGAFAD/ALOXljsYaSs+TV8vYlq/aqPq0T18podKCL7vd8/+TkQaq0RcAFgN5jYkUcrFjGWgvUKMFVMB6o/3Ms7inxt/4rXXkgmODTKHVNIuvJ1ptPHpiMMOQ3JTB+wJksLS8+9PuIBQlY8n/iAJFcYYXRcEzvPl2+n8FTrWr6gFl2D5aGviOFA7F+f6lzxXZuFb9Wzj/wDDQ40tg7JEsBUUL+HnlZQoDgw/RhPOJuqgRHyTTwdzJ1rCOxW+jV+IO4fAfyOPlCK7JvkCoMy/rLL4Gj3cCd9DoHYNvw36/M5/BG6+FoXd/wBvF7cDSsHbIVYnhjTUbKa0usq86R420m79+s3iK1A1WXApR2auE7Q0Hj/yuZtaKZ5L2+K1iibWZ2Ndf8eZU5sHRH1rxMDWMdl0v5iD6c7fheGmjqrHsPy/f/IHYV0dmuqEGzHsL/Ush0B2R/8AkD6E/T+A9DXwabD9MZg0JXf/AJGZ7SAHL4MZdjO0ecoBKuzyKv4P5fM+fwuc9OYJAqRseJ4+fK92yaBGyofaXZ/yzaw3hf0j3lAPvH7hRpp0+ZzGczmbzn8OetdVhmhdjzGUC1xUJ+2qrgBhyedodoo6KwHocL7YWHHcHxcF0hyCezq5tilgLE3nP48zmc9O8pwkQDsjrENqtH1NUf8AWQZiEVUdwYr5PMoUSWMNO+NYGgImzDUyfQNIB0Uitaa52MS4KSjuTRN994iIbIMOazGZsXWg6XAKAnkuMYKC608P9TN9r/X/AHpUToWs3dZDtmYhvJVjpprFLCrOrnV9R2Pai17Y2m5cUz+1d347s5nM56czmczmcz5nM5nPT5nM5nM5nM5nM5nPTmczmczmc9OZzOZzHZgMriHXvdWTmeEgpp6gF/2iCOcxYddq8OfbSDDn/rghDBlqXVkIAAXM32grotHb/M5nM5nM5nM5nM56czma0Vhpww3rZM++v+wtdgONRu6R5wTQDpb3FsxrJDRNLd84vLEb6WkMX/0nzGqrBYdbgEQuIbFjHLrKm1wLQYouZ8yw9r8DLBUe3Yr/AJH0EJOUqAGwCtpgXf8AEITDtaGsh6KpuaebXzwO58L/AHFiQqJn06f4dpzOZzOenM5nM5nM5nM5nM5nM5/K/wD8A8iqjp4Mb0yqthRr1usi1819wEAVBMFh2+iAzasFs5MOIjouxUfeoi3CGqB4mbAde73/APwXyLt/Sn7gjWNAV9hcj5l3VdRj9KvqFX7dPyxfgTYIHuJv8QxGTaa5s57QUmtRbjF5rvNodF5V+j+41jjdbFOnzKk+BVMh3vH1NObNAnufsIGymbB64VPBR5YCeKAB4D8yc1qfdGPRSWGFVxPcjlivEclBj2Ga0+6G73zkfpAeKZeE8pndjAPKk9XAdA38nP2HjTT8r/Dno/hz05nPXmbzmcy+nP4Nel5BqjRgIa/t3ueoEy+8TwV/ve0DejQnM565nM56czmZ6czmczmczaczmczVyoQPDOxoUB8wjhE7A/sH7uYnvph9EOp7vZfyEWYKVoK7V/yVVy1filB+YaLZq1nwKeFSCt/Bh6DTrtOZz1ZItdYV0eWQ9OjUyFqcEdxl7ngxRFelWgo8jiUv7g1UFKXjsX/1xfZxBzVEqANuUbNH5iLrokFRTqiGw14aiDt6b7tBcFlVgwuRdhqPhnM5nMzK6kroyvw79O8r8C6RzUy8mdivd4gzUtQL7K9MQcQwg7Fp8XHzc4Gj87Hl4i1+WZ+kK1WCsXm1DzVzKJLH6xquUvJSmFuy8+R86f8AjpNJ36bfhnrt1uX+WelTMqb/AIMLIOHdsyqbM5igPasb+H9rjXWEnCpWnJu53XaGtd8q+97NG+YUxWbKPIFHsCNMAbVP3ZA29+G+rfqU8Z1Fzs9/YTxLrbBio3enS6TJuAlkgtm473WnmONVDGyIm4h7tgIrcvQ1P0nhm3TP44/9XYjWe9WX2x217TElZwNy39PEHhDVLITksygb5iSNo9+/iEINmCNW3mXTE0vW6cDlTT4gaKZucjwdo3t3dy+y+6vn/wDTj/0EwpC3Bg5aIJUuvZo0HX+C3AK6lYUwNb6MZbqrhIAayVdh37M68uiXhGm1g8pp6M+YVS1VOr1/dwIVbAD4mZY1m0z0H0PFNMTj+D9HdOdSx1spyRQC8BQ0o+wKa2bJYlBlagoPROpenaFDqYYtnV6bXx1+f/wK0CtTQHeFCk0qT5b+/IarqaktqpVr3zfuW8dF79BDNGBdkovZ7QbuBdIvZao5YEKjUGnbv8sRFHN7T95ggKUlbpxind1rxCb1iYQLYwBFN6X3HlO9RvBHRCdL1hDtf4bTf89vyLK1qUB5YjmKSF7VfdlYSuP1Wh9w1IewH2/mVYJ3bjs/2QQXo0DylH2TNgiiP+7f+e0HIXt9g1XwSykBe02Jm1g1qY1sghbUx3Oai3wgzGlDN1s2G8XiowrkuvB52eBjQKI4Gn42ha1N9xe9YHp8wtNRyy2V5v5lY9mRtAyliYM0ONd4yy57BhPUxTnGmdZe04mE/wBqPXicTicTicdOJxOJxPAzJ5LE5qUCho2/Cg8rC2fYHoJOJbtT0ZXf3T1cCVNV3Etef+yjHZPKI/ol5kVHaxXrOYUY3Hj/AHg4pYFdt/JitYzSbwsVWvMoQXqUXBzIWLu1f0ROIIKt7tlG/mKjXAOWaI7MAM1cdVD0FOH3rL6cTjpxOJxOJx04lwU6NIRXYar4IpZmAn2A+Jg9bdnxDEvmzDAdhgPVf3C0vTFE3yf3HYEd3f60+5aezAbHo0l1kFMnfjtGNthe4z4E2dvJZKDDunG6DZJxOJxOJx04nE46Yv4+ULZulJ4ojUZppAXbHiFAKB1xXaPbB4KN5iyzGvCPtPg83ApEoCq7RaMsDr8kQ/qR2RcR7fky0QgncSqhCI23s5fwfcJ7wurgtr1riEUEeeA8mCIAaWeYA9/ROJx05689OZ89OYRauT8Ls1vrpWWzG2rHauWl04+9YLVunvmPKAKNbiqDGWBm8NmIFOqxQfU99fRpF8ERoDaMWOnioJyHGbsrWV30Gl0ur7ByeszEzRKUTFh287y5YhC1aP6IP+QLMJwl9zNV6ggGzJcFTWYlw13i2KuTvh+w/MQiXB9ylH7R3OHeo6AX9hq+5gQGngD/ADOZz056XOZc5ly5hES3l5fsEXonaf2/iBeYZMMkx2dA9URCid828rL420uX3iM37dWvR+JEsjj3IFCsa42PA2fHohTpLJj8PnpzNoSC70AtnvYmgtm8Hka9Zji0veJ/QrYVpLSGxVlfxseIrr8kVe/z1elwhng9/wAhYULSsjBm894KLbiF1WL8UGXGUE+cf05ZMf8AjhnU1Lex3fBO1jD8gJb8RejAZwiXddsbUPMQ65TUvNvnt8wC01DKLaANVbf8lZwLcF6G/FU7wkmWipPAP3Ccw7wPDkdMZxk3nC+UQey69VvcI8AA7FkrSBU7hX+UTd3crH/sMqCndTMa2BCarph4D5m8mjCljHdeTiDA79G7Vj6SnmWFwAcjLcdSneOm6JFfHCfIf3AKp2eQn5cdQF/YYPK6RCP6CUemXyDyS5UMN3NTX3FrwSocGBemjL7jkC2K5o/dxlTNa0D4x/4EiyJULpX+gf8AepeFUvZ0vPoj6vfo/m3AQuT6C1WD36jAmHMmm7vvbE6UpxhsNMYRujGQLyW16OPs30DU+TD7moP5X+DM/bm/gJqj6UC8vypawz4X7uJiCcZFvkoQ16PKg/ihLfUqybqzkzp3h594zZOr0KdXBwxK1VzW7eDQ+d//ABYu+ag1WgPK0czf7Gb3Cm9496uwUOCzZG2GU7B81N6tW8dzN9I9SBcBba024gEcA86QbmNLOZnrK0Xd+I68oYQVlz+95XQafg/q4Kdq3yP/ANiMVxzAiqABpWh+YUUFiwZt4T5mqLj6ldhrP0nM01DNbML6PzqfW7HEcMCdgmv+Y+5e8q4aZJj9xFjOZ6B/lxPIOaKFHfW4qlD6u353kfBqLsDK8FwrRBUod8r0+gzUbMxRNRzere4Sh3Dh6ND4hMWxuDwGh7lUcqqwt6wev/ElnDXtM22AMucWZs7d/wBQ0UoHdrONdD/pCsCANiO//gT2pc0S+fIvtUc7cvt4iGrZfupxW8wgZhUAI9XpRBhXuvXF19RcsWjZ9ylQHykQLMm3SumN30gLl12cfKW+2GH0mtErch7wQzoAE7l66mp5W27w1LNHyaf+RIMAzcFvumVgdt12viha7cTFqLoAac68xwim4v6gxGAHFHd8S4z1ZYKzfdGvyZqF10jT1d+hWRd9Rj+YwbJ8QLr6hLABoXdPZjo36pWPF8MXSjBdg1ainMCxRVVoO3qDaPpOKNnv9MthxyvAaA17u0GNLYJEtwe3mYnDdtPNL6JdfRPvnbxE0mfqV40JdhYOwKV7/DmUJEFS1bBuvaN3FoEndM4dspQambZ7FuQ8UEvQJwdPB/1RkZV8mn9dMifhfsGb5ig113KDj/xuCdnDAM1NOdSExpp6GE2BxI0fqWjUTXPd4B6nM56czmZ2vncXE13a+zsykSDeaEK5SaJC9QRfiAAAAqjxG4Ehz+potUbB1imo3DU/7DN2SLR/Mz3gVfaya13GB9kogpAvza7VGm/mCpLQwYoy/iVCiilPnOfkZ8gr0/xuX0uFbVQoHd8QC00hF9U3rAG9X3inlg1j7Xvvo03SABLSjLziCX2GZDb6RppldMwRWhYgHk0x2mVOs7hdH2Z0750JvbOUQBnd1uGvQ47FG4cCkTkrgF+ZQM7ANavv5KgUEs20f5JRvnENG/7uWeAENdZ4YvhOZigH8whqtETuF1UcjuJMqBB9gERls26D3PPmKc2C94FjWBb7eJqOQvD+VL6cdC21QOG1cCHu5d4BXglXCZ0A9d/83KoUGmlPb5H0zUjdTe5jMsiSiw27X2jUe/l3/LAsFaopT2xjb/xB9BKZWXQ5LzSPK/dv8fMsd5E4zEpIs9A0p+HBdeOl9OIdYGMWDZG941Zvw0K2ITe/Gho+ouEKrPfL+orRHomoPiiYW07rPiXL9S5cJctle4C/YUPNkqfyCvdlerSW9kSXs2uj4ZzrRrYuVtWXK7ed1otYJSWn2Cvx56c9EmCFzb6Dx43TxLCwVVVK67Zy4lz1VvLdd137sp8+6kOnkd9jOtQQUlUFa6ruvlhA4SsW5s1dVr4i9A+6ldvoBKdMjWLS/wCfMWvegEd+GVhW7PkKqnm7iNXUt4NQ9tzxUxokLFLtSee/1M6ma+f3K9qfO8RRh3tr8OxLGuVaIfGv1NSC2rmxbm/uPyK/aNFoDTMskAFr6lPUcvdFv7qKbBrzM8rb/Z8tkNf0DwT5nM3n1oKBX9RtkdM2ir8s7F6xO5+YwzRS/wDND5CGSO03HX+4SVootqjxEIlLLcBu/r/xU1IC1rXR8wwpLuFWT+5kfAeVlit1uW7HnBNnYuU5nPTnph9w03ouGdVuuhw+Atx5mVqsruJ283HYdC+Sn8zP+JcLWgZ2U0EuI9TtsLh0mlvrQadrqKuFQ+ozk7guzXAaZXggRxCmVW7e6rl6jDKoFRlYaat3Ms2pssDcA5NfPZm2OKvsaqvBROZzPnrX4LsG4Ad/NrGEALMw5psFu0NmK75wPlgZRGNlzK5+gNpSSvIV2/mVIZY2hWHdLv8AUMSWzCwQ/oEdgS2+9lWQ8IRZr0VfAXymJgRUg4Gv6DEu7Q6dVD+lTwRndmAnJkXrR3bfMpRAK7NfplAkFNhRuefqGZStAzyHSAoXgsh2P77QrQ+xNEmktZ2uK/ff8XTUjxL9YFH4v5mp7f30aUtFFdkzcGKCanhsTjJxFwmy/Wz/ABKIzAt257V/cBLpANa3owf+CKPKNTTbV5X/AMiRDW36jmCljvQ2jgH/AH7/AO3ZrDpbZL6LsvyX+boBRSO5Lw5lt1aAKHbI94BbegaDkxeHOI4xwRRH6TnoDORhs/wmiO8D/DiV5HYY/irZpz6CMtvUAA1XaLeiuavm02ot7DxmwLIU7nX+B4jt69hr/FbLXcK7n/2fxuXLly5iVchRLTNBuJr21jUVKxaqlmxWeYs7RqaAde9ZqIx+oH57PiFDNSi7JUmihpVtCsF7uGsQErOyCrDAY2DQ5g8oAXg0NvBCFsBN7LovsH2w7FTa3vVfdwq5jgSg9wuMsSz/AOlOGHMBHyFAqvDkgNRofB1fUYE2GQxqA3/eZWmrTwdH+47qqJphK/D7ZEw5DbsKlTIKGru/zu9o/hvKK3z5P4mJdippfb++mISDVq3vqfz8x1N0Nni9f1AuPyuX0QQdHEEuapy1uUFiKXxUvR93waXFoHHyC8+tV/uDqly1VAfBfL0vpcuYlwZ+0EnscRo8HAFFK1nYMFsoFNK7u/Qlpkrl/XVX+/xLG9hQBqvYl+nFBsHBaltNTr2IEgbb7K9q+MewehoaWg53tr14lrTkdMxjwWl7rjvFLk9mkjXL5EvpxMfn9g2SBEeYF1VDY8OIqyqTwkVMd2AAwJWr0jir068IHyVj3M6HGtIP8MD+pSzqJorYMrrsrGFI0zHyHf3XM1mTVdf8djQ2jtDhdAfy3zcusaqaPw2eXPiJwviu/pnereghTptO16bRPblYr6ZHIxgqb7UvwzNPSRQOyM8kaVbRJXzMmcu09jT/AG0B2dYAHS5cucwW/b9WVgj4Lr+oqnrA1kYzmPvRODv4mctD1D9/zHSsjr/MQJl2ek2eM/563NOty4pSqRjuGx3d/ULVhfahQKRZ1cV7/wDkPQLbvVwGX4CHVh69qhD7haxvisOnpIwpRMyB2dVNPle0raACigMJpQ02TD3igdWnyewcj1cJEYp5dh5UI126Z9teLa3aFUPnMI5iL+3ZpoaH3ECGoLKhdL0g+4jKopp1HTVZ2e0CnbXv3Uq+ndvcJ3X/AHb8PiPXicdOJd9zAVbX34vs/EPqo6oMZOP8wLBFnaFCg1/mXJCmpvW9MLzKroyak9mX5jhdw/a2qAKxhR6rZD6g4MOx/O8ACPsw7/EDgwoaux+r0M75ec1Xd1rLCpAvrdU/ljsC1VRA7Foqxmy6709LMxqv6lV++nE46cdOJxOJfu++v+ZkxpR+oC1AKeTs/HzBK6FWqfo17waLFIrBdNeLroH4K7f5/wAxuo2PB/mHtDQH0ih7gOj/AE+Ot9UsJ0khACwPCBz9EqHpz599iLQWFVih+iKGR/KDq/DjlzGK4lD+ZcL1IZC+Czh046cTicdUCLyy91gyvOLv1LpLKVj6AiebzLa9mtaHSs37Nr0Bq5458VaD1iYAo2fsqYS9xilTwhQ/EJCfFUW+LX0A955AgwjwaD7d+80EyD/fcYcRT4Wv3T2McJ8V039PxOJx04nH5tVEZ/qFY9ICkLGPko1lkVWtVbpk3rEX+ppmhZ9RafnLVDNDsFs21GtQQQP8B615qtyAbQqC1DTub3qpcprdp2P9rGWt7Xy1jkkDvfabZ67npj3EakQ5O8boVUYyuSvL8QXci3heKvvf7QyALY9jj7hgHEGzAx02jS3rxfqFUbOQA/qMJRRuL7N6TExCYldKq2+I/wDEud6/qgACVSr7kuzqM4K/iOEDceP6QzwxwIMtQQdiU417eoVQR3QH62jgvy7k7EiYzw7dmAWx2Rr+f3LKi9foEGh5hdTWbPn9TQC+2o7Ir1ZtA6mzzKF1ZWzlmIngQHe8doUoaDue/wDTTfLM30WnpmQbRxe/b+pf9QHgTWZsDLxK+h64/L0tpbhYeNfQzWNqC71L/Xona5tHbXusIM5zFOE7NpdhxrfBf3AYyxLssbg0XuZiqHYSyNhtDe5aTTgOVrwG+dJXQW5aOq517xxMopqZ5FWY6YmP/BRHgob1LPi4RNo2DrdxuArV0B3MP+9xjnepYA9tVHhCHdwBE2f/ALvHJkxXeFOa2ENeouR+cYHDUvlryBly1Bg3+kA1B2ddXmJRnqIfc0GIJC77Fr/OkJNZu6v/AB2ldWmF6tD6/wBrBDBitq7p7hmA9VYXr+4N/MFpso85etSpXTwD8V/SXDtT4U/iMUJXc1Is9yvw/wCJ32K/ZmOCskF1rUItqXiKXxppMzjHPC137d2WgMIG/wDyNtGN6r9QLs9LFqL0KGoU81HUrwyscir7idQisiDGdNaYBapD4X/u80hyp8bQ7S5R9JEfQOyO5bttpp/mJBaWnOkd7hJ2QfvDfrX4+DYtP1h92QhytTRdXjWYU7Y7oWdQsLbFsf6SwNA8j72c2S+bo4EOzVeMcwV2UjIMvYbq0BjARR2i2dgKaKDzULHABqsK8tHvCK9XXfky9a6V+GJ3nEJVrYVr5ri4RFxAlN1795RerXQH9TD1gGseBeGOlI5uH2NpkmAAT3fC+SnzDMG2RbxT+4t5euesVAQi2Jxj/fEE9sRH6ll7yx+okv8AhGjLKI8v3JCpbSkHE4lE46K4lrCwdkjWpiCp8t4Zirsot102jWWI3Xh41jpUpTTtMSumOlTlvyCfzLh7D+f5lhSNzRP+RI4XY5B/uB3Ea9j+oi2SgHsjVzECijtY2X9yoQf/AIHmAHYmjUcut065iRDhywfv+YE+y7CmPQ/9zSBPZ/YXEbd31X8RFi93X9QnYdRpmBgVK2PjaZXwA4JRNX3mABRR2llnb/j+Zn21b9RhGiuQP6nHTiUSicSoJd3TYRjsavrzMp3Lysyt3KHweZp1HSHe0xY09QFnMHYX4Mcp2ErXK7iZH0ytqETI8KXu7wAYZL9lWvz14/DibdeZzOYzmDYxQWM5jyxWBLcEhJsvsbfqPpqy2M/eZzDNFhQa1HfiGUQFHUsnM56c9eenM5nMCNmDSOf5WcqFKND/AHaFPUXn0E5nPTmc9CbIJUBa0XDX7GZKR4ieR3JcwW+1dlRxg+x/qFMGDdwX8MVlb9JNHvDCo6L3T/MLRnTVFn8S0OtLvuYlGwfEo/8AEDuIP5jCArX7ItBrjvIzmczmczmODI9gP9tFQhcXZqj/AOB3wwTUnGyBTlHxEIbSstdtO5/UqMH+iG6nE2nM56czmczmczmczn8zzkyMz4oFwvH4OhB2S4Y/Pjpx/wCe/TClCM7CfoI20J6Zp+d4mszrN6da2i3bDciNuC6dxD+4B4bLxU1l8lAOF24f5gBDOPdJ/axktaH1b+f/ACUDKUawHbNuFFq05hvXV/Be+0HsNtLVlT3X+tPyBlAGVWoHGus1R+w6G79PgAADQvIY0lhf30a8WviGDeOFXeR+E58//m+fxuXPnpfX5/P563L6uDgTXjJDkFVsHfx58R639i0dO+IsDAU8gpHZsjaArPpVvjERsikrsP8AaTXSP1X8xqQADu0fkZgXUnIRItZAfX/hjLOwzEzxU/kPB3rXxBAmgCL5HPPHiC0MAFAdj8fno5m2bZ18n0MJq0ibix/OtPa3djuGIXpTPFGIgIv3R+pFCjN13B46r/Hv0+Zf5c9eevM56czmX7fFV8LhoqtNAe4U1nYcHcCV7YzFintiuyf7TpzOZzOZzOZzOZz15nPTmDUlKHsCftEpqzbVP98wmpfFtLCJBUByTHit4WXLtOQUHtoxupAllNH+1JY3Qk7ZSh/6zZ/MoN3fyj+IXmK+zePLwtY2Xe3VaLaolrb1f3EQM0/knB6u+073JYl8H0HhgTEo8ngMHTn8OZzOY6C8fELPS/KV9pXtYStdnzUPAGc1sr4LWOKNMcqcocR67TXuOK+RxOZzOenPTnpzOZzOfx7zjrxMdMRoMzOBKQ0eznEencai3RGg4tNrl4qCgIDVvd7wW/traIU+Q08XWhhPK4hDG5TnOm0fAO7uQrUBg6Z3yQIJKF7G9mzjSJV8H3iam3Lbyc4mOnExMfhifMx1oLml7An7gEGDLuJ6/mKqPC9p1gNh9L6lzKWF9gY+2NARN/I/6jRQXY+f9c/1+pHfzX1rhQWVPt/UFLPmjaEvrZg9wa35Jt4u7MOg0Vew9XjLLNBzlPwuPpO5A/xRYPAY64mJj8MTE7lgwH9tVdq7wWHMi1+trkljmsoOqe/fulaWzOqJss1X9/cUcQAbmVyqzfpjpx1464mJx05nM56czmczmczmEhdgair+m2ue0v44EEAZcGDEwUxeEZM4bXtwtjiwZTcQF+ag+No6B2CAUHq/kKhcdYXSOyOyRIFyoNuxY28S6a1IuDmVRvRRpco2tbt4sVgc6mabIPyDnUAP8zmc9OenM5nM56czmVxWramSxxqDLhmZor4AiNJaxRe4qzEmBYmctnR+nbtGAGDU7POkttBhj+xEDebrPiF/8ZJLhP7iQAKK7P8A8jQzZtUbXrFKIsVVybyjPmnEefB4MpvOaWL9uTXghHgpAOwGk5nM5nPTmczmczmczmWMjUK2ybP73jYRKFp2yF9X7jQCWbJ75Pxb2jNkAG1qX3/4xvOZz05nM5nM5nPTnpzOer+D0JWEM6+h478TO82tvKEyruvogrGo4m2t+B1vLjyHSlsEp8gB5uGUBQCg/LEmFbB3rI41p0O0w4wkM3AF8d3xHw1gBgoKaPs//AhmghB2SIrKoBv2G68JyxokBQgX26HfX1EKrK6W7O4lI5EzFcoMGG+4LwttfqEwKgXeu3fWd6Zm3PTbHeh7zCMzSu+Bzb5hIABQG3/4a/8AOo/lxMdOOjB8/awA7qwG7lIDdN1SUpjvrArOw41sdl78xMt9KPgBpvt+NErqxJqR1N2yZK8EKmlMLaKhrukznkq7OX3fTfpxMSpUr8fnpx02gvW0vN9zLk1NxRWVAGF050Hhp79pdaKRVjF9o1hYZ7nwrT0UTH5fMrpxKlTid5xOJx+FSpiVOOnE468TafPX5nPTmczmczmanArVgUu9W693eYGJWBdkoHfVlkxsdblPbud76czE5nPXmcw2GlEEaNR7/ECX4RSroqXlr1D1Wr0nYbOS/fBOZzOZzOelzmcznpzOevPTmcznpzOZzOZz056cznrz15/G6LZog+npzOZZOZz0xOZz07z56v4Y84VXsZofeTEYltRI7Ndi3S6+YYEQvASxsQ4rrf43Lly33DDdCK9WEyx28OwJ2dNa4gwizhY8oxbTBcvpc46XLl9N5xL/ABuXLly5cuX+Fy5fW+ly5x1Bk1n+wuI1ohEcK/oeZYXPNGngBI/7gvVusvO67z0IB9y/aiNB7FnzUDzjTT7qWvVHmJnD2DmrU8lnnpc4ly+l/hzOZzOZzOYsyqcMcBoNbrbSVFlvEtWqsL4LYlQERsKuczmczmczmczmczmBmHaMCAL6u4UM3Fi4FpgrGs1zj3shS3cM663OZzOZzOZzEcWMAbq6EHoyoZAVi09lka9EhOFOCPTEu2Du0j4nM5nM5nM5nPTnpzOZzOZzOZzOZzOZzOZzOZzOZzOYipSrhalmQ7EDRRirVQQ+CDzV93eKS3snlt5yT1yyi94H2ywu35Z/adw/yIesn2Ran6kewbXzcfF7Avk0Hv6gcWLWw2xk8LiD1qKhH0eOj40nM5nM56czmcy5xHpxOJjFS1Vuh6wvEO9yZh0DLDul3lscJ6gtizWNL36cflxOOpc5KadwnkczONrHxoXLHvENDXwnQtW6M71OOvE46JQAFaZht7GL83uEFAQAK0AAYnsDSn9TIJ5Sz3DI+TMoKfsR8n1u40TGQK+fZ8nvR2enE4nH4cTicR2QC1cVLpTyC+VBzH+VGbS+0WX5v/6fUPlWGB1FgnD4wzj8OJx+G0ZyR5BOdcDRGVgotTbu0C0Vsdj/AKx82yVgev2z5GkClRmlA+DeAACg2mbKHfIXQ/2gLM7ALTctq8ywx8LR1Kw48OUh5D1fcl61Xn47SoF6vvfbcfsYSNieAHDZkRM/MSiAnfOz5p5Hpx046cdcdMdSGNCBVorxWU52ldrS2PaaBd+GmVk1TUgU12dMa6a4mOlTicSjrx0xB5g9t2Gz0oQ6tAGk22TVXqVmVmu9b6HN952nE4nEYAggHcSn1KKFodUledeY7tlfjHUabLuFrJr9N+/YuIYe0tu2fkcah0rpt146YgBD+Q+PQtxWIhF3kna53Xmx4gYdoPB4NPqWzmCAy7RVTBVps5fyBK0cQQmULpY4g/XTicdOOnE4jDTv0Fpp2Ww7FjQmh/kKFFYdh/W8ElvXzv4NqyYqh9Sspu/10qboJ/2PXz3nzKc/gLry59RUwhDEwRemwRfTzKPMPIgr0ZPsj0o8bwur+6A9vTicTaVKnecS5cvqm/wNCujuPLvKwMxOxHm84gYck0gvI2uz49Tnpz1vpz0uAyABasYnShU9RYBemr6qZRQ2QOtAODNW+NrFh3gq3VHKy+nPVFKXiIfTFLQAHmj/AHHqMVPej/vMvrzAdrQf8PZ1NSDhdbl7N+uD49fjbKkVAbe10AyxiFVBoeHd/Xe6NK6YYXu93y5/FaqrIDGmluyB4KfP/gJQVquA7y7csjCx8LB8luN7quzuuTC8gQIQJV2MzLnZfD23+B94hrUdZdiMzSwachqOKB7pMaFFYA7RyV1zAAzZmT+aBzUr0Vw8J/TUTxeZKv2TmXOZz/5UBhQLfIYC/f7hxOq+IgHdusqAOJltQwJj/wA3I6SUNzQNXiV8BLsT+Q7817vFQuVZQOUwZ0q/zYRaHBz9RuWpk3AE+6iQ6z/TsktDKkdoRQO5Cm0PeI/88dDhrWgqMeEFoGMpf/D0BHKqVFymOGwHMPAl+4g0WdmoCwwAavP+0RmEqKekDko3WoNVcuNmjpwfvykAAAUBtX5qdpZ7K/w/+CL5K7KCwtFZQ80n2Mq2PuFbPi4WiCDg69lPhtXl+gjVZ0lcP6jvza+qIa4j+AFzaowALIt7b4183A2Or8R/Sogh8nsr/wAsTHTEckZ1sq0mnh/+huUy0cAy/XGsquULVbFDgW0THTExMTExMTExKNVod86Nhyfdxwig25tXKtTx29xWohLZTSYmOmOtHlpvtT+YDUpLtgXXiopao5Tfx/XnEpJuA7jB/BxFilqBaz+4Yi9gPvX1mZsPPVaD77GusAlRgCrC7fOYYhlK2AGV+WDaLT1soH5ftCPZj6Ub3/P8ROsIOgWzADk3sIGxFDpeCIkMvVpcNdmgipW6nsu3xREIoBu7RCcaT3HvsGYFqUdbs+YDZS+0+7w6GTanz+6Vc/BmOuJjpiWuNDG7RevLR6Lf7gXxQHvC+2YmIJpFqzFGV+NHukMMFQG2KoiKqwqbOr7r23AAAqjGmkwJv57y0+lT7/YX6DvN4xP0H4CEA37iaEYKhjDBYvtxiYmJiY6Y68TicTiX2BXViAt9X6gggWxC9ctdtgmJ8TYFdfKq81OJxOOnE4nE4nEsjqMwsSOGMA1mDwawbSmGymHDf3F3QGgPdQF83OJx+HHUF673UGHFBDJbVFYOhzVGspbUiaWjfFKzCqaGbrKPntLW21V7l/3j1Fh2bjN/m+I1BBsE9hZorzUXOwXcBofi/mXZKs0rBf7IoCtRuH0AIBxZrt7hka5EqB7/ANo5pcxyvua931HQKshuzg8Z9SiK2X7oUiD+8fO/uYPRMsiYDPN9iUnEQ0Wt4CtFsFLWq/DHJoikatbuVro8TicTicTiKYBbXBnKI812jXA/ZcuTHB2P98CKQNTj4lS7VvgXXltvtUUBWqJYd6HgdPm75qIAu2DFYdDVMUeVZRReWy/jQ9FQVt3vavF3obdmKQ7CwXQ4HYyfAkN2pE0G6+FtXsHScTicTicTicdPmfP4UgWNYHZgnG1PuEF81+JSBizYvKgUea8RQFtOH0+RsnzPmfM+Z89A8pP0AWszd2tgjsGGO76lGk7RbfhBXR7+SCRwpanhgV79QAMaT5nzPnp8z5nzM7r4vYs9lo5jdO+5UqHtV57xKP7N/wBP3cUVyAXvByAgpzt+vE2MMeJpXvVYg5iEm693+xCxgwAAQx2vCX2x5aOYV6NXOukY0BQG8v8AviXRlGMtfsPv1H3ImrVoyxVpUZY7V+kmaVVUUZN3vrL4R5B30yOuIaQNEN0JdPCZ4rW5bIMVHen729xsIZLf8MGko4aYZXfiGAs9DtKV8y7ZF9XTmeDgTAAfE+Z8z5nz0+ejkpjDVVnRuo9UnC7kxKwdiirdhKHiBRhgrT3vZodzzMiRdKbGr8Y9pDRAAAaRjiJ0O258TTQoJZIx+07jOe1H8H2+JcgRnLZwYeR1aMxICm6+1S6t2r7exHIaO1B8dlV2arS4T56fM+Z8z5nzPnpzOZzOZzDGjqQLpdqEx49TFADbIaqsLpgtxEwmte4qvjK4nM5nM56EHtRSq0ACr4CD50rtpgRdL7hiLUnVSBoLhK3Lv03HczaUgSlvrd5MepzOZzOZzOZzOZzG5cbNUW/snMyLYUgh9+7QrtiHotgbAHW08tg2HXxesFSg5fL5uVBnmWfe4F7NP+5hoG6ZzY2xj/CigSBouxp+GblY+ahHsHqh5mOEg+V9ZL0e2kI+Dj3nD5zfzrNrK6JJCjBdmzKTzbDrZu/b7gbqrLZXFvFweCi/MjxAF3Qje31Gpe1G15+phBJasFq8jZxOZzOZzOZzOZzL96dDu8qzw7VAibo2ro2aq73ryUtyH3qVZ2ynkyb3rHUgEwA6cC3GGixMssoNzLh8ENpSNtjT/N1jMERXqLHeELIeVhvbUGGrdqvg2wCDaM3kgpftWX6rm9s1pGDw5d3aB/WgoBoBOZzOZzOZzOZz+GfwxAa1oW6t7ULxGWIgE7DGDu2+doi0NjUNltqzR7n4fEM7HZX5ier07Ql3puuHtAKEaXZuvgVru6TTnhAXa41PUMafnx1WsBnywRX9wLRYM3d33j7hK9qu+7+oFtEHgbZn7z9R8H7tPl/qEa2FIDej+5cFgsong/eceYhmU6Cg0DtrECunQ10V8DLbA9YzL5vpmQI+LD9XGUpNkmdNY3bDjMT6HDo81M4ppHlIDQ4f/k2FBPdwGomvHQhkECoa7KGPnPojN0JTrhXx/vMUG7j6Q+gf+Q7n7R40ei7Nt4UTDauK0eL8bygvxbV/dU8IygWRm0nJSQLw5ScY/UAUPvdeMv3LZCPgSufkkfmuQlPGF+CwDoc57qr9B6g1fDgfBDeCNFB9oDDlc1EDvvfIRCRRBY8medOz146V+HHTicTSB80ayN0n65Zspbd6FhyrjXKwgWGshxgTcUtWtug27Z6KFopaaHI7TiNBbpFElQyUNKG5RDoSgtdwpVGkMq4JbDRU0bzZnXkEjZYT5A8wSwAAFB0o6YnHTicTid4wQ1v2NScgNEWmFHnHFxEAhe60EPJ8Yj9u796w0zC8BdgPP8yjlBirVZx5SWGqUuUVdfULVhtWUOPekuiETe6wfLLtLZxjYvhpOSV0o8v20ofcJQNROQHvKVNLh126Q7X/ALWUB3YObP27eM+g59RVB2vU7F3ptDsJSfQ6Z2uoPUbIwvdRCAFqDthHhZloqfCXkPHevmFtfTlH+GV+fHUs7UCxPMSPObyPQfwjdbFHv4hRNeAGcq9GIAW1ufcw3gF5IQHlICnnt4yxcrU7v0MI85n00C+aD9szqkazffMsaibmv2yHoIShKrunyzffV2jnFYo8JpTp2dGyUE9+B+HZ1H2ajMTicSunHTnpzOerExkoZeXu3xdRGTAoKR0L4WbsBNcG+8Bri0GKdeyKwYPWqKDt2iL9lqw8tORo3AUzX2d1mhBD3QsNJhF1w1fbSU6mGWNfJ5VnM5nM5nM5nM5nM5nMNiuR8Aaq9jLMEdZAq0aEre1PaQmwVxkGuPuNgASpd4P+784fUDujKu751loshALp58qxAAFHS7ub5LLYm01muw0DXzHAVQSi6zWTtBYGwLuGq7RNYZOS8UPEuZz0wwdoWivOpMGkahrr/SQQ0G8BWzqdzTHn3CNFDzT+Nj1GDDQmsPanbdgv3yiXZar6iQkezX07+4jFWBRuO00iCtm8Y+6lsIbCnIfsOJzOZzOZzOZzOZzOZzOZlC5ZyNGMngZfBmB6SmwO0wF7KDe3EUJe5vA1TtoG3aGoR8z+g4rmVL3Vo+NIBoA7GPqOUSC4Ayhjdq0+KYKO0x1p2uVmphiv1sXY08WMJesAuLEB7Yu29X3nPTmczmcx/K+uV1ZIuB7jx72LjPi1aTVuXSqBoIhyXBsbU8Lt4PcGpEqsPsgeIbqg1PK+1f8AwudulxrYtBaNC3V/toGZgM163ZE6hTbp2MEDAncuF2egW7s7d0vwbLXk/pcdbSsGX57kRrGu0vvEzgKju9nxcUh0DGA8vb7lNhcvj/sMLqXvgAb5b9E74YddMfV/gMXQvjA5/tPMcuJOTfJ80sJMoA43NP8AsAUMyVbYLTut5KajZMrbmnezJyBMsoKKLHPrWKsEvQ2/Z3NKhahrvbsO8DMy1btHvf4ijI5ctoB9n0giWZv8Lly+t9M9XPACX0G74GBdJXn19u7toeEBC2ap37DsdtewYEDxg8BCqP1LlLfaG2lnQUYXidyqdnH8QqYEY6u2v3TzAAcYj+iIsMrfepH1ZXq5lmG7VrLfLZzL/HmczmczmXSMDN4aF8nf0IL1yFiO85gU4WOAeF93YZeblfBl4MWat5eMAyaY9mf35ry9pzOZzOZzOZzOZz05nPTmYyLxhHYdkaT1HTFivR8D2Axqb51hh+ngRLsaSDsDipzC5nmhhYD+5f5Ar5Le3P8A8lJBAtaMsAYL43G/lCtzwnM56cxwC8nipX1TzDLasPc2mCSGKawCEbIb7lb6v3AFA4PkL/5HrO413JmOoFIIS/v5Ys3ltkNMwRKzyZ+XlisgBWJ5imJMsYVbVInY0005nM56czmczmcxiVumssB5VA9wNlrqHgX4RsuurKrJIDXez4Gl8+mViRDLsdoAAKoigZ2mc+Je906PLU1qsj/wlxtQHZUe2iXVQAN1lfmWIiSj4Wr8qeyXRV3tYF5pOeveczicdAGoFoi4DLBjVnv2Xk5I5wwILiLKbo9shtadpmha2qxvJh77wb24iH2RRF72wfJtteP/AHmgdsbO8RQ7VABb8UlnuYZQV7O5w2cTjpxOJx0468TicTicTCADNDobIdz9Yh1puh+PVtXLF1CZHSlTuJhic+2FTj8LxU/zbD2tHMoT555+GlfSdpxOOtOdEnQMvgDF3AoGD0+2j0PYTZKttUXxLQjU7q+dP5iMXCykWq4PERTFrX/6/wBiBGUPmcQR5OV2PMZvXPldntqPY7WhxOOnHXjpxFc5B3ixDht8MQ4t5yq+zKaBK8rr7W/csE1uXrR8x9TBe/ZGVrMqIsADVZn9evrVh2Brk9o92Uo9ms+hr5aIWm9W1Du+cXfcjGtpTOnhopHE4nErr8z5nzABPLSXuGR8jGuhxQj2wt9tvmCptaN0Z4ig8iMkoiFwZz3Lb3LjvLEoBQYAbE3Tl3sEbkSbvoPv4RWN3A7AJ9x89LnzN/y+elz56IJSYjU0J/z3gXyO9xLK9IbTQmXh4XCsomEN+sy39i8TocEKMumOvbsRSy+zQZJ3t15dYNmAUAVXX5m8uVJkYP0RVvytGk00mX8HRBKQTcjFveQJRANdAAzEBUCGd9Fh192wfcwB6Nv7h+RxpfS+t9d58y4mq/HAy+XMXdyfat+rUu1l8IXXzMQwose8tWi5grr1K3I6XCr1TSh59TWJAtAeY4+oj0NvDV3xiWWzoeq7f7BKYMxRdV0HjP3csxGjCVOQe5gPbCfgOoAoPifM+evzOenMUjVFatXX1L9R7SgbLiHYYeyF17AhsXvc6xfN25hgrV1uIKXYej/EQRSjPD/UgnmRHsG/3OZzOZz05nM5nM5nPTmczmczmFzSgWJ2SXQxsxU9M+2jsy552jI2xwO5qbymsTsU+dY3jA/KuviNbf1bC4t7tdc60aHjyvTmczmczmUj1NA6BTPj0sskinCDf0ZNu1zCWb/uxQ9LA+Bt7z/StqvuTdo1rl1jxeAJD4VzGjVQDKBtX5HnLtCcfhy9BOZzOZzOZzOZzOZzOY2XIu4WPdilxj9etu/A5D2doeK1YQVMUvZ7d7GARN2qrBx1z71MRru+24M3S7MvlaPRHRYonplfwx82u17RcYOoaPy7+P1rFb3xfY8ePH/2AWFbd5+uafZcGY8Cug0GV7GwbHLOZzOZzOZzOJxOOnHTHwR8C+QOIgbAKPt33CWby5tXqjb+iJcpFJhb/wDO+JUADI3QQ/fxMxiG6mgfA+enEqcTjpx0468dOOldOJxMjfq1LZDKO43LqN1ENK8AepWtQSkkB/WO7vKnE4nE46cdNCWhgPVeOq8V2IJhJuFdr7Jv/OsIRrPtcufNYF6jpmMPDKZV8H3fM4nE46VOJxOJUr8OIcQMQWD94XXcDeVMDlfs7n6iRIWUP2mH91iEyBpXflsPwQcpV3/SkanXm+Sn1AIRkwr3Byegiy5a108LoesMwaO7NvvU/B2gAAACsGkowvEOTIPquu7s38Waj3C/jQ2CcTicTicTjpiYmJiYmI99tcFbb7Byu6m8o+wEnuO37eTMLJNSP3Av7ioC0Mha13fldpjQwBKNCttOuoYxmFBiYmJiYmJiYmJiYmOmJiYmJiYmJjpiYmOmJiYmJiYlCsOCPRG2os2X3DixR0f2fOrMTHTExMTExMTExMTExMRrSITXxxuXNBylbemKFCXrYSmVHwtRoUA1OHcHREmK/GfoZoR+k4Wj6Ya0DuUveB+4AAArAEakMlIO7sHloI4wGRX8n0UeYMPAIAbAYJiYmJiY6YmOnE4nE4nHQOJaB09do/VjmgHxAPKYJZ4bJOJxOJxOJx04nHTicTicTicTicTicdOJxOJxOJxOJxOJxOJxOOvE4nE4nE4nE4nHXjpxOJTAp9ZHZO+sYOiYFuduzGXtEASqlq0vc7RMLYcql2Cr1/cVMzus5ar7iY3mg/5X5qII+revCis5IfD8o7Pdd3yzicTicTjpxOJx+Hfpz+Hz0+fyufM5nz056/M+fwuYnzOZz+O3T5mJc5/Lv+fPT5689KgBdGv4/M+ZzH8vmczmczmczmczmczmc9OZzOZz05nM5nM5nM5nM5nPTmczmczmczmczmczmczmczmczmczmczmczmc9OenM5nM5nM56czmczmc9OZzOZzOZzOZz05nM3j0ejGbzt1fwZvCP4HTaEY9N5t03h0fxZ36nXfp3h03/Dv0Om/XtO/Q69+vfoTfp36f/9k='
};
const artBrowseState={level:'categorie',categoria:'',brand:''};
function normalizeCategoryValue(raw){
  const v=String(raw??'').trim();
  return (!v || /^senza\s+categoria$/i.test(v)) ? '' : v;
}
function displayCategoryValue(raw){
  return normalizeCategoryValue(raw) || 'Senza categoria';
}
function normalizeBrandValue(raw){
  const v=String(raw??'').trim();
  return (!v || /^senza\s+brand$/i.test(v)) ? '' : v;
}
function displayBrandValue(raw){
  return normalizeBrandValue(raw) || 'Senza brand';
}
function matchesBrowseCategory(articleValue, browseValue){
  return displayCategoryValue(articleValue)===displayCategoryValue(browseValue);
}
function matchesBrowseBrand(articleValue, browseValue){
  return displayBrandValue(articleValue)===displayBrandValue(browseValue);
}
function visualSeed(text){
  let seed=0;
  for(const ch of String(text||'')) seed=(seed*33 + ch.charCodeAt(0)) % 360;
  return seed;
}
function svgDataUri(svg){
  return 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svg);
}
function brandLogoDataUri(brand){
  const raw=displayBrandValue(brand);
  const clean=String(raw||'Brand').trim() || 'Brand';
  const parts=clean.split(/\s+/).filter(Boolean);
  const initials=((parts[0]?.[0]||'B') + (parts[1]?.[0]||parts[0]?.[1]||'')).toUpperCase().slice(0,2);
  const seed=visualSeed(clean);
  const h1=seed%360;
  const h2=(seed+42)%360;
  const h3=(seed+210)%360;
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96">
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="hsl(${h1},95%,78%)"/>
        <stop offset="100%" stop-color="hsl(${h2},92%,68%)"/>
      </linearGradient>
      <linearGradient id="badge" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#fffef7"/>
        <stop offset="100%" stop-color="#fff1cf"/>
      </linearGradient>
      <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
        <feDropShadow dx="0" dy="3" stdDeviation="3" flood-color="rgba(26,34,52,.22)"/>
      </filter>
    </defs>
    <rect width="96" height="96" rx="26" fill="#fff9ef"/>
    <rect x="6" y="6" width="84" height="84" rx="24" fill="url(#bg)" stroke="rgba(34,40,56,.16)" stroke-width="2"/>
    <path d="M16 64c10-11 21-10 31-6 11 5 20 3 33-5v17H16z" fill="rgba(255,255,255,.26)"/>
    <circle cx="24" cy="22" r="6" fill="rgba(255,255,255,.4)"/>
    <circle cx="74" cy="18" r="4" fill="rgba(255,255,255,.34)"/>
    <path d="M24 66c0-18 10-34 24-34s24 16 24 34" fill="none" stroke="rgba(255,255,255,.45)" stroke-width="5" stroke-linecap="round"/>
    <g filter="url(#shadow)">
      <path d="M48 20l7 8 11 1 3 10 9 6-2 11 6 9-8 7-2 11-11 1-7 8-10-4-10 4-7-8-11-1-2-11-8-7 6-9-2-11 9-6 3-10 11-1z" fill="url(#badge)" stroke="#2b3342" stroke-width="2.4" stroke-linejoin="round"/>
      <circle cx="48" cy="49" r="22" fill="rgba(255,255,255,.55)" stroke="rgba(43,51,66,.12)"/>
      <text x="48" y="58" text-anchor="middle" font-family="Arial, sans-serif" font-size="25" font-weight="900" fill="#273142">${initials}</text>
      <path d="M37 67c3 3 19 3 22 0" fill="none" stroke="#273142" stroke-width="2.4" stroke-linecap="round" opacity=".75"/>
    </g>
    <g transform="translate(67 58)">
      <circle cx="0" cy="0" r="11" fill="hsl(${h3},92%,74%)" stroke="#2b3342" stroke-width="2"/>
      <path d="M-3 -1l3-7 3 7 7 3-7 3-3 7-3-7-7-3z" fill="#fff7cf" stroke="#2b3342" stroke-width="1.4" stroke-linejoin="round"/>
    </g>
  </svg>`;
  return svgDataUri(svg);
}
function categoryClipArtDataUri(cat){
  const label=displayCategoryValue(cat);
  const key=(normalizeCategoryValue(cat).toLowerCase()) || 'generico';
  const token=ART_ICONS[key] || 'bag';
  const seed=visualSeed(label||token);
  const h1=seed%360;
  const h2=(seed+48)%360;
  const h3=(seed+205)%360;
  const top=`hsl(${h1},96%,80%)`;
  const bottom=`hsl(${h2},94%,68%)`;
  const accent=`hsl(${h3},92%,72%)`;
  const face=`<circle cx="42" cy="49" r="2.2" fill="#263142"/><circle cx="54" cy="49" r="2.2" fill="#263142"/><path d="M42 57c3 3 9 3 12 0" fill="none" stroke="#263142" stroke-width="2" stroke-linecap="round"/>`;
  let art='';
  if(token==='bag') art=`
    <path d="M26 39h44l-4 30H30z" fill="#fff8f0" stroke="#263142" stroke-width="2.8" stroke-linejoin="round"/>
    <path d="M37 39c0-8 5-13 11-13s11 5 11 13" fill="none" stroke="#263142" stroke-width="2.8" stroke-linecap="round"/>
    <path d="M33 60c7 3 23 3 30 0" fill="none" stroke="${accent}" stroke-width="4" stroke-linecap="round" opacity=".9"/>
    ${face}`;
  else if(token==='wallet') art=`
    <rect x="21" y="31" width="54" height="34" rx="11" fill="#fff8f0" stroke="#263142" stroke-width="2.8"/>
    <path d="M21 42h35c8 0 13 5 13 12v11" fill="none" stroke="#263142" stroke-width="2.6"/>
    <rect x="48" y="43" width="22" height="13" rx="6" fill="#ffd68c" stroke="#263142" stroke-width="2.2"/>
    <circle cx="60" cy="49.5" r="2.2" fill="#263142"/>
    ${face}`;
  else if(token==='belt') art=`
    <path d="M18 51h38" stroke="#263142" stroke-width="11" stroke-linecap="round"/>
    <rect x="53" y="43" width="18" height="15" rx="4" fill="#fff8f0" stroke="#263142" stroke-width="2.6"/>
    <path d="M71 51h9" stroke="#263142" stroke-width="6" stroke-linecap="round"/>
    <circle cx="61" cy="50.5" r="2.3" fill="#263142"/>
    <path d="M28 44c4-3 12-3 16 0" fill="none" stroke="#fff6d0" stroke-width="2.4" stroke-linecap="round" opacity=".9"/>
    <path d="M32 61c4 3 10 3 14 0" fill="none" stroke="#263142" stroke-width="2" stroke-linecap="round"/>`;
  else if(token==='shoe') art=`
    <path d="M21 58c8 0 14-4 19-14 4 5 9 10 17 12 5 2 11 2 17 2v7H21z" fill="#fff8f0" stroke="#263142" stroke-width="2.8" stroke-linejoin="round"/>
    <path d="M37 51c3 2 6 4 10 5" stroke="#263142" stroke-width="2.2" stroke-linecap="round"/>
    <path d="M29 58h41" stroke="${accent}" stroke-width="4" stroke-linecap="round" opacity=".85"/>
    <circle cx="41" cy="49" r="2.1" fill="#263142"/><circle cx="53" cy="49" r="2.1" fill="#263142"/><path d="M42 55c3 2 8 2 10 0" fill="none" stroke="#263142" stroke-width="1.8" stroke-linecap="round"/>`;
  else if(token==='jewel') art=`
    <path d="M48 24l16 10-16 38-16-38z" fill="#fff8f0" stroke="#263142" stroke-width="2.8" stroke-linejoin="round"/>
    <path d="M32 34h32" stroke="#263142" stroke-width="2.4"/>
    <path d="M40 29l8 8 8-8" fill="none" stroke="#263142" stroke-width="2.2"/>
    <circle cx="48" cy="47" r="7" fill="${accent}" opacity=".95" stroke="#263142" stroke-width="1.7"/>
    <path d="M44 49c2 2 6 2 8 0" fill="none" stroke="#263142" stroke-width="1.8" stroke-linecap="round"/>`;
  else if(token==='watch') art=`
    <rect x="36" y="17" width="24" height="61" rx="10" fill="rgba(255,255,255,.5)"/>
    <rect x="28" y="28" width="40" height="40" rx="13" fill="#fff8f0" stroke="#263142" stroke-width="2.8"/>
    <circle cx="48" cy="48" r="12" fill="#fff1b4" stroke="#263142" stroke-width="2.2"/>
    <path d="M48 48l7-4" stroke="#263142" stroke-width="2.2" stroke-linecap="round"/>
    <path d="M48 48v-8" stroke="#263142" stroke-width="2.2" stroke-linecap="round"/>
    <circle cx="44" cy="44" r="1.8" fill="#263142"/><circle cx="52" cy="44" r="1.8" fill="#263142"/><path d="M44 53c2 1.6 6 1.6 8 0" fill="none" stroke="#263142" stroke-width="1.6" stroke-linecap="round"/>`;
  else if(token==='glasses') art=`
    <path d="M18 46h11" stroke="#263142" stroke-width="2.6"/>
    <path d="M67 46h11" stroke="#263142" stroke-width="2.6"/>
    <rect x="24" y="38" width="20" height="16" rx="7" fill="#fff8f0" stroke="#263142" stroke-width="2.6"/>
    <rect x="52" y="38" width="20" height="16" rx="7" fill="#fff8f0" stroke="#263142" stroke-width="2.6"/>
    <path d="M44 46h8" stroke="#263142" stroke-width="2.6"/>
    <circle cx="34" cy="46" r="2" fill="${accent}" opacity=".75"/><circle cx="62" cy="46" r="2" fill="${accent}" opacity=".75"/>
    <path d="M41 58c4 3 10 3 14 0" fill="none" stroke="#263142" stroke-width="2" stroke-linecap="round"/>`;
  else art=`
    <path d="M48 22l6 12 14 2-10 10 2 14-12-7-12 7 2-14-10-10 14-2z" fill="#fff8f0" stroke="#263142" stroke-width="2.8" stroke-linejoin="round"/>
    <circle cx="43" cy="46" r="2" fill="#263142"/><circle cx="53" cy="46" r="2" fill="#263142"/><path d="M43 54c2.5 2 7.5 2 10 0" fill="none" stroke="#263142" stroke-width="1.9" stroke-linecap="round"/>`;
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96">
    <defs>
      <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${top}"/>
        <stop offset="100%" stop-color="${bottom}"/>
      </linearGradient>
      <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
        <feDropShadow dx="0" dy="3" stdDeviation="3" flood-color="rgba(26,34,52,.18)"/>
      </filter>
    </defs>
    <rect width="96" height="96" rx="26" fill="#fff9ef"/>
    <rect x="6" y="6" width="84" height="84" rx="24" fill="url(#g)" stroke="rgba(34,40,56,.16)" stroke-width="2"/>
    <path d="M16 65c9-8 18-10 28-7 10 3 19 5 36-4v18H16z" fill="rgba(255,255,255,.24)"/>
    <circle cx="24" cy="22" r="6" fill="rgba(255,255,255,.38)"/>
    <circle cx="74" cy="18" r="4" fill="rgba(255,255,255,.34)"/>
    <g filter="url(#shadow)">${art}</g>
    <path d="M68 30l2-5 2 5 5 2-5 2-2 5-2-5-5-2z" fill="#fff6cd" stroke="#263142" stroke-width="1.2" stroke-linejoin="round"/>
  </svg>`;
  return svgDataUri(svg);
}
const CATEGORY_IMAGE_MAP={
  'borsa':'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/7QA4UGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAAA4QklNBCUAAAAAABDUHYzZjwCyBOmACZjs+EJ+/9sAQwAGBAUGBQQGBgUGBwcGCAoQCgoJCQoUDg8MEBcUGBgXFBYWGh0lHxobIxwWFiAsICMmJykqKRkfLTAtKDAlKCko/9sAQwEHBwcKCAoTCgoTKBoWGigoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgo/8IAEQgA7gEmAwEiAAIRAQMRAf/EABwAAQACAwEBAQAAAAAAAAAAAAADBAIFBgcBCP/EABgBAQEBAQEAAAAAAAAAAAAAAAABAgME/9oADAMBAAIQAxAAAAH1QAAAAAAAAAAAAAAAAAAAAAAAAAAAgidr45doo2rJBQAAAAAAAAAAAAA0Uu40XKfeXfCn6Fto8sz9TanlOXqkJxnUazmT0n7xfU75WxrIAAAAAAAAAArmjipbTl113Yeb8lXr2l8owl9J+cCzr0bbePVrPe63ju/1nroo5cb7j7VtdvOFAAAAAAAYc9zXGY36BouQq276hBvlo7DPHn00G3uU8a3E/KxydLFz46SzyX06PWUthVXZXqVaC70PO9ee623nta59f3/h2+y9maPeb5hQAAAHhNGTLHbVWM9ulqrqq2Om3gjzwAAAAA+ywjazaOut+OaXedbsalfU9D9E849H3xCwAAqabOuki5zW43xWHUfM9K1Lo9DM8LJhLrViSDPKX7CJ0GUTIRMhEqAT/Icamq5QVjtqV+p6V/u5db6XzdvfHcjpzAA5zT9dr+Xb5y/SM68418Na2tbsW9Ygw+Uy/BFtMaofNt9jT476hWvWcZa/2aSKv3b5mlbefcw+6iTeVDbVyx0nIVsb9Vw4P1iTeDv5wAAHE9t5lLy9G5r+XbKbCbcivVJ5YsM/hDFbxs+2JKkbTHVfDaYV7WLTnpNpsI9pGrknp6liDGcxw3OqxrL3r89e975WxvAAADyn1by3OuX11vYY61ZII9LtFfit33Jdhz6U+N7Hk7KEuxobxaUfpgtSEOy02/zes5Xb0sdOTv0pOvKzRlxI8LdCzY+1+K+6zOQ6cwAAHD9xoJfF5aVvPTOzXnmsYpYbOm3HC91y7R89uuSRB9z68pI7HyWCaqsu7bW2ePXtNR1XnM1qvmNztxo2lGy/r8JI3ftXnPo2uYayAAA+fR+eJun4bHTZYUryrUUC7vHUT41ueZ3+0zvWa2pNvniu4VLnrPpnYs7bO9jznPzJnHLlvEFrXxJJE2lnsO8LzCgAAAOU8i/Q3jGd8/DnjNZZ441dr/ZM35utN9mvSdDx/TTUMPUSRznRavmdTr+AzzRLWayjjyufknzYy6z0vnfXLm2NYAAAAAfPo02p69HBVfRy+Yx+pDzXXetpfHHsavH8PY0eMZeyrPKJ/UEvm9vvVnHW+mGk2k5AoAAAAAAAAAAAAAAAAAAAAAD/xAAuEAACAgEDAgUEAQQDAAAAAAABAgMEAAUREgYTEBQhMDEVICIjQBYyM0E1YHD/2gAIAQEAAQUC/wDAHljjw24Rnnq+LahOI6uP5skixra1JYlm1WWYiK5Jg0uRs+ktn0+ZMDXIMraqu62R/Lnvrlq9lTSprBr6fDCFUKPFo0fLWlRyZtY0xq10AV50sJ/H1Odu4pnXGhKaizKiy6nWRJ9egQSdRqFPUiYvUMWQazDK0eo1JDrC9yuKl2tm9mtKPUfxZZooss3q5vTX2jGp3Jilq6JMlmlmKoz4Kk5zyc+NWmXNtsjtzJHWsQPiajeQ3r3erwTxSj+AzBVl1qlGZ+o4lMvUNljLqFqZiFOVYHkmsakIpFhmnaDTeWJXqwF7QXDbOedOLdGGzGy+VqWMk0yTILM1TCTag2yK9bgxNeuoI+pfxj6hpvlW/WtH29avCe1um8jKTkYyvV/VZMt4pXhhxrca5LalkHNtvsHoeZyK46nzMM6GoqMwSzliuYWK5tlePlgUI+j3fPU/atTdnWJ04Ptkce7V6qGvNfNlpZmlwkn2/jFkKlbY4tZS5giO8kX4hcMp8t0l8+1q3pqf+UFPWoqAW7TTlDg99shsCQP+GOSxmb9XR39vsySJEt+rNavU4ZkaLSea6rChp4uDw3zf298Y4cr2/wBfaXk1aZ86TYRzfdYnWBCbEpMTYtZ7U1nuVp+cjkSQBtS7klX4IGAHPXN83zkM3+zfOQzlm5z1w+EVeWbPptnjHStQmqnYhZIpUqy8X+0/ldjgk5O4GWr4pu2pSST3rT2MAxe5Di3OWCKu8claaBvnNs2zbNs2zbNs2zbNs2xFaR/pMsYMtCo8t2xJg+YBuKt6BkDREO/ar/bPXWUvUnwabyOorFT0tduxL/fAQMA2eQRkFNsimlgaGyJXiSmQKqPBNplyLGrzqSpHjwchaVlsNMxvL5OPJNSl4ys8zrCBhRdmQqPjHGafFG1mvpVOvJ7HVknHT4jyxo+RA2zkeI9THBjwMuAgBvyxgTkSzRqupXomTW7QKavMuLq1jJ7Vzt9x5MDxgDtjI0MjMNjHIYzz4ZvueJ7cQ5GCTt+11a3Kyf10WfmUBbDGVLoymKYqzyO2dt8dCmKxQif8GdnwKSOO2RzPGJJwuH1O3pkUytkswfxjZVLuoiRh5tx27FQ8qvsdTf8ALXzi5E22Mu2SfimIobK1t+1dmjmE4CSYu3OXlicu14IFOJDyztUVzVVgMn+2/HE9fFlOXkHm6Q2p+x1REx1SwRNbWNTFIAp8IYRv29pYld6l1mSCwC11a+ySRNHgJAJJyOF2x4MOVe32+3vNqaqYyrKe43EyNwRCxmiMbP8AM+8sajivsdSps7EYGPD5wJxDRkYp2Om9uY6aJOF8P5jUu0siSsseKnoyFCjFWllMjdodqZP0q9nZ07xkYllQtnxkU7KXsHedGXNIiM9j2ddi7ul+gEYLYCRiPjSbeCloZNFYbatJwduTj/StxxW3wuFw+FMNzjP7d/12bBEakDD+SyyLv84TiHkvS0ZZvZI3FyHy1uCUDGlVgD4RtGuWGTKdrsvPvdyMhXiKGJ+HjAI+VgJy5NlUt3nvJHWcK6PsDvgGKFGN6YXOaLX8tpvtdVwcL3hyIRWJw/O+IoI06YVrWp6b3m/JCg5MeJP4snhWpPYbUuzVgG/IsdkQHGKDJMDEZtvmm1vM3fb6lrd/TVixo8BIzkcRS+GL09QS/JdP1Jq+NFV1CObRXGS1LgHl7biLSrb5X0iGPNQ1SKAO7zOq5KvawSkZy9Sd84HhnSlff3CARqmnSUZXJYqpOcfAyErEqPnaOxVVWOR4Wr63KuLrVchtYrjJtfyzqFi1jRbYBse4y40ufOEbYm4wSelXSbdt6sCVq/uzaZTmx+n6bY3TcWN00Tn9NS4enLGPolohtBvE/Qr+DRL4z6Hd2OhXs+gXs/p+9kPT9wAdNznF6YGL0zBidPVFxNDoKE0qimRxRxf93//EACQRAAICAQQCAgMBAAAAAAAAAAABAhEhEBIgMRMwA1EyQEFx/9oACAEDAQE/Af3NrK96Vi+OKzI8sV+KPOzz/aKhPolFr2xv+G1y7F8aPGeNGyh7qz6lEpaKP2YL0ssr6GijZfNZQiOM+iyhYJd8IxcjxV2JUrXsUbROHCM1Q/kj0N4KLoTLL4NmWURlRKa4ofVaI/zRpa2LVYZPjHsq3p2RwiRRZREaxw+TjHvhF2iTxwhRenR2T75J6qWSavKLKLIR/rHPS/RF8E2i0zaYQ5N44N+iy2bmb2bjczcbmWX+z//EACYRAAICAQQBAwUBAAAAAAAAAAABAhEhEBIgMTATQEEiMlFhcVL/2gAIAQIBAT8B95a9i5t9Hpt9npHpluPYpX5X+y6NzNxbNx9N48TkLOjl+DPFP8l3o5065/Ix+FSY1YuDlRvHnHCuFFauRGXBxYoPsj2NlWNNFMp8IqzCE0OAovixLODBK2sFf6P4R3fJUWVno2ola6FlZOi20R4y6N20q8n2obshgUkzab10TE8jyLB30Q4swOxfsapkeyvwWykSbuih4O+z7eiPJqzo7NiSIusMUaybjbmyUvhCgWNX4Gf3TK7HTKaLMsikjOjv48VaKKWlabVpXuf/xABHEAABAgMDCAUKBQEFCQAAAAABAAIDESESIjEEEBMyQVFhcSMwYoGRIDNCUnKSobHB0RRAguHwUyRzo7LCQ0RgY3CTotLx/9oACAEBAAY/Av8AoBfe1vMrWPc0rXPula8uYkpscHDgfz03uACnRo3v+ylCD3c6fAKr7E9guq9aP6XFah9wq7bb4hWndIO0PqpPc6E7t1b4rpLva2fm5Qnwx23mndvUoR0uUbXTnJaSOTXa5YTKugDyLzQrlDxWE4Pqn6LSQzKGcGOaQPFWoZ5jd+YZk7G2pyJb62P/AKlXcicORCgxozGhzhhjtA/1fBTeQ0bynOD7YG1gmPHBXLJPP7I2GzOy7+6ox3u/uq/5SpAWvZKlpmtO5935qEyd2JEDT3qxCDY0PZsTYzoGjGBwqp/luliMZ7RkocaC7TaKr7G6Th/qVdG34q3GcyHLU2P1gcO5XGucf6kU2iule53NXWk8gvNuXmyqw3eCqtHatQ/VdVDRvOSxMQ1xnDnvQbFbDO4yxWjeyy+r6VEgF0URj+R/IlziABtKlpS89kKUPJ4hPaMldDIY4CZXSZVEs8DL5KgPeqRNAw0MQmQ4pwyMl7j/ALZ4r3blak4k4lyvOJ4MCvBlrcbx8FJkM/qcGfutbJ//ACcv92PNjl5th9mIW/NdJCMu00OHiF0YLT/yzP4ImC5sUcMVo3ttQ9sKJ/KIfhnlz8HQvSH3C4ro8oiy5zWMKKOLarpsn91yqIrebVKBFDnbsD1kXJQbsNp73SmrgIdxV6ZdnGU5SP7PalKci/krLQWwGasJgo1Xnsteq2+74Lo4U+LzP4KTnGW7AKU5DcKeTMUVa81fv+1j4qUX/EFPEIRcne6GRUObUeKOmsjKHUDmi7E+xVh5v7W59Zo5rSQ7hY13+XFCI6kQXXc+rjP3R3T5TRb6plmvGSfHyrooDKUxcdyDos5gSa1tA1NtgGyJCexV6uimJT34fJSitc4SljNMgxnSlqRXY8ijPAbVbYDZzRC/cIY+f0WVfpw7+ryr+8KtAbK5nOyl9mCBuq7g1BtRBZ5tk9UfkmQcodJrdV8sP2Rt1icMJZmN4l30+iykez9eqtRHBrd5UeLBhPLXPJE6fNObo3O3hgtfJNeXATqG4q260I0M2cDZxwH5QQcoFqDsPpM5KelaYWx4/lECyE9zZDAKPCfdiOaDI8J/fy5mZJo1oxKvxLHYZ915yL/3Crr3NDMHOcXfVaKNYfOukcJ/DBMLdNGDfUdYbP5STi6JCAZIzaZ13TRAyd+kiOnPGn8kpHyMOqw8joob38gg4ta0He4Jz2loDdYh2xNGLB8ELQBGxCE91oHUcdvDyo7nGZbcbwEgVeZ0luel4T/gWKtQXVPolaVxFqUhdnJNtOiEdo5rUNxaeyU0ZVDbGY0S3FThxbEUnzbue9SeyY3tr5WGbDybENpc47AEx+Wvbk8JxlM1OCP4aD+JMqPjYT5J3SFoJnZZQK8Jp2iub00RYrg/AzQdk8VgeDaFZhOJc0xZl4lvx8q1NzX+s1XcpEuLF00YkbmiSyh0NjW3aHiaLC8Nu9S3UVLp3mqIFHekTgqCvDDNOE8tKd+IgMiE+lgjposWAZ+raCdEhZVAdZmbBMneCbODO1hZM1J0CKObCqgjPMMeR7KpBd30QGURoUKfG0VJuljv43WoMgQ4WTtaZiwKq1FeXO3uKGlMhwV+6PRU9h25ieKgCMLTHOsuE0Hw4V8YEmfUsZ670GnzcMF0lNlVxVnYuK6W41G00y3ogNVR8UA1tFaY97HDAAkKemfOUr1VVsN3cndGypntUmsh47kGOeA0jY1dPGiu4TRl3UwRNXHdJSapHEKhXR7VMq1K6nt3tpzVqeBB59VkkMYgEy5//E53pRH2e4V+aCkBMqySJqThJXpubuRmTyU7LvBC0rpIRtVijAq+ZrBVHwUm4KUHDbNcVPZmk6UPi2iIsN57c95lpA6zTgzcoZa2QnJPZuJCgnewdTD/ALoV3VKgw/UZM8zX7ZjUtntRppJ+kpOiWju3ZnWp6pKHRPMuyUGxREbD9K6U9gxa4t+OYTwTdNqbLKrLRcc42ndgjFfIBrrAh7ytTJ/ALobIkJ3RjUD75rIZYrrlWHNtietnmDVFzTJhAdPuUAdgfLqcnOyIyx8f3UVxdIFxlyQGAHpqQcHZwS5p7IU2ba2fj9EwQ2QyO05NgRWze9jg0h05kBRwP6jvmiHa5wkrylOiqVOV3epwZuaqqC6NVoL5zHsKmTusUlRSa2Ths5lXgQrJqOKs4N3BCSliM2S0FYVgdxIQAwHU5HH/AKbj8p/RSaBzVnZuVFN9eyMVSo4IEYhRNNIvOxOayLRp2hZPOJeDpAtEtiY1lXAVM/5x8U5gwOa06YZvVR3qYW4bgrbXzHJWIdgstDEV2bfBVhN95RIjjLAWdh/k06+XAGhW5VxUiZt3KzDNliE5VWQNPoxXHuAaeqjS1mi0FjVGyJyVCparvWVynFVQNQU+uJQedj/oUYsQ3nHNMKmv2sFJszzwzk4N2rRNqHYKfBWGmrpT4UCq2aHpjwsozv8AGUs8naqixHDUJA75fb49VIqLCODHSC9RSDAM99kzvmhbvnZKirQbEWMqBXmVJ4PFOsanpTXR2u/O3G3uOCNokP3BaxQi1dY37VV+OG8qbpNBraVDPMJ0Xrqjgc0FpF4i07merbF2RG/LPQU9ZEAaQI5qnuRZFow4T2LTZPLSbW+si14II2FAb0GtbZ4vWqQ4Duz0oza5NZDo7YFNylsU3mTVQGxvVDMIyOaDCNQ51eW3rHOGtCv923+cFM4KYw45saKiu1dtUipHxQZFvQ/iFauv7QxC6CICNzkA+CXSw2qzoIlkbLKq0Qx2ipxjpTuwCsZPJzuGAVp5JObfmnLNa2ZomUvHYb9esIOCmGnQ+i9TOa7mDdgUpkOROAG9DGZ2K1CeWngpR2B3HBVtjuXpLooXvFSiPkzcMEDOc1ZwUmvMlcu56IWfOKZbo2nFzhJMgw9Vo66/k8Oe8U+SoYrf1T+apHf+oTVMs/w/3VMpYf0qkaF8UAdCZds/ZEnRH9S1G++vNN94LzTbXthUhN73rzbPeWqz3ledB94/ZXsohieNJq9lXgz91ejxe6S1ox715px/WVTJoffVdHDaz2RL/jf/xAArEAEAAgEDAwQCAgMBAQEAAAABABEhMUFRYXGRgaGxwTDwENEg4fFAYHD/2gAIAQEAAT8h/wDwBynumTdE5V9T9g+plyrlh7zqQSz/AN2xss7ymOHvdtTGl00XT7PWIZjuT2GZkS/L9ScHq/0xzcTcflqIgA73eyMHGX+8lcrR0Db9dvWDZZp/6dNYW/2sD/jvKHIMNR6+N6Kgu5/UT+vY/e9yjCcBX+GuB5rMDXsNHn/sw6t5sPdsyxvbsecKHtj5meCtTX/0LssdGQqrtVnME1bh/cDagL4VmbX7d0cFuqUROp7VfsdZjS0YzrwT3mnM6sbjEzL3EP1Gu5fCxE9Fab7NPtDIZ5E+yE36ryweFH0gYSahF4WBRBa2q04w81FQNy//ADC2J0YqRBQbqg9xLh2rf9ZgJxWrMhyfOo/qMdm8GhLFwtsHY2jnvZNE9YqJf2E+AdotUUeGMMoVTQ7Xp6SkFEU1Wzob5l7n1KV5EaZlyxmZEqu23mB6wNt/8JY2tSglecA776RUR8XxuU/97F49prZHT4NCM6TVVawZWJRUVY642hKwCvV3rscdYtSe1ZeuZczO9ivWAAvM9tfzMCZ0nxFNse43vOV7a+Cbr92VGTXn+oOkRLyCh5Z9oYH/ACoekSeIBrubrqRoXDTQNcU7ZrnBHI1BvEhEdmrw2QEu5Y/YkqCZ5fCfcrPTx+Fm5LL34H8jDrejas8VXnpVhpOiri2lCrJdssmdhXR+l/uA/sEy89WZz9hNh5gNE/1Bjyy3Nx/AfdzQH2B4P8U2CuSKt1fOrzrB2gaNqdjmZYA4st+2pHI7ZV+j+4C6Vqw46vO8wcDCFMv0jWCy83dmUKU5tkVD1qVMs0mlNz8eBruLu2eJR7qBmTQQqDPvEwTpRezBvn94AdUoBdCKqhNfQ0o09oTSs40PGn4xVaR5GFSo2ZeaTqXod3oy2V6BjjW4veH0+dO5yc3LbA/bvM0ehohzbb4eYnKlp0q/GHrvywGyIHXpt9QIIheP6jvt8FpuhLf2SmOz8zpNU66/Z4j+v6YkbXGh7E5NZa2r6ESpos+HyivhW8/6/iYl27REhkBql4dEQdcTMLrF+qYH+CwTq7+kJ57AwcNCg0Tetf8ABv8Aks/zuXLiJnigDQnF6lvrSVUYCk1m6E3dGHDbM7qX9yx4COnK3w/zICtuDwS8c62q+T7Tcfu9ZZBi9VrwHZ8QV0zXAnc004ZvMp4RWdGr2lzPy2dWXLVHmWVV6WFsoHWqaRFARNRhM2TMdjzLcpX9J1JTmXLlxBqzqHmdGfScUd4TqWOs0vOWTzDFMKrasPUWATc2bn9RDytbz/aW5fcR6Fdut6ju79S+L/yvfBB609VfY4ing3vOoHOmiW0IQV5Cx9PVjx3aFPS8fveJgCWio+mkyYI1A3XBXRl5sB2LrNnaA30NOM4eEOIQUwEN8d4JFP5+3+LsleHidstLS8HaLrSwsK3WjJ0O1a7y8yhsGV9RpxELWc4KtDtAN05Qs7suuTzDKI2g1vfWXmTiGwlNdGOIrQhnQDXXbf8AyG0IqzNddn1iivUN9kjeRy/MfHiKM6BXuwvw7TLT4jz2U8IgLOPjFHLu5PKDj/AGCYrGniINTqMzFbTJhFbDbTOk3xslAtbtT5mQV1ULNXprsyxLM4X1PckP4sh1AASR8MrkfJgn4LsKrFHf2iOkKZ5nGsXzsEu73ncgwYurbhdwNSPlmfMNqtoby8qf9zABp8v+R8gZGIuDTueGbxUSr2v8Nc7YnIC/NRKjTt1r7j6TdXrLCJQxLLnBgaAVaBM66TC4iCUHsSC2L6x7prSBVDgZzNW/Uj2j207KCr1OssV1i1nwzBHXdmp9YEqbTrdW+esJSgYNusviRepp8wV0v6syjZtVQ9ZjsvWI41gZZO8cygS5uXU6EcovmOdyOsQTWzsafcawdgVv1H4g2WfhLLPWQBCyABAnXJ4ES5iuJSWjgldUbXpLEFOmqsx3BPPBBDRd0OWhL7S6udINw0lO01x6ZaBpzUU6pi8h6Jvgs6sVi1yooi9Nzq4YRo13lyGK6rPSAB6aLxPMYJevSaOj/wBEFsSrvXE4SN7XidVT7fh32P7zjnTQTTO+YMBBJjTaLRTBQVqZ9zrVf8CtIUDd290mkgksT4IxsWYOPHr6QaG8N4aRdT5nebMy37tD2g0+rWF/9hrNJ7sTTzKCbxslR8DcEXQxZKW+YREM1ZwxhuRlrNoxM/c/dZQqUzjLFlLKb2GXdsfs/CStB71/CaswD0HtMMMiBIzoJ/D7cRAd5MsCRUdwBlZ2UGIG82XOpUvzi89xwa/cp2FrtrfA6hmiMVUXhiwI4Q/M7FsrRRvhG0KepBTyiwZZkZwPkheQqyCHWyaMf0aAfYQgKdSWBA3BsmEJqUQMOrVyxnBqEdBuo6W4uS/6CDoIo/DxXK8fAGeUO75wCsFehD1M4s4azJ0bIr54j65J3o2aHT93YoYYGX7iQzyyC1cImovWNl87oo46238Jm6LDXtNqTpygZXDctz3iLphams94KktBpNGNl1ACaOEsoNNugs9qwqU0Ru63mkIOXReIikwGsDN0WbLZYQBJGit5bXu23yn5/EtXa/QM+1w1VljENSUW1NZjbDCxhZgY8wtARxyvPSWraVlUQZreorXZB5gErDwOuz7SgjIrdfolNqLCIqC+pcI8LorXmGaDhvfoJk3zwfwWo0694IEFD26+1J6EqvqTSElTovLXjvCrD1aTRXYLJMu32gVgA5lkAjS5WcGdYUX8A/EBgscIxxVps3Lx7RyjqxvLo3kZyy9JzgR2a5lpG0Msicn4Yt8gP69vVmIbdDRuHIrZ1p0jvh1fwxtUegvYGqWZnqNlwu+1mhI8C9R4+YMqS2HwcxzeFTnXbnpBXr81UuCGjrA1QdZfIg0xt1hHchJVldiYxM7KdTPbB6fjHJGovVwSu1eYS4YPN+6d4XcJEBDZeOsMMVNTO1NXzBgda39riMHoXcdZaEakKSVGmVQgRmuoyt0Ypqqb3uTXVt6wg076djllHymuhy/uYEvSzEi7TQl1QumYheUovmIu0SACgdYIYIdIxG9mfYP5KJ5/0dswjVPa5jF+WpmmNXARLC4mjbrrHAYmniN7AkqgtNN1TIPTH9fEDoHQw/cdmIr20vk/1Bp+oJ8W4m0dDD8x3vw/guO3RzY9nf1mK3wP62O2BtZTpMLSxeNpZ1VOo6Spj9rxHdtemkpHalZ4i0DGatd18Hn8hMiikd4nyDBk9eGbzmI4McsbXe61HftM3ThjdqDlvkJU9u1DU9694VJcWpSgeGUKJtgey3g+4JZe7P0RJam3X+3rALcfGIlhF0zNYkJyDr3mVysUX6Y2iW37Sgg3w7+0MP4DPTeG7pi9+X1fyoJSWSyymzfzSO4vgFPBidnsBT4nBGwwQ94Z9we89H1E41xud5uYHOP9Iho/YR6xe8VMC5WD5ZoSHQZ/zMF2fTKIM2HBBDY6grfE3W+jAdT2j6Z8nifBKlka39bNYXb94dRXA/8A27//2gAMAwEAAgADAAAAEPPPPPPPPPPPPPPPPPPPPPPPPPPPPv8AfzzzzzzzzzzzzzzJQ8x3nbzzzzzzzzzzzhOT3+7xpbzzzzzzzyHh2/LNKJl53CXbzzzzzDPLMAAAAAGKJvXzzzyoiNhLBo4rpTEqhfzzx0eIXEQp2D+aCjSUvzzzyqO+xY226MS9W9f3zzzz5AhZ4qQnZfbo7/Lzzzym9JllPNwuE+zGn3zzzyyeuVtOfb3kHJlVbzzzzxhKjrxg5CRhmkLzzzzzzy/2+2449w4z/wA8888888888888888888888//EACARAAMAAgIDAQEBAAAAAAAAAAABESExIEEQUWEwQHH/2gAIAQMBAT8Q/rSPgNlv92NELaDxQ9aQqwpnyWbX9ZrEbFbwI9D9BmqGxImvyuqyDwL0iO8+FTSGxRMiHtDvYasNDT0KVQ1OWoJ7Kb2G+VHSjGkGhtcTSDhWwJ6ATv5OCmEsrgiieBLBUU8VBfQmCXgarYkffCGvBS8RPrL4rkZJGEmQnkxQ1nJ0BVCjWWJloRPY8PBaxEg25TBZgSbCUpnobLJ7FSmTgqoJwecIeNkW8WiMrbFBy4EfQUoWy0ihXBIyNEqxK5LWC6MaxycsoTuSzI1UiFA6x4aSGboLNqYJ2KBvsbrvJWmPeD/TDePOvPsncfIFUKxJPZJRfgmXfmGzZXio6iy/ZX/R/8QAIBEBAQEBAAIBBQEAAAAAAAAAAQARITFBIBAwQFFhcf/aAAgBAgEBPxD8tcv7Qj4++oeZLBHUoH7tHh+iF90zXUHwJj/UepuzGDoux9nHwSR2wOtt0SrzZYWF08Ni8QfCB/cMB35cNTQ5PTJX5bH8tEWNI4Z8C8424EnpAj12ZPoyyy19AFuSj+7Tj8HOkl05D2sXMs9HIzWGNLD1a223tSDI5f3ne/j4TdRfa8pjRAM2JLieRlgCLOsh9rXDZjQ2GtI535GADdsSmzbxLp21Qt8LF6gnZwbDhIdraHVa9/EaZADt+q0k7h4julgGw1lnfd5BsNcJJwsDgk/yvDfkPLeOE+rcBtfoY26ifuRf0vCjYOeZDxsPD2OfIr4jhPJyENo5l6cZ9W10rt54kNkOCDe/YwsFl4SyzZAO2WLPyP/EACsQAQACAgEEAgEEAwADAQAAAAERIQAxQVFhcYGRobEwwdHwIEDhEGDxUP/aAAgBAQABPxD/ANan/wDGCJRIIvy4VL0QfyIyBhm6DvwSwWB/0GAZ2UAj8n+9fMoLtdA2vYvE7M5Qrt/Ao9sSMOEn7ESPJxQLk3n7XvEeo6j5cTH1Vne7wCewMUgsQGeLh94o2QDTPlA9oGDQTDCZ5/cAd3ABBRIjI/7KgVQFq4uMJoHyR85LUwTAqnQwpiYQCiBAmwaWJLmuuzcdgB6mEw6pfggtOywcO+EPr/AhnRGgeyzEdG73gCzymLjRWirl18kabkGEUO6UFyCkm7dxKjhpCBN0Yk8Io7FP9hqeYVJAqgSIhhByyMDeCX4YRCyTi1xJQamRhC5elMMvK1iRvQkHbt2wbWQDbCkroCWCVRkgU6CHSlix6yGJICxgm2p6msh48giJJtnRO2BLBX7M6d9cLZjBiQJQYQBKESp1hpSKoQLvS+5zQBuUdEEel/bErckVEGtaIMMNxE4euAJ7/wCsx67/AJRxXchBkxOkvowErrJvtIDMvARZ9ZquypEImAQvZOV15UWBJGKo5qsMMBkS/QegZFEejfjgEjP6LwrZ4/kwaQHVPwnO162H7xe6Yhvk57GU6iGAFOoDISJOcjYOUgXDA5o1DGCR+DAQiDZF7ReQX4Lk8g1/owICIAcq0Y8I2Ae+IC9OUcIQP8v1j7dcqftywwF3GSOkGDFsbMu/z/OVfD/cSeUpvfPXOd2xgHGkWTl2R/YGkq2mzkOC2FPEwQ9h5zgxBxv92mU0hwLuBke8bY+gN7kZFUHUpR5wCi91APSDmjnsr9ofbExq2PeSj8TvlFIEJ3RTE9pnti8nZJb8vcHJDeXZcAqsUHIWMhKmANaQaJH4TI7CTHieIT4jJdehIXmIfEZMq6b16kYaCqxoX3PrGYKKKDyxD9fqQipdSSPWCBwytwRRg04Y9fjIgCE8E5OXXVydYx7xAz0gEqIHYReqINKKm3dGVJF7T1GKcJBIKLq3Mn3F7Z0TkMvxzOkmcJhFjOhGesA277hTzAZHb/AcM6WE9mC1CyF+OPthiyshH4J8QmJ0zBCJcBIeh75EMglvWRDw+RgejQUQpharBVC6MbgunGeakTuMPC4YWzGMtWu8Iq8JCjtNc4oVxRKVZ238yY5ymZCAfAiPZkuMP0h4eStAD5ke8dvJ0ZUGn2Q+8kClnRbgIwtG0eOPeA44ZZSWxs9kqFwfEY0gETVMEsdDQGQFh6SeAEV7rbko8sxCXrCA+D9OO3kUn5LzgQ4E/Yp7s49XMFDJ5KFdq66GTBSh8CgAwyFm44byAqd1kyC8EMOsYkk2F9sPzkAGAg5iVr+9slxEBJym7osWKInREY+b/TjaWRvK/vklUfMifei+8gEsb4MO/hGV6WWsiI/lhEuwNRomLRUtwBrK4mGEP627ES8YBmaRnxC3fb2LgHDE0WdKYUBIkEjvc4pEi6zX5fK4ZpfO0n9DnFQCCTFwqeJXy4fowGjkITq3ly9YqSkPAl+8mUcqUI2g9qvIRGTMYJcMh0jy7zUQ054ImwKFlwjxglJyunBnOHXgMm5yTrk+P8JOuI/8XJDeDK4yVwG2WHtLVQhb6HyOwslVw2Tw8lUuC8FAtLKHn7YtMj84FW+x5/zg3GOYcweBVYAFWMQIKQgD3hN3Idsj2vT+MmZgTQsSgTuskCLlgQbjgJIRKBXoZZpOZjMQGwEKWhDO2Upu4pUnZyQAsDqY4kvDbJjQBqc9sVG0AhHuZBQw9mML0u5/GUWncg5GX9D++RbE8ozRT5wbUvF5Prk+uTOcE0YlzemJ4Pgsm2B3YxUz+RgAVz5j8YzQjGmAMIQ9HQ9uNeMEhoKmrfWT5cMNkmiMZERlib40Cu2gOXu8S1ybSMTU2IC9SJ4x9WqSCXiAIdhK2v8AGMBfNQN5NU2C4aBmNB0C+FUIVFaRpCtuB0gIjipsJDYJu6y9uSMmmCUeYkuG0vlEgFdk4BDoi3JYSJWvrKIvNE14I6DhH3SgZaKVNJ6t85a8AESAD4EKstOLrk+sTyAQ2G8OkhxbHocV5xnsvrEzoesS7Hxn/wAhgDRPBnYyfjECWjEFpCzuwXxkbkNa7VoB5pCKwXBCRBMhAODIiG8v9YbPCnBA3OGyO+Cz3wV1ylPMiAk4uryFHslIJURSHcZO5EY1ooYV0iMeMs6CtJ5VIqWWUMzhr/FMFhAQKgEQtiDEsROKjez9iL6wIntwPYqoPEPfFiRQu0iVYLVw0MHmpFgab4dbwAyoy60B+xxTNYYSfPHx7xQ0V2ajIR3If5yKbLMyd4Zfx4x9LN40UAFMGFJSbDjgxfqpEwKI7cRLOO14zDSpLOIS9cgWhFzsCkoCHYZQ+u/kwA8E1xikFSKLU3pTiKMG5iPnC9XGdw6bMcjNpp7CMG3XB0voD9ZUmTJCEordIWZYnVvDqCjS4JY73gW+hGCJLQ0jUw5IfxJ+7qtG+2bL/hXbhK+8gxCGmE9Fwkb51g8tJsGRhISQhX9ViTSCGtAr7WK1ggvsQlp3gw86snn1DQe+/wBFYevPf0wMvmiRVwpfUtY/RNdSyvfWJ94uxwOZ/s4lyERdp06wS13cDPSLC4E8gCFJWAvE4/0mRuTrgcmqzmfOV0/ih+2CyFxKep67MLrhAqoYlNj8YbQSbQVCWdrnnFigiRQT0Dl4w90bgNgdFYx59al181g5SELJCpE8HORv2TzFUMDfTDDhBTHsYLOWfRyRO1KvL3wMwReAHf5wSqEORwsoPTpv6vNR6IzTPo685Ope0ss/nph5cgHUn93lB7iLVZhhEOU3jZMtRy74RpIkifouFKo2n2RYxBVIqHoE2PUYwhb6uPPWgs/tY3U1qUu6ET7yrVU9uzrJO02cxzILucczuoG7KDVYMJokSLzOC1AExUuHJZBtgSVv4xbeRHSIfxHS8fEgaVB6MjHkVr4nWFJUilDHb7wWmXUZ7w/zjQ8NYN3pL/zHJSKwPgKxbiQk6mOuNnCNBTzEZEIEEoHVe4PjAzJWHontGMCod4KmcOzKIf7rtlbngVH8PrFBAgKAi3SaTk5weLAljqS+cQ1iU+hf9e8dtldXuX9/0dxRCm1MdLyRVaGP3WfBjvPJfecIcxbW8+YdfGWaylhRen84W4IBAh3NwwpBgjEqnzkwEKQGFDKaudsEEmHPpizU4r/EkWjMuokuyz5TlyYEWB3zjwQnCXXrGSmEkiYO+NFOxOcSPSNZsBEKoS6i7ajEUXYatHKlxqf5xKTNUTd3X8jglGBxBGmoVO7nUWTh1EyYpWoISAUgEVm5juYgIIWXsTjqhBAVE2zGndYqw4FMFWKcbuvWAOGQkhQnX3GIyMdCpHNfn4xMWqFZOYNHfDueH2YT5xNge9foij0QOUzRy59C0X4QfGGxJDWFmEiZ/bISD2QfNdNYRyWv8fy5UYElMMu/dZrBqOfGCxtEX5OdwE2DGMKBcFRgvbO9xnORlZ+W5IVN9F5KIGiKRyT7PTlsUyxRGhYi9X2wKJEkL+POOjTzr2awwDhso8Yu7cJAOTC41GMowo8lXx0xAKWqyzj8YKJ/prAIbb9B0xh6Ajg1RmUiLxG5U1BM3EiMHmRxUKJZCUO+JeGRS9EOz5wLnOQAfLt429MchIEkgvM9sSVQsQh/jEASghF9Ji3HSXSL7D5mFbAS6AQforI0aRto+J/OVNBgFs2/WSwrTyJ/vGIToAHWKQkRDC1ukXXXoYVKMaN0hvu/OJVBEY56c98nsUCgBLHgWc9W8i9JkzkFWnXp1yJNH7POLuAxTmQksSq1Nsw0VvBZcquw5i+aMGFgZd44TLBbnUOcOMAyEoE2Pc94MslFaYT/AJlzogERz3vBv3Gwd+grU4bSpSnEM1AzV3fGVL8JE8eMLMsLTLOpWh2kvSFtagJg+Qn37yfi9DxwAvKmHAsgNJ+/8ZKKgqFiGruLMrF6YQFzLCk3hhYup28d5wABOk6APcj9IU6AVkhHvM+8uRdAnXdzw7aH9/bGGPgUhN3rFWa3yGNA4Z3vrkFFcurFyeXbGWWiV2444UgQpbvnk7+cZwzIkQguG8YYfoPAPC0nhTLq+YtNtcEwdgCsJpVW8f2cncQqHh3/AOfWUIkiIaH5Xy+MM0gREfCV0nhMWoCuAP7/ADggHHWfGR+BsbA4jv8AtkZEhZgyT+gdTA10J8D/ABnrTRJM+h2twx0j0TB/Y/eIuCJAH1YqKnpWC0FpEe/V9xjFkHB/fOMpfQxUQSa09Pv7yveqFEg8Po/0hWjoEiOxx3MButS9wxHAyEwSPDOGQdJZKfjCaVzzzP8ATARyN66ZGMMGwi+h5xDAsVW4Qw+cXqiVIC7K67oT70izum1C8AW5V1GRBAg1iks3PbjEEmLbYdFRsvnIqDLtE9R4w5jrMlH9rKBLa6Be/wB5M4QmCiwLfMX9Y4SAkDDq5akEgR/NkIFplkxEvWZ5HTHIMDgj06OoYhkY3gRwdESliAQBs7DEvTLUmNQ4TFKRO8QpxzJL8E4OwoRUbNpcNo+gTHzWSoxZCj8ZJwfE7oA5D4TnP6TdjehpA4BLM7yU0awU2w+cGEXICS83xdRhw4opoHvwfVZD2WKdBQfvASJBwGD4mtOPdA29/GNOzqk27EgXimicKCZLIIcmjrmns7sTAhfRMhxIS2A85MDCvRxZA7qOmL0IN0NtceStZIQXYNyPH98YzJkZldvnH0BQUHPD4FC5ulBQR9py7yz5PnLwoNg/OP8A67UTM1rCVVgpJLMB0oe1ZypEfP0mp1gb9oUhI4jG4BiDvtiSZ6scecNwnHINwnUB3jCiv07VQlAlJBl0CXG0YtcyUNh4P/ub8skoPM84QzyQhU+sdtgRRPxvGErgSB+ceBiNFkqOMgQ7w8YtLYSyOB9/trIzngejgJ2HVrhqMMhCQk9F+g9ZxRVMXoRfWJYei0HZqUbzVPoo/h+cBTy1JjtK+YwNx4B+a+xO2NEPqUDpFI6FHLxkjlxtf700Y2hY6W5Ui6JLb+xjsqCBCo1XvJUMysuTt/3B76UUHjFkAbDrvpgwFoNmHG0IoNhHXRPYfqKlcBIEhHGJBv4OB+m6Yk6YihgCqI6ZBIpRQHzgESIn2H9TiBSBsdjiyaA8sEE+MXHBVkPoVWFmcAM+K3k1MpIIjqk03WbIzKMdHt2a7YCKqb3vVPoMaAcEJ8zikYybu+cBdVET4H75v4ZWO4fkckR0SF1bX+MpInRA5m61imxGagXqGNaASCLW3CKi7HK4NkJtLbo5VYtMh/PjCa3EgQmju8ZeoJEjmGCvFdzGWEq2UyndFe6/qshJSJI4+jbJf5kOVRDRgdCRHvFWeSCa/EYc4HQz4MfGTPkmfpYgLQyLLPaFhohkhyDhtks9Ns8FisYYb+m8FIO+PtyciG0EjokOAmFYld7xMfnzhiuz8v8AaMbyDKiXWlgkhKljpemEjuJ+UrIqN6fk8Pvot8i4qPJCT5APrFR4m/8AK52DKD6P9WP8o/8AXP/Z',
  'borse':'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/7QA4UGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAAA4QklNBCUAAAAAABDUHYzZjwCyBOmACZjs+EJ+/9sAQwAGBAUGBQQGBgUGBwcGCAoQCgoJCQoUDg8MEBcUGBgXFBYWGh0lHxobIxwWFiAsICMmJykqKRkfLTAtKDAlKCko/9sAQwEHBwcKCAoTCgoTKBoWGigoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgo/8IAEQgA7gEmAwEiAAIRAQMRAf/EABwAAQACAwEBAQAAAAAAAAAAAAADBAIFBgcBCP/EABgBAQEBAQEAAAAAAAAAAAAAAAABAgME/9oADAMBAAIQAxAAAAH1QAAAAAAAAAAAAAAAAAAAAAAAAAAAgidr45doo2rJBQAAAAAAAAAAAAA0Uu40XKfeXfCn6Fto8sz9TanlOXqkJxnUazmT0n7xfU75WxrIAAAAAAAAAArmjipbTl113Yeb8lXr2l8owl9J+cCzr0bbePVrPe63ju/1nroo5cb7j7VtdvOFAAAAAAAYc9zXGY36BouQq276hBvlo7DPHn00G3uU8a3E/KxydLFz46SzyX06PWUthVXZXqVaC70PO9ee623nta59f3/h2+y9maPeb5hQAAAHhNGTLHbVWM9ulqrqq2Om3gjzwAAAAA+ywjazaOut+OaXedbsalfU9D9E849H3xCwAAqabOuki5zW43xWHUfM9K1Lo9DM8LJhLrViSDPKX7CJ0GUTIRMhEqAT/Icamq5QVjtqV+p6V/u5db6XzdvfHcjpzAA5zT9dr+Xb5y/SM68418Na2tbsW9Ygw+Uy/BFtMaofNt9jT476hWvWcZa/2aSKv3b5mlbefcw+6iTeVDbVyx0nIVsb9Vw4P1iTeDv5wAAHE9t5lLy9G5r+XbKbCbcivVJ5YsM/hDFbxs+2JKkbTHVfDaYV7WLTnpNpsI9pGrknp6liDGcxw3OqxrL3r89e975WxvAAADyn1by3OuX11vYY61ZII9LtFfit33Jdhz6U+N7Hk7KEuxobxaUfpgtSEOy02/zes5Xb0sdOTv0pOvKzRlxI8LdCzY+1+K+6zOQ6cwAAHD9xoJfF5aVvPTOzXnmsYpYbOm3HC91y7R89uuSRB9z68pI7HyWCaqsu7bW2ePXtNR1XnM1qvmNztxo2lGy/r8JI3ftXnPo2uYayAAA+fR+eJun4bHTZYUryrUUC7vHUT41ueZ3+0zvWa2pNvniu4VLnrPpnYs7bO9jznPzJnHLlvEFrXxJJE2lnsO8LzCgAAAOU8i/Q3jGd8/DnjNZZ441dr/ZM35utN9mvSdDx/TTUMPUSRznRavmdTr+AzzRLWayjjyufknzYy6z0vnfXLm2NYAAAAAfPo02p69HBVfRy+Yx+pDzXXetpfHHsavH8PY0eMZeyrPKJ/UEvm9vvVnHW+mGk2k5AoAAAAAAAAAAAAAAAAAAAAAD/xAAuEAACAgEDAgUEAQQDAAAAAAABAgMEAAUREgYTEBQhMDEVICIjQBYyM0E1YHD/2gAIAQEAAQUC/wDAHljjw24Rnnq+LahOI6uP5skixra1JYlm1WWYiK5Jg0uRs+ktn0+ZMDXIMraqu62R/Lnvrlq9lTSprBr6fDCFUKPFo0fLWlRyZtY0xq10AV50sJ/H1Odu4pnXGhKaizKiy6nWRJ9egQSdRqFPUiYvUMWQazDK0eo1JDrC9yuKl2tm9mtKPUfxZZooss3q5vTX2jGp3Jilq6JMlmlmKoz4Kk5zyc+NWmXNtsjtzJHWsQPiajeQ3r3erwTxSj+AzBVl1qlGZ+o4lMvUNljLqFqZiFOVYHkmsakIpFhmnaDTeWJXqwF7QXDbOedOLdGGzGy+VqWMk0yTILM1TCTag2yK9bgxNeuoI+pfxj6hpvlW/WtH29avCe1um8jKTkYyvV/VZMt4pXhhxrca5LalkHNtvsHoeZyK46nzMM6GoqMwSzliuYWK5tlePlgUI+j3fPU/atTdnWJ04Ptkce7V6qGvNfNlpZmlwkn2/jFkKlbY4tZS5giO8kX4hcMp8t0l8+1q3pqf+UFPWoqAW7TTlDg99shsCQP+GOSxmb9XR39vsySJEt+rNavU4ZkaLSea6rChp4uDw3zf298Y4cr2/wBfaXk1aZ86TYRzfdYnWBCbEpMTYtZ7U1nuVp+cjkSQBtS7klX4IGAHPXN83zkM3+zfOQzlm5z1w+EVeWbPptnjHStQmqnYhZIpUqy8X+0/ldjgk5O4GWr4pu2pSST3rT2MAxe5Di3OWCKu8claaBvnNs2zbNs2zbNs2zbNs2xFaR/pMsYMtCo8t2xJg+YBuKt6BkDREO/ar/bPXWUvUnwabyOorFT0tduxL/fAQMA2eQRkFNsimlgaGyJXiSmQKqPBNplyLGrzqSpHjwchaVlsNMxvL5OPJNSl4ys8zrCBhRdmQqPjHGafFG1mvpVOvJ7HVknHT4jyxo+RA2zkeI9THBjwMuAgBvyxgTkSzRqupXomTW7QKavMuLq1jJ7Vzt9x5MDxgDtjI0MjMNjHIYzz4ZvueJ7cQ5GCTt+11a3Kyf10WfmUBbDGVLoymKYqzyO2dt8dCmKxQif8GdnwKSOO2RzPGJJwuH1O3pkUytkswfxjZVLuoiRh5tx27FQ8qvsdTf8ALXzi5E22Mu2SfimIobK1t+1dmjmE4CSYu3OXlicu14IFOJDyztUVzVVgMn+2/HE9fFlOXkHm6Q2p+x1REx1SwRNbWNTFIAp8IYRv29pYld6l1mSCwC11a+ySRNHgJAJJyOF2x4MOVe32+3vNqaqYyrKe43EyNwRCxmiMbP8AM+8sajivsdSps7EYGPD5wJxDRkYp2Om9uY6aJOF8P5jUu0siSsseKnoyFCjFWllMjdodqZP0q9nZ07xkYllQtnxkU7KXsHedGXNIiM9j2ddi7ul+gEYLYCRiPjSbeCloZNFYbatJwduTj/StxxW3wuFw+FMNzjP7d/12bBEakDD+SyyLv84TiHkvS0ZZvZI3FyHy1uCUDGlVgD4RtGuWGTKdrsvPvdyMhXiKGJ+HjAI+VgJy5NlUt3nvJHWcK6PsDvgGKFGN6YXOaLX8tpvtdVwcL3hyIRWJw/O+IoI06YVrWp6b3m/JCg5MeJP4snhWpPYbUuzVgG/IsdkQHGKDJMDEZtvmm1vM3fb6lrd/TVixo8BIzkcRS+GL09QS/JdP1Jq+NFV1CObRXGS1LgHl7biLSrb5X0iGPNQ1SKAO7zOq5KvawSkZy9Sd84HhnSlff3CARqmnSUZXJYqpOcfAyErEqPnaOxVVWOR4Wr63KuLrVchtYrjJtfyzqFi1jRbYBse4y40ufOEbYm4wSelXSbdt6sCVq/uzaZTmx+n6bY3TcWN00Tn9NS4enLGPolohtBvE/Qr+DRL4z6Hd2OhXs+gXs/p+9kPT9wAdNznF6YGL0zBidPVFxNDoKE0qimRxRxf93//EACQRAAICAQQCAgMBAAAAAAAAAAABAhEhEBIgMRMwA1EyQEFx/9oACAEDAQE/Af3NrK96Vi+OKzI8sV+KPOzz/aKhPolFr2xv+G1y7F8aPGeNGyh7qz6lEpaKP2YL0ssr6GijZfNZQiOM+iyhYJd8IxcjxV2JUrXsUbROHCM1Q/kj0N4KLoTLL4NmWURlRKa4ofVaI/zRpa2LVYZPjHsq3p2RwiRRZREaxw+TjHvhF2iTxwhRenR2T75J6qWSavKLKLIR/rHPS/RF8E2i0zaYQ5N44N+iy2bmb2bjczcbmWX+z//EACYRAAICAQQBAwUBAAAAAAAAAAABAhEhEBIgMTATQEEiMlFhcVL/2gAIAQIBAT8B95a9i5t9Hpt9npHpluPYpX5X+y6NzNxbNx9N48TkLOjl+DPFP8l3o5065/Ix+FSY1YuDlRvHnHCuFFauRGXBxYoPsj2NlWNNFMp8IqzCE0OAovixLODBK2sFf6P4R3fJUWVno2ola6FlZOi20R4y6N20q8n2obshgUkzab10TE8jyLB30Q4swOxfsapkeyvwWykSbuih4O+z7eiPJqzo7NiSIusMUaybjbmyUvhCgWNX4Gf3TK7HTKaLMsikjOjv48VaKKWlabVpXuf/xABHEAABAgMDCAUKBQEFCQAAAAABAAIDESESIjEEEBMyQVFhcSMwYoGRIDNCUnKSobHB0RRAguHwUyRzo7LCQ0RgY3CTotLx/9oACAEBAAY/Av8AoBfe1vMrWPc0rXPula8uYkpscHDgfz03uACnRo3v+ylCD3c6fAKr7E9guq9aP6XFah9wq7bb4hWndIO0PqpPc6E7t1b4rpLva2fm5Qnwx23mndvUoR0uUbXTnJaSOTXa5YTKugDyLzQrlDxWE4Pqn6LSQzKGcGOaQPFWoZ5jd+YZk7G2pyJb62P/AKlXcicORCgxozGhzhhjtA/1fBTeQ0bynOD7YG1gmPHBXLJPP7I2GzOy7+6ox3u/uq/5SpAWvZKlpmtO5935qEyd2JEDT3qxCDY0PZsTYzoGjGBwqp/luliMZ7RkocaC7TaKr7G6Th/qVdG34q3GcyHLU2P1gcO5XGucf6kU2iule53NXWk8gvNuXmyqw3eCqtHatQ/VdVDRvOSxMQ1xnDnvQbFbDO4yxWjeyy+r6VEgF0URj+R/IlziABtKlpS89kKUPJ4hPaMldDIY4CZXSZVEs8DL5KgPeqRNAw0MQmQ4pwyMl7j/ALZ4r3blak4k4lyvOJ4MCvBlrcbx8FJkM/qcGfutbJ//ACcv92PNjl5th9mIW/NdJCMu00OHiF0YLT/yzP4ImC5sUcMVo3ttQ9sKJ/KIfhnlz8HQvSH3C4ro8oiy5zWMKKOLarpsn91yqIrebVKBFDnbsD1kXJQbsNp73SmrgIdxV6ZdnGU5SP7PalKci/krLQWwGasJgo1Xnsteq2+74Lo4U+LzP4KTnGW7AKU5DcKeTMUVa81fv+1j4qUX/EFPEIRcne6GRUObUeKOmsjKHUDmi7E+xVh5v7W59Zo5rSQ7hY13+XFCI6kQXXc+rjP3R3T5TRb6plmvGSfHyrooDKUxcdyDos5gSa1tA1NtgGyJCexV6uimJT34fJSitc4SljNMgxnSlqRXY8ijPAbVbYDZzRC/cIY+f0WVfpw7+ryr+8KtAbK5nOyl9mCBuq7g1BtRBZ5tk9UfkmQcodJrdV8sP2Rt1icMJZmN4l30+iykez9eqtRHBrd5UeLBhPLXPJE6fNObo3O3hgtfJNeXATqG4q260I0M2cDZxwH5QQcoFqDsPpM5KelaYWx4/lECyE9zZDAKPCfdiOaDI8J/fy5mZJo1oxKvxLHYZ915yL/3Crr3NDMHOcXfVaKNYfOukcJ/DBMLdNGDfUdYbP5STi6JCAZIzaZ13TRAyd+kiOnPGn8kpHyMOqw8joob38gg4ta0He4Jz2loDdYh2xNGLB8ELQBGxCE91oHUcdvDyo7nGZbcbwEgVeZ0luel4T/gWKtQXVPolaVxFqUhdnJNtOiEdo5rUNxaeyU0ZVDbGY0S3FThxbEUnzbue9SeyY3tr5WGbDybENpc47AEx+Wvbk8JxlM1OCP4aD+JMqPjYT5J3SFoJnZZQK8Jp2iub00RYrg/AzQdk8VgeDaFZhOJc0xZl4lvx8q1NzX+s1XcpEuLF00YkbmiSyh0NjW3aHiaLC8Nu9S3UVLp3mqIFHekTgqCvDDNOE8tKd+IgMiE+lgjposWAZ+raCdEhZVAdZmbBMneCbODO1hZM1J0CKObCqgjPMMeR7KpBd30QGURoUKfG0VJuljv43WoMgQ4WTtaZiwKq1FeXO3uKGlMhwV+6PRU9h25ieKgCMLTHOsuE0Hw4V8YEmfUsZ670GnzcMF0lNlVxVnYuK6W41G00y3ogNVR8UA1tFaY97HDAAkKemfOUr1VVsN3cndGypntUmsh47kGOeA0jY1dPGiu4TRl3UwRNXHdJSapHEKhXR7VMq1K6nt3tpzVqeBB59VkkMYgEy5//E53pRH2e4V+aCkBMqySJqThJXpubuRmTyU7LvBC0rpIRtVijAq+ZrBVHwUm4KUHDbNcVPZmk6UPi2iIsN57c95lpA6zTgzcoZa2QnJPZuJCgnewdTD/ALoV3VKgw/UZM8zX7ZjUtntRppJ+kpOiWju3ZnWp6pKHRPMuyUGxREbD9K6U9gxa4t+OYTwTdNqbLKrLRcc42ndgjFfIBrrAh7ytTJ/ALobIkJ3RjUD75rIZYrrlWHNtietnmDVFzTJhAdPuUAdgfLqcnOyIyx8f3UVxdIFxlyQGAHpqQcHZwS5p7IU2ba2fj9EwQ2QyO05NgRWze9jg0h05kBRwP6jvmiHa5wkrylOiqVOV3epwZuaqqC6NVoL5zHsKmTusUlRSa2Ths5lXgQrJqOKs4N3BCSliM2S0FYVgdxIQAwHU5HH/AKbj8p/RSaBzVnZuVFN9eyMVSo4IEYhRNNIvOxOayLRp2hZPOJeDpAtEtiY1lXAVM/5x8U5gwOa06YZvVR3qYW4bgrbXzHJWIdgstDEV2bfBVhN95RIjjLAWdh/k06+XAGhW5VxUiZt3KzDNliE5VWQNPoxXHuAaeqjS1mi0FjVGyJyVCparvWVynFVQNQU+uJQedj/oUYsQ3nHNMKmv2sFJszzwzk4N2rRNqHYKfBWGmrpT4UCq2aHpjwsozv8AGUs8naqixHDUJA75fb49VIqLCODHSC9RSDAM99kzvmhbvnZKirQbEWMqBXmVJ4PFOsanpTXR2u/O3G3uOCNokP3BaxQi1dY37VV+OG8qbpNBraVDPMJ0Xrqjgc0FpF4i07merbF2RG/LPQU9ZEAaQI5qnuRZFow4T2LTZPLSbW+si14II2FAb0GtbZ4vWqQ4Duz0oza5NZDo7YFNylsU3mTVQGxvVDMIyOaDCNQ51eW3rHOGtCv923+cFM4KYw45saKiu1dtUipHxQZFvQ/iFauv7QxC6CICNzkA+CXSw2qzoIlkbLKq0Qx2ipxjpTuwCsZPJzuGAVp5JObfmnLNa2ZomUvHYb9esIOCmGnQ+i9TOa7mDdgUpkOROAG9DGZ2K1CeWngpR2B3HBVtjuXpLooXvFSiPkzcMEDOc1ZwUmvMlcu56IWfOKZbo2nFzhJMgw9Vo66/k8Oe8U+SoYrf1T+apHf+oTVMs/w/3VMpYf0qkaF8UAdCZds/ZEnRH9S1G++vNN94LzTbXthUhN73rzbPeWqz3ledB94/ZXsohieNJq9lXgz91ejxe6S1ox715px/WVTJoffVdHDaz2RL/jf/xAArEAEAAgEDAwQCAgMBAQEAAAABABEhMUFRYXGRgaGxwTDwENEg4fFAYHD/2gAIAQEAAT8h/wDwBynumTdE5V9T9g+plyrlh7zqQSz/AN2xss7ymOHvdtTGl00XT7PWIZjuT2GZkS/L9ScHq/0xzcTcflqIgA73eyMHGX+8lcrR0Db9dvWDZZp/6dNYW/2sD/jvKHIMNR6+N6Kgu5/UT+vY/e9yjCcBX+GuB5rMDXsNHn/sw6t5sPdsyxvbsecKHtj5meCtTX/0LssdGQqrtVnME1bh/cDagL4VmbX7d0cFuqUROp7VfsdZjS0YzrwT3mnM6sbjEzL3EP1Gu5fCxE9Fab7NPtDIZ5E+yE36ryweFH0gYSahF4WBRBa2q04w81FQNy//ADC2J0YqRBQbqg9xLh2rf9ZgJxWrMhyfOo/qMdm8GhLFwtsHY2jnvZNE9YqJf2E+AdotUUeGMMoVTQ7Xp6SkFEU1Wzob5l7n1KV5EaZlyxmZEqu23mB6wNt/8JY2tSglecA776RUR8XxuU/97F49prZHT4NCM6TVVawZWJRUVY642hKwCvV3rscdYtSe1ZeuZczO9ivWAAvM9tfzMCZ0nxFNse43vOV7a+Cbr92VGTXn+oOkRLyCh5Z9oYH/ACoekSeIBrubrqRoXDTQNcU7ZrnBHI1BvEhEdmrw2QEu5Y/YkqCZ5fCfcrPTx+Fm5LL34H8jDrejas8VXnpVhpOiri2lCrJdssmdhXR+l/uA/sEy89WZz9hNh5gNE/1Bjyy3Nx/AfdzQH2B4P8U2CuSKt1fOrzrB2gaNqdjmZYA4st+2pHI7ZV+j+4C6Vqw46vO8wcDCFMv0jWCy83dmUKU5tkVD1qVMs0mlNz8eBruLu2eJR7qBmTQQqDPvEwTpRezBvn94AdUoBdCKqhNfQ0o09oTSs40PGn4xVaR5GFSo2ZeaTqXod3oy2V6BjjW4veH0+dO5yc3LbA/bvM0ehohzbb4eYnKlp0q/GHrvywGyIHXpt9QIIheP6jvt8FpuhLf2SmOz8zpNU66/Z4j+v6YkbXGh7E5NZa2r6ESpos+HyivhW8/6/iYl27REhkBql4dEQdcTMLrF+qYH+CwTq7+kJ57AwcNCg0Tetf8ABv8Aks/zuXLiJnigDQnF6lvrSVUYCk1m6E3dGHDbM7qX9yx4COnK3w/zICtuDwS8c62q+T7Tcfu9ZZBi9VrwHZ8QV0zXAnc004ZvMp4RWdGr2lzPy2dWXLVHmWVV6WFsoHWqaRFARNRhM2TMdjzLcpX9J1JTmXLlxBqzqHmdGfScUd4TqWOs0vOWTzDFMKrasPUWATc2bn9RDytbz/aW5fcR6Fdut6ju79S+L/yvfBB609VfY4ing3vOoHOmiW0IQV5Cx9PVjx3aFPS8fveJgCWio+mkyYI1A3XBXRl5sB2LrNnaA30NOM4eEOIQUwEN8d4JFP5+3+LsleHidstLS8HaLrSwsK3WjJ0O1a7y8yhsGV9RpxELWc4KtDtAN05Qs7suuTzDKI2g1vfWXmTiGwlNdGOIrQhnQDXXbf8AyG0IqzNddn1iivUN9kjeRy/MfHiKM6BXuwvw7TLT4jz2U8IgLOPjFHLu5PKDj/AGCYrGniINTqMzFbTJhFbDbTOk3xslAtbtT5mQV1ULNXprsyxLM4X1PckP4sh1AASR8MrkfJgn4LsKrFHf2iOkKZ5nGsXzsEu73ncgwYurbhdwNSPlmfMNqtoby8qf9zABp8v+R8gZGIuDTueGbxUSr2v8Nc7YnIC/NRKjTt1r7j6TdXrLCJQxLLnBgaAVaBM66TC4iCUHsSC2L6x7prSBVDgZzNW/Uj2j207KCr1OssV1i1nwzBHXdmp9YEqbTrdW+esJSgYNusviRepp8wV0v6syjZtVQ9ZjsvWI41gZZO8cygS5uXU6EcovmOdyOsQTWzsafcawdgVv1H4g2WfhLLPWQBCyABAnXJ4ES5iuJSWjgldUbXpLEFOmqsx3BPPBBDRd0OWhL7S6udINw0lO01x6ZaBpzUU6pi8h6Jvgs6sVi1yooi9Nzq4YRo13lyGK6rPSAB6aLxPMYJevSaOj/wBEFsSrvXE4SN7XidVT7fh32P7zjnTQTTO+YMBBJjTaLRTBQVqZ9zrVf8CtIUDd290mkgksT4IxsWYOPHr6QaG8N4aRdT5nebMy37tD2g0+rWF/9hrNJ7sTTzKCbxslR8DcEXQxZKW+YREM1ZwxhuRlrNoxM/c/dZQqUzjLFlLKb2GXdsfs/CStB71/CaswD0HtMMMiBIzoJ/D7cRAd5MsCRUdwBlZ2UGIG82XOpUvzi89xwa/cp2FrtrfA6hmiMVUXhiwI4Q/M7FsrRRvhG0KepBTyiwZZkZwPkheQqyCHWyaMf0aAfYQgKdSWBA3BsmEJqUQMOrVyxnBqEdBuo6W4uS/6CDoIo/DxXK8fAGeUO75wCsFehD1M4s4azJ0bIr54j65J3o2aHT93YoYYGX7iQzyyC1cImovWNl87oo46238Jm6LDXtNqTpygZXDctz3iLphams94KktBpNGNl1ACaOEsoNNugs9qwqU0Ru63mkIOXReIikwGsDN0WbLZYQBJGit5bXu23yn5/EtXa/QM+1w1VljENSUW1NZjbDCxhZgY8wtARxyvPSWraVlUQZreorXZB5gErDwOuz7SgjIrdfolNqLCIqC+pcI8LorXmGaDhvfoJk3zwfwWo0694IEFD26+1J6EqvqTSElTovLXjvCrD1aTRXYLJMu32gVgA5lkAjS5WcGdYUX8A/EBgscIxxVps3Lx7RyjqxvLo3kZyy9JzgR2a5lpG0Msicn4Yt8gP69vVmIbdDRuHIrZ1p0jvh1fwxtUegvYGqWZnqNlwu+1mhI8C9R4+YMqS2HwcxzeFTnXbnpBXr81UuCGjrA1QdZfIg0xt1hHchJVldiYxM7KdTPbB6fjHJGovVwSu1eYS4YPN+6d4XcJEBDZeOsMMVNTO1NXzBgda39riMHoXcdZaEakKSVGmVQgRmuoyt0Ypqqb3uTXVt6wg076djllHymuhy/uYEvSzEi7TQl1QumYheUovmIu0SACgdYIYIdIxG9mfYP5KJ5/0dswjVPa5jF+WpmmNXARLC4mjbrrHAYmniN7AkqgtNN1TIPTH9fEDoHQw/cdmIr20vk/1Bp+oJ8W4m0dDD8x3vw/guO3RzY9nf1mK3wP62O2BtZTpMLSxeNpZ1VOo6Spj9rxHdtemkpHalZ4i0DGatd18Hn8hMiikd4nyDBk9eGbzmI4McsbXe61HftM3ThjdqDlvkJU9u1DU9694VJcWpSgeGUKJtgey3g+4JZe7P0RJam3X+3rALcfGIlhF0zNYkJyDr3mVysUX6Y2iW37Sgg3w7+0MP4DPTeG7pi9+X1fyoJSWSyymzfzSO4vgFPBidnsBT4nBGwwQ94Z9we89H1E41xud5uYHOP9Iho/YR6xe8VMC5WD5ZoSHQZ/zMF2fTKIM2HBBDY6grfE3W+jAdT2j6Z8nifBKlka39bNYXb94dRXA/8A27//2gAMAwEAAgADAAAAEPPPPPPPPPPPPPPPPPPPPPPPPPPPPv8AfzzzzzzzzzzzzzzJQ8x3nbzzzzzzzzzzzhOT3+7xpbzzzzzzzyHh2/LNKJl53CXbzzzzzDPLMAAAAAGKJvXzzzyoiNhLBo4rpTEqhfzzx0eIXEQp2D+aCjSUvzzzyqO+xY226MS9W9f3zzzz5AhZ4qQnZfbo7/Lzzzym9JllPNwuE+zGn3zzzyyeuVtOfb3kHJlVbzzzzxhKjrxg5CRhmkLzzzzzzy/2+2449w4z/wA8888888888888888888888//EACARAAMAAgIDAQEBAAAAAAAAAAABESExIEEQUWEwQHH/2gAIAQMBAT8Q/rSPgNlv92NELaDxQ9aQqwpnyWbX9ZrEbFbwI9D9BmqGxImvyuqyDwL0iO8+FTSGxRMiHtDvYasNDT0KVQ1OWoJ7Kb2G+VHSjGkGhtcTSDhWwJ6ATv5OCmEsrgiieBLBUU8VBfQmCXgarYkffCGvBS8RPrL4rkZJGEmQnkxQ1nJ0BVCjWWJloRPY8PBaxEg25TBZgSbCUpnobLJ7FSmTgqoJwecIeNkW8WiMrbFBy4EfQUoWy0ihXBIyNEqxK5LWC6MaxycsoTuSzI1UiFA6x4aSGboLNqYJ2KBvsbrvJWmPeD/TDePOvPsncfIFUKxJPZJRfgmXfmGzZXio6iy/ZX/R/8QAIBEBAQEBAAIBBQEAAAAAAAAAAQARITFBIBAwQFFhcf/aAAgBAgEBPxD8tcv7Qj4++oeZLBHUoH7tHh+iF90zXUHwJj/UepuzGDoux9nHwSR2wOtt0SrzZYWF08Ni8QfCB/cMB35cNTQ5PTJX5bH8tEWNI4Z8C8424EnpAj12ZPoyyy19AFuSj+7Tj8HOkl05D2sXMs9HIzWGNLD1a223tSDI5f3ne/j4TdRfa8pjRAM2JLieRlgCLOsh9rXDZjQ2GtI535GADdsSmzbxLp21Qt8LF6gnZwbDhIdraHVa9/EaZADt+q0k7h4julgGw1lnfd5BsNcJJwsDgk/yvDfkPLeOE+rcBtfoY26ifuRf0vCjYOeZDxsPD2OfIr4jhPJyENo5l6cZ9W10rt54kNkOCDe/YwsFl4SyzZAO2WLPyP/EACsQAQACAgEEAgEEAwADAQAAAAERIQAxQVFhcYGRobEwwdHwIEDhEGDxUP/aAAgBAQABPxD/ANan/wDGCJRIIvy4VL0QfyIyBhm6DvwSwWB/0GAZ2UAj8n+9fMoLtdA2vYvE7M5Qrt/Ao9sSMOEn7ESPJxQLk3n7XvEeo6j5cTH1Vne7wCewMUgsQGeLh94o2QDTPlA9oGDQTDCZ5/cAd3ABBRIjI/7KgVQFq4uMJoHyR85LUwTAqnQwpiYQCiBAmwaWJLmuuzcdgB6mEw6pfggtOywcO+EPr/AhnRGgeyzEdG73gCzymLjRWirl18kabkGEUO6UFyCkm7dxKjhpCBN0Yk8Io7FP9hqeYVJAqgSIhhByyMDeCX4YRCyTi1xJQamRhC5elMMvK1iRvQkHbt2wbWQDbCkroCWCVRkgU6CHSlix6yGJICxgm2p6msh48giJJtnRO2BLBX7M6d9cLZjBiQJQYQBKESp1hpSKoQLvS+5zQBuUdEEel/bErckVEGtaIMMNxE4euAJ7/wCsx67/AJRxXchBkxOkvowErrJvtIDMvARZ9ZquypEImAQvZOV15UWBJGKo5qsMMBkS/QegZFEejfjgEjP6LwrZ4/kwaQHVPwnO162H7xe6Yhvk57GU6iGAFOoDISJOcjYOUgXDA5o1DGCR+DAQiDZF7ReQX4Lk8g1/owICIAcq0Y8I2Ae+IC9OUcIQP8v1j7dcqftywwF3GSOkGDFsbMu/z/OVfD/cSeUpvfPXOd2xgHGkWTl2R/YGkq2mzkOC2FPEwQ9h5zgxBxv92mU0hwLuBke8bY+gN7kZFUHUpR5wCi91APSDmjnsr9ofbExq2PeSj8TvlFIEJ3RTE9pnti8nZJb8vcHJDeXZcAqsUHIWMhKmANaQaJH4TI7CTHieIT4jJdehIXmIfEZMq6b16kYaCqxoX3PrGYKKKDyxD9fqQipdSSPWCBwytwRRg04Y9fjIgCE8E5OXXVydYx7xAz0gEqIHYReqINKKm3dGVJF7T1GKcJBIKLq3Mn3F7Z0TkMvxzOkmcJhFjOhGesA277hTzAZHb/AcM6WE9mC1CyF+OPthiyshH4J8QmJ0zBCJcBIeh75EMglvWRDw+RgejQUQpharBVC6MbgunGeakTuMPC4YWzGMtWu8Iq8JCjtNc4oVxRKVZ238yY5ymZCAfAiPZkuMP0h4eStAD5ke8dvJ0ZUGn2Q+8kClnRbgIwtG0eOPeA44ZZSWxs9kqFwfEY0gETVMEsdDQGQFh6SeAEV7rbko8sxCXrCA+D9OO3kUn5LzgQ4E/Yp7s49XMFDJ5KFdq66GTBSh8CgAwyFm44byAqd1kyC8EMOsYkk2F9sPzkAGAg5iVr+9slxEBJym7osWKInREY+b/TjaWRvK/vklUfMifei+8gEsb4MO/hGV6WWsiI/lhEuwNRomLRUtwBrK4mGEP627ES8YBmaRnxC3fb2LgHDE0WdKYUBIkEjvc4pEi6zX5fK4ZpfO0n9DnFQCCTFwqeJXy4fowGjkITq3ly9YqSkPAl+8mUcqUI2g9qvIRGTMYJcMh0jy7zUQ054ImwKFlwjxglJyunBnOHXgMm5yTrk+P8JOuI/8XJDeDK4yVwG2WHtLVQhb6HyOwslVw2Tw8lUuC8FAtLKHn7YtMj84FW+x5/zg3GOYcweBVYAFWMQIKQgD3hN3Idsj2vT+MmZgTQsSgTuskCLlgQbjgJIRKBXoZZpOZjMQGwEKWhDO2Upu4pUnZyQAsDqY4kvDbJjQBqc9sVG0AhHuZBQw9mML0u5/GUWncg5GX9D++RbE8ozRT5wbUvF5Prk+uTOcE0YlzemJ4Pgsm2B3YxUz+RgAVz5j8YzQjGmAMIQ9HQ9uNeMEhoKmrfWT5cMNkmiMZERlib40Cu2gOXu8S1ybSMTU2IC9SJ4x9WqSCXiAIdhK2v8AGMBfNQN5NU2C4aBmNB0C+FUIVFaRpCtuB0gIjipsJDYJu6y9uSMmmCUeYkuG0vlEgFdk4BDoi3JYSJWvrKIvNE14I6DhH3SgZaKVNJ6t85a8AESAD4EKstOLrk+sTyAQ2G8OkhxbHocV5xnsvrEzoesS7Hxn/wAhgDRPBnYyfjECWjEFpCzuwXxkbkNa7VoB5pCKwXBCRBMhAODIiG8v9YbPCnBA3OGyO+Cz3wV1ylPMiAk4uryFHslIJURSHcZO5EY1ooYV0iMeMs6CtJ5VIqWWUMzhr/FMFhAQKgEQtiDEsROKjez9iL6wIntwPYqoPEPfFiRQu0iVYLVw0MHmpFgab4dbwAyoy60B+xxTNYYSfPHx7xQ0V2ajIR3If5yKbLMyd4Zfx4x9LN40UAFMGFJSbDjgxfqpEwKI7cRLOO14zDSpLOIS9cgWhFzsCkoCHYZQ+u/kwA8E1xikFSKLU3pTiKMG5iPnC9XGdw6bMcjNpp7CMG3XB0voD9ZUmTJCEordIWZYnVvDqCjS4JY73gW+hGCJLQ0jUw5IfxJ+7qtG+2bL/hXbhK+8gxCGmE9Fwkb51g8tJsGRhISQhX9ViTSCGtAr7WK1ggvsQlp3gw86snn1DQe+/wBFYevPf0wMvmiRVwpfUtY/RNdSyvfWJ94uxwOZ/s4lyERdp06wS13cDPSLC4E8gCFJWAvE4/0mRuTrgcmqzmfOV0/ih+2CyFxKep67MLrhAqoYlNj8YbQSbQVCWdrnnFigiRQT0Dl4w90bgNgdFYx59al181g5SELJCpE8HORv2TzFUMDfTDDhBTHsYLOWfRyRO1KvL3wMwReAHf5wSqEORwsoPTpv6vNR6IzTPo685Ope0ss/nph5cgHUn93lB7iLVZhhEOU3jZMtRy74RpIkifouFKo2n2RYxBVIqHoE2PUYwhb6uPPWgs/tY3U1qUu6ET7yrVU9uzrJO02cxzILucczuoG7KDVYMJokSLzOC1AExUuHJZBtgSVv4xbeRHSIfxHS8fEgaVB6MjHkVr4nWFJUilDHb7wWmXUZ7w/zjQ8NYN3pL/zHJSKwPgKxbiQk6mOuNnCNBTzEZEIEEoHVe4PjAzJWHontGMCod4KmcOzKIf7rtlbngVH8PrFBAgKAi3SaTk5weLAljqS+cQ1iU+hf9e8dtldXuX9/0dxRCm1MdLyRVaGP3WfBjvPJfecIcxbW8+YdfGWaylhRen84W4IBAh3NwwpBgjEqnzkwEKQGFDKaudsEEmHPpizU4r/EkWjMuokuyz5TlyYEWB3zjwQnCXXrGSmEkiYO+NFOxOcSPSNZsBEKoS6i7ajEUXYatHKlxqf5xKTNUTd3X8jglGBxBGmoVO7nUWTh1EyYpWoISAUgEVm5juYgIIWXsTjqhBAVE2zGndYqw4FMFWKcbuvWAOGQkhQnX3GIyMdCpHNfn4xMWqFZOYNHfDueH2YT5xNge9foij0QOUzRy59C0X4QfGGxJDWFmEiZ/bISD2QfNdNYRyWv8fy5UYElMMu/dZrBqOfGCxtEX5OdwE2DGMKBcFRgvbO9xnORlZ+W5IVN9F5KIGiKRyT7PTlsUyxRGhYi9X2wKJEkL+POOjTzr2awwDhso8Yu7cJAOTC41GMowo8lXx0xAKWqyzj8YKJ/prAIbb9B0xh6Ajg1RmUiLxG5U1BM3EiMHmRxUKJZCUO+JeGRS9EOz5wLnOQAfLt429MchIEkgvM9sSVQsQh/jEASghF9Ji3HSXSL7D5mFbAS6AQforI0aRto+J/OVNBgFs2/WSwrTyJ/vGIToAHWKQkRDC1ukXXXoYVKMaN0hvu/OJVBEY56c98nsUCgBLHgWc9W8i9JkzkFWnXp1yJNH7POLuAxTmQksSq1Nsw0VvBZcquw5i+aMGFgZd44TLBbnUOcOMAyEoE2Pc94MslFaYT/AJlzogERz3vBv3Gwd+grU4bSpSnEM1AzV3fGVL8JE8eMLMsLTLOpWh2kvSFtagJg+Qn37yfi9DxwAvKmHAsgNJ+/8ZKKgqFiGruLMrF6YQFzLCk3hhYup28d5wABOk6APcj9IU6AVkhHvM+8uRdAnXdzw7aH9/bGGPgUhN3rFWa3yGNA4Z3vrkFFcurFyeXbGWWiV2444UgQpbvnk7+cZwzIkQguG8YYfoPAPC0nhTLq+YtNtcEwdgCsJpVW8f2cncQqHh3/AOfWUIkiIaH5Xy+MM0gREfCV0nhMWoCuAP7/ADggHHWfGR+BsbA4jv8AtkZEhZgyT+gdTA10J8D/ABnrTRJM+h2twx0j0TB/Y/eIuCJAH1YqKnpWC0FpEe/V9xjFkHB/fOMpfQxUQSa09Pv7yveqFEg8Po/0hWjoEiOxx3MButS9wxHAyEwSPDOGQdJZKfjCaVzzzP8ATARyN66ZGMMGwi+h5xDAsVW4Qw+cXqiVIC7K67oT70izum1C8AW5V1GRBAg1iks3PbjEEmLbYdFRsvnIqDLtE9R4w5jrMlH9rKBLa6Be/wB5M4QmCiwLfMX9Y4SAkDDq5akEgR/NkIFplkxEvWZ5HTHIMDgj06OoYhkY3gRwdESliAQBs7DEvTLUmNQ4TFKRO8QpxzJL8E4OwoRUbNpcNo+gTHzWSoxZCj8ZJwfE7oA5D4TnP6TdjehpA4BLM7yU0awU2w+cGEXICS83xdRhw4opoHvwfVZD2WKdBQfvASJBwGD4mtOPdA29/GNOzqk27EgXimicKCZLIIcmjrmns7sTAhfRMhxIS2A85MDCvRxZA7qOmL0IN0NtceStZIQXYNyPH98YzJkZldvnH0BQUHPD4FC5ulBQR9py7yz5PnLwoNg/OP8A67UTM1rCVVgpJLMB0oe1ZypEfP0mp1gb9oUhI4jG4BiDvtiSZ6scecNwnHINwnUB3jCiv07VQlAlJBl0CXG0YtcyUNh4P/ub8skoPM84QzyQhU+sdtgRRPxvGErgSB+ceBiNFkqOMgQ7w8YtLYSyOB9/trIzngejgJ2HVrhqMMhCQk9F+g9ZxRVMXoRfWJYei0HZqUbzVPoo/h+cBTy1JjtK+YwNx4B+a+xO2NEPqUDpFI6FHLxkjlxtf700Y2hY6W5Ui6JLb+xjsqCBCo1XvJUMysuTt/3B76UUHjFkAbDrvpgwFoNmHG0IoNhHXRPYfqKlcBIEhHGJBv4OB+m6Yk6YihgCqI6ZBIpRQHzgESIn2H9TiBSBsdjiyaA8sEE+MXHBVkPoVWFmcAM+K3k1MpIIjqk03WbIzKMdHt2a7YCKqb3vVPoMaAcEJ8zikYybu+cBdVET4H75v4ZWO4fkckR0SF1bX+MpInRA5m61imxGagXqGNaASCLW3CKi7HK4NkJtLbo5VYtMh/PjCa3EgQmju8ZeoJEjmGCvFdzGWEq2UyndFe6/qshJSJI4+jbJf5kOVRDRgdCRHvFWeSCa/EYc4HQz4MfGTPkmfpYgLQyLLPaFhohkhyDhtks9Ns8FisYYb+m8FIO+PtyciG0EjokOAmFYld7xMfnzhiuz8v8AaMbyDKiXWlgkhKljpemEjuJ+UrIqN6fk8Pvot8i4qPJCT5APrFR4m/8AK52DKD6P9WP8o/8AXP/Z',
  'portafoglio':'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wgARCAJyAnIDASIAAhEBAxEB/8QAHAABAAIDAQEBAAAAAAAAAAAAAAUGAwQHAgEI/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAECAwQFBv/aAAwDAQACEAMQAAAB6oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgK0dEc4ny0Pn0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0+UY7HybRu/vznFtUNPoMBWaP1as0vtx7i1tntwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVuyczIy0w938ns81ey8xxZtPp3O987lq2Gt8XRr9J5D136Dg+i0AADXNhp7gAAAAAAAAAAAAAAAAAAAAAAAAAAAAA5d1GnERb6XJeJ2aU/Rcl6+L3UrxnPmq7XnLWB69zLpnvcH0XgBVsFIyvi+2/a4OilYbppROXoHMvvbz9NHRmAAAAAAAAAAAAAAAAAAAAAAAAAAAx5BxG42PlPDvZ7VXcXndFngNX1V9q/zqHp88ntndgAw5qcUC7RNq8vrgsUXYIrNfa9ZuLWlx90hNFtmuV9U93hCQAAAAAAAAAAAAAAAAAAAAAAAAAADV2hzWI7D8q5BN9ExnnPFR1lmUrQOiOX6R13m8BAl+t1XkvE7atuW2vq1jbutD1r0Oq2KE4uiC6/+cd/3/N784J7mO8OET1p60JkAAAAAAAAAAAAAAAAAAAAAAAYDLXuPZ6Uv8PEbmOeppWNSlSw2nBCE2ZbLRGbEhkzaObb91a+LfyUV+ywexPpXr7W8nLvDpTBvTC26ijVnrjQdfKlhHOrVlrfV0d4Hb1AAAAAAAAAAAAAAAAAAAAAAAKna+HlR6NX4Hl57nt2bP5l6ts2BnOhvfWYKAD78kY9eW5W5HDtNTkJXQ6tvkbtbqdG71j7jhaKdufYYfVWk+rklq/KRe+ndGvm7Or0AAAAAAAAAAAAAAAAAAAAAAVwpnLrHGVm5rvUPJ5qp0SEpfRPTdGoT2TLp7xWM8SWG7R8yXqUP5nfsoPJNfYiH9yqEZ6kfVUb8k/pGeZTyRfmW+WQ/ib+TEBjtpSm6t8r2mnQLrU7Z29QAAAAAAAAAAAAAAAAAAAADlXVeMm/X7O5Oyt32p1bLlvulE2rDmo2K2RfTWx7nPekcW2TY+uSPvzTqGs3tztrfoimW/GmQYwAAAB9oV8pvXXafPu3Gqtqpu2vbZnkth9HtvKBmTKAAAAAAAAAAAAAAAAAAABxPtfC4mV09rBz9uWXgdVWSq1ukYrVZVVq89mrepPTy2DYq0JhrZbRpWfPv0vMPaaISm3/xnb7u866LTzw56gAAPHtKiYeg6vZWvUiyVbupsYd350+hGeJX3MebZWoSafpLPX7BagAAAAAAAAAAAAAAAAADgne/z/W05i9+MO0DSxyKa7+7VfcRKVS378V59PylXcuvCSu5plEZsma++34z+ctcNlg/NIuu/wAz8YZ9c+8g951645RuZ16WochnFsQUhi3fP3QiKfVLfUfciZF/QefQ0tHfir4/oGdjpG+QAAAAAAAAAAAAAAAAAHj8/d44XS8x8MewAADD79kSezB+6zJV6a2lOfa3Tou+NEk9iB1rYs1Wka6WLJD7NdJDJp5q32vGFEfMGwmuhqTXuYrPm2e1aXqdCwTWoZrDqzMbn86ExsRH3Ppn+lMhNAAAAAAAAAAAAAAAAAAIjjXWuU003xj1gAAAAAfMuMje3YHXiJSG2duc6rp9L9S5tsXbQmIPcyaszu5YXEWH7WNAuzx7psAAPhCefErvyd1FswAAAAAAAAAAAAAAAAAKlzi+0XPXYGXUAAAAAAAAx5BGZd5NdfN68o3NqAwQtfumaqLLRrDAaZXL7H6cXnENsxeQefVbsGfRmIuz1e87cnUxagAAAAAAAAAAAAAAAAAHPqnY6/lt9GfSAAAAAAAAAAAB8gZaGvnt4m7tydW9x7u8D3EyamtAj+qc95/Q9x+zp8vrxfT+V9l25LgJqAAAAAAAAAAAAAAAAAByyL29fPbEMukAAAAAAAAAAB8+6hrx+/oaY+rDWLt0cFrHb4QCFmoiulEyYcnmfUQnfPz/APpLTn3BMAAAAAAAAAAAAAAAAAAcb9au5lvrDPoAAAAAAAAAAHwx6HrzanjVy/L00NrQuc5aUg1L4TW9TNO+HTYKh61qz+OA+c/pZf01+c/0bfEAAAAAAAAAAAAAAAAAADh+9GyOXRhGe4AAAAAAAAADR961qhNdLZ0pCaV+6Uy6JDPZ68jKxDJWpmGvlv8Ae+L9o25QAAAAAAAAAAAAAAAAAAODScVJ5dHwZ7gAAAAAAAANf7pWqE1AjZGO3ZpEXCrWmLBTUAfCOj9jS0wvnVOfdB15wAAAAAAAAAAAAAAAAAAOAysJN49IU2AAAAAAAAYPGraoTUACM2dbJbNY4SbroFNAGtmj5rrxsjE64dvtkNM3xAAAAAAAAAAAAAAAAAAA/O8/WrLj0hTYAAAAAAYDLp4vlqBMAADwiPe9e2cxKaO9nuEWfGkecZfPWhpnRvj+jsxfIAAAAAAAAAAAAAAAAAAD82Wqt2LLp9DPYAAAeT0wYpjcwafyYyYyagAAAMGfTmqPlYW1Ldn+ecuj351tdGTEWqBp59Ow6c/bRagAAAAAAAAAAAAAAAAAAHPuU/pelxPOskD9ptO/Nb1TTOwDL58JffgAAAAAAAI+QjJrIQFir1qWPyU1AAY8mvMat4o3UL4dAFqAAAAAAAAAAAAAAAAAAAAa3NOqD8y7nfuXRaCQEnTXb9eMMX2Xn1EgAAAAAAI2SjZpIQUzFTE2K6AANfYwTEf2zhv6J055ETUAAAAAAAAAAAAAAAAAAAAACG5T28fmKW7HyaLavyMlaa7LT9xbZEWAAAAAR0jHzXNDyl+tlznJ3aItHI/fRIyJqWSXjoeGnopxfprgP6BvkAAAAAAAAAAAAAAAAAAAAAAAABUOT/ofyfmqR6Tyyt82aPkK6Z2pki2cRYAABob+hNfHVeT9nvjaxagAAAAAAAAAAAAAAAAAAAAAAAAAAAAADFlHNeY/pjTPz3vWrnddJfJp79NfoiwAHzU2PE1ju88C/RumG4JqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZIcZpH6dgziO7tVWmtgau1XUInD785ZiE/S/wCc/wBG6cwTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACsWcfn+F/TNPieV7HmBrpYEdljTN+g+J9s05gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEHODlkP2sQM8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH/8QAMxAAAAYAAggGAgICAwEAAAAAAAECAwQFBhESExQVICEiUBAjMDIzQDFgJDRBkCU1NkP/2gAIAQEAAQUC/wBcMu2hRDcxVFI04qjiLeQJJ/pMh9uMzKs5lu9Fo2EEe7Y4NyrcD9LFeS1Jn0blfOZnsfo9zLXbWJamtit17skmW2I5Kc0ikRY6VNr2gKJ2isWHUvtfouIJWyVeHY5IYqWte4tWkdvaJgkS710q9Tk+7sWjNqY0mfX4NlGpj9FxsvyFeRS6BMsB1aIuJG3EOobWU3EoqT/i0vkYo9BbzbYTKYX3zG6eiSWspNYTzU6Y7vaVFZlIiIOsvGI7LAPkKXqi1Pm4r4ra4YryXLtbQ0UC1BWHyBMWlcKnEKH1d5xVH19TRPk/XVTmrTiTyZ5YhcIquLIfnC5kGhhxSa2twbGPR4cQWpV7FXWG6aHjdPZZZhUWckHNXHVZ1jc1vDdosnO8KSSkrSqitpLJSkMyWNrzIxpCVZttnEjKQuQty6nxWERo/A6tLbcQlWtpqjmP2856uc39CzacQ82tKVoyOqkYii5CombdA7xZwWrCMlyXRvsyodg3upghuppQW/BrUG5MvHaquar4/Dip7U1FOgo1bWo1Vbidxa3UVEJLFLBegEJrBSI0A9sqsGOmlzvL7Db7czC7Sj3PcMjctu8IeF2GzZaQyjixr/UfLRpuWpxOwsOXsYokarkWKa96RAsVe2o/NF0Yn76paUhywhthd5XICsS15BeKooVixIVix0KxTMFlbSbBuFlKqqp3XVikkpO6oDSmH232pLhTsQyXCZZqEG3BSqQ7M0rYa23IbVcEDsLhIw/cy37DuJnkJF1Xsm7iiGkO4sMOYmnLCrW2eCt5vDdshRlUqBVKAVWwQKvjEChxyBMMkNBJB5KVtYelapxxRwJSTJRB/DzanIlY7XWLy95yL6WUeHXk8wzHdJ5nxp+WJO4POE01Y2cmyeaquSa2OQTEYSEpIgpREFSWEjbmAT61D+YobPPMbFMMFXPDdRGN0RgVTCIWlSnV1dqmQkozsY9tfQDnvqCo0qWJcqPWx4EZ2zlCv6OCn/8AS9wxO9qaeOvVPaxGqb2ySRV8xQ3ORhFPDSEQ4yARZelY1LUoE9Z1gbxC2DxAwFW02WcOmUpaSJJC2aOPISolJ8KQs8S9wxPZFNkphk9X6x1lLDjbzXpm4ggcqOQOwiEDtIRA7iEHLGrWCsKpIK8hkW/Ig35DG+4YO3gKSuQzFW1YR1ltTBikWgsRE82oEefbsUW/MizN5hVacmO3KbYekVchixjPMrs4aAq7hkFX7IViAxvqWobwtFjXWygaLNY2KWobrWY3SQ3U2N1MjdbA3ZHG7Y43bGG7Yw3bHG7I43YwN1sDdTQ3SgHUjdKgdU6Ho0iInCj7z9d2u9m7DX1sPaChI/nKLSKRGXBNSW5LUyGuMcFER8FCjkCYZSNNlAOWwQ26ONrIwTzpjOWYynGNVYGNnsRstiNjsBsNgNgnDYJo2CaNgnDYZ42KwGyWI2axEZzWs+N0f8fCyNCl7Xjd0RUaqNaQTUdfdKaKPJZkpkQTQpC0ulMrzQK95hbiaqEE18RISwykEWX0oPQfjeGKZGhVdrxeenbqUSAlZKEqA0+HokiIqFeuIH8WxSvTYVNgJfEKe/XLiyWpTfhKksxkPXpqVtdssbfaNCNetqNtaXEenaoOLLSZKLwuT/kRcUE20ziaCsNW8B0IWlZdoxGeliKR8iizDcvIxJgMvh6FIiqi3S9FGiaTJia04zIr3a64bkC2skw0w6x2WtOyxTI5phTzjRPw4k5tbcqmehyW5THpLSlaHociApuxYUELStNl1zzitg4hA4qwTb7ZsXFhHOFilWbLiXmuy2Z6zE73yAyJRJN6KI0xp/wkwGXw9BkRlKmLUcSxS4JdalYjObLLRYx5LkeTCbRiSboxoUhMiPJinpMutzo7WlUWvqOx2XjriLVvddh5g01jXJBOoMcjKWgkLoP+n7Ks9ZiR35PF+Mh0IkyYojyWpBCTCZfEmteaEWc5HGuizUyq5xof52dZkyqVGUm5nthu3fRLs7Lbm4l2wTKLaEoIlxlgjI/RUeSar+ox1SvE0kY0SQ/NPzKMsqjssLruV+/hcitrND8pgMS2nvCRFZfEiqcSGpUiManYssLYejhqSlXhopGpYWFQWjB1yRu1Q3fKQCVZMgrWe2EX8ggjEJBF9FMItoSwiXHWCPMWK9XBi+XXQi6+BXOVJ5v16dGB2RR5JpeqYf541tocCNY2G3SUQdaQ6T9SkwpqVDNTqXAl1TYbfSvwS4ZBKiPxJaiGuUD1SgcaGoHXRVA6hJhVS6Ngltm4U8kbVIS208bY2sFKQCfbMEojCecpzqfQWijskxWjEoi8z00qNIS+ErSrwfgMOh6pWQdYcZNDy0BEpIStKglZkCcI+PSUQ1qxr1DX5hWoUFRoagqvimF1iAuA6kEbjRwU62f2W3Vo1dGXR63UQKS6kNymVn/h2DHdDtQHK6SgGb7QTKWEzMgmckIlsqBPNmNNJjP0k+3D6NO57LiA8qam/q/QUhKyJpTYKXJbDdjHWEqSsvyFxWFhVZGMKqGwdOoHUvg6uSN2ygonGHUHmjiPkRcomEk6Vx2XFJ5UlVygfTWhKxsaCMjmNgp76Am0YCZ0ZQS+0oaRH4SZIf6pH443zyZe6YuCk/zuy4vVlUV3Kt+uZEYOOyYOEyY2BoLbOM8GW1vynGbNkHMcbBWDYTMZMJUSi8Jn9abyZwQjp7LjM8q2FyrPtvHpS1nkmgL/AJQpChr0qJyNAdD1FXuibRSYgiStb4TfZOPpwWjKu7LjY/4sflX/AGnjBc5cg8mcMpzmcCVqSMRxSbcYXrWpfyTvdhVGjS9lxwfJH9P7JnkR8zZ5vyz8nC6enhuU6dZWHmy/zlTD86iToVHZcbn5/wCGPsunzETmU724bTlA4bY8q2r+Jz+1J+eIjVxey41P+e7yL7C1aJBZ5Jhl5M73RZ8qI2i/dIIv2gi6hmEWcNQTIZWMQuZV1cWUb/7oLWzOzYxPO2f9/wBczyJR5mJB5MxuTEw/OjOaMZTcVwKr4qgqoIwqpfIKr5SQqM+kaTrYJ5whSp1lt2bFXVeP/L9dxWkfhLPyW+TcjqkFyLxzMaahrFg1qBZbNhZGnddmxFzxE78v1nV8E32BHXK431aLLvTFwWjOx7NddWJF+/6ri8uGVzdMQucrjmn5c08msDo7PY88Sf5+o4vLic5zHeTVYWcji/AfPMTj6cGIyruzSueI/qLXlxlzmyfgqi6uJ4wv3zj6sLo0KXsy+d99NbnoMc5Mz4qsvL4VHkX5M/nln51OjV1fZi53P0TPILXn6MPmJ3trSyjcK1aRguch7qkNJ0G+zMHnZfQU5kDPP0VHkmF8c73Qiyi8C16Xi38sFOusuzxuU/1jcIgpRn6b/JmJ8Ez5WCyY8FHkFrNXA37MNo1l12exbOJbJUSk+jmRA3CBumDPP1ZXwMcmZPN8iyI1EQU6Pzw/iHg5GladnxPUnKTHkqYNEjTLWmNaY1pjWGNYoaxQ0lDP6M34kFkhXOSZmfG5ybe5RMEN9XaLihZnCXEkwHWpQIyMvrTfBnnI43/hm8m8GN6Nb2l9lt9uzwwHEPRHWpJH4kZH9OTzeVyTE+fjf9k4+rDberpu1y4jExuzwy42NJxhbUhKgpJKGkpAIyMvoOc5j3xQvk43OZzD86vRqoPbZ9dGnJs8OyIwQ8tsNPpWFNcydyP1y5zZPwMu6o9rG1pG1NjaGxrmwS0n4ZB7qkpLJPb7Koizys6OVCDUhSAhaHS1amwh0lH6rX9qZ8ODGkqiO1kJ0O4drlhzCsYw5hNQcwvNSF4esUhVTYIC48pAp62RJm9ys6GLMFjVSq82pKkjy3k5ONhDqV+pG+Sd8eD05VPfDIjKyw5HkCbAlQFtShkh0snEBDiVelE9k4YYRoUvfnEJdRZ4ZbWJEeRCdalAyS4WipIJXGf4i/DO99KnQqf0CRHakN2eGDIKS9FdakpV6DnxsFkzM+WInQifoU2FHmos8NPMhK3GFNSEr4nfiSWSXi05Zcv0WwrY09Nnh+TFDby2w28lzgcLNAjJ07f9HsqaLOFlSSoIakKSG3Ur4KQtZe/pNlQRZYn0cyGEPrQESkmFSEEnB7JuWn6XMq4cwScKFmWF5ulUVyK6N/s2/8QALhEAAQIEBAUEAgIDAAAAAAAAAQACAxESMRMgQFEQITAyQQQiUGEFQiNScHGA/9oACAEDAQE/Af8AKkKHV7nWWJ/QKo/uFFhS9zfhYgtDTzSOSIlJAeERz+EdzIeqhMgpgQvNEzPFjC88lTDb9qUJ3iSiQyzXQogHtdZBv9Vz88lEi/q3IRQ0MHlCYMmpvMc1TMU6+anlf3NKLTOYRAbzCFwnOE1UFPVOeG3WO1Y/0sR+ynFKpibrDduhC+1CeHCly/2qB4UR9Al5UVvnh6e+qcBEVAHQbGe1OjvKupTToRFlABB1JEuaez9mpj6uRTogasb6WI7ZVRNlOKv5VTE3VMTdUxN1TE3VMTdOMRqxXJkVxMtQWzEk6EQnw5pr5e1+TDftne2ocIPdpxfgeSLGuT4KpdDsmFr1U1vthoRHzlNOaInI3Tm0mWYsa5QWyeqQqGpzJaRt+JbspkXRYHJ/pvIU3N7k2lypO6dDc7msJyoKkpcYHeeLraSH3ZZcHNBToOy9zUIgVXCSoasJqwQhApsqXr37Jx0kLu6ElzRDTdYWypepxFiO2WLuMsTSQu7pSmqAqTuvcqiLqKUI7Sq28HWT76SDfrPXq3SYViuCb6p4XpfWTNJTj7U++kg36xuvXukw8YXeEOwJ19JA6pXlGEIpIKd+PYfCd+OamehodUsTlJHSQOoTw8qD5yP0sDpk8R5UG2R/nSwbdInJ4UPt4uT7aWDbozy/qmduR9tLBPLNNVZjZO7ULKri/SgyTYqmp9J1k/xkKffThxCa8HpOTrjIU6+pa8hB07KedyiHmqysQrEWJrA9A7KeU3US/wAEIm6H1k8p1/hGxN1fi6/woMkIm6qCP/AP/8QANBEAAQMCAwYDBwMFAAAAAAAAAQACAxESBCExEBMgIkBBMDJRFDNQUmFikSOBoUJwcYCx/9oACAECAQE/Af7qYifd8rfMnMOsz00ge7eVh8TebH6/BWvzfMoBvXEuzUclwdy0yVxDbh2TTUV+CAcskS3Li1ro1iX50/KpyU+ZNbaKbZZWxC5ydNO/McoQlxDc8ioMQ2YZddicOXHeR6p7gTz5FNDSeXmWHw5Dt5JrwF18jpDo1PLHMD5dVILXcpTJS0iX89eQDqgANOFvu5G/VMlYWhr+ya8yXBwy/wCLSN37JpAABV7fVVr1TnhmqOJavavQLfSeiMsncozHu9b1vdy30Yzqn8360X7hW18q30lKPOSiaD+o7yN/lCXfVdTZhdT1T2iXROxDgaAURxEh7ovcdTwWE9lGJWGrQqbz3ka3Qbm2L8qVk8vmCijljNbU6J2oWGBBNepLtVFNcfqixmI82RRw8TMjVWQ9mq0DSNVI/pC3rvUfwt875kZj86333rffet996Ex+db19Kgr2h6jnc51D1AcQap+GjlzGRThJH7z8pstwo78qdk0ed2SuJ1Kjgkk0C9jd6hSQvj8w4sKcy312Yfz9OUFbVBxbkVu2Hy5Kx0f+EMNE43t/Cc1zhdLkPROjjDL7U2V0f1Yp4gw1boeEGmYTcSD5woW0eVmqlB3SO0219VbXRBzm6qjHZ6FAuHmVbgrGeidDEW2EI4GI6FHAfK5HASDRHCTDsjE8ahNbVwCi1cdo6R+nFagXNQkHdZORaqbKLNXOVyD/AKK5qyQ6STTwbVzhb31W8aqsXL6qzhb0kmnh1VGq1q3YTArCrTsGqb0knjNUQzVgW6Clhohqh0knjwa7X+Vd0Okk8bsryzRDFFDFL2i4UVvSya+N2T+BvSya+O/Xgb0smvjd07XaE3pX6+N3R14B0snHTiGqGuym1vTW+IEOAIdPSqt8IIacAQ6mioqcYTVarVarespspxN0+BW8PZD4IWrTaPg1qp/oF//EAEgQAAEDAQIHCwkHAwMFAQAAAAEAAgMRBCESIjFBUWFxEBMgIzJQUoGRobEwM0BCYnKCksEUNENgY3PRBVPwJIOQRJOio+Hx/9oACAEBAAY/Av8AjhpLO3C6LbysSGZ3YFjWeUbCCqCbAdofd+SnSzODWNzoxWOsVn/zKfoqy1kcqH7O06LqqhMHWKLCgOBrBqEA7jLPoOT/AOLfITtGcfkgWaA8RGcviU0Bprka0ZXFYf8AUXljD+Aw3dZVLPAxmwKjmtI1oOgcLJM7Jg5HfCn2a1xgSjlNzEaQmzRVMDu8aEySM1Y4VH5Gme00ecRu0rfXZX+Cd/UJhqhBzN07gY0Yc5yDRtW+NBaMzaAdyZ9udR8eRtKXj/KoTR+ehxm6xnCIb6zcJm1S2V/4Zwm7D+RrLHpcXdn/AOp9Mu94P+dqihbkYANx0ltBwCatPgVhxuDm6Qmy2cYjMrtgy7hZ/akczvU0YyOwh9fI8ZIxu00WLNE7Y8c+WR2arh4J2DniwvqopW5HtDlZrJC7ABoXnTqWBOwOHgm2Zjy6GXMnbzG1mFeaKqfJ/clc4KVwyNwv44eCcefMwfVYhMcXs4oVZZr9QWLMexYVmlc5mgX9yENsAilyVzH+OenkcqI4f8oMN5jxCNSfYZDjwmrPaYrNNA4/aNA7lgush33avt9uGCfUbubzFfNNiNC/bbQayp7W/K84I+vCwI/vD+Tq1r7RbKuJvofqsCww77S4vyMHXn6lj2uGM6GRV8Vxdsgk1SR4Pggz+oQ7zXJI01YVvkOCJcoOZy+wWyuGLmE+HPJa4VByotNTZ397VHNBJgytxo5B/mRNdb4mw2wCgceSdiqO3c3uDjpzkYy9OtVscDMR1MCZZrN5lpy/VMhjFGMFBwXPfc1oqSpLVMMWtw8AjZ2ktgj86Rn9n+VBvMbfsVKFoCpWTbgoPicHNOcIteA5pygprak2KQ5/wz/CbbIrnsIwiO4qOb1jc7bzyYpcvquztK3mduFAcmg7Fg1Y/wBh+VcU6aH3HrjZbRKNDpEQMBp6LLyt6s7cCCt+jrWBHe48p5ynhPAyyEMQkd0S8qPC85Lxj9pvVnsjTQPvPbct6MIN17zylM2R7XRuOLTcfE7I4UW9y8qhicrVZne99Dz0WTMD2HMVhWSUx+y68Kkc9RqlVJrQANchWFapHTHQLggyJgY0ZgOHZ/3Popaf2vooaZMEKG1R/h3HVoW+MvmI83rX2m2TubhXtFELDaX75G/kO3LZTJ9ocrQBnw/Hn7GcBtWPaoR8YV9qb1AlXOkdsYsWGY9gWLZHdb//AIsWysG1yxYoB1H+U1k4ZgtNRghRjpx4J8FDhcuLinDWEQ4Ag5QUZjDyca8kgdSEkLw5mpWcQHCbFSpGq9Oe7I0VQfJc6QmQ9amlspeHEk1aaZV560/9xeetHzrzs/avOzfKmWe0vD2vrlF45yvRDrQ0n2b1iMmf1UXFWX5nrEbCzY1XSyfC2ix5Jz7z1Vxb1lY0reoLGld1BXl561yO9eaaromfKrmjsTmOIAIT7JIc+Lt0J04FbNL52nqnpIFpBBzjcJhmdG0+rSqY+B2HA4UfW4hbzH91YayP6R0BGNvnJLhqCP8ApJXYV9aZk2QCleBH+47684vkfyWjCKoSRGTixjIuNk6mq8OO0q6JvWsVoGwLGIG0q+VnasVxcdTVxdltDvhWLYyPeeAuRZ27XEq+eFuxlVjW13wsosa1Wk/EsYyu2vXma7XFCSxNwXs9UZ1vNqo2XJU5HImwyAN/tP5PVoXG2KX/AGyHLirDPX26NX+rkEcX9uLPtKDQAD6sYRtVq81Xt1DVuSwO5UbyOBH+47wPOM2l9GJj9Bqt8wsSlarCs8TWRnI6Q5Vj2trfdauNtU7lfGXe85YsEXyq4AbPJF7OLl06VR4MkWu8LjIHD3SsWKTrWBZIcH3RUrfbe7Cdlwa+JQDQABkA3BbIxVpxZB9UC01B3We+/wADziIoTWGLP0io6cvKCnQPrg1vaU18RBYRdTyl72DrV88XzhfeIu1feG9hXnj8pWOwO/2li2f/ANQVAJAPdX4vyr8T5Vyn/Ki1zzQ5asVbFNvkJ/DcCKK9+CfaXnWdqD3PaGVdeTqKukYdhV3NzrFZnapHDwVFVtXWU5fYKGnM4LS05szlh761mpxoQr7Q07L1cZHbGrFhkO00WJZu1y4uzs7CVdHT4FyiOwK+0OHxrGtJ+YrGn7lfKflXnHrlPWV/avX7Vkd2rI7tXJd2rI7tWR3avX7Vlf2rlvV0juxXTf8AirpW9i5bFh4VBpa5ONocX0fgtJ5sfI3zhxW7U+WW8XgVzlQsddjgHtRDhUHKCi+EF9mztzsV+MwquWPSg1zaSaMLKvMhebYOpcqMdi881XPJ2NKxYpnbGLFslp+VXWKTrNF9zA2yBeYiHxrk2cda5VmXnbP2L7xD2L71F8q+9R/IvvUfyL71F8q+8Q/KvPQdi5dnK/6dBxFDn4DBpcoPaq7v5sssW1xUbNARmhFT6w+qEdqBe3pZ1hQPDvEIy2OgJyxZnbE5pFCLnMdlC3yz1p0c4WDbXzDQ4P8AFV3sv1l5V1nj6xVYsUY+EK4U9CnhOWOQ8CIbVZG/pjmyFn6Y8Sryriq0wX6QsNlaD1mINtTcMdIZUHxScYPWHKCDbRQVyPHJP8IuZiydxW9yAmPOw5tiw4XVGjON3CmeG6s5WDZYK63fwqtjI+BcZFUa2fwqWmMxnSLwg6Nwc05x5QWto4t+LIgWmoO60aGpkclluaKVa5Y++x7W/wALFtUfWaeKqxwcNR5pA0YA3KglrhkIQbaKNOZ2Y7laYDtIWGypA9Zi3u2ME0Zy6Vh/09+/R54Tym7Fp8WoSwuNOkEGT0jl7isBlHTnNoW/W5zr82dbzDGXy9CJtSsWwGntSgKtqsksY6Qo8dywgGur67VhsOHAT27UJI8mcaD5MteKtNxCLrNWWz5cDOFjVYdYVWGoRGwLOFc5XEFVbhA+yVdaHnU+/wAUBbIQR0o/4TJIzVjhUHmZ/wC4O4I7lDeFxOPH0D9FRpo/oncrTBdpasNmMB6zcywn+dH4gy9awJ6A6cywoLj0cyDrRHhEZimxNnEENKve647B/KwLHJA1upwvTGQz0kw6kNdfRMkY8OuFaHIUZ7HRk+cerJt/lODm+y9jsxW9kneJPDyvGxMdtClDeTvhon06a9Qq+M9RV4cNoXKCzEIYOdWX3OZpj+q5O4FcjtIXGjfY9OdcW6/Qcu5jNo7pBVZxjdWVYLsZmgrBfytdxVY8dvfuVFDsKLoS9h9lXy195oTrRgswnCjgBQFMwocB7TlBUbJhJhgUJovPU2grFniPxK6/Z5EnQKoHS4lE7TwLwCmYN1a1Q1BWT9sczSu9pxR28KoxHaWrHG/s71RrqO6LtzjG36RlVYThjRnWCa+69cYN5k6WZYbDhR9Jt4WNincva07Qr2AFXYQV0h7Fiys67liX+65XG0DtWM8/E1Y0cTuqix7P2OWM2VvVVeeptBCxJ4j8SuNdind7BTfcJTjq4LRoCcrM3RG0d3MpOhPd7J8jjtBWJJVuh96xrjuUkaHDWqwOpqcq0c3WMi4xgB6TLu5YrqtWg7mngcoq+hWPCw9SvipsWK5zetYk3aFivYVij5XIsfv5Yc15C3txxaYNCEaAGqvZ3rI5cpXEFP1CiOsoDQKcyzO0MJ7lMfZ8pcVjDsVx3L2YJ0tuVYnB2o3FcYxzVcbljCixSDuaOHlKyrMr21WNA3sC81TYrnSNWJP2tWKWO2FHKNKs7elIPHma1n9J3gpzs8viPc1Y7A8aWZexUD6O0OuO5fGAfZuXFS9TguRhe6VjYbdqvAK5JGwq+q5QG1ecb2rlN7fJyO0klWUe1Xs5mtXuqY6/QaOAK4iVzNWULjYhINLFe7APtKrSHDVuY0TOxXNcNhWLI4bQrpm9YVzoz1rI35l5vvCocV41ppOUjyHUmnosJ5mn14I71J73omO0HaqxudGdRWLMJB7S42zV91YwezaFdM3ruV0rD8Syjt3MGPrKdtp5B51FdQU7tEdO/mY63gLa4+kXgHar4wshHWsrkwRyGj8o3Gtivkc65cZZnHY2vgqSw07le1wXKptWKQRuvXWrW/3R48zRDTL9Co9v19Mj7UTqURHq1PcsgVHtqsezxfIuLwoz7LkZbM/fWjRcexYD+X47jBpeE0KV3Sk+g5ms49s+Cg9LojqanqR2hnBuKba4Bg4Zx6ZnJrtKhGslNCi9ouPfzNZB730Vn930qqqpT1blodsHCnGgV704aCmamrqVkHsA8zWUaGlQD2B6VTcedJTRrRPSfwrR7qftTtTQE5Qs6LAO7maAfp/VMHsj0nXuE6txoQaw8XlALVjwsOy5Y8DxsNVeXt2tV07eu5Ys0Z+IKleW4BDWaqU6wE1vSfTv5nYP0x4ldXpb01dSjaQCMELHib2LFJb1rEm7Qriw9a83XYVjRSdipV7VyjerKP1AeZ6aGtCPpGrdO1N2JypwMpXKK5RV7iqkDISofZBPdzO8a2eATtvo9BwGjXuDW7yDzqXUApX9GP68zyfuN+idt9GoMvBiG4zt8gQqa1a3+6PHmeT970agy8JifsWweQGtwTQpHdKT6czzfvH0W7LwzqTlIdXDooxrTQoPaq7v5nmP6r/r6JRvkJSutPOvyDdQ3LK39Mczyn9R/wBfQr1q8jIU0LaeFq3Hamp1NNE1ugU5ncdJd6Dder/Ik6kdqaFHwdW7KdgUDelKPHmjrPl7r/KP2ILqTBqG7etXAldrKsw0Eu7BzRM3oyVGxBzch8ll3LlefKuTdicgFeVdwinO6MZ5o+02cVmYKFvSCp6uhVbRZlmWZZtzKsvoQ2po1L4ll4btiaNitUmpreaTJFxVo05nbVgzsLDmOYrjO0K68ejsG43b5ByaFI/pSfTmosmY17DmIRf/AE93+24+BRZI10b9BCx7j6NEESh5ADSQmhWfWC7tPNmBaIw8eCL7E7fG9A5UWmrSMrSr7ivqse9ukKoyegsT9iOzyDPeWwKzs6MbR3c3UtEdTmcMoRfZ+Pi1codSpm0FaDoKrGcE9ypKME6fQDqCcjdVcjvXJK9ZZe5coK5ze3dI10QGjnAmRmDJ025UXAb7F0m5toVDeFTuK4o3dEqhxXaD5aUrrVpLmggvAv2LHssPy0V0Tme68rEmmbtoVxdqB2sWLJC7rK8yHbHhX2WXqFVjxTN2tKi4pwja4FziLqc5lzRvMvSbk6wqyMqz+43IqPvC0rFx26FoOg+UlOtN2onpSE8+0ORF9l4iTR6pXHsLdDhkKpJ2qtxV2OFTIdB8k460xWfXU9/P5bI0OacoKL7C7e3dB2RYMzHRv8VSTtV9CsV1RocrxThlBN2KyD9MH8glk8bZG6Ci+wOr+m76FFr2uY8ZQVR9x8g7YmrqULeiwDu/IeDaIw7xCL7Gd+Z0fWCLTUUytKvuPCfsQGpBukgfkbj48bpjKi+Hj4tWUdSpm0FaDwCNyBumVvj+SC5zcCXpt+qLi3fIumxX3hXG/RwLP+5X8lFzBvMulmTsROBvkfSjvWWu1YworjUoy5o2HtP5M46FuF0hcVWy2jqkH1VC+Cmmp/hb2w1cb3O0n/k3/8QALBAAAgECAwcEAwEBAQAAAAAAAAERITFBUWFxgZGhsdHwECBQwTBA4WDxkP/aAAgBAQABPyH/AM4XmM+EiIa4weaigFhZ2H12E01Kt/iVGGlsYUmbmG14UcxS2oouArJ0L1B4KbVFZ86qUk0Ul6X2ZhR077uT/wARwGsPxp/ScA1DnvjC/aOnWINq0pTKoBgkjCAQ7pPydj6iEUbm9FdB3uC8ZtSGtTtP8MyED4GkjwpXJeCCJkTnzo2NkYnGrOCmYxhX1EqNCDy3YEBQfhDqivJE7iQwysA94uPX/DPWAfbkBcPRU3qBYwq7lAysVRqUqcgUGfjyiclWjuoOz0iSmgTkqDYS2n/H4eXjh1DzUfOOyJgT3ALuj6DsEpvKmyhapfkRlNrPYYnkN2sxvTQpSfUNx4NsB8m4mMc5fLu99/spbttYDvL8OpuzGAv/AEI1K9VGsGY0OMbzbgt75o1TlBdluRn8vQnIZe5LxbcB4IRtTZ1dUZR7CdKdkSP1L2YjC2C9ECuoXNlKtR5rqVN1W8cW4xw9yg1NdGUVXnj29Q647DOGn45asVlzoXENo2OITAZKDg8zuS/TPemP6+ZUAShHijAtJ+FUJpdq+0M4CVpm9hVEnoGiuVrf2A8DtL6dE/CkTXF/ooCgPax6WyiRNIWbbfwRQsJvQ3dlfMUl+iVfop6J7FFsY4LXjCEpjphOpVExZ6gAVR4oclv8ytCEqtAdm3Jq3j/RAUi6KN3YcmvYPSLTMig38aHzUmnXVmjb+iDdwpV9z2+Ptj6C4Ldb6DNeDeu24lVDaOgSGdGIZySlwr1dPTpaA8DvCBU7GH3CrJr+HzV7riZHhvyedctlrS6m1hp7khR8YvEsUqjL3u4sJDaPEyr8XBCiXq/FS3EnJbIOmrQk58YOM4wQ1tcTtlHSC4UrsQGQcHV88plHqj0QhJUvyIR5JG0TfH19hj5uQzzJY91QCGexsaYU3tEhqFE2So9hEQoQoyKiJMoADsGxwdjQuAqpdhscOPuPIwG3DszSSSYSO47i7p9xf1oQV4J/RFJZKUxKcNnySEbaEhCO4T6Shuc0ic2WCVr2EPo24N82N7V5fQhLRaq+ynO9qO2G0ZjBuPSAXR3tcte/qWQ7grBmPYKrIVqs3neDAEFJufcJ6FKsMaTUNSmXM/sCoM7RQ/6PqLhKyiajCYlvH9DMWGbfQgQML9ULD8I+RMwhtmiqUdUN7k5sonA8j79JE6U0+rgOh0RSJnGppnHQpEuMgis/DFBc/l1DfTo6KEQutYYo8DExF82vg1F1/hLmPgNy6++uGtcZoRdDOwSgOF3VCnAFn35mVGVoWBHQlboRp7K/kUI0nD0b78pJTUpYwlyk8NkhHBfn7C5OXAyTZ6jLbtxiuWEficsJuBU20Ujm0OfdDCr2aWRqt6kicKWPMrInZZUspBJQosF6O+0S5eMhSRKU167Js+QG4RLrT0Zos3SVPMS7Mg+jpkKmzPkNPxQ8h0vQ53ClpIXLdTLzuWfQnibCeyx1DqUSGknEq+xZfA7nh/oWSl6IqEY0x1mGrhsskWhIKyJKoXSIFXCEQksmtPjn0gl4nmOUl2xLpfnfaG42qPNkQ6MU7pCoueXYOTFY88DaJ8qA3Y8dB+cbefU/eM/vEzuHdba0eL95i+lBY3AQv6aMzhuxme52ULR5fKP+W7Dw+WPsoJ7n9D+wMI2bvfYQLhAGdZ7OXELH4x791diXAHUgmzlAQgKDEDkhcrrqrQj8LRrAiCs6L9iZinE0bBbd7LLDtyj+50L9uXJWjaIFzVJdVtgLpMhWwBgNq/oktvUnwOJPdW92JLp86Hiex5zsec7Hmexr3jQyW73Yjtx3YWv3sbewSZNeyNDM5f0lmLu4vjGSl0+sl9i8STO0yCgrkF4HRLb3IifFLmIX7UHU+oxhOiDiIcOQtX0BAON1BJBpKsVTCfQmOSsSLDYRLzf6CFdqRu9lTbvOBtI+Kn4zKVJ4hh0WucE31L2ku2sOt2OAB/8AYmkUdKO1WKHTaWjzLaFCfmSVL19gxr33UL1hTHboESxthVfAW4dFXUu3El7yDFcs5GZK/I0c0JawyfmQkpVJr1n85LHoo65PRogqjbByku2Vr4Sb4nxcX+xq9hKWrBIi23Z816T3i+BjZBXl2EmowaLOjJ+AVa8mg5J2bnEIFt0WjbSXnBQCNMGtkqp1zdW3LYP/ANaE8t5UVtdcKmcBUo7b+RkmBteItPQTy0ZHqMXqoy+U/wAa1isjEVC05BQQ+NUxEq/FDbXFy3GMR70JBbZa7AiJMhksaCg1vEMSs4vhtkU8Dt695WmXTKg+PjraInM130mmPVw1CuiT2RRf7ClSumdtJiPjmwY9bm6tSoDBJ/uzCntnm0Vo1MBDyGGx6WKi7i65YmYio3v2UxpTYz4HtX5asfOvxFKCi00oO3mhyrGRTk70Qc8hkBba+ONVXMEMoSWy+H7yDiTmPaLqTF4bCeLeOknpLvcayUVq/UJooNshJ4lgVJsZMzadm4SsbgsCg9DqNtcbVPKwHEfveDtEKooU2mQllTRRpll3OOi4FMutpI/wakgvJDezTnaIcJ4IiRQQzU+GfWebZV7lEN7EKSjNVo74BH6JXDuwkU85QS/isCxdpuBSxTR/2AoH1C/oALhkUOjBmEm0Nl7vi6VaknIUbIa1Wi+xYo2vsYi89DoIvsWhTnQ0CrbiElYI40K9l1LNlIe1tSWPyJ5QifCz1gkrLM5oufgWbwxHou8JNxMoy/TYfwTUntlxKRrPljyljYHNDKZT29N+mgizuuXoqWLMHciG6eD7lkee3eXj4ovzWUVyfUMQuGYG8ZWxE3yAL+QN3QYVW05XjKxkhGqrwmiZ8MK5sCi5/ku0juHqCk2Cp9NAimuNUOU5jV5s1X0lNX2l+F7e3YK04wkd4kYDIgl2vMrhvjR3uCoOrvi2JcuTgOaXX5BfC7LAQaNOv50+6C4M3jojiESHlUjUwdiuZiBN/BYoeSoc5CipoL3EuxCWqA7uRcCLMNWDAkzX4mA2lXLT9C+Fn+zxaQkeLT9GIN1RxL75BvFtD4DiHZKwa4YaR0Q6ouG1o9JFf5cMx03Il1R2ELP2INGbYTE5s4BloBv3tI8ipbxd8Tza6ffw21rkRZWbdF+pycw9U0LcdFLhJm45R1tS0AOQUgrJ3ouP8cCgIEoRl78zkVjoE7v9CdvhoF5zf0LD+wOWwOmmh0bB4C948ZoAhUdiziSW0wHkl9Z6hzvx9HCTZqT9XiC7hcxoFmNsGn4ZpqAu0s+b9tuFJVmCY0GYe/8AvEIXYOgFrUkZzzofITviTyYnuWcYfsIazh9DEm2TbJNxeXwxDn2BIek/t4Pf6GbhHiFLXte8gj2IE2id/wBGiqu0afKENuUk18Uvr4betwsL0Pl+1NMNIxvuIn1aRvT1/dpocInQaRmvmTbCHikdfv4aXMnmuw1oHQ/anhw9ZrbYNW3kl7po9HMSqamgPPBJA7H8M2BnzGwX7Ntxb00GYg2mxpySkhtWCg51Zh7lGPFY2FhWyxw60CHKmAcfpEuzhfzBGiPxBU+G0MWGDkn7CpmNmfpuAJuMkkMkQ5XgMYWdPQ5P/eWjH6jxinYGWALbEtRspaGDamaWS/Wo3Ofh2/ZAGyWesWsiFh6CwZwJBk9iXbjCMRDSrFtFkcPCCmf+m+HfZAFf66+y9m8AlEITxtx+/OSZWIksYvNPh23J5Ctmr9uLeEaE2Lvv4FOm0Quuj8O4M+h1b9Yh+2k5IeRqJF5r97cJfpe2ibZP+LyT4dpHnP6tt76t5PoeOASZRF78HvH34+RsIpJ1i3OfDt4VUL9PvH4OOeo8RzG2SL3JnY3UZWvNZM6ySM1k97Wp+GY+tM/SKWWGU2/CrZrG3wqGb7W4Us6I9N0CKBiJa+y/hjPKFX9FVFYc8t+HSZha2YfcpNtFPP2OhaL1V6zkGOUUL4druX1/M/Ti7umX42ASNVsedlDOJeslajQMnseNZkqW4gP4djtK9vErkOQlEr8TvkE82YBAzEfleNSBQn5I0kXpZkd7G20v2WE5Tu0+bMvHOLS+IR6MFfvIdHU4nwEVwaA0Ro+jPS9A86Sd2/0WhWY2QCq1+xdG97SMmNqEJnsEOb+JYPJlXHgPsyGa8hmAgSplofr1LNYqG9p/geNjA+0ycVV3BJ/firgQJyPEd4XEQJc1H27ATlSrD0Ulsurr9PeH7H2ExZ0E3+CrILmbrSRPFxvPjMkuzfYeBmfdldmYk7dQjHIh1v1i6XwS6HYtK6omSno/RoOSGhwWXZfgJD2iaGQvj1QRsaK3xVyjBP6Nw7lVCociQfaY+mkYtPz+A4DwLGEkqVFn4AsQUzBNwn4wnekyJzYdSeRTGJQxgj5DKidPezKOvh/wHBjZZ5ldSAqz/MleUoNG2hEWUJNv6G1U80rciU8wYjZswIdGvsaUrZfRX0KV3xzAZxsYDHcKtonydRdwagbarpV/g4oWJoutGNai6KQnxb8lQzQjxQ84KF865ITa6ZOhXYLlYbiJp9VsGMVCdA+PlXQrvpu406Gf4UV5ovRNpUX/AHvn7cTnKZtVir2PAY9Zrdwh0IeQp0nMXjg1M2fX30s0FjWbGojzHNT/AIF3Q4JQWXlr4ZloIjg4oWBde9oZqN0R6f8ACcyQH+D6DJSs34MQQ1qEoW9+7nBpMnoICQhYf4WGIy0V3kPYcV43YZ4BSk9F+zWb00sXJ/iK+Xhw39ilh4VtqwKPv1zm8eyEKtXDL/xVTWwqtommN/2K6KFQyF2OcdHliIxVydx3/wAZON5/+6h5mUvLDsPxApU48teC/wDTf//aAAwDAQACAAMAAAAQ88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888800888888888888888888888888888888888888DidH888888888888888888888888888888888884mQzBk8884w888888888888888888888888888888bqDUP88FOsz88888888888888888888888888888CYLvc84bQReW8888888888888888888888888888sXvU00gbOd6N238888888888888888888888888ZR3/+OQ6nNblb9sU88888888888888888888888ojEt9//wDc8THN8n89PPPPPPPPPPPPPPPPPPPPPPPGKfVF2pvPby3R7b/TlPPPPPPPPPPPPPPPPPPPPPOACc2L/c+OP/8A/wD/ALd+3NPPPPPPPPPPPPPPPPPPPPDJeRACxlvGlP8A/wD/APfGwcUVPPPPPPPPPPPPPPPPPPEnf3sNHh2X7jcMOevZPjtfPPPPPPPPPPPPPPPPPPFv/wD/AP8AnL2lcvTv73tpo/xNPPPPPPPPPPPPPPPPPPFP/wD/AP8A/wD/AMwvEFshe3//AP8ARzzzzzzzzzzzzzzzzzzwz/8A/wD/AP8A/wD/AO+5zjuvv3f5fzzzzzzzzzzzzzzzzzzy7/8A/wD/AP8A/wD/AP8A/wD/APag05eQXzzzzzzzzzzzzzzzzzzwn/8A/wD/AP8A/wD/AP8A/wD6uiP/AO8X/wA888888888888888888y//AP8A/wD/AP8A/wD/AP8Av6j7DNsFHzzzzzzzzzzzzzzzzzzxT/8A/wD/AP8A/wD/AP8A/wDPp/P/AF31zzzzzzzzzzzzzzzzzzyjj/8A/wD/AP8A/wD/AP8A9++SX/8A/wCtzzzzzzzzzzzzzzzzzzzwb/8A/wD/AP8A/wD/AO3776rX/wDrUc888888888888888888of8A/wD/AP8A/wD/AK/+++/if/8AvmtPPPPPPPPPPPPPPPPPPOMP/wD/AP8A/vPPvvvrZFe3PhfPPPPPPPPPPPPPPPPPPPOvf7/fPvvvvvvvmfvvvCvPPPPPPPPPPPPPPPPPPPPDEMdPvvvvvvvr5PvvPXPPPPPPPPPPPPPPPPPPPPPPPPDetfvvvvvqn4OD9bfPPPPPPPPPPPPPPPPPPPPPPPPKEo9fvvvprvPPDPPPPPPPPPPPPPPPPPPPPPPPPPPPLHDdvvvmePPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLJevPvIvPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLKscIfPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLHPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP/EACwRAQACAQIEBgEEAwEAAAAAAAEAETEhQRAgQFEwYXGhsfBQgZHB0XCA4fH/2gAIAQMBAT8Q/wAqGHQEBjT7xTCkAbHx+FoqxWsoDTL2q9YCqwypH4R9idJVB0rr0iCzAS4eNYg0eq+9o6JX7v8ApFO51wm8i5okQF190JNj55GyjUwMwETpI2NjqeT14zDFOXkuO9qkKlzBBNfmfKf4l9rPNIBw9Vk0doi9ovx7J9FSzPuluflNW4NtSYZqYQdsa/e8NLWvaHSc8MnVK6Op8QwyGmOYuFUMDq43lGqmN6LI4s6lQLeIu5B2jEKRlHEXY+cuxFn0lLf4n1f+T7GfYz7GfQ/8gtrPPhNdOQb01mDr3iqj9Z6cAXEqLt+z/UROaxCYhs9PilWS3nILZHrUsmRqO0YNahpQ9WXPwQemu6Ii5tccy9O0d0l2GULvpDZ4mt6GbX+01Oa+55Q0QvzP6j1BqUtkO2biW0T2l5aVwNp58XSDv0mDlStyplSDdwOWO8oBgjEOYttFNo7TLFupTvcsZi0rpMPgPZGnnMGr2lMuVYYFtc7sKOUWOuncnY09JTiP0x1Y95olzFMGw8FSZtdJn8ZXR5y6HaG6m4x5lljeLX0mbxVomKVL04tGO588ArXSbvFds/jABsmC9yTZX7ME7OnlAApiK3pMHxNvgZzUrkXx0uD4e2cVqoc+RaLpc3hbZyDrfWGhxW0WrrdajfldJFDgtRbi93S645kx7ObSppBNEPZFvgtDpXdks0ZeXlvg55scmDNrp8bPIZdZ8HGprLkwjt9UAdphtefI9Yhpnn8K/aV7Rbb6tjR1Ibl+kNry4vwa2NUY5crP+DFNSbMCajhvMn4VdRwxVdzU/wCgP//EACwRAQACAQICCQUBAQEAAAAAAAEAETEhQUBRECBhcYGRodHwMFCxweHxcID/2gAIAQIBAT8Q/wCqPQ7WCZ7HkfP1EtM9pp+/xFo69L3fZdV5Gj55Q8LC1zldpRahVdnjKDMz1/p6spzuX9kYRkb8P8plH9u5u8yw2to0YX9y7TlAeH9a8GVPKB02s/sC0O0z6+0zYexF/TLFoTJxw7SPr8/GkohS2qzw3PUlEsuQV55fx3zwUjYOoeucB2wZW145XBcuNmAXI12h378j2gwb47RRcEoV1b84W9agcrsrfsZp7AdK2YmRzp+X8fmKwWB+J2DzgMHis9h8DFRXx6YbAeIfuEwefsR/2f5Bmr5e7NdKx03O/wDfxlNTvyHyU9GII+itaXyNb72Ug1gvK/avtCLUSt3Hyuj0HFN6tTTwjYHgt9ZoV/DT8VN5uipTDCUtyHufaN9rfMshq0vav0iVr3VoTW4m5WSAK2u7XxJXjbiRCm0Uha5+f9/Mer3sf1T4EAyviwwj1mQB4H7ZTgI5h8z2nIPP+TufN9pX5fad35vtOQef8iGo93+Q5sKb3EUBP5OfO6aKbOTXz+X3wLfRwJnB2NsYDVNLngmwXd82W6wvgXee+vQbPD4MwicJ+2IPvUdtnw/ZTETRe4z8+aTIwPV7S7bsD5pCFgN7t+ukJu7sjk+bJpATXrHzs6qQH1c8zR8dmFW2JfN0VmnCZYY6NRWqJyzRYswaOLOZ7TsCRcROsBIAx4zMJD2Zng+Mzs5FPBjcxZ5p05cJn6vZHkmEjGxrzIOJiRlOcpLGFgG8U6oMAjsmC8MFPGNDmJcMNn3gtstySzeVADh6u7hPy/Tu51lm07ZgmGGYiMQ26TDhMTv+sN5cYrtF5QsgnHhMT6oXDDDp6RajnMOEzPqhXQoDBczuYhNHnLWvC4PqB0OE2HTRBwuD6YdLsdWGOPA6mwmbpMy42qB1uboC+jPhRrfWph15mmWHT3cKglMa4lEolfRzm96mUx4dEKJX0c5m6mUw4lLFGZ2OvugslJWV6JpxadolZ6ww/Yx5IiZ6rD7HVzkxOhtMPsqDmPLL/wDgL//EACwQAQABAgQFAwQDAQEAAAAAAAERACExQVFhcYGRobHB0fAgMFDhEEDxYJD/2gAIAQEAAT8Q/wDOFZ7HNB0ScPGKVCTRXu1dLV3tElIDKCXeb1UaUUSI2T/iZopN7BmuAGNEEFhLVivf4L1metn2XqtYSXWFyBaJxexF3hRpYeyrPhKcZcBpt+PY2an/AIRZ9OeHB/4dq9moDHLJqGFBVBE9XIM1m5dCg18DRNAu9i1HAPElxYl5tM9szEPJrdsynnRy43VdhlWXsK4p5qzT4fhbaXk2I8HUo6uqmjzt/wAMvYZTEsSbknKgrEdZ4OrLyKR4rDBqJNeb6cak7bIyCpA0i7aC98gx2qVAkSWbeRSXk79XQ5WZWsNTdUYMSxtpDjDUOZYcSEvo8Wmwx8QETkCa6/8ACmxYw3AeVLiJ4ySl1VJlBUaEKwVMIBuRJFmQi2CbVd56BTmUuiACAwlsqHW1QJCSNmhspoYlHIQ5VCSG1JQfsJpqPn5draPLHZoR/NuEXG3RHhpbhYJnGotAoJoB9am8DQNxBOBNxXakwLK2z6hco2c3NASOVgnMd6AAYCy39sChegGVaYKb8ZjD0agjkOmh6tD6kDNpC6HId3Snh9srF8edMT2/c34qe1S7uWHkrE5VWpvIPKWrmpLGmZuuNtzCpth+ZjjmDGE9weVMqSmZ+gqOTTEJzF0yjWTDpbSggQokIwHdYM4qToL3TiocJrBNp5ZEGeALA3VnjhWJ2xXJtsAOOrtUsQCbldVPWhELMIB6qDmoxfpQEqS5hrOwZvBqf8PrIb3sVxh56UlyW7YZWsjQNC3UEj3PQqTy+a3MaMiO4JwX5qWJUnIshGuXoqQRVnHifN1ctPzLeDFSIQjyoNH5AmRsmr2f3RrixAhza4CfsScvbYSwlhi43JiaFB6WQZONBKojGoSWB8p2rDXOk/OlmNVZbvuqbbRMgMNlFhvq0UoXOQZu6yu79Iv2WyUr0KdMFdB6QS/ug54g5k5BJcMkM6z6yhCthNEJkwzUttQs3MvPQoKNS6R/e1W9tPDcrE6dyrAnV8uXw/SJbPVGCdzSrEkG7XqxNk/MpfZeGoNTUzOTSG1wKLPKuq5mdRqVwgnF5lTqBU9rmahasOLkBSMQ7kcXn1VG6KRR5Oa6HpnQR0eMejDIy4y/VGAHc4V7DOdQSBlrI+AKXsE5lxjgJwCkvBHkt1sXedYLgRdmOVzgtQP8vskSLkIUwk4fwf4rC8/yYafFrtu4B4xPjStQ3niPh2p/M5C+GcdncvTsKyIDgLOc0PROxFRwJQkULBscBGgmC6fWZV1KH5cFFyPr1fo8R+7UaEEBGkTxS2OFwWKTYyIJhBO1xzKAPgEBjvLCLmNzt2mfQXA0wyvQGyJBmzNNwUVkcN6gOhMZTTyVPwh5H8dKkqTWuX5ad6k1qaejWZ+VAzs6z0Gmm0qcfturHkUmNKZrvoUmipeKpi0fDgK7uNNPqkKxhMVbXpehQukvcGscwk3zziD50iV0wJxEcSkvhgJCVuvhheipFM3SmbZigbPl5YqjoSSzaORuZBPfChsJX2iUnYVMu3tgxMnwrBqvh3XKXAbiay4Ia1IngJSUwgnJDr+SBoaVWAKsN8TWdJKd6nvhJg9qRO7O9vUpAAcHvI8UoQ5Rhz9WnZdZDdGhLI4rrsNHHwwxiiPSXyWmupg8FMSjvPWsQ3A+bXae9iu2qD0pCemgRo8mGo1hfIZQd4k3HWo/lmlKxmiW6tKMqpSRcEcymQzQiSJpS2emFhoMluM0kSCsAltnYInB1oAwfUAGzJuv6kEqluydu1nHapJzEcMLRoiXnTqiNyUhT0/mxIqKsAKjA/IbFroBXYpZb02Jf2Tyiil6l5sc3tQpLmz4igQmmcnvNDwHsngoGRtg81LBUyB9prg8npVJRo9m82ngCf0jGsBndDooK78Ip1eHqVdYID2KSfG2hT0yNV0Lm1CAvM2Y9+JUcuWwZcM2NQ2e1K0+czOMPRJKh7zm5wuPUpFk13BVqRxfSjo2JsWqMZOx3XQ1Xdoim5JCGBaM3litQMDt5UAJzMFh6j1+kUMD8hnx88ZSOmryoQak3psCcG+NNaYr2IZGoLxyaiohx8o0ZHUwS8r1rIXKchCoNV1k9WaHgnQPGlXFXj9m52ZmN5ty+s0AWopiNj0WOFGzO4XohR5aLH6y0ilqJA85zIqXfZA18rHWj6uIgjADI/gXhA2WHgOI1rL/ACmT+YBUJh+PJlQC6tRhMBbiydQLHNzrJ2dWQuxhwaGJSBdAbcY4NGSVPJDGZJhGX2pM3SnCevauyIvLUrbNfcr4O/CsWHwLUk4+A5U9f8wV5tQsjmeq0UIMBXQroiqPmeJq1h4xe9OtQUlxEijaTLFOoRHfUcalAzmEcyRrzjh5qzsmkLBdYvNTQ3VfhrdpCn8cRdcNddDp+mtCbIgN2rWgODV3T8nHGJS8QcOOylt5y5uRyd8TOhmGGkCRb8SzXTg8MUa9N/IoxlfhY05HMz4FYWDaiW2JaJRa5HSryGCieOY0tx+FZtZ98A9azu4FRsW5PpQeJqAYF8bUHnfO1f6ev9DX+1pXJ+dqVxD5aUpgNBmA4y9Kyz4t60jEoHxnD+9d8gKSkxpIRcNHKp+Oo8vCrsK4/jCdDk+U3YC8ikmUAKVxv1BebwqzW3XEQJHpR3TSJA4iUprHHtr6zLvReHZdi1HJpaTEGw20PZo+eX4o+zzWNT48Wrtu4vNC3CVAbzi+NKzJp6BQfA5FfLVb0L8/a1h+1Dzj/FPPRqMRwc/SvCBK+ADaj4jwVTO/jLHIbiqwYceqwd2Kr3VAoPPbDntQtHRWRCMdPokd7JUGEjnAZ2D8ZkEAatCYCObZL3Wm1re+LoZ7nOobWqW95wdHjUbJLiOIXKcd87O1/wAbtWDgJ66Jlvg0eqEJ5ms7m9IogtkIQobnPWn0ABHOpDDRhIj4Jmoy24RvSi4C2DxX+hWNR96Ak4TVhOJups9n6FQ5C9iiuEIk3H1fjF0oO/61YEZQxakp+5MziUm6fKxbMHzvQ1kSsPEF/CtBOgC4mHY0BLkv9H6DJpV+GB5dJeo5LWsmLEeid+tOze43DyXh70aBgNZdMjw5fyK3XXAbvininjFPjrUedsvf1JYixbfWFTgNC6XHA70cWJkj7hyKCxYdk57qNoklImv86WCdUrHihDAA5DWh5cxbnNPigvRIT+wrYPQPap/DlNrHx0zbYp8fD/8AuajZo2QY+SezbehzHnWIzywl3wvZoGzMgm6hfwoC3Woe4e7DvShi7LLO+6bp2ahDZRI5BieGgBU4LsuNml5tgEw2y4tnrULZY9wcPSM+GK+8LADKWTQX4VG0C6eNHuVBi1hNuSyrCJkRdWkG7QWSNu7Hh6VEjYpa0OgP1Sr3qUNzyX+2qXgMgcmlXoTLw4u8TmVCFrKQeJ+qCYbHko1Lh2B70m9JLzWWXNrCU4pUDTaR7q2E1HsWlxWyncKQ8kouYZESEj+FcGmks9hNFPLO38FDKASNXcHc0j1OXZqXDYc9teX8XG3KBXcwfO9EEbk03kLnKiXsJWFuNvu0cA0IcsZeOFSBXdT1GXjhVlVq0TAM2UMJtR98L1Wrg+QYXqWsMJxqlld2WiIbJTCCysTHapxFiSzgxgzNq25kBaOxoF9axpwFZY+g0zjGazYXckdp1+7dV2Er6/ei9unTEIdqIS8ClEtOVM+PAL60pwPxNq8zX0oQutGD3qPFWsGki9SMFNJZcY+X8NmiCcozxSn6A0oTuW2d9fNQjLMaxxx69aFwJPZD2n+Lhl+0MHnUHQXgsN/bNEJ8iVNkcuDTCb5rovy1WDG9lvfNxKJATqmFBkvwQZoEVzghoxjVmRozvBoAGkkHBg4NSmySVQsvBNQcaawFnQicZy0qPBWnpkUxDOgT0WoU/UPGgmJHH7BvYNciakYyn1Pat+3rz7/zLrQUFbDVluQizBJamyce6tM1n15Pr+Falr3P3KU3VefqiNDI0p1iogkzIL178a3QIo3g48v4lRZbVzz5zTIxzg/RrVabHkm5yq5a6IbxjzOdGz1eeU2Zc6gY9XNzyqYYyNSM6oCzVp0Unohr1ZvkpDZ9l9SirpoG8JUuaHxJKQsh8VJUdIM19DTpwgrtR7B9/SfVUWObk7eirMhp6RFOAi5BPRaCkPVHjWC5GyuY92hks5zKpv8AQH9fT/um1wQ9hVqYWjc/CwYIToJpOKZvOpS+qvf7EQ0dFvBxqPDsDicLB1amM3GUk7NYm1afCJE4OJyqdnL7ALnOaVDM+YSW61LqHECXHE5RRonWd4cOVR0qzbPB/iKHgtW2LWx/hKlo7MV5eM0OQB0odxfFm9KwEWq8TWLBoB8KvwNIO4aweuI8NM10ZE9RqI1weUMmplTsrYJEYiYnCsrom6bUQ3j5ZleAEfWsE4EldjoaH+1EVcHSebFGXhaNiPwtz4uXBNfKQy9Kx+29Z9MulPh8bSsMV0bNJZExxHOoOW3nTB6Vp5f/AAHtXWgG4ODUMIjfKiThIe9DTsg36VYljpSwTW+FCCUJqfSW0cKwz81aw4BrG15RSxB2iz5pOUWZHxWKz18A1clNkPcpMg2GO4+lSZEwsvQFKRi7JJMmrwKLnN+GbJ9Uj1r5VIdZfev7ug+eOkVafiZEPJrZUO9DFyokEXkkjUksZ0+1u1PlRp8B0pUMcl22e1IWhm47KwCeCu1TBLWSohL4dKsruxDxWJfkrtWn3pOD8ErHD7BdihMl3ZPSrST5TVg/C3pifmm9bzg6ft/R2g7NHtV/0fuNhVuOYqi+NK1Rs2HMkoC+ZI9qJAmm3Km1ZyF9SKl5F1fWa+Kw6RRZ2mTwWnezPmnxhm9YUPhZ0I3EhMPEYowoDjVJ+uY8i9KS0upxT71Op7F+G4UMfE+VfJ9D/UOjdAXrjWkRV/73oW0ML7q+9FQAxb4vS+rB6B9KBLjlPyK+FB412qw1Ik5a1Z20PHvpuMGLxRCMDHT64i/RUXUng0JbDH4fTWEg1HcPT+wHBugPmp27cz6awjjP1mndqD6UmqlbEkkzFk9v4BniGAM5LtqHQo3g+rrJqKSegqIFNo9ZTISe6d62rgk/lhZF5krYNOg0Q8us4CfJ+GjR9rVAPlvp/bJEwBLSbYmhePFbnXtWJwLhOHuV2KpKvQuJA9GjZRxg64mlQJwYk82mxhQcXUDgvCjABYix7Xb+OEzyJa+ESP3SmIRHAHlfwxZl02HrW9HnX1/twg929LvkR1j3qSax62pmSznMXgfpALhquPKjCYbRgDwDzWtCHA2hkLPet008v2qfSPqf1U2l2Ov8M8X+Dr5TIe/9ocGhT41WaWwAfOVRf5k+lRJMQPW+n1ClkWyD4nrSKLW+CHtT/wBO4VAGi9alkhYv4bQM5PxKny0R/tQi2veNZ18i6+tcXD0P3UvYp5D9/qFTj10lbQSdqZ++xWuBE6ApgkPTA/DGzL957dDYh2/s4T8GNYstbnXtUG6709K30ep/VGclVRS3Rie9GATmt+WhyT+FIVC9b/JoHkXkinglMFvWl3UeUyEqicSPZPSk3ovIe9Z7dnCgCAgLH4ZAcDeaetWjRv7Ch7FI8/A0P4kWsetqjGq6lr5LMfWhDqQ8NG1SkNYiXrCsfbidhV2iaTdxrB52S7lINtr4toqBV8YooQsIA5VceRrMutOJvns73xRh+G+JZv60pPSDt/Xwq2PR33/mAfIn0rbHxUkNykdioiwAdP5wwtWGTgqD7tBwLnSSD3RoJQZKFvL605SyfIju0Yfhcq2M+U405O7+vJLWzen0ORY+j+6iaQFILGHpW5frvVZBxiuH/AoTliDoh8D+GcGsRz4p0t08v9aCtdi6fTxfJ5p7VtELTqbw1yF+xucA8VD1oNlnSatfFE+n4ZwafCj0fZTk6q/1TMkvtSllx+nZpPlqFMvFVkP0h6/WS2QJaW/iDlM+lfABH7qPUMd1A+V/DOFZsR2H7UYH9QptOZ0pVZWX6j8htPWp7qHUlWV9Qf19cIPdvTjbpV71Jr3qf1U0Y65kdg/DNT5rdKsH9PGTj7PscJQ+OVRuhPLUH6oH7+plyzVpkWVZa+QdQrajdp9aksgG2K7v4d/qIv8ASWaDzVncLXj9jC9cD/q1Hqm9D91C6h4PT6SRYDFppcBg/i5/sVanejE8Vgir5Aen4dO2b6/0fXxyKlgX7O9x7VDrnsFS6B9T+qhGp1P6EBVgMVplgnv/ADtPtKMOXEbJnt+HNRJi6z7xASoGrVoubYVltpYfblG862qY6jv+qizTeWvhRH8y6DQzaQjCw+hLuYeRUZJebQXcKMPw2CkMCOwld2irzhjb7WGfnWFT7FLwN7dpeU4/u8QB3qE7HremAZIOhUAZB0KwAHTOkbRUMVVc36Fgul6zpNS6/l3qT+ItPUWxuRrctmWyKbY7kVZpo7VbjZl5OJXzmvlNfIa2+itR00rkOAUrHktOIvF/o7QPhrYQ+1Ll2izP5/Xumu1OUsg9aQVZhxW8H4m1m0XWxnsvrNX/AB5w9Rs8OpQsRHS8ntRN4wVJ/XSdm+h60LDIq+Y/s/YtzF7iFAF8BHrViiOdTTu/iuD9Gk32d6mtmfhL46qxeZgScGyb1HlsMXtRAovBGRpoTM0mKRR6xZOJ/T5GvUe1bTL2qU/4H2B8wRU2gfW/qji0mLOQdo/GMI2ZGG1G64NFpXpYPdh2vGpNvlodFYNS621dwfeihmHERwmsfA3x8MSjCVgqf6OyBfLXGz7Vus90+xwiPkLXwSY+tEFmHEE/joPeR0e9LJtTF6DYhv5Ogq85EORtqVBiVmY8HOpue4gdQphmOGLhOVIQVI4P3/nWX3rjwDuVFPIpJFJ8HxWX3BGsc4gPrWTfFVhZ8ZKxYcBRCWPBmgXDMooTTCPYosLAORH5CcjlmS9g49Ss8vTlHU4rm9QKxZlzg0uDIXG/zhSpzavJycqiCDGx0c/vDa3ke1TBovLTGMow3MGrJQY9cINSJNz8BJRQlwI52KWt2j946UPG5evrolhup7KVNrxn7rXAivPlMJ4MgFJcViANaPyMUWdfxZeg8SHenijiu3Li+Mc6jAeke9Dlo5eoUZT8+C2c6anBiMD3+5xVHu1uhPp+1W9vOagek/XBUcaj8oLtIBImiUo4M0Tf9bahcwQ3km3Jh2qMgdK/MzomIMmjmYlZL+fB4OdXeTxH/T7OKhuM1zi/FNmQTnH2/PnfGATbjQBKyrHuXAycKGgMI2NRwHCaXNkduZQ9T4G/RoTuVHDEc5rK51DwS31rZE9qkeo7/quEE9/1U8EXHH3n/A4zc5gOpmO5egrRYOdsB4dVNWy7rmOJvUIHePahJREczBoIIPq2S8dQPj63qY9B60ROHRQf8HCYy+RuDcqLeXthbZcsO1QwaMkOiNxqBebJWeD9Tj5Vq2qHas8O5wetCOCIP+Emn8JI/f42ZKlzmOHu5xlypWbHZyuGlHHVHy1+iLsgdUpxasRMybUH/Dm5DAK2Yc996axSCEHW8d6heHqzg0WBnAP7+hxFnIH0aMD/AIhBL0mVcRZei8SGpFb0JAa+iRvV+QbQzHrUANalnvQFYrAzNKlKnkJ0emn/AIqKYyzS9rYnnNZShTIpCJauWtwupc625YosZDI46/8Apv8A/9k=',
  'portafogli':'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wgARCAJyAnIDASIAAhEBAxEB/8QAHAABAAIDAQEBAAAAAAAAAAAAAAUGAwQHAgEI/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAECAwQFBv/aAAwDAQACEAMQAAAB6oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgK0dEc4ny0Pn0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0+UY7HybRu/vznFtUNPoMBWaP1as0vtx7i1tntwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVuyczIy0w938ns81ey8xxZtPp3O987lq2Gt8XRr9J5D136Dg+i0AADXNhp7gAAAAAAAAAAAAAAAAAAAAAAAAAAAAA5d1GnERb6XJeJ2aU/Rcl6+L3UrxnPmq7XnLWB69zLpnvcH0XgBVsFIyvi+2/a4OilYbppROXoHMvvbz9NHRmAAAAAAAAAAAAAAAAAAAAAAAAAAAx5BxG42PlPDvZ7VXcXndFngNX1V9q/zqHp88ntndgAw5qcUC7RNq8vrgsUXYIrNfa9ZuLWlx90hNFtmuV9U93hCQAAAAAAAAAAAAAAAAAAAAAAAAAADV2hzWI7D8q5BN9ExnnPFR1lmUrQOiOX6R13m8BAl+t1XkvE7atuW2vq1jbutD1r0Oq2KE4uiC6/+cd/3/N784J7mO8OET1p60JkAAAAAAAAAAAAAAAAAAAAAAAYDLXuPZ6Uv8PEbmOeppWNSlSw2nBCE2ZbLRGbEhkzaObb91a+LfyUV+ywexPpXr7W8nLvDpTBvTC26ijVnrjQdfKlhHOrVlrfV0d4Hb1AAAAAAAAAAAAAAAAAAAAAAAKna+HlR6NX4Hl57nt2bP5l6ts2BnOhvfWYKAD78kY9eW5W5HDtNTkJXQ6tvkbtbqdG71j7jhaKdufYYfVWk+rklq/KRe+ndGvm7Or0AAAAAAAAAAAAAAAAAAAAAAVwpnLrHGVm5rvUPJ5qp0SEpfRPTdGoT2TLp7xWM8SWG7R8yXqUP5nfsoPJNfYiH9yqEZ6kfVUb8k/pGeZTyRfmW+WQ/ib+TEBjtpSm6t8r2mnQLrU7Z29QAAAAAAAAAAAAAAAAAAAADlXVeMm/X7O5Oyt32p1bLlvulE2rDmo2K2RfTWx7nPekcW2TY+uSPvzTqGs3tztrfoimW/GmQYwAAAB9oV8pvXXafPu3Gqtqpu2vbZnkth9HtvKBmTKAAAAAAAAAAAAAAAAAAABxPtfC4mV09rBz9uWXgdVWSq1ukYrVZVVq89mrepPTy2DYq0JhrZbRpWfPv0vMPaaISm3/xnb7u866LTzw56gAAPHtKiYeg6vZWvUiyVbupsYd350+hGeJX3MebZWoSafpLPX7BagAAAAAAAAAAAAAAAAADgne/z/W05i9+MO0DSxyKa7+7VfcRKVS378V59PylXcuvCSu5plEZsma++34z+ctcNlg/NIuu/wAz8YZ9c+8g951645RuZ16WochnFsQUhi3fP3QiKfVLfUfciZF/QefQ0tHfir4/oGdjpG+QAAAAAAAAAAAAAAAAAHj8/d44XS8x8MewAADD79kSezB+6zJV6a2lOfa3Tou+NEk9iB1rYs1Wka6WLJD7NdJDJp5q32vGFEfMGwmuhqTXuYrPm2e1aXqdCwTWoZrDqzMbn86ExsRH3Ppn+lMhNAAAAAAAAAAAAAAAAAAIjjXWuU003xj1gAAAAAfMuMje3YHXiJSG2duc6rp9L9S5tsXbQmIPcyaszu5YXEWH7WNAuzx7psAAPhCefErvyd1FswAAAAAAAAAAAAAAAAAKlzi+0XPXYGXUAAAAAAAAx5BGZd5NdfN68o3NqAwQtfumaqLLRrDAaZXL7H6cXnENsxeQefVbsGfRmIuz1e87cnUxagAAAAAAAAAAAAAAAAAHPqnY6/lt9GfSAAAAAAAAAAAB8gZaGvnt4m7tydW9x7u8D3EyamtAj+qc95/Q9x+zp8vrxfT+V9l25LgJqAAAAAAAAAAAAAAAAAByyL29fPbEMukAAAAAAAAAAB8+6hrx+/oaY+rDWLt0cFrHb4QCFmoiulEyYcnmfUQnfPz/APpLTn3BMAAAAAAAAAAAAAAAAAAcb9au5lvrDPoAAAAAAAAAAHwx6HrzanjVy/L00NrQuc5aUg1L4TW9TNO+HTYKh61qz+OA+c/pZf01+c/0bfEAAAAAAAAAAAAAAAAAADh+9GyOXRhGe4AAAAAAAAADR961qhNdLZ0pCaV+6Uy6JDPZ68jKxDJWpmGvlv8Ae+L9o25QAAAAAAAAAAAAAAAAAAODScVJ5dHwZ7gAAAAAAAANf7pWqE1AjZGO3ZpEXCrWmLBTUAfCOj9jS0wvnVOfdB15wAAAAAAAAAAAAAAAAAAOAysJN49IU2AAAAAAAAYPGraoTUACM2dbJbNY4SbroFNAGtmj5rrxsjE64dvtkNM3xAAAAAAAAAAAAAAAAAAA/O8/WrLj0hTYAAAAAAYDLp4vlqBMAADwiPe9e2cxKaO9nuEWfGkecZfPWhpnRvj+jsxfIAAAAAAAAAAAAAAAAAAD82Wqt2LLp9DPYAAAeT0wYpjcwafyYyYyagAAAMGfTmqPlYW1Ldn+ecuj351tdGTEWqBp59Ow6c/bRagAAAAAAAAAAAAAAAAAAHPuU/pelxPOskD9ptO/Nb1TTOwDL58JffgAAAAAAAI+QjJrIQFir1qWPyU1AAY8mvMat4o3UL4dAFqAAAAAAAAAAAAAAAAAAAAa3NOqD8y7nfuXRaCQEnTXb9eMMX2Xn1EgAAAAAAI2SjZpIQUzFTE2K6AANfYwTEf2zhv6J055ETUAAAAAAAAAAAAAAAAAAAAACG5T28fmKW7HyaLavyMlaa7LT9xbZEWAAAAAR0jHzXNDyl+tlznJ3aItHI/fRIyJqWSXjoeGnopxfprgP6BvkAAAAAAAAAAAAAAAAAAAAAAAABUOT/ofyfmqR6Tyyt82aPkK6Z2pki2cRYAABob+hNfHVeT9nvjaxagAAAAAAAAAAAAAAAAAAAAAAAAAAAAADFlHNeY/pjTPz3vWrnddJfJp79NfoiwAHzU2PE1ju88C/RumG4JqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZIcZpH6dgziO7tVWmtgau1XUInD785ZiE/S/wCc/wBG6cwTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACsWcfn+F/TNPieV7HmBrpYEdljTN+g+J9s05gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEHODlkP2sQM8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH/8QAMxAAAAYAAggGAgICAwEAAAAAAAECAwQFBhESExQVICEiUBAjMDIzQDFgJDRBkCU1NkP/2gAIAQEAAQUC/wBcMu2hRDcxVFI04qjiLeQJJ/pMh9uMzKs5lu9Fo2EEe7Y4NyrcD9LFeS1Jn0blfOZnsfo9zLXbWJamtit17skmW2I5Kc0ikRY6VNr2gKJ2isWHUvtfouIJWyVeHY5IYqWte4tWkdvaJgkS710q9Tk+7sWjNqY0mfX4NlGpj9FxsvyFeRS6BMsB1aIuJG3EOobWU3EoqT/i0vkYo9BbzbYTKYX3zG6eiSWspNYTzU6Y7vaVFZlIiIOsvGI7LAPkKXqi1Pm4r4ra4YryXLtbQ0UC1BWHyBMWlcKnEKH1d5xVH19TRPk/XVTmrTiTyZ5YhcIquLIfnC5kGhhxSa2twbGPR4cQWpV7FXWG6aHjdPZZZhUWckHNXHVZ1jc1vDdosnO8KSSkrSqitpLJSkMyWNrzIxpCVZttnEjKQuQty6nxWERo/A6tLbcQlWtpqjmP2856uc39CzacQ82tKVoyOqkYii5CombdA7xZwWrCMlyXRvsyodg3upghuppQW/BrUG5MvHaquar4/Dip7U1FOgo1bWo1Vbidxa3UVEJLFLBegEJrBSI0A9sqsGOmlzvL7Db7czC7Sj3PcMjctu8IeF2GzZaQyjixr/UfLRpuWpxOwsOXsYokarkWKa96RAsVe2o/NF0Yn76paUhywhthd5XICsS15BeKooVixIVix0KxTMFlbSbBuFlKqqp3XVikkpO6oDSmH232pLhTsQyXCZZqEG3BSqQ7M0rYa23IbVcEDsLhIw/cy37DuJnkJF1Xsm7iiGkO4sMOYmnLCrW2eCt5vDdshRlUqBVKAVWwQKvjEChxyBMMkNBJB5KVtYelapxxRwJSTJRB/DzanIlY7XWLy95yL6WUeHXk8wzHdJ5nxp+WJO4POE01Y2cmyeaquSa2OQTEYSEpIgpREFSWEjbmAT61D+YobPPMbFMMFXPDdRGN0RgVTCIWlSnV1dqmQkozsY9tfQDnvqCo0qWJcqPWx4EZ2zlCv6OCn/8AS9wxO9qaeOvVPaxGqb2ySRV8xQ3ORhFPDSEQ4yARZelY1LUoE9Z1gbxC2DxAwFW02WcOmUpaSJJC2aOPISolJ8KQs8S9wxPZFNkphk9X6x1lLDjbzXpm4ggcqOQOwiEDtIRA7iEHLGrWCsKpIK8hkW/Ig35DG+4YO3gKSuQzFW1YR1ltTBikWgsRE82oEefbsUW/MizN5hVacmO3KbYekVchixjPMrs4aAq7hkFX7IViAxvqWobwtFjXWygaLNY2KWobrWY3SQ3U2N1MjdbA3ZHG7Y43bGG7Yw3bHG7I43YwN1sDdTQ3SgHUjdKgdU6Ho0iInCj7z9d2u9m7DX1sPaChI/nKLSKRGXBNSW5LUyGuMcFER8FCjkCYZSNNlAOWwQ26ONrIwTzpjOWYynGNVYGNnsRstiNjsBsNgNgnDYJo2CaNgnDYZ42KwGyWI2axEZzWs+N0f8fCyNCl7Xjd0RUaqNaQTUdfdKaKPJZkpkQTQpC0ulMrzQK95hbiaqEE18RISwykEWX0oPQfjeGKZGhVdrxeenbqUSAlZKEqA0+HokiIqFeuIH8WxSvTYVNgJfEKe/XLiyWpTfhKksxkPXpqVtdssbfaNCNetqNtaXEenaoOLLSZKLwuT/kRcUE20ziaCsNW8B0IWlZdoxGeliKR8iizDcvIxJgMvh6FIiqi3S9FGiaTJia04zIr3a64bkC2skw0w6x2WtOyxTI5phTzjRPw4k5tbcqmehyW5THpLSlaHociApuxYUELStNl1zzitg4hA4qwTb7ZsXFhHOFilWbLiXmuy2Z6zE73yAyJRJN6KI0xp/wkwGXw9BkRlKmLUcSxS4JdalYjObLLRYx5LkeTCbRiSboxoUhMiPJinpMutzo7WlUWvqOx2XjriLVvddh5g01jXJBOoMcjKWgkLoP+n7Ks9ZiR35PF+Mh0IkyYojyWpBCTCZfEmteaEWc5HGuizUyq5xof52dZkyqVGUm5nthu3fRLs7Lbm4l2wTKLaEoIlxlgjI/RUeSar+ox1SvE0kY0SQ/NPzKMsqjssLruV+/hcitrND8pgMS2nvCRFZfEiqcSGpUiManYssLYejhqSlXhopGpYWFQWjB1yRu1Q3fKQCVZMgrWe2EX8ggjEJBF9FMItoSwiXHWCPMWK9XBi+XXQi6+BXOVJ5v16dGB2RR5JpeqYf541tocCNY2G3SUQdaQ6T9SkwpqVDNTqXAl1TYbfSvwS4ZBKiPxJaiGuUD1SgcaGoHXRVA6hJhVS6Ngltm4U8kbVIS208bY2sFKQCfbMEojCecpzqfQWijskxWjEoi8z00qNIS+ErSrwfgMOh6pWQdYcZNDy0BEpIStKglZkCcI+PSUQ1qxr1DX5hWoUFRoagqvimF1iAuA6kEbjRwU62f2W3Vo1dGXR63UQKS6kNymVn/h2DHdDtQHK6SgGb7QTKWEzMgmckIlsqBPNmNNJjP0k+3D6NO57LiA8qam/q/QUhKyJpTYKXJbDdjHWEqSsvyFxWFhVZGMKqGwdOoHUvg6uSN2ygonGHUHmjiPkRcomEk6Vx2XFJ5UlVygfTWhKxsaCMjmNgp76Am0YCZ0ZQS+0oaRH4SZIf6pH443zyZe6YuCk/zuy4vVlUV3Kt+uZEYOOyYOEyY2BoLbOM8GW1vynGbNkHMcbBWDYTMZMJUSi8Jn9abyZwQjp7LjM8q2FyrPtvHpS1nkmgL/AJQpChr0qJyNAdD1FXuibRSYgiStb4TfZOPpwWjKu7LjY/4sflX/AGnjBc5cg8mcMpzmcCVqSMRxSbcYXrWpfyTvdhVGjS9lxwfJH9P7JnkR8zZ5vyz8nC6enhuU6dZWHmy/zlTD86iToVHZcbn5/wCGPsunzETmU724bTlA4bY8q2r+Jz+1J+eIjVxey41P+e7yL7C1aJBZ5Jhl5M73RZ8qI2i/dIIv2gi6hmEWcNQTIZWMQuZV1cWUb/7oLWzOzYxPO2f9/wBczyJR5mJB5MxuTEw/OjOaMZTcVwKr4qgqoIwqpfIKr5SQqM+kaTrYJ5whSp1lt2bFXVeP/L9dxWkfhLPyW+TcjqkFyLxzMaahrFg1qBZbNhZGnddmxFzxE78v1nV8E32BHXK431aLLvTFwWjOx7NddWJF+/6ri8uGVzdMQucrjmn5c08msDo7PY88Sf5+o4vLic5zHeTVYWcji/AfPMTj6cGIyruzSueI/qLXlxlzmyfgqi6uJ4wv3zj6sLo0KXsy+d99NbnoMc5Mz4qsvL4VHkX5M/nln51OjV1fZi53P0TPILXn6MPmJ3trSyjcK1aRguch7qkNJ0G+zMHnZfQU5kDPP0VHkmF8c73Qiyi8C16Xi38sFOusuzxuU/1jcIgpRn6b/JmJ8Ez5WCyY8FHkFrNXA37MNo1l12exbOJbJUSk+jmRA3CBumDPP1ZXwMcmZPN8iyI1EQU6Pzw/iHg5GladnxPUnKTHkqYNEjTLWmNaY1pjWGNYoaxQ0lDP6M34kFkhXOSZmfG5ybe5RMEN9XaLihZnCXEkwHWpQIyMvrTfBnnI43/hm8m8GN6Nb2l9lt9uzwwHEPRHWpJH4kZH9OTzeVyTE+fjf9k4+rDberpu1y4jExuzwy42NJxhbUhKgpJKGkpAIyMvoOc5j3xQvk43OZzD86vRqoPbZ9dGnJs8OyIwQ8tsNPpWFNcydyP1y5zZPwMu6o9rG1pG1NjaGxrmwS0n4ZB7qkpLJPb7Koizys6OVCDUhSAhaHS1amwh0lH6rX9qZ8ODGkqiO1kJ0O4drlhzCsYw5hNQcwvNSF4esUhVTYIC48pAp62RJm9ys6GLMFjVSq82pKkjy3k5ONhDqV+pG+Sd8eD05VPfDIjKyw5HkCbAlQFtShkh0snEBDiVelE9k4YYRoUvfnEJdRZ4ZbWJEeRCdalAyS4WipIJXGf4i/DO99KnQqf0CRHakN2eGDIKS9FdakpV6DnxsFkzM+WInQifoU2FHmos8NPMhK3GFNSEr4nfiSWSXi05Zcv0WwrY09Nnh+TFDby2w28lzgcLNAjJ07f9HsqaLOFlSSoIakKSG3Ur4KQtZe/pNlQRZYn0cyGEPrQESkmFSEEnB7JuWn6XMq4cwScKFmWF5ulUVyK6N/s2/8QALhEAAQIEBAUEAgIDAAAAAAAAAQACAxESMRMgQFEQITAyQQQiUGEFQiNScHGA/9oACAEDAQE/Af8AKkKHV7nWWJ/QKo/uFFhS9zfhYgtDTzSOSIlJAeERz+EdzIeqhMgpgQvNEzPFjC88lTDb9qUJ3iSiQyzXQogHtdZBv9Vz88lEi/q3IRQ0MHlCYMmpvMc1TMU6+anlf3NKLTOYRAbzCFwnOE1UFPVOeG3WO1Y/0sR+ynFKpibrDduhC+1CeHCly/2qB4UR9Al5UVvnh6e+qcBEVAHQbGe1OjvKupTToRFlABB1JEuaez9mpj6uRTogasb6WI7ZVRNlOKv5VTE3VMTdUxN1TE3VMTdOMRqxXJkVxMtQWzEk6EQnw5pr5e1+TDftne2ocIPdpxfgeSLGuT4KpdDsmFr1U1vthoRHzlNOaInI3Tm0mWYsa5QWyeqQqGpzJaRt+JbspkXRYHJ/pvIU3N7k2lypO6dDc7msJyoKkpcYHeeLraSH3ZZcHNBToOy9zUIgVXCSoasJqwQhApsqXr37Jx0kLu6ElzRDTdYWypepxFiO2WLuMsTSQu7pSmqAqTuvcqiLqKUI7Sq28HWT76SDfrPXq3SYViuCb6p4XpfWTNJTj7U++kg36xuvXukw8YXeEOwJ19JA6pXlGEIpIKd+PYfCd+OamehodUsTlJHSQOoTw8qD5yP0sDpk8R5UG2R/nSwbdInJ4UPt4uT7aWDbozy/qmduR9tLBPLNNVZjZO7ULKri/SgyTYqmp9J1k/xkKffThxCa8HpOTrjIU6+pa8hB07KedyiHmqysQrEWJrA9A7KeU3US/wAEIm6H1k8p1/hGxN1fi6/woMkIm6qCP/AP/8QANBEAAQMCAwYDBwMFAAAAAAAAAQACAxESBCExEBMgIkBBMDJRFDNQUmFikSOBoUJwcYCx/9oACAECAQE/Af7qYifd8rfMnMOsz00ge7eVh8TebH6/BWvzfMoBvXEuzUclwdy0yVxDbh2TTUV+CAcskS3Li1ro1iX50/KpyU+ZNbaKbZZWxC5ydNO/McoQlxDc8ioMQ2YZddicOXHeR6p7gTz5FNDSeXmWHw5Dt5JrwF18jpDo1PLHMD5dVILXcpTJS0iX89eQDqgANOFvu5G/VMlYWhr+ya8yXBwy/wCLSN37JpAABV7fVVr1TnhmqOJavavQLfSeiMsncozHu9b1vdy30Yzqn8360X7hW18q30lKPOSiaD+o7yN/lCXfVdTZhdT1T2iXROxDgaAURxEh7ovcdTwWE9lGJWGrQqbz3ka3Qbm2L8qVk8vmCijljNbU6J2oWGBBNepLtVFNcfqixmI82RRw8TMjVWQ9mq0DSNVI/pC3rvUfwt875kZj86333rffet996Ex+db19Kgr2h6jnc51D1AcQap+GjlzGRThJH7z8pstwo78qdk0ed2SuJ1Kjgkk0C9jd6hSQvj8w4sKcy312Yfz9OUFbVBxbkVu2Hy5Kx0f+EMNE43t/Cc1zhdLkPROjjDL7U2V0f1Yp4gw1boeEGmYTcSD5woW0eVmqlB3SO0219VbXRBzm6qjHZ6FAuHmVbgrGeidDEW2EI4GI6FHAfK5HASDRHCTDsjE8ahNbVwCi1cdo6R+nFagXNQkHdZORaqbKLNXOVyD/AKK5qyQ6STTwbVzhb31W8aqsXL6qzhb0kmnh1VGq1q3YTArCrTsGqb0knjNUQzVgW6Clhohqh0knjwa7X+Vd0Okk8bsryzRDFFDFL2i4UVvSya+N2T+BvSya+O/Xgb0smvjd07XaE3pX6+N3R14B0snHTiGqGuym1vTW+IEOAIdPSqt8IIacAQ6mioqcYTVarVarespspxN0+BW8PZD4IWrTaPg1qp/oF//EAEgQAAEDAQIHCwkHAwMFAQAAAAEAAgMRBCESIjFBUWFxEBMgIzJQUoGRobEwM0BCYnKCksEUNENgY3PRBVPwJIOQRJOio+Hx/9oACAEBAAY/Av8AjhpLO3C6LbysSGZ3YFjWeUbCCqCbAdofd+SnSzODWNzoxWOsVn/zKfoqy1kcqH7O06LqqhMHWKLCgOBrBqEA7jLPoOT/AOLfITtGcfkgWaA8RGcviU0Bprka0ZXFYf8AUXljD+Aw3dZVLPAxmwKjmtI1oOgcLJM7Jg5HfCn2a1xgSjlNzEaQmzRVMDu8aEySM1Y4VH5Gme00ecRu0rfXZX+Cd/UJhqhBzN07gY0Yc5yDRtW+NBaMzaAdyZ9udR8eRtKXj/KoTR+ehxm6xnCIb6zcJm1S2V/4Zwm7D+RrLHpcXdn/AOp9Mu94P+dqihbkYANx0ltBwCatPgVhxuDm6Qmy2cYjMrtgy7hZ/akczvU0YyOwh9fI8ZIxu00WLNE7Y8c+WR2arh4J2DniwvqopW5HtDlZrJC7ABoXnTqWBOwOHgm2Zjy6GXMnbzG1mFeaKqfJ/clc4KVwyNwv44eCcefMwfVYhMcXs4oVZZr9QWLMexYVmlc5mgX9yENsAilyVzH+OenkcqI4f8oMN5jxCNSfYZDjwmrPaYrNNA4/aNA7lgush33avt9uGCfUbubzFfNNiNC/bbQayp7W/K84I+vCwI/vD+Tq1r7RbKuJvofqsCww77S4vyMHXn6lj2uGM6GRV8Vxdsgk1SR4Pggz+oQ7zXJI01YVvkOCJcoOZy+wWyuGLmE+HPJa4VByotNTZ397VHNBJgytxo5B/mRNdb4mw2wCgceSdiqO3c3uDjpzkYy9OtVscDMR1MCZZrN5lpy/VMhjFGMFBwXPfc1oqSpLVMMWtw8AjZ2ktgj86Rn9n+VBvMbfsVKFoCpWTbgoPicHNOcIteA5pygprak2KQ5/wz/CbbIrnsIwiO4qOb1jc7bzyYpcvquztK3mduFAcmg7Fg1Y/wBh+VcU6aH3HrjZbRKNDpEQMBp6LLyt6s7cCCt+jrWBHe48p5ynhPAyyEMQkd0S8qPC85Lxj9pvVnsjTQPvPbct6MIN17zylM2R7XRuOLTcfE7I4UW9y8qhicrVZne99Dz0WTMD2HMVhWSUx+y68Kkc9RqlVJrQANchWFapHTHQLggyJgY0ZgOHZ/3Popaf2vooaZMEKG1R/h3HVoW+MvmI83rX2m2TubhXtFELDaX75G/kO3LZTJ9ocrQBnw/Hn7GcBtWPaoR8YV9qb1AlXOkdsYsWGY9gWLZHdb//AIsWysG1yxYoB1H+U1k4ZgtNRghRjpx4J8FDhcuLinDWEQ4Ag5QUZjDyca8kgdSEkLw5mpWcQHCbFSpGq9Oe7I0VQfJc6QmQ9amlspeHEk1aaZV560/9xeetHzrzs/avOzfKmWe0vD2vrlF45yvRDrQ0n2b1iMmf1UXFWX5nrEbCzY1XSyfC2ix5Jz7z1Vxb1lY0reoLGld1BXl561yO9eaaromfKrmjsTmOIAIT7JIc+Lt0J04FbNL52nqnpIFpBBzjcJhmdG0+rSqY+B2HA4UfW4hbzH91YayP6R0BGNvnJLhqCP8ApJXYV9aZk2QCleBH+47684vkfyWjCKoSRGTixjIuNk6mq8OO0q6JvWsVoGwLGIG0q+VnasVxcdTVxdltDvhWLYyPeeAuRZ27XEq+eFuxlVjW13wsosa1Wk/EsYyu2vXma7XFCSxNwXs9UZ1vNqo2XJU5HImwyAN/tP5PVoXG2KX/AGyHLirDPX26NX+rkEcX9uLPtKDQAD6sYRtVq81Xt1DVuSwO5UbyOBH+47wPOM2l9GJj9Bqt8wsSlarCs8TWRnI6Q5Vj2trfdauNtU7lfGXe85YsEXyq4AbPJF7OLl06VR4MkWu8LjIHD3SsWKTrWBZIcH3RUrfbe7Cdlwa+JQDQABkA3BbIxVpxZB9UC01B3We+/wADziIoTWGLP0io6cvKCnQPrg1vaU18RBYRdTyl72DrV88XzhfeIu1feG9hXnj8pWOwO/2li2f/ANQVAJAPdX4vyr8T5Vyn/Ki1zzQ5asVbFNvkJ/DcCKK9+CfaXnWdqD3PaGVdeTqKukYdhV3NzrFZnapHDwVFVtXWU5fYKGnM4LS05szlh761mpxoQr7Q07L1cZHbGrFhkO00WJZu1y4uzs7CVdHT4FyiOwK+0OHxrGtJ+YrGn7lfKflXnHrlPWV/avX7Vkd2rI7tXJd2rI7tWR3avX7Vlf2rlvV0juxXTf8AirpW9i5bFh4VBpa5ONocX0fgtJ5sfI3zhxW7U+WW8XgVzlQsddjgHtRDhUHKCi+EF9mztzsV+MwquWPSg1zaSaMLKvMhebYOpcqMdi881XPJ2NKxYpnbGLFslp+VXWKTrNF9zA2yBeYiHxrk2cda5VmXnbP2L7xD2L71F8q+9R/IvvUfyL71F8q+8Q/KvPQdi5dnK/6dBxFDn4DBpcoPaq7v5sssW1xUbNARmhFT6w+qEdqBe3pZ1hQPDvEIy2OgJyxZnbE5pFCLnMdlC3yz1p0c4WDbXzDQ4P8AFV3sv1l5V1nj6xVYsUY+EK4U9CnhOWOQ8CIbVZG/pjmyFn6Y8Sryriq0wX6QsNlaD1mINtTcMdIZUHxScYPWHKCDbRQVyPHJP8IuZiydxW9yAmPOw5tiw4XVGjON3CmeG6s5WDZYK63fwqtjI+BcZFUa2fwqWmMxnSLwg6Nwc05x5QWto4t+LIgWmoO60aGpkclluaKVa5Y++x7W/wALFtUfWaeKqxwcNR5pA0YA3KglrhkIQbaKNOZ2Y7laYDtIWGypA9Zi3u2ME0Zy6Vh/09+/R54Tym7Fp8WoSwuNOkEGT0jl7isBlHTnNoW/W5zr82dbzDGXy9CJtSsWwGntSgKtqsksY6Qo8dywgGur67VhsOHAT27UJI8mcaD5MteKtNxCLrNWWz5cDOFjVYdYVWGoRGwLOFc5XEFVbhA+yVdaHnU+/wAUBbIQR0o/4TJIzVjhUHmZ/wC4O4I7lDeFxOPH0D9FRpo/oncrTBdpasNmMB6zcywn+dH4gy9awJ6A6cywoLj0cyDrRHhEZimxNnEENKve647B/KwLHJA1upwvTGQz0kw6kNdfRMkY8OuFaHIUZ7HRk+cerJt/lODm+y9jsxW9kneJPDyvGxMdtClDeTvhon06a9Qq+M9RV4cNoXKCzEIYOdWX3OZpj+q5O4FcjtIXGjfY9OdcW6/Qcu5jNo7pBVZxjdWVYLsZmgrBfytdxVY8dvfuVFDsKLoS9h9lXy195oTrRgswnCjgBQFMwocB7TlBUbJhJhgUJovPU2grFniPxK6/Z5EnQKoHS4lE7TwLwCmYN1a1Q1BWT9sczSu9pxR28KoxHaWrHG/s71RrqO6LtzjG36RlVYThjRnWCa+69cYN5k6WZYbDhR9Jt4WNincva07Qr2AFXYQV0h7Fiys67liX+65XG0DtWM8/E1Y0cTuqix7P2OWM2VvVVeeptBCxJ4j8SuNdind7BTfcJTjq4LRoCcrM3RG0d3MpOhPd7J8jjtBWJJVuh96xrjuUkaHDWqwOpqcq0c3WMi4xgB6TLu5YrqtWg7mngcoq+hWPCw9SvipsWK5zetYk3aFivYVij5XIsfv5Yc15C3txxaYNCEaAGqvZ3rI5cpXEFP1CiOsoDQKcyzO0MJ7lMfZ8pcVjDsVx3L2YJ0tuVYnB2o3FcYxzVcbljCixSDuaOHlKyrMr21WNA3sC81TYrnSNWJP2tWKWO2FHKNKs7elIPHma1n9J3gpzs8viPc1Y7A8aWZexUD6O0OuO5fGAfZuXFS9TguRhe6VjYbdqvAK5JGwq+q5QG1ecb2rlN7fJyO0klWUe1Xs5mtXuqY6/QaOAK4iVzNWULjYhINLFe7APtKrSHDVuY0TOxXNcNhWLI4bQrpm9YVzoz1rI35l5vvCocV41ppOUjyHUmnosJ5mn14I71J73omO0HaqxudGdRWLMJB7S42zV91YwezaFdM3ruV0rD8Syjt3MGPrKdtp5B51FdQU7tEdO/mY63gLa4+kXgHar4wshHWsrkwRyGj8o3Gtivkc65cZZnHY2vgqSw07le1wXKptWKQRuvXWrW/3R48zRDTL9Co9v19Mj7UTqURHq1PcsgVHtqsezxfIuLwoz7LkZbM/fWjRcexYD+X47jBpeE0KV3Sk+g5ms49s+Cg9LojqanqR2hnBuKba4Bg4Zx6ZnJrtKhGslNCi9ouPfzNZB730Vn930qqqpT1blodsHCnGgV704aCmamrqVkHsA8zWUaGlQD2B6VTcedJTRrRPSfwrR7qftTtTQE5Qs6LAO7maAfp/VMHsj0nXuE6txoQaw8XlALVjwsOy5Y8DxsNVeXt2tV07eu5Ys0Z+IKleW4BDWaqU6wE1vSfTv5nYP0x4ldXpb01dSjaQCMELHib2LFJb1rEm7Qriw9a83XYVjRSdipV7VyjerKP1AeZ6aGtCPpGrdO1N2JypwMpXKK5RV7iqkDISofZBPdzO8a2eATtvo9BwGjXuDW7yDzqXUApX9GP68zyfuN+idt9GoMvBiG4zt8gQqa1a3+6PHmeT970agy8JifsWweQGtwTQpHdKT6czzfvH0W7LwzqTlIdXDooxrTQoPaq7v5nmP6r/r6JRvkJSutPOvyDdQ3LK39Mczyn9R/wBfQr1q8jIU0LaeFq3Hamp1NNE1ugU5ncdJd6Dder/Ik6kdqaFHwdW7KdgUDelKPHmjrPl7r/KP2ILqTBqG7etXAldrKsw0Eu7BzRM3oyVGxBzch8ll3LlefKuTdicgFeVdwinO6MZ5o+02cVmYKFvSCp6uhVbRZlmWZZtzKsvoQ2po1L4ll4btiaNitUmpreaTJFxVo05nbVgzsLDmOYrjO0K68ejsG43b5ByaFI/pSfTmosmY17DmIRf/AE93+24+BRZI10b9BCx7j6NEESh5ADSQmhWfWC7tPNmBaIw8eCL7E7fG9A5UWmrSMrSr7ivqse9ukKoyegsT9iOzyDPeWwKzs6MbR3c3UtEdTmcMoRfZ+Pi1codSpm0FaDoKrGcE9ypKME6fQDqCcjdVcjvXJK9ZZe5coK5ze3dI10QGjnAmRmDJ025UXAb7F0m5toVDeFTuK4o3dEqhxXaD5aUrrVpLmggvAv2LHssPy0V0Tme68rEmmbtoVxdqB2sWLJC7rK8yHbHhX2WXqFVjxTN2tKi4pwja4FziLqc5lzRvMvSbk6wqyMqz+43IqPvC0rFx26FoOg+UlOtN2onpSE8+0ORF9l4iTR6pXHsLdDhkKpJ2qtxV2OFTIdB8k460xWfXU9/P5bI0OacoKL7C7e3dB2RYMzHRv8VSTtV9CsV1RocrxThlBN2KyD9MH8glk8bZG6Ci+wOr+m76FFr2uY8ZQVR9x8g7YmrqULeiwDu/IeDaIw7xCL7Gd+Z0fWCLTUUytKvuPCfsQGpBukgfkbj48bpjKi+Hj4tWUdSpm0FaDwCNyBumVvj+SC5zcCXpt+qLi3fIumxX3hXG/RwLP+5X8lFzBvMulmTsROBvkfSjvWWu1YworjUoy5o2HtP5M46FuF0hcVWy2jqkH1VC+Cmmp/hb2w1cb3O0n/k3/8QALBAAAgECAwcEAwEBAQAAAAAAAAERITFBUWFxgZGhsdHwECBQwTBA4WDxkP/aAAgBAQABPyH/AM4XmM+EiIa4weaigFhZ2H12E01Kt/iVGGlsYUmbmG14UcxS2oouArJ0L1B4KbVFZ86qUk0Ul6X2ZhR077uT/wARwGsPxp/ScA1DnvjC/aOnWINq0pTKoBgkjCAQ7pPydj6iEUbm9FdB3uC8ZtSGtTtP8MyED4GkjwpXJeCCJkTnzo2NkYnGrOCmYxhX1EqNCDy3YEBQfhDqivJE7iQwysA94uPX/DPWAfbkBcPRU3qBYwq7lAysVRqUqcgUGfjyiclWjuoOz0iSmgTkqDYS2n/H4eXjh1DzUfOOyJgT3ALuj6DsEpvKmyhapfkRlNrPYYnkN2sxvTQpSfUNx4NsB8m4mMc5fLu99/spbttYDvL8OpuzGAv/AEI1K9VGsGY0OMbzbgt75o1TlBdluRn8vQnIZe5LxbcB4IRtTZ1dUZR7CdKdkSP1L2YjC2C9ECuoXNlKtR5rqVN1W8cW4xw9yg1NdGUVXnj29Q647DOGn45asVlzoXENo2OITAZKDg8zuS/TPemP6+ZUAShHijAtJ+FUJpdq+0M4CVpm9hVEnoGiuVrf2A8DtL6dE/CkTXF/ooCgPax6WyiRNIWbbfwRQsJvQ3dlfMUl+iVfop6J7FFsY4LXjCEpjphOpVExZ6gAVR4oclv8ytCEqtAdm3Jq3j/RAUi6KN3YcmvYPSLTMig38aHzUmnXVmjb+iDdwpV9z2+Ptj6C4Ldb6DNeDeu24lVDaOgSGdGIZySlwr1dPTpaA8DvCBU7GH3CrJr+HzV7riZHhvyedctlrS6m1hp7khR8YvEsUqjL3u4sJDaPEyr8XBCiXq/FS3EnJbIOmrQk58YOM4wQ1tcTtlHSC4UrsQGQcHV88plHqj0QhJUvyIR5JG0TfH19hj5uQzzJY91QCGexsaYU3tEhqFE2So9hEQoQoyKiJMoADsGxwdjQuAqpdhscOPuPIwG3DszSSSYSO47i7p9xf1oQV4J/RFJZKUxKcNnySEbaEhCO4T6Shuc0ic2WCVr2EPo24N82N7V5fQhLRaq+ynO9qO2G0ZjBuPSAXR3tcte/qWQ7grBmPYKrIVqs3neDAEFJufcJ6FKsMaTUNSmXM/sCoM7RQ/6PqLhKyiajCYlvH9DMWGbfQgQML9ULD8I+RMwhtmiqUdUN7k5sonA8j79JE6U0+rgOh0RSJnGppnHQpEuMgis/DFBc/l1DfTo6KEQutYYo8DExF82vg1F1/hLmPgNy6++uGtcZoRdDOwSgOF3VCnAFn35mVGVoWBHQlboRp7K/kUI0nD0b78pJTUpYwlyk8NkhHBfn7C5OXAyTZ6jLbtxiuWEficsJuBU20Ujm0OfdDCr2aWRqt6kicKWPMrInZZUspBJQosF6O+0S5eMhSRKU167Js+QG4RLrT0Zos3SVPMS7Mg+jpkKmzPkNPxQ8h0vQ53ClpIXLdTLzuWfQnibCeyx1DqUSGknEq+xZfA7nh/oWSl6IqEY0x1mGrhsskWhIKyJKoXSIFXCEQksmtPjn0gl4nmOUl2xLpfnfaG42qPNkQ6MU7pCoueXYOTFY88DaJ8qA3Y8dB+cbefU/eM/vEzuHdba0eL95i+lBY3AQv6aMzhuxme52ULR5fKP+W7Dw+WPsoJ7n9D+wMI2bvfYQLhAGdZ7OXELH4x791diXAHUgmzlAQgKDEDkhcrrqrQj8LRrAiCs6L9iZinE0bBbd7LLDtyj+50L9uXJWjaIFzVJdVtgLpMhWwBgNq/oktvUnwOJPdW92JLp86Hiex5zsec7Hmexr3jQyW73Yjtx3YWv3sbewSZNeyNDM5f0lmLu4vjGSl0+sl9i8STO0yCgrkF4HRLb3IifFLmIX7UHU+oxhOiDiIcOQtX0BAON1BJBpKsVTCfQmOSsSLDYRLzf6CFdqRu9lTbvOBtI+Kn4zKVJ4hh0WucE31L2ku2sOt2OAB/8AYmkUdKO1WKHTaWjzLaFCfmSVL19gxr33UL1hTHboESxthVfAW4dFXUu3El7yDFcs5GZK/I0c0JawyfmQkpVJr1n85LHoo65PRogqjbByku2Vr4Sb4nxcX+xq9hKWrBIi23Z816T3i+BjZBXl2EmowaLOjJ+AVa8mg5J2bnEIFt0WjbSXnBQCNMGtkqp1zdW3LYP/ANaE8t5UVtdcKmcBUo7b+RkmBteItPQTy0ZHqMXqoy+U/wAa1isjEVC05BQQ+NUxEq/FDbXFy3GMR70JBbZa7AiJMhksaCg1vEMSs4vhtkU8Dt695WmXTKg+PjraInM130mmPVw1CuiT2RRf7ClSumdtJiPjmwY9bm6tSoDBJ/uzCntnm0Vo1MBDyGGx6WKi7i65YmYio3v2UxpTYz4HtX5asfOvxFKCi00oO3mhyrGRTk70Qc8hkBba+ONVXMEMoSWy+H7yDiTmPaLqTF4bCeLeOknpLvcayUVq/UJooNshJ4lgVJsZMzadm4SsbgsCg9DqNtcbVPKwHEfveDtEKooU2mQllTRRpll3OOi4FMutpI/wakgvJDezTnaIcJ4IiRQQzU+GfWebZV7lEN7EKSjNVo74BH6JXDuwkU85QS/isCxdpuBSxTR/2AoH1C/oALhkUOjBmEm0Nl7vi6VaknIUbIa1Wi+xYo2vsYi89DoIvsWhTnQ0CrbiElYI40K9l1LNlIe1tSWPyJ5QifCz1gkrLM5oufgWbwxHou8JNxMoy/TYfwTUntlxKRrPljyljYHNDKZT29N+mgizuuXoqWLMHciG6eD7lkee3eXj4ovzWUVyfUMQuGYG8ZWxE3yAL+QN3QYVW05XjKxkhGqrwmiZ8MK5sCi5/ku0juHqCk2Cp9NAimuNUOU5jV5s1X0lNX2l+F7e3YK04wkd4kYDIgl2vMrhvjR3uCoOrvi2JcuTgOaXX5BfC7LAQaNOv50+6C4M3jojiESHlUjUwdiuZiBN/BYoeSoc5CipoL3EuxCWqA7uRcCLMNWDAkzX4mA2lXLT9C+Fn+zxaQkeLT9GIN1RxL75BvFtD4DiHZKwa4YaR0Q6ouG1o9JFf5cMx03Il1R2ELP2INGbYTE5s4BloBv3tI8ipbxd8Tza6ffw21rkRZWbdF+pycw9U0LcdFLhJm45R1tS0AOQUgrJ3ouP8cCgIEoRl78zkVjoE7v9CdvhoF5zf0LD+wOWwOmmh0bB4C948ZoAhUdiziSW0wHkl9Z6hzvx9HCTZqT9XiC7hcxoFmNsGn4ZpqAu0s+b9tuFJVmCY0GYe/8AvEIXYOgFrUkZzzofITviTyYnuWcYfsIazh9DEm2TbJNxeXwxDn2BIek/t4Pf6GbhHiFLXte8gj2IE2id/wBGiqu0afKENuUk18Uvr4betwsL0Pl+1NMNIxvuIn1aRvT1/dpocInQaRmvmTbCHikdfv4aXMnmuw1oHQ/anhw9ZrbYNW3kl7po9HMSqamgPPBJA7H8M2BnzGwX7Ntxb00GYg2mxpySkhtWCg51Zh7lGPFY2FhWyxw60CHKmAcfpEuzhfzBGiPxBU+G0MWGDkn7CpmNmfpuAJuMkkMkQ5XgMYWdPQ5P/eWjH6jxinYGWALbEtRspaGDamaWS/Wo3Ofh2/ZAGyWesWsiFh6CwZwJBk9iXbjCMRDSrFtFkcPCCmf+m+HfZAFf66+y9m8AlEITxtx+/OSZWIksYvNPh23J5Ctmr9uLeEaE2Lvv4FOm0Quuj8O4M+h1b9Yh+2k5IeRqJF5r97cJfpe2ibZP+LyT4dpHnP6tt76t5PoeOASZRF78HvH34+RsIpJ1i3OfDt4VUL9PvH4OOeo8RzG2SL3JnY3UZWvNZM6ySM1k97Wp+GY+tM/SKWWGU2/CrZrG3wqGb7W4Us6I9N0CKBiJa+y/hjPKFX9FVFYc8t+HSZha2YfcpNtFPP2OhaL1V6zkGOUUL4druX1/M/Ti7umX42ASNVsedlDOJeslajQMnseNZkqW4gP4djtK9vErkOQlEr8TvkE82YBAzEfleNSBQn5I0kXpZkd7G20v2WE5Tu0+bMvHOLS+IR6MFfvIdHU4nwEVwaA0Ro+jPS9A86Sd2/0WhWY2QCq1+xdG97SMmNqEJnsEOb+JYPJlXHgPsyGa8hmAgSplofr1LNYqG9p/geNjA+0ycVV3BJ/firgQJyPEd4XEQJc1H27ATlSrD0Ulsurr9PeH7H2ExZ0E3+CrILmbrSRPFxvPjMkuzfYeBmfdldmYk7dQjHIh1v1i6XwS6HYtK6omSno/RoOSGhwWXZfgJD2iaGQvj1QRsaK3xVyjBP6Nw7lVCociQfaY+mkYtPz+A4DwLGEkqVFn4AsQUzBNwn4wnekyJzYdSeRTGJQxgj5DKidPezKOvh/wHBjZZ5ldSAqz/MleUoNG2hEWUJNv6G1U80rciU8wYjZswIdGvsaUrZfRX0KV3xzAZxsYDHcKtonydRdwagbarpV/g4oWJoutGNai6KQnxb8lQzQjxQ84KF865ITa6ZOhXYLlYbiJp9VsGMVCdA+PlXQrvpu406Gf4UV5ovRNpUX/AHvn7cTnKZtVir2PAY9Zrdwh0IeQp0nMXjg1M2fX30s0FjWbGojzHNT/AIF3Q4JQWXlr4ZloIjg4oWBde9oZqN0R6f8ACcyQH+D6DJSs34MQQ1qEoW9+7nBpMnoICQhYf4WGIy0V3kPYcV43YZ4BSk9F+zWb00sXJ/iK+Xhw39ilh4VtqwKPv1zm8eyEKtXDL/xVTWwqtommN/2K6KFQyF2OcdHliIxVydx3/wAZON5/+6h5mUvLDsPxApU48teC/wDTf//aAAwDAQACAAMAAAAQ88888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888800888888888888888888888888888888888888DidH888888888888888888888888888888888884mQzBk8884w888888888888888888888888888888bqDUP88FOsz88888888888888888888888888888CYLvc84bQReW8888888888888888888888888888sXvU00gbOd6N238888888888888888888888888ZR3/+OQ6nNblb9sU88888888888888888888888ojEt9//wDc8THN8n89PPPPPPPPPPPPPPPPPPPPPPPGKfVF2pvPby3R7b/TlPPPPPPPPPPPPPPPPPPPPPOACc2L/c+OP/8A/wD/ALd+3NPPPPPPPPPPPPPPPPPPPPDJeRACxlvGlP8A/wD/APfGwcUVPPPPPPPPPPPPPPPPPPEnf3sNHh2X7jcMOevZPjtfPPPPPPPPPPPPPPPPPPFv/wD/AP8AnL2lcvTv73tpo/xNPPPPPPPPPPPPPPPPPPFP/wD/AP8A/wD/AMwvEFshe3//AP8ARzzzzzzzzzzzzzzzzzzwz/8A/wD/AP8A/wD/AO+5zjuvv3f5fzzzzzzzzzzzzzzzzzzy7/8A/wD/AP8A/wD/AP8A/wD/APag05eQXzzzzzzzzzzzzzzzzzzwn/8A/wD/AP8A/wD/AP8A/wD6uiP/AO8X/wA888888888888888888y//AP8A/wD/AP8A/wD/AP8Av6j7DNsFHzzzzzzzzzzzzzzzzzzxT/8A/wD/AP8A/wD/AP8A/wDPp/P/AF31zzzzzzzzzzzzzzzzzzyjj/8A/wD/AP8A/wD/AP8A9++SX/8A/wCtzzzzzzzzzzzzzzzzzzzwb/8A/wD/AP8A/wD/AO3776rX/wDrUc888888888888888888of8A/wD/AP8A/wD/AK/+++/if/8AvmtPPPPPPPPPPPPPPPPPPOMP/wD/AP8A/vPPvvvrZFe3PhfPPPPPPPPPPPPPPPPPPPOvf7/fPvvvvvvvmfvvvCvPPPPPPPPPPPPPPPPPPPPDEMdPvvvvvvvr5PvvPXPPPPPPPPPPPPPPPPPPPPPPPPDetfvvvvvqn4OD9bfPPPPPPPPPPPPPPPPPPPPPPPPKEo9fvvvprvPPDPPPPPPPPPPPPPPPPPPPPPPPPPPPLHDdvvvmePPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLJevPvIvPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLKscIfPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLHPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP/EACwRAQACAQIEBgEEAwEAAAAAAAEAETEhQRAgQFEwYXGhsfBQgZHB0XCA4fH/2gAIAQMBAT8Q/wAqGHQEBjT7xTCkAbHx+FoqxWsoDTL2q9YCqwypH4R9idJVB0rr0iCzAS4eNYg0eq+9o6JX7v8ApFO51wm8i5okQF190JNj55GyjUwMwETpI2NjqeT14zDFOXkuO9qkKlzBBNfmfKf4l9rPNIBw9Vk0doi9ovx7J9FSzPuluflNW4NtSYZqYQdsa/e8NLWvaHSc8MnVK6Op8QwyGmOYuFUMDq43lGqmN6LI4s6lQLeIu5B2jEKRlHEXY+cuxFn0lLf4n1f+T7GfYz7GfQ/8gtrPPhNdOQb01mDr3iqj9Z6cAXEqLt+z/UROaxCYhs9PilWS3nILZHrUsmRqO0YNahpQ9WXPwQemu6Ii5tccy9O0d0l2GULvpDZ4mt6GbX+01Oa+55Q0QvzP6j1BqUtkO2biW0T2l5aVwNp58XSDv0mDlStyplSDdwOWO8oBgjEOYttFNo7TLFupTvcsZi0rpMPgPZGnnMGr2lMuVYYFtc7sKOUWOuncnY09JTiP0x1Y95olzFMGw8FSZtdJn8ZXR5y6HaG6m4x5lljeLX0mbxVomKVL04tGO588ArXSbvFds/jABsmC9yTZX7ME7OnlAApiK3pMHxNvgZzUrkXx0uD4e2cVqoc+RaLpc3hbZyDrfWGhxW0WrrdajfldJFDgtRbi93S645kx7ObSppBNEPZFvgtDpXdks0ZeXlvg55scmDNrp8bPIZdZ8HGprLkwjt9UAdphtefI9Yhpnn8K/aV7Rbb6tjR1Ibl+kNry4vwa2NUY5crP+DFNSbMCajhvMn4VdRwxVdzU/wCgP//EACwRAQACAQICCQUBAQEAAAAAAAEAETEhQUBRECBhcYGRodHwMFCxweHxcID/2gAIAQIBAT8Q/wCqPQ7WCZ7HkfP1EtM9pp+/xFo69L3fZdV5Gj55Q8LC1zldpRahVdnjKDMz1/p6spzuX9kYRkb8P8plH9u5u8yw2to0YX9y7TlAeH9a8GVPKB02s/sC0O0z6+0zYexF/TLFoTJxw7SPr8/GkohS2qzw3PUlEsuQV55fx3zwUjYOoeucB2wZW145XBcuNmAXI12h378j2gwb47RRcEoV1b84W9agcrsrfsZp7AdK2YmRzp+X8fmKwWB+J2DzgMHis9h8DFRXx6YbAeIfuEwefsR/2f5Bmr5e7NdKx03O/wDfxlNTvyHyU9GII+itaXyNb72Ug1gvK/avtCLUSt3Hyuj0HFN6tTTwjYHgt9ZoV/DT8VN5uipTDCUtyHufaN9rfMshq0vav0iVr3VoTW4m5WSAK2u7XxJXjbiRCm0Uha5+f9/Mer3sf1T4EAyviwwj1mQB4H7ZTgI5h8z2nIPP+TufN9pX5fad35vtOQef8iGo93+Q5sKb3EUBP5OfO6aKbOTXz+X3wLfRwJnB2NsYDVNLngmwXd82W6wvgXee+vQbPD4MwicJ+2IPvUdtnw/ZTETRe4z8+aTIwPV7S7bsD5pCFgN7t+ukJu7sjk+bJpATXrHzs6qQH1c8zR8dmFW2JfN0VmnCZYY6NRWqJyzRYswaOLOZ7TsCRcROsBIAx4zMJD2Zng+Mzs5FPBjcxZ5p05cJn6vZHkmEjGxrzIOJiRlOcpLGFgG8U6oMAjsmC8MFPGNDmJcMNn3gtstySzeVADh6u7hPy/Tu51lm07ZgmGGYiMQ26TDhMTv+sN5cYrtF5QsgnHhMT6oXDDDp6RajnMOEzPqhXQoDBczuYhNHnLWvC4PqB0OE2HTRBwuD6YdLsdWGOPA6mwmbpMy42qB1uboC+jPhRrfWph15mmWHT3cKglMa4lEolfRzm96mUx4dEKJX0c5m6mUw4lLFGZ2OvugslJWV6JpxadolZ6ww/Yx5IiZ6rD7HVzkxOhtMPsqDmPLL/wDgL//EACwQAQABAgQFAwQDAQEAAAAAAAERACExQVFhcYGRobHB0fAgMFDhEEDxYJD/2gAIAQEAAT8Q/wDOFZ7HNB0ScPGKVCTRXu1dLV3tElIDKCXeb1UaUUSI2T/iZopN7BmuAGNEEFhLVivf4L1metn2XqtYSXWFyBaJxexF3hRpYeyrPhKcZcBpt+PY2an/AIRZ9OeHB/4dq9moDHLJqGFBVBE9XIM1m5dCg18DRNAu9i1HAPElxYl5tM9szEPJrdsynnRy43VdhlWXsK4p5qzT4fhbaXk2I8HUo6uqmjzt/wAMvYZTEsSbknKgrEdZ4OrLyKR4rDBqJNeb6cak7bIyCpA0i7aC98gx2qVAkSWbeRSXk79XQ5WZWsNTdUYMSxtpDjDUOZYcSEvo8Wmwx8QETkCa6/8ACmxYw3AeVLiJ4ySl1VJlBUaEKwVMIBuRJFmQi2CbVd56BTmUuiACAwlsqHW1QJCSNmhspoYlHIQ5VCSG1JQfsJpqPn5draPLHZoR/NuEXG3RHhpbhYJnGotAoJoB9am8DQNxBOBNxXakwLK2z6hco2c3NASOVgnMd6AAYCy39sChegGVaYKb8ZjD0agjkOmh6tD6kDNpC6HId3Snh9srF8edMT2/c34qe1S7uWHkrE5VWpvIPKWrmpLGmZuuNtzCpth+ZjjmDGE9weVMqSmZ+gqOTTEJzF0yjWTDpbSggQokIwHdYM4qToL3TiocJrBNp5ZEGeALA3VnjhWJ2xXJtsAOOrtUsQCbldVPWhELMIB6qDmoxfpQEqS5hrOwZvBqf8PrIb3sVxh56UlyW7YZWsjQNC3UEj3PQqTy+a3MaMiO4JwX5qWJUnIshGuXoqQRVnHifN1ctPzLeDFSIQjyoNH5AmRsmr2f3RrixAhza4CfsScvbYSwlhi43JiaFB6WQZONBKojGoSWB8p2rDXOk/OlmNVZbvuqbbRMgMNlFhvq0UoXOQZu6yu79Iv2WyUr0KdMFdB6QS/ug54g5k5BJcMkM6z6yhCthNEJkwzUttQs3MvPQoKNS6R/e1W9tPDcrE6dyrAnV8uXw/SJbPVGCdzSrEkG7XqxNk/MpfZeGoNTUzOTSG1wKLPKuq5mdRqVwgnF5lTqBU9rmahasOLkBSMQ7kcXn1VG6KRR5Oa6HpnQR0eMejDIy4y/VGAHc4V7DOdQSBlrI+AKXsE5lxjgJwCkvBHkt1sXedYLgRdmOVzgtQP8vskSLkIUwk4fwf4rC8/yYafFrtu4B4xPjStQ3niPh2p/M5C+GcdncvTsKyIDgLOc0PROxFRwJQkULBscBGgmC6fWZV1KH5cFFyPr1fo8R+7UaEEBGkTxS2OFwWKTYyIJhBO1xzKAPgEBjvLCLmNzt2mfQXA0wyvQGyJBmzNNwUVkcN6gOhMZTTyVPwh5H8dKkqTWuX5ad6k1qaejWZ+VAzs6z0Gmm0qcfturHkUmNKZrvoUmipeKpi0fDgK7uNNPqkKxhMVbXpehQukvcGscwk3zziD50iV0wJxEcSkvhgJCVuvhheipFM3SmbZigbPl5YqjoSSzaORuZBPfChsJX2iUnYVMu3tgxMnwrBqvh3XKXAbiay4Ia1IngJSUwgnJDr+SBoaVWAKsN8TWdJKd6nvhJg9qRO7O9vUpAAcHvI8UoQ5Rhz9WnZdZDdGhLI4rrsNHHwwxiiPSXyWmupg8FMSjvPWsQ3A+bXae9iu2qD0pCemgRo8mGo1hfIZQd4k3HWo/lmlKxmiW6tKMqpSRcEcymQzQiSJpS2emFhoMluM0kSCsAltnYInB1oAwfUAGzJuv6kEqluydu1nHapJzEcMLRoiXnTqiNyUhT0/mxIqKsAKjA/IbFroBXYpZb02Jf2Tyiil6l5sc3tQpLmz4igQmmcnvNDwHsngoGRtg81LBUyB9prg8npVJRo9m82ngCf0jGsBndDooK78Ip1eHqVdYID2KSfG2hT0yNV0Lm1CAvM2Y9+JUcuWwZcM2NQ2e1K0+czOMPRJKh7zm5wuPUpFk13BVqRxfSjo2JsWqMZOx3XQ1Xdoim5JCGBaM3litQMDt5UAJzMFh6j1+kUMD8hnx88ZSOmryoQak3psCcG+NNaYr2IZGoLxyaiohx8o0ZHUwS8r1rIXKchCoNV1k9WaHgnQPGlXFXj9m52ZmN5ty+s0AWopiNj0WOFGzO4XohR5aLH6y0ilqJA85zIqXfZA18rHWj6uIgjADI/gXhA2WHgOI1rL/ACmT+YBUJh+PJlQC6tRhMBbiydQLHNzrJ2dWQuxhwaGJSBdAbcY4NGSVPJDGZJhGX2pM3SnCevauyIvLUrbNfcr4O/CsWHwLUk4+A5U9f8wV5tQsjmeq0UIMBXQroiqPmeJq1h4xe9OtQUlxEijaTLFOoRHfUcalAzmEcyRrzjh5qzsmkLBdYvNTQ3VfhrdpCn8cRdcNddDp+mtCbIgN2rWgODV3T8nHGJS8QcOOylt5y5uRyd8TOhmGGkCRb8SzXTg8MUa9N/IoxlfhY05HMz4FYWDaiW2JaJRa5HSryGCieOY0tx+FZtZ98A9azu4FRsW5PpQeJqAYF8bUHnfO1f6ev9DX+1pXJ+dqVxD5aUpgNBmA4y9Kyz4t60jEoHxnD+9d8gKSkxpIRcNHKp+Oo8vCrsK4/jCdDk+U3YC8ikmUAKVxv1BebwqzW3XEQJHpR3TSJA4iUprHHtr6zLvReHZdi1HJpaTEGw20PZo+eX4o+zzWNT48Wrtu4vNC3CVAbzi+NKzJp6BQfA5FfLVb0L8/a1h+1Dzj/FPPRqMRwc/SvCBK+ADaj4jwVTO/jLHIbiqwYceqwd2Kr3VAoPPbDntQtHRWRCMdPokd7JUGEjnAZ2D8ZkEAatCYCObZL3Wm1re+LoZ7nOobWqW95wdHjUbJLiOIXKcd87O1/wAbtWDgJ66Jlvg0eqEJ5ms7m9IogtkIQobnPWn0ABHOpDDRhIj4Jmoy24RvSi4C2DxX+hWNR96Ak4TVhOJups9n6FQ5C9iiuEIk3H1fjF0oO/61YEZQxakp+5MziUm6fKxbMHzvQ1kSsPEF/CtBOgC4mHY0BLkv9H6DJpV+GB5dJeo5LWsmLEeid+tOze43DyXh70aBgNZdMjw5fyK3XXAbvininjFPjrUedsvf1JYixbfWFTgNC6XHA70cWJkj7hyKCxYdk57qNoklImv86WCdUrHihDAA5DWh5cxbnNPigvRIT+wrYPQPap/DlNrHx0zbYp8fD/8AuajZo2QY+SezbehzHnWIzywl3wvZoGzMgm6hfwoC3Woe4e7DvShi7LLO+6bp2ahDZRI5BieGgBU4LsuNml5tgEw2y4tnrULZY9wcPSM+GK+8LADKWTQX4VG0C6eNHuVBi1hNuSyrCJkRdWkG7QWSNu7Hh6VEjYpa0OgP1Sr3qUNzyX+2qXgMgcmlXoTLw4u8TmVCFrKQeJ+qCYbHko1Lh2B70m9JLzWWXNrCU4pUDTaR7q2E1HsWlxWyncKQ8kouYZESEj+FcGmks9hNFPLO38FDKASNXcHc0j1OXZqXDYc9teX8XG3KBXcwfO9EEbk03kLnKiXsJWFuNvu0cA0IcsZeOFSBXdT1GXjhVlVq0TAM2UMJtR98L1Wrg+QYXqWsMJxqlld2WiIbJTCCysTHapxFiSzgxgzNq25kBaOxoF9axpwFZY+g0zjGazYXckdp1+7dV2Er6/ei9unTEIdqIS8ClEtOVM+PAL60pwPxNq8zX0oQutGD3qPFWsGki9SMFNJZcY+X8NmiCcozxSn6A0oTuW2d9fNQjLMaxxx69aFwJPZD2n+Lhl+0MHnUHQXgsN/bNEJ8iVNkcuDTCb5rovy1WDG9lvfNxKJATqmFBkvwQZoEVzghoxjVmRozvBoAGkkHBg4NSmySVQsvBNQcaawFnQicZy0qPBWnpkUxDOgT0WoU/UPGgmJHH7BvYNciakYyn1Pat+3rz7/zLrQUFbDVluQizBJamyce6tM1n15Pr+Falr3P3KU3VefqiNDI0p1iogkzIL178a3QIo3g48v4lRZbVzz5zTIxzg/RrVabHkm5yq5a6IbxjzOdGz1eeU2Zc6gY9XNzyqYYyNSM6oCzVp0Unohr1ZvkpDZ9l9SirpoG8JUuaHxJKQsh8VJUdIM19DTpwgrtR7B9/SfVUWObk7eirMhp6RFOAi5BPRaCkPVHjWC5GyuY92hks5zKpv8AQH9fT/um1wQ9hVqYWjc/CwYIToJpOKZvOpS+qvf7EQ0dFvBxqPDsDicLB1amM3GUk7NYm1afCJE4OJyqdnL7ALnOaVDM+YSW61LqHECXHE5RRonWd4cOVR0qzbPB/iKHgtW2LWx/hKlo7MV5eM0OQB0odxfFm9KwEWq8TWLBoB8KvwNIO4aweuI8NM10ZE9RqI1weUMmplTsrYJEYiYnCsrom6bUQ3j5ZleAEfWsE4EldjoaH+1EVcHSebFGXhaNiPwtz4uXBNfKQy9Kx+29Z9MulPh8bSsMV0bNJZExxHOoOW3nTB6Vp5f/AAHtXWgG4ODUMIjfKiThIe9DTsg36VYljpSwTW+FCCUJqfSW0cKwz81aw4BrG15RSxB2iz5pOUWZHxWKz18A1clNkPcpMg2GO4+lSZEwsvQFKRi7JJMmrwKLnN+GbJ9Uj1r5VIdZfev7ug+eOkVafiZEPJrZUO9DFyokEXkkjUksZ0+1u1PlRp8B0pUMcl22e1IWhm47KwCeCu1TBLWSohL4dKsruxDxWJfkrtWn3pOD8ErHD7BdihMl3ZPSrST5TVg/C3pifmm9bzg6ft/R2g7NHtV/0fuNhVuOYqi+NK1Rs2HMkoC+ZI9qJAmm3Km1ZyF9SKl5F1fWa+Kw6RRZ2mTwWnezPmnxhm9YUPhZ0I3EhMPEYowoDjVJ+uY8i9KS0upxT71Op7F+G4UMfE+VfJ9D/UOjdAXrjWkRV/73oW0ML7q+9FQAxb4vS+rB6B9KBLjlPyK+FB412qw1Ik5a1Z20PHvpuMGLxRCMDHT64i/RUXUng0JbDH4fTWEg1HcPT+wHBugPmp27cz6awjjP1mndqD6UmqlbEkkzFk9v4BniGAM5LtqHQo3g+rrJqKSegqIFNo9ZTISe6d62rgk/lhZF5krYNOg0Q8us4CfJ+GjR9rVAPlvp/bJEwBLSbYmhePFbnXtWJwLhOHuV2KpKvQuJA9GjZRxg64mlQJwYk82mxhQcXUDgvCjABYix7Xb+OEzyJa+ESP3SmIRHAHlfwxZl02HrW9HnX1/twg929LvkR1j3qSax62pmSznMXgfpALhquPKjCYbRgDwDzWtCHA2hkLPet008v2qfSPqf1U2l2Ov8M8X+Dr5TIe/9ocGhT41WaWwAfOVRf5k+lRJMQPW+n1ClkWyD4nrSKLW+CHtT/wBO4VAGi9alkhYv4bQM5PxKny0R/tQi2veNZ18i6+tcXD0P3UvYp5D9/qFTj10lbQSdqZ++xWuBE6ApgkPTA/DGzL957dDYh2/s4T8GNYstbnXtUG6709K30ep/VGclVRS3Rie9GATmt+WhyT+FIVC9b/JoHkXkinglMFvWl3UeUyEqicSPZPSk3ovIe9Z7dnCgCAgLH4ZAcDeaetWjRv7Ch7FI8/A0P4kWsetqjGq6lr5LMfWhDqQ8NG1SkNYiXrCsfbidhV2iaTdxrB52S7lINtr4toqBV8YooQsIA5VceRrMutOJvns73xRh+G+JZv60pPSDt/Xwq2PR33/mAfIn0rbHxUkNykdioiwAdP5wwtWGTgqD7tBwLnSSD3RoJQZKFvL605SyfIju0Yfhcq2M+U405O7+vJLWzen0ORY+j+6iaQFILGHpW5frvVZBxiuH/AoTliDoh8D+GcGsRz4p0t08v9aCtdi6fTxfJ5p7VtELTqbw1yF+xucA8VD1oNlnSatfFE+n4ZwafCj0fZTk6q/1TMkvtSllx+nZpPlqFMvFVkP0h6/WS2QJaW/iDlM+lfABH7qPUMd1A+V/DOFZsR2H7UYH9QptOZ0pVZWX6j8htPWp7qHUlWV9Qf19cIPdvTjbpV71Jr3qf1U0Y65kdg/DNT5rdKsH9PGTj7PscJQ+OVRuhPLUH6oH7+plyzVpkWVZa+QdQrajdp9aksgG2K7v4d/qIv8ASWaDzVncLXj9jC9cD/q1Hqm9D91C6h4PT6SRYDFppcBg/i5/sVanejE8Vgir5Aen4dO2b6/0fXxyKlgX7O9x7VDrnsFS6B9T+qhGp1P6EBVgMVplgnv/ADtPtKMOXEbJnt+HNRJi6z7xASoGrVoubYVltpYfblG862qY6jv+qizTeWvhRH8y6DQzaQjCw+hLuYeRUZJebQXcKMPw2CkMCOwld2irzhjb7WGfnWFT7FLwN7dpeU4/u8QB3qE7HremAZIOhUAZB0KwAHTOkbRUMVVc36Fgul6zpNS6/l3qT+ItPUWxuRrctmWyKbY7kVZpo7VbjZl5OJXzmvlNfIa2+itR00rkOAUrHktOIvF/o7QPhrYQ+1Ll2izP5/Xumu1OUsg9aQVZhxW8H4m1m0XWxnsvrNX/AB5w9Rs8OpQsRHS8ntRN4wVJ/XSdm+h60LDIq+Y/s/YtzF7iFAF8BHrViiOdTTu/iuD9Gk32d6mtmfhL46qxeZgScGyb1HlsMXtRAovBGRpoTM0mKRR6xZOJ/T5GvUe1bTL2qU/4H2B8wRU2gfW/qji0mLOQdo/GMI2ZGG1G64NFpXpYPdh2vGpNvlodFYNS621dwfeihmHERwmsfA3x8MSjCVgqf6OyBfLXGz7Vus90+xwiPkLXwSY+tEFmHEE/joPeR0e9LJtTF6DYhv5Ogq85EORtqVBiVmY8HOpue4gdQphmOGLhOVIQVI4P3/nWX3rjwDuVFPIpJFJ8HxWX3BGsc4gPrWTfFVhZ8ZKxYcBRCWPBmgXDMooTTCPYosLAORH5CcjlmS9g49Ss8vTlHU4rm9QKxZlzg0uDIXG/zhSpzavJycqiCDGx0c/vDa3ke1TBovLTGMow3MGrJQY9cINSJNz8BJRQlwI52KWt2j946UPG5evrolhup7KVNrxn7rXAivPlMJ4MgFJcViANaPyMUWdfxZeg8SHenijiu3Li+Mc6jAeke9Dlo5eoUZT8+C2c6anBiMD3+5xVHu1uhPp+1W9vOagek/XBUcaj8oLtIBImiUo4M0Tf9bahcwQ3km3Jh2qMgdK/MzomIMmjmYlZL+fB4OdXeTxH/T7OKhuM1zi/FNmQTnH2/PnfGATbjQBKyrHuXAycKGgMI2NRwHCaXNkduZQ9T4G/RoTuVHDEc5rK51DwS31rZE9qkeo7/quEE9/1U8EXHH3n/A4zc5gOpmO5egrRYOdsB4dVNWy7rmOJvUIHePahJREczBoIIPq2S8dQPj63qY9B60ROHRQf8HCYy+RuDcqLeXthbZcsO1QwaMkOiNxqBebJWeD9Tj5Vq2qHas8O5wetCOCIP+Emn8JI/f42ZKlzmOHu5xlypWbHZyuGlHHVHy1+iLsgdUpxasRMybUH/Dm5DAK2Yc996axSCEHW8d6heHqzg0WBnAP7+hxFnIH0aMD/AIhBL0mVcRZei8SGpFb0JAa+iRvV+QbQzHrUANalnvQFYrAzNKlKnkJ0emn/AIqKYyzS9rYnnNZShTIpCJauWtwupc625YosZDI46/8Apv8A/9k='
};
function artIconForCategory(cat){
  const key=normalizeCategoryValue(cat).toLowerCase();
  if(CATEGORY_IMAGE_MAP[key]) return CATEGORY_IMAGE_MAP[key];
  return categoryClipArtDataUri(cat);
}
function setArtBrowse(level,categoria='',brand='',pushHistory=true){
  artBrowseState.level=level;
  artBrowseState.categoria=categoria||'';
  artBrowseState.brand=brand||'';
  if(pushHistory && currentHistoryPage()==='articoli'){
    history.pushState({page:'articoli', artBrowse:{...artBrowseState}},'', '#articoli');
  }
}
function renderArtBreadcrumbs(){
  const box=document.getElementById('artBreadcrumbs');
  if(!box) return;
  const parts=[`<button class="artCrumb ${artBrowseState.level==='categorie'?'active':''}" type="button" data-action="artBackToCategories">Categorie</button>`];
  if(artBrowseState.categoria){
    parts.push(`<button class="artCrumb ${artBrowseState.level==='brands'?'active':''}" type="button" data-action="artBackToBrands">${esc(artBrowseState.categoria)}</button>`);
  }
  if(artBrowseState.brand){
    parts.push(`<span class="artCrumb active">${esc(artBrowseState.brand)}</span>`);
  }
  box.innerHTML=parts.join('');
  box.style.display=(artBrowseState.categoria||artBrowseState.brand)?'flex':'none';
}
function renderArt(){
  const db=loadDB();
  refreshArticleCategorySelects();
  const q=document.getElementById('qArt').value.trim().toLowerCase();
  const catFilter=String(document.getElementById('qArtCat')?.value||'').trim();
  const items=db.articoli.filter(a=>{
    const catLabel=displayCategoryValue(a.categoria);
    const brandLabel=displayBrandValue(a.brand);
    const hay=((a.codice||'')+' '+brandLabel+' '+(a.modello||'')+' '+catLabel+' '+(a.descrizione||'')+' '+(a.colore||'')+' '+(a.taglia||'')+' '+(a.variante||'')).toLowerCase();
    const okText=!q || hay.includes(q);
    const okCat=!catFilter || displayCategoryValue(a.categoria)===displayCategoryValue(catFilter);
    return okText && okCat;
  }).sort((a,b)=>Number(b._ts||0)-Number(a._ts||0));
  const el=document.getElementById('listArt');
  renderArtBreadcrumbs();
  if(q){
    const cards=items.map(a=>{
      const promo=pseudoPromoBadge(a);
      return `<div class="artCard tight" data-open="art" data-id="${a.id}">
        <img class="artThumbLarge" data-photo-for="${a.id}"/>
        <div class="artPlaceholder" data-placeholder-for="${a.id}"><img class="artPlaceholderImg" alt="Categoria ${esc(displayCategoryValue(a.categoria))}" src="${artIconForCategory(a.categoria)}"/></div>
        <div class="artMeta"><div class="t">${esc(a.modello||a.codice||'-')}</div><div class="s">${esc(displayBrandValue(a.brand))} • ${esc(displayCategoryValue(a.categoria))}</div>${promo}</div>
        <div class="artPrice">${money(currentPrice(a))}</div>
        <div class="artActions"><button class="btn orderAdd small" type="button" data-action="addArtToOrder" data-id="${a.id}">Aggiungi a ordine</button><button class="btn smallish" type="button" data-action="duplicateArt" data-id="${a.id}">Duplica</button></div>
      </div>`;
    }).join('');
    el.innerHTML=cards || `<div class="card" style="grid-column:1/-1"><div class="small">Nessun articolo trovato.</div></div>`;
    hydrateArticleThumbs(items);
    return;
  }

  if(artBrowseState.level==='articoli' && artBrowseState.categoria && artBrowseState.brand){
    const scoped=items.filter(a=>matchesBrowseCategory(a.categoria, artBrowseState.categoria) && matchesBrowseBrand(a.brand, artBrowseState.brand));
    const cards=scoped.map(a=>{
      const promo=pseudoPromoBadge(a);
      return `<div class="artCard tight" data-open="art" data-id="${a.id}">
        <img class="artThumbLarge" data-photo-for="${a.id}"/>
        <div class="artPlaceholder" data-placeholder-for="${a.id}"><img class="artPlaceholderImg" alt="Categoria ${esc(displayCategoryValue(a.categoria))}" src="${artIconForCategory(a.categoria)}"/></div>
        <div class="artMeta"><div class="t">${esc(a.modello||a.codice||'-')}</div><div class="s">${esc(a.codice||'Senza codice')} • ${esc(qualityFromCode(a.codice)||'')}</div>${promo}</div>
        <div class="artPrice">${money(currentPrice(a))}</div>
        <div class="artActions"><button class="btn orderAdd small" type="button" data-action="addArtToOrder" data-id="${a.id}">Aggiungi a ordine</button><button class="btn smallish" type="button" data-action="duplicateArt" data-id="${a.id}">Duplica</button></div>
      </div>`;
    }).join('');
    el.innerHTML=cards || `<div class="card" style="grid-column:1/-1"><div class="small">Nessun articolo in questo brand.</div></div>`;
    hydrateArticleThumbs(scoped);
    return;
  }

  if(artBrowseState.level==='brands' && artBrowseState.categoria){
    const scoped=items.filter(a=>matchesBrowseCategory(a.categoria, artBrowseState.categoria));
    const groups=new Map();
    scoped.forEach(a=>{
      const brand=displayBrandValue(a.brand);
      if(!groups.has(brand)) groups.set(brand,{brand,count:0,latest:0});
      const g=groups.get(brand); g.count+=1; g.latest=Math.max(g.latest,Number(a._ts||0));
    });
    const brands=[...groups.values()].sort((a,b)=>b.count-a.count || b.latest-a.latest || a.brand.localeCompare(b.brand));
    el.innerHTML=brands.map(g=>`<div class="artCard" data-action="openArtBrand" data-category="${esc(artBrowseState.categoria)}" data-brand="${esc(g.brand)}"><div class="artCardHead"><div class="artMeta"><div class="t">${esc(g.brand)}</div><div class="s">Brand</div></div><img class="brandLogoMini" alt="Logo ${esc(g.brand)}" src="${brandLogoDataUri(g.brand)}"/></div><div class="artCount">${g.count} articol${g.count===1?'o':'i'}</div></div>`).join('') || `<div class="card" style="grid-column:1/-1"><div class="small">Nessun brand in questa categoria.</div></div>`;
    return;
  }

  const groups=new Map();
  items.forEach(a=>{
    const categoria=displayCategoryValue(a.categoria);
    if(!groups.has(categoria)) groups.set(categoria,{categoria,count:0,latest:0,brands:new Set()});
    const g=groups.get(categoria); g.count+=1; g.latest=Math.max(g.latest,Number(a._ts||0)); if(normalizeBrandValue(a.brand)) g.brands.add(normalizeBrandValue(a.brand));
  });
  const cats=[...groups.values()].sort((a,b)=>b.count-a.count || b.latest-a.latest || a.categoria.localeCompare(b.categoria));
  el.innerHTML=cats.map(g=>`<div class="artCard" data-action="openArtCategory" data-category="${esc(g.categoria)}"><div class="artCardHead"><div class="artMeta"><div class="t">${esc(g.categoria)}</div><div class="s">Categorie articoli</div></div><div class="artIcon"><img class="artIconImg" alt="Categoria ${esc(g.categoria)}" src="${artIconForCategory(g.categoria)}"/></div></div><div class="artCount">${g.count} articol${g.count===1?'o':'i'} • ${g.brands.size} brand</div></div>`).join('') || `<div class="card" style="grid-column:1/-1"><div class="small">Nessun articolo</div></div>`;
}
async function hydrateArticleThumbs(items){
  for(const a of items){
    const pics=await getArticlePics(a);
    const el=document.querySelector('[data-photo-for="'+a.id+'"]');
    const ph=document.querySelector('[data-placeholder-for="'+a.id+'"]');
    if(el && pics[0]){ el.src=pics[0]; el.style.display='block'; if(ph) ph.style.display='none'; }
    else if(ph){ ph.style.display='flex'; }
  }
}
function pseudoPromoBadge(a){
  if(!a.promoAttiva) return '';
  const ok=promoValid(a);
  if(ok) return `<div class="pill promo" style="margin-top:6px"><span class="dot"></span>PROMO attiva</div>`;
  return `<div class="pill" style="margin-top:6px">PROMO impostata</div>`;
}

function renderCli(){
  const db=loadDB();
  const q=document.getElementById('qCli').value.trim().toLowerCase();
  const items=db.clienti.filter(c=>{
    const hay=((c.nome||'')+' '+(c.telefono||'')+' '+(c.citta||'')+' '+(c.provincia||'')).toLowerCase();
    return !q || hay.includes(q);
  }).sort((a,b)=>String(b._ts||0).localeCompare(String(a._ts||0)));
  const el=document.getElementById('listCli');
  el.innerHTML=items.map(c=>`
    <div class="row" data-open="cli" data-id="${c.id}" style="grid-template-columns:1fr auto">
      <div>
        <div class="t">${esc(c.nome||'-')}</div>
        <div class="s">${esc(c.telefono||'')} • ${esc(c.citta||'')} (${esc(c.provincia||'')})</div>
      </div>
      <div class="pill">${esc(c.provincia||'-')}</div>
    </div>
  `).join('') || `<div class="card"><div class="small">Nessun cliente</div></div>`;
}

function renderOrd(){
  const db=loadDB();
  const q=document.getElementById('qOrd').value.trim().toLowerCase();
  const items=db.ordini.filter(o=>{
    const c=db.clienti.find(x=>x.id===o.clienteId);
    const hay=((o.id||'')+' '+(o.stato||'')+' '+(c?c.nome:'')).toLowerCase();
    return !q || hay.includes(q);
  }).sort((a,b)=>String(b._ts||0).localeCompare(String(a._ts||0)));
  const el=document.getElementById('listOrd');
  el.innerHTML=items.map(o=>{
    const c=db.clienti.find(x=>x.id===o.clienteId);
    const righe=Array.isArray(o.righe)?o.righe:[];
    const subTotale=calcOrderSubtotal(righe);
    const scontoCliente=calcOrderDiscount(o);
    const totale=(Number(o?.totale)>0 || subTotale===0) ? Number(o?.totale||0) : calcOrderNetTotal(righe, scontoCliente);
    const paid=orderPaidStatus(o);
    const totalCls=paid?'pricePaid':'priceHot';
    const paidTotal=paid ? totale : orderIncassato({...o, totale});
    const profitVal=orderMargin(o, db);
    return `<div class="row" data-open="ord" data-id="${o.id}" style="grid-template-columns:1fr auto">
      <div>
        <div class="t">${esc(c?c.nome:'-')} • Totale pagato <span class="${totalCls}">${money(paidTotal)}</span></div>
        <div class="s">${esc(o.stato||'-')} • ${esc(o.data||'')}${o.mis?` • Mis. ${esc(o.mis)}`:''}${o.tracking?` • Track ${esc(o.tracking)}`:''}</div>
        <div class="s">Guadagno <span class="pricePaid">${money(profitVal)}</span></div>
      </div>
      <div class="pill">${esc(o.stato||'-')}</div>
    </div>`;
  }).join('') || `<div class="card"><div class="small">Nessun ordine</div></div>`;
}

function renderBarChart(rows, moneyValues=true){
  if(!rows.length) return `<div class="small">Nessun dato.</div>`;
  const max=Math.max(...rows.map(r=>r.value),1);
  return `<div class="chartBars">${rows.map(r=>`<div class="chartRow"><div class="k">${esc(r.label)}</div><div class="barTrack"><div class="barFill" style="width:${Math.max(4,(r.value/max)*100)}%"></div></div><div class="t">${moneyValues?money(r.value):r.value}</div></div>`).join('')}</div>`;
}
async function renderStorageInfo(){
  const box=document.getElementById('storageInfo');
  if(!box) return;
  try{
    const est=await estimateStorageInfo();
    if(!est || !est.quota){ box.textContent='Il browser non espone il limite preciso, ma con IndexedDB hai molto più margine rispetto a localStorage.'; return; }
    const perc=((est.usage/est.quota)*100).toFixed(1);
    box.innerHTML=`<div class="mutedBox">Usati <b>${fmtMB(est.usage)}</b> su circa <b>${fmtMB(est.quota)}</b> disponibili (${perc}%).</div>`;
  }catch(e){ box.textContent='Impossibile leggere la quota del browser.'; }
}
async function getDiagnostics(){
  const db=loadDB();
  const articleRefs=new Set();
  let embeddedPhotos=0;
  let duplicatedRefs=0;
  let articoliConFoto=0;
  for(const a of db.articoli||[]){
    const ids=Array.isArray(a.photoIds)?a.photoIds.filter(Boolean).map(String):[];
    const uniq=new Set(ids);
    if(ids.length) articoliConFoto++;
    duplicatedRefs += Math.max(0, ids.length-uniq.size);
    uniq.forEach(id=>articleRefs.add(id));
    if(Array.isArray(a.foto) && a.foto.length) embeddedPhotos += a.foto.length;
  }
  let idbKeys=[]; let quota=null; let idbError='';
  try{ idbKeys=await idbListKeys(); }catch(e){ idbError=String(e?.message||e||''); }
  try{ quota=await estimateStorageInfo(); }catch(_e){}
  const idbSetKeys=new Set(idbKeys.map(String));
  let missingRefs=0;
  articleRefs.forEach(id=>{ if(!idbSetKeys.has(String(id))) missingRefs++; });
  let orphanPhotos=0;
  idbSetKeys.forEach(id=>{ if(!articleRefs.has(String(id))) orphanPhotos++; });
  const legacyKeys=[...(typeof LEGACY_KEYS!=='undefined'?LEGACY_KEYS:[])].filter(k=>!!localStorage.getItem(k));
  return {
    articoli: db.articoli.length,
    clienti: db.clienti.length,
    ordini: db.ordini.length,
    articoliConFoto,
    referencedPhotos: articleRefs.size,
    photosInIDB: idbKeys.length,
    embeddedPhotos,
    duplicatedRefs,
    missingRefs,
    orphanPhotos,
    legacyKeys,
    quota,
    idbError
  };
}
async function renderDiagnostics(){
  const box=document.getElementById('diagBox');
  if(!box) return;
  box.innerHTML='Lettura archivio in corso…';
  try{
    const d=await getDiagnostics();
    const storageLine=d.quota&&d.quota.quota ? `Usati <b>${fmtMB(d.quota.usage||0)}</b> su circa <b>${fmtMB(d.quota.quota||0)}</b>.` : 'Quota browser non disponibile.';
    box.innerHTML=`
      <div class="smallGrid">
        <div class="mutedBox"><div class="k">Articoli</div><div class="v">${d.articoli}</div></div>
        <div class="mutedBox"><div class="k">Clienti</div><div class="v">${d.clienti}</div></div>
        <div class="mutedBox"><div class="k">Ordini</div><div class="v">${d.ordini}</div></div>
        <div class="mutedBox"><div class="k">Articoli con foto</div><div class="v">${d.articoliConFoto}</div></div>
        <div class="mutedBox"><div class="k">Foto referenziate</div><div class="v">${d.referencedPhotos}</div></div>
        <div class="mutedBox"><div class="k">Foto in IndexedDB</div><div class="v">${d.photosInIDB}</div></div>
      </div>
      <div class="smallGrid" style="margin-top:10px">
        <div class="mutedBox"><div class="k">Foto vecchie nel DB</div><div class="v">${d.embeddedPhotos}</div><div class="small">Da pulire</div></div>
        <div class="mutedBox"><div class="k">Riferimenti doppi</div><div class="v">${d.duplicatedRefs}</div><div class="small">Stesso file agganciato più volte</div></div>
        <div class="mutedBox"><div class="k">Foto mancanti</div><div class="v">${d.missingRefs}</div><div class="small">Articolo punta a foto non trovate</div></div>
        <div class="mutedBox"><div class="k">Foto orfane</div><div class="v">${d.orphanPhotos}</div><div class="small">Occupano spazio ma nessun articolo le usa</div></div>
      </div>
      <div class="mutedBox" style="margin-top:10px">${storageLine}</div>
      <div class="mutedBox" style="margin-top:10px">Chiavi archivio trovate: <b>${([KEY,...d.legacyKeys].filter((v,i,a)=>a.indexOf(v)===i).join(', ')||KEY)}</b></div>
      ${d.idbError?`<div class="mutedBox" style="margin-top:10px;color:#991b1b">Errore IndexedDB: ${esc(d.idbError)}</div>`:''}
    `;
  }catch(e){
    box.innerHTML=`<div class="mutedBox" style="color:#991b1b">Diagnostica fallita: ${esc(String(e?.message||e||'Errore sconosciuto'))}</div>`;
  }
}
async function repairArchive(){
  const db=loadDB();
  const referenced=new Set();
  for(const a of db.articoli||[]){
    if(Array.isArray(a.foto) && a.foto.length){
      if(!Array.isArray(a.photoIds)) a.photoIds=[];
      for(const src of a.foto.slice(0,6)){
        const pid='ph_'+uid();
        await idbSet(pid,src);
        a.photoIds.push(pid);
      }
      a.foto=[];
    }
    const ids=Array.isArray(a.photoIds)?a.photoIds.filter(Boolean).map(String):[];
    const uniq=[];
    const seen=new Set();
    for(const id of ids){
      if(seen.has(id)) continue;
      seen.add(id);
      uniq.push(id);
    }
    a.photoIds=uniq.slice(0,6);
    a.photoIds.forEach(id=>referenced.add(String(id)));
  }
  const keys=await idbListKeys().catch(()=>[]);
  for(const key of keys){
    if(!referenced.has(String(key))){
      try{ await idbDelete(key); }catch(_e){}
    }
  }
  if(!saveDB(db)) throw new Error('Riparazione completata a metà: database principale non salvato.');
  await renderDiagnostics();
}
function renderFinanze(){
  const db=loadDB();
  const fatt=db.ordini.reduce((s,o)=>s+Number(o.totale||0),0);
  const inc=db.ordini.reduce((s,o)=>s+orderIncassato(o),0);
  const profit=db.ordini.reduce((s,o)=>s+(orderPaidStatus(o)?orderMargin(o,db):0),0);
  const due=Math.max(0,fatt-inc);
  const now=new Date(), curMonth=now.getMonth(), curYear=now.getFullYear();
  const sameMonth=o=>{ const d=new Date((o.data||'')+'T12:00:00'); return !isNaN(d) && d.getMonth()===curMonth && d.getFullYear()===curYear; };
  const sameYear=o=>{ const d=new Date((o.data||'')+'T12:00:00'); return !isNaN(d) && d.getFullYear()===curYear; };
  const profitMonth=db.ordini.filter(sameMonth).reduce((s,o)=>s+(orderPaidStatus(o)?orderMargin(o,db):0),0);
  const profitYear=db.ordini.filter(sameYear).reduce((s,o)=>s+(orderPaidStatus(o)?orderMargin(o,db):0),0);
  const incMonth=db.ordini.filter(sameMonth).reduce((s,o)=>s+orderIncassato(o),0);
  const fattMonth=db.ordini.filter(sameMonth).reduce((s,o)=>s+Number(o.totale||0),0);
  document.getElementById('f_fatt').textContent=money(fatt);
  document.getElementById('f_inc').textContent=money(inc);
  document.getElementById('f_due').textContent=money(due);
  document.getElementById('f_profit').textContent=money(profit);
  document.getElementById('f_profit_month').textContent=money(profitMonth);
  document.getElementById('f_profit_year').textContent=money(profitYear);

  const bySt={};
  db.ordini.forEach(o=>{
    const k=o.stato||'Sconosciuto';
    bySt[k]??={tot:0,inc:0,n:0};
    bySt[k].tot+=Number(o.totale||0);
    bySt[k].inc+=orderIncassato(o);
    bySt[k].n+=1;
  });
  const sRows=Object.entries(bySt).sort((a,b)=>b[1].inc-a[1].inc);
  document.getElementById('finByStatus').innerHTML=sRows.length ? sRows.map(([k,v])=>`
    <div class="row" style="grid-template-columns:1fr auto">
      <div>
        <div class="t">${esc(k)}</div>
        <div class="s">${v.n} ordini • totale ${money(v.tot)}</div>
      </div>
      <div class="priceHot">${money(v.inc)}</div>
    </div>
  `).join('') : `<div class="small">Nessun dato.</div>`;

  const byCat={};
  db.ordini.forEach(o=>(o.righe||[]).forEach(r=>{
    const a=db.articoli.find(x=>x.id===r.articoloId);
    const k=(a?.categoria||r.categoria||'Senza categoria').trim()||'Senza categoria';
    byCat[k]??={rev:0,qty:0};
    byCat[k].rev+=Number(r.prezzo||0);
    byCat[k].qty+=1;
  }));
  const cRows=Object.entries(byCat).sort((a,b)=>b[1].rev-a[1].rev);
  document.getElementById('finByCat').innerHTML=cRows.length ? cRows.map(([k,v])=>`
    <div class="row" style="grid-template-columns:1fr auto">
      <div>
        <div class="t">${esc(k)}</div>
        <div class="s">${v.qty} righe ordine</div>
      </div>
      <div class="priceHot">${money(v.rev)}</div>
    </div>
  `).join('') : `<div class="small">Nessun dato.</div>`;

  const monthNames=['Gen','Feb','Mar','Apr','Mag','Giu','Lug','Ago','Set','Ott','Nov','Dic'];
  const trend=[];
  for(let i=5;i>=0;i--){
    const d=new Date(curYear, curMonth-i, 1);
    const m=d.getMonth(), y=d.getFullYear();
    const rows=db.ordini.filter(o=>{ const od=new Date((o.data||'')+'T12:00:00'); return !isNaN(od)&&od.getMonth()===m&&od.getFullYear()===y; });
    trend.push({label:monthNames[m], value:rows.reduce((s,o)=>s+(orderPaidStatus(o)?orderMargin(o,db):0),0)});
  }
  document.getElementById('finTrendChart').innerHTML=renderBarChart(trend,true);

  const yearRows=[];
  for(let m=0;m<12;m++){
    const rows=db.ordini.filter(o=>{ const od=new Date((o.data||'')+'T12:00:00'); return !isNaN(od)&&od.getMonth()===m&&od.getFullYear()===curYear; });
    yearRows.push({label:monthNames[m]+' inc', value:rows.reduce((s,o)=>s+orderIncassato(o),0)});
    yearRows.push({label:monthNames[m]+' marg', value:rows.reduce((s,o)=>s+(orderPaidStatus(o)?orderMargin(o,db):0),0)});
  }
  document.getElementById('finYearChart').innerHTML=`<div class="smallGrid"><div class="mutedBox"><div class="k">Incassato mese corrente</div><div class="v">${money(incMonth)}</div><div class="small">Fatturato mese ${money(fattMonth)}</div></div><div class="mutedBox"><div class="k">Margine medio ordine</div><div class="v">${money(db.ordini.length ? profit/db.ordini.length : 0)}</div><div class="small">Su ${db.ordini.length} ordini</div></div></div>` + renderBarChart(yearRows,true);
  renderStorageInfo();
}

function renderAll(){ renderHome(); renderArt(); renderCli(); renderOrd(); renderFinanze(); renderCategorySettings(); renderBrandSettings(); refreshArticleCategorySelects(); refreshArticleBrandSelects(); }

/* ====== ART view/edit ====== */
let currentArtId=null;
let currentArtExistingPics=[];
let currentArtPhotosCleared=false;
let currentArtDuplicateData=null;
async function openArtView(id){
  const db=loadDB(); const a=db.articoli.find(x=>x.id===id); if(!a) return;
  currentArtId=id;
  const pics=await getArticlePics(a);
  const hero=document.getElementById('vArtHero');
  const thumbs=document.getElementById('vArtThumbs');
  hero.src=pics[0]||''; hero.style.display=pics[0]?'block':'none';
  thumbs.innerHTML=pics.map(src=>`<img src="${src}" onclick="document.getElementById('vArtHero').src='${src}'"/>`).join('');
  document.getElementById('vArtCod').textContent=a.codice||'-';
  document.getElementById('vArtQual').textContent=qualityFromCode(a.codice)||'-';
  document.getElementById('vArtBrand').textContent=a.brand||'-';
  document.getElementById('vArtForn').textContent=a.fornitore||'-';
  document.getElementById('vArtPrezzo').textContent=money(a.prezzoVendita||0);
  document.getElementById('vArtPrezzoUse').textContent=money(currentPrice(a));
  const pill=document.getElementById('vArtPromoPill');
  pill.innerHTML = promoValid(a)?`<div class="pill promo" style="margin-top:6px"><span class="dot"></span>PROMO attiva</div>`:(a.promoAttiva?`<div class="pill" style="margin-top:6px">PROMO impostata</div>`:'');
  document.getElementById('vArtPost').value=buildPost(a);
  fitTextarea(document.getElementById('vArtPost'));
  const vArtSupplierLink=document.getElementById('vArtSupplierLink');
  if(vArtSupplierLink) vArtSupplierLink.value=(a.fornitoreLink||'').trim();
  show('mArtView');
}
async function openArtEdit(id){
  const db=loadDB();
  const a=id?db.articoli.find(x=>x.id===id):null;
  currentArtId=id||null;
  currentArtDuplicateData=null;
  currentArtPhotosCleared=false;
  document.getElementById('artEditTitle').textContent = a?'Modifica articolo':'Nuovo articolo';
  const set=(k,v)=>document.getElementById(k).value=(v===0?0:(v||''));

  if(!a){
    ['a_cod','a_mod','a_desc','a_forn','a_taglia','a_variante','a_colore','a_mis','a_usd','a_promo_price','a_promo_date','a_note','a_post','a_qual','a_eur','a_sell','a_final','a_margin','a_margin_pct']
    .forEach(fid => document.getElementById(fid).value='');
    syncBrandField('');
    refreshArticleCategorySelects('');
    document.getElementById('a_promo_on').checked=false;
    document.getElementById('a_photo').value='';
    currentArtExistingPics=[];
    renderArtPhotoPrev([]);
    show('mArtEdit');
    return;
  }
  set('a_cod', a?.codice); syncBrandField(a?.brand); set('a_mod', a?.modello);
  refreshArticleCategorySelects(a?.categoria||'');
  set('a_desc', a?.descrizione); set('a_forn', a?.fornitore); set('a_forn_link', a?.fornitoreLink||'');
  set('a_taglia', a?.taglia); set('a_variante', a?.variante); set('a_colore', a?.colore);
  set('a_mis', a?.misura); set('a_usd', a?.costoUsd||'');
  document.getElementById('a_promo_on').checked = !!a?.promoAttiva;
  set('a_promo_date', a?.scadenzaPromo); set('a_promo_price', a?.prezzoPromo||'');
  document.getElementById('a_note').value=a?.note||'';
  document.getElementById('a_post').value=a?.post||'';
  fitTextarea(document.getElementById('a_post'));
  document.getElementById('a_photo').value='';
  renderArtAutoFields();
  currentArtExistingPics=await getArticlePics(a);
  renderArtPhotoPrev(currentArtExistingPics);
  show('mArtEdit');
}
function renderArtPhotoPrev(pics){
  const box=document.getElementById('a_photo_prev');
  box.innerHTML=(pics||[]).map(src=>`<img src="${src}"/>`).join('') || `<div class="small">Nessuna foto articolo</div>`;
}
function mergePreviewPics(existingPics,newPics){
  const out=[];
  for(const src of [...(existingPics||[]), ...(newPics||[])]){
    if(src && !out.includes(src)) out.push(src);
    if(out.length>=6) break;
  }
  return out;
}
async function filesToObjectUrls(fileList,maxCount){
  const files=Array.from(fileList||[]).filter(f=>f && String(f.type||'').startsWith('image/')).slice(0,Math.max(0,maxCount||0));
  return files.map(f=>URL.createObjectURL(f));
}
function revokeObjectUrls(urls){
  (urls||[]).forEach(src=>{ if(typeof src==='string' && src.startsWith('blob:')){ try{ URL.revokeObjectURL(src); }catch(_e){} } });
}
async function refreshArtPhotoPreviewFromInput(){
  const input=document.getElementById('a_photo');
  if(!input) return;
  const maxNew=Math.max(0, 6 - (Array.isArray(currentArtExistingPics)?currentArtExistingPics.length:0));
  const files=Array.from(input.files||[]).filter(f=>f && String(f.type||'').startsWith('image/'));
  if(files.length>maxNew){
    toast(`Puoi aggiungere ancora ${maxNew} foto`);
    const dt=new DataTransfer();
    files.slice(0,maxNew).forEach(f=>dt.items.add(f));
    input.files=dt.files;
  }
  const selected=Array.from(input.files||[]);
  const blobUrls=await filesToObjectUrls(selected,maxNew);
  renderArtPhotoPrev(mergePreviewPics(currentArtExistingPics, blobUrls));
  setTimeout(()=>revokeObjectUrls(blobUrls), 1200);
}
function fitTextarea(el){
  if(!el) return;
  el.style.height='auto';
  el.style.height=Math.max(el.scrollHeight,96)+'px';
}
function initTextareaAutosize(ids){
  ids.forEach(id=>{
    const el=document.getElementById(id);
    if(!el || el.dataset.autoSized==='1') return;
    el.dataset.autoSized='1';
    ['input','focus','change'].forEach(evt=>el.addEventListener(evt,()=>fitTextarea(el)));
    fitTextarea(el);
  });
}
function setArticlePostAuto(text){
  const el=document.getElementById('a_post');
  if(!el) return;
  if(document.activeElement===el) return;
  const prevScroll=el.scrollTop;
  el.value=text;
  fitTextarea(el);
  el.scrollTop=prevScroll;
}
function renderArtAutoFields(){
  const code=document.getElementById('a_cod').value.trim();
  const usdRaw=document.getElementById('a_usd').value.trim();
  const hasCode=code!=='';
  const hasUsd=usdRaw!=='' && !Number.isNaN(Number(usdRaw));
  const qual=hasCode ? qualityFromCode(code) : '';
  document.getElementById('a_qual').value=qual||'';
  updateSupplierField(document.getElementById('a_forn')?.value||'');

  if(!hasCode && !hasUsd){
    document.getElementById('a_eur').value='';
    document.getElementById('a_sell').value='';
    document.getElementById('a_final').value='';
    document.getElementById('a_margin').value='';
    document.getElementById('a_margin_pct').textContent='';
    document.getElementById('a_post').value='';
    fitTextarea(document.getElementById('a_post'));
    return;
  }

  if(!hasUsd){
    document.getElementById('a_eur').value='';
    document.getElementById('a_sell').value='';
    document.getElementById('a_final').value='';
    document.getElementById('a_margin').value='';
    document.getElementById('a_margin_pct').textContent='';
    const draft={
      codice:code,
      brand:getArticleBrandValue(),
      modello:document.getElementById('a_mod').value.trim(),
      promoAttiva:document.getElementById('a_promo_on').checked,
      prezzoPromo:Number(document.getElementById('a_promo_price').value||0),
      scadenzaPromo:document.getElementById('a_promo_date').value.trim(),
      prezzoVendita:0,
      misura:document.getElementById('a_mis').value.trim(),
      taglia:document.getElementById('a_taglia').value.trim(),
      variante:document.getElementById('a_variante').value.trim(),
      colore:document.getElementById('a_colore').value.trim(),
      descrizione:document.getElementById('a_desc').value.trim(),
      fornitore:document.getElementById('a_forn').value.trim(),
      materiale:'', colori:'', tracolla:'', scatola:false
    };
    setArticlePostAuto(buildPost(draft));
    return;
  }

  const usd=Number(usdRaw);
  if(usdRaw===''){ document.getElementById('a_eur').value=''; document.getElementById('a_sell').value=''; document.getElementById('a_final').value=''; document.getElementById('a_margin').value=''; document.getElementById('a_margin_pct').textContent=''; return; }
  const r=calcFromUsd(usd, qual);
  document.getElementById('a_eur').value = isFinite(r.costo)?money(r.costo):'';
  document.getElementById('a_sell').value = isFinite(r.sell)?String(r.sell):'';
  const promoOn=document.getElementById('a_promo_on').checked;
  const promoPrice=Number(document.getElementById('a_promo_price').value||0);
  const promoDate=document.getElementById('a_promo_date').value.trim();
  const a={codice:code, prezzoVendita:r.sell, promoAttiva:promoOn, prezzoPromo:promoPrice, scadenzaPromo:promoDate};
  const finalPrice = r.sell ? round5(currentPrice(a)) : 0;
  document.getElementById('a_final').value = finalPrice ? String(finalPrice) : '';
  const margin = Math.max(0, finalPrice - (Number(r.costo)||0));
  document.getElementById('a_margin').value = margin ? money(margin) : '';
  document.getElementById('a_margin_pct').textContent = (finalPrice && margin) ? ('Margine ' + Math.round((margin/finalPrice)*100) + '%') : '';
  // auto post
  const draft={
    codice:code, brand:getArticleBrandValue(),
    modello:document.getElementById('a_mod').value.trim(),
    promoAttiva:promoOn, prezzoPromo:promoPrice, scadenzaPromo:promoDate,
    prezzoVendita:r.sell,
    misura:document.getElementById('a_mis').value.trim(),
    taglia:document.getElementById('a_taglia').value.trim(),
    variante:document.getElementById('a_variante').value.trim(),
    colore:document.getElementById('a_colore').value.trim(),
    descrizione:document.getElementById('a_desc').value.trim(),
    fornitore:document.getElementById('a_forn').value.trim(),
    materiale:'', colori:'', tracolla:'', scatola:false
  };
  setArticlePostAuto(buildPost(draft));
}

async function fileToDataURL(file){
  return new Promise((res,rej)=>{
    const r=new FileReader();
    r.onload=()=>res(r.result);
    r.onerror=()=>rej(r.error);
    r.readAsDataURL(file);
  });
}
async function compressImageFile(file,maxSide=1600,quality=0.78){
  const src=await fileToDataURL(file);
  return new Promise((res,rej)=>{
    const img=new Image();
    img.onload=()=>{
      let w=img.width,h=img.height;
      const scale=Math.min(1,maxSide/Math.max(w,h));
      w=Math.max(1,Math.round(w*scale));
      h=Math.max(1,Math.round(h*scale));
      const canvas=document.createElement('canvas');
      canvas.width=w; canvas.height=h;
      const ctx=canvas.getContext('2d');
      ctx.drawImage(img,0,0,w,h);
      let out=canvas.toDataURL('image/jpeg',quality);
      if(out.length>1600000) out=canvas.toDataURL('image/jpeg',0.62);
      res(out);
    };
    img.onerror=()=>rej(new Error('Impossibile leggere la foto selezionata'));
    img.src=src;
  });
}
async function compressImageBlob(file,maxSide=1600,quality=0.78){
  const src=await fileToDataURL(file);
  return new Promise((res,rej)=>{
    const img=new Image();
    img.onload=()=>{
      let w=img.width,h=img.height;
      const scale=Math.min(1,maxSide/Math.max(w,h));
      w=Math.max(1,Math.round(w*scale));
      h=Math.max(1,Math.round(h*scale));
      const canvas=document.createElement('canvas');
      canvas.width=w; canvas.height=h;
      const ctx=canvas.getContext('2d');
      ctx.drawImage(img,0,0,w,h);
      canvas.toBlob((blob)=>{
        if(blob) return res(blob);
        try{
          const fallback=canvas.toDataURL('image/jpeg',quality);
          fetch(fallback).then(r=>r.blob()).then(res).catch(()=>rej(new Error('Compressione foto fallita')));
        }catch(err){ rej(err); }
      }, 'image/jpeg', quality);
    };
    img.onerror=()=>rej(new Error('Impossibile leggere la foto selezionata'));
    img.src=src;
  });
}

async function duplicateCurrentArticle(sourceId=null){
  const articleId=sourceId || currentArtId;
  if(!articleId){ toast('Apri prima un articolo'); return; }
  const db=loadDB();
  const a=db.articoli.find(x=>x.id===articleId);
  if(!a){ toast('Articolo non trovato'); return; }
  const clone=JSON.parse(JSON.stringify(a));
  currentArtId=null;
  currentArtPhotosCleared=false;
  currentArtDuplicateData={
    foto: Array.isArray(clone?.foto) ? clone.foto.filter(Boolean).slice(0,6) : [],
    photoIds: Array.isArray(clone?.photoIds) ? clone.photoIds.filter(Boolean).slice(0,6) : []
  };
  hide('mArtView', true);
  document.getElementById('artEditTitle').textContent='Duplica articolo';
  document.getElementById('a_cod').value='';
  syncBrandField(clone.brand||'');
  document.getElementById('a_mod').value=clone.modello||'';
  refreshArticleCategorySelects(clone.categoria||'');
  document.getElementById('a_desc').value=clone.descrizione||'';
  updateSupplierField(clone.fornitore||'');
  document.getElementById('a_forn_link').value=clone.fornitoreLink||'';
  document.getElementById('a_taglia').value=clone.taglia||'';
  document.getElementById('a_variante').value=clone.variante||'';
  document.getElementById('a_colore').value=clone.colore||'';
  document.getElementById('a_mis').value=clone.misura||'';
  document.getElementById('a_usd').value=clone.costoUsd||'';
  document.getElementById('a_promo_on').checked=!!clone.promoAttiva;
  document.getElementById('a_promo_date').value=clone.scadenzaPromo||'';
  document.getElementById('a_promo_price').value=clone.prezzoPromo||'';
  document.getElementById('a_note').value=clone.note||'';
  document.getElementById('a_post').value=clone.post||'';
  fitTextarea(document.getElementById('a_post'));
  document.getElementById('a_photo').value='';
  currentArtExistingPics=await getArticlePics(a);
  renderArtPhotoPrev(currentArtExistingPics);
  renderArtAutoFields();
  show('mArtEdit');
  toast('Articolo duplicato: cambia il codice e salva');
}

async function saveArt(){
  try{
    const db=loadDB();
    const code=document.getElementById('a_cod').value.trim();
    if(!code){ toast('Codice articolo obbligatorio'); return; }

    const codeLower=safeLower(code);
    const exists = db.articoli.find(a => 
      safeLower(a?.codice) === codeLower
      && a.id !== currentArtId
    );
    if(exists){
      toast('Codice articolo già esistente');
      return;
    }
    const qual=qualityFromCode(code);
    const usd=Number(document.getElementById('a_usd').value||0);
    const r=calcFromUsd(usd, qual);
    const old=currentArtId?db.articoli.find(x=>x.id===currentArtId):(currentArtDuplicateData||null);
    const keptFoto=currentArtPhotosCleared ? [] : (Array.isArray(old?.foto) ? old.foto.filter(x=>typeof x==='string' && !String(x).startsWith('data:')).slice() : []);
    const keptPhotoIds=currentArtPhotosCleared ? [] : (Array.isArray(old?.photoIds) ? old.photoIds.filter(Boolean).slice() : []);
    const obj={
      id: currentArtId||uid(),
      codice: code,
      brand: getArticleBrandValue(),
      modello: document.getElementById('a_mod').value.trim(),
      categoria: document.getElementById('a_cat').value.trim(),
      descrizione: document.getElementById('a_desc').value.trim(),
      fornitore: document.getElementById('a_forn').value.trim(),
      fornitoreLink: document.getElementById('a_forn_link').value.trim(),
      taglia: document.getElementById('a_taglia').value.trim(),
      variante: document.getElementById('a_variante').value.trim(),
      colore: document.getElementById('a_colore').value.trim(),
      misura: document.getElementById('a_mis').value.trim(),
      costoUsd: usd,
      costoEur: r.costo,
      prezzoVendita: r.sell,
      promoAttiva: document.getElementById('a_promo_on').checked,
      prezzoPromo: Number(document.getElementById('a_promo_price').value||0),
      scadenzaPromo: document.getElementById('a_promo_date').value.trim(),
      post: document.getElementById('a_post').value,
      note: document.getElementById('a_note').value,
      foto: keptFoto,
      photoIds: keptPhotoIds
    };
    const photoInput=document.getElementById('a_photo');
    const selectedFiles=Array.from(photoInput?.files||[]).filter(f=>f && String(f.type||'').startsWith('image/'));
    let photoUploadWarning='';
    if(selectedFiles.length){
      obj.foto = Array.isArray(obj.foto) ? obj.foto.filter(x=>typeof x==='string' && !String(x).startsWith('data:')) : [];
      obj.photoIds = Array.isArray(obj.photoIds) ? obj.photoIds.filter(Boolean) : [];
      const existingCount=Math.max((obj.foto||[]).length, (obj.photoIds||[]).length);
      const maxNew=Math.max(0, 6 - existingCount);
      const filesToSave=selectedFiles.slice(0,maxNew);
      if(selectedFiles.length>maxNew) photoUploadWarning=`Caricate ${maxNew} foto, limite massimo raggiunto`;

      if(filesToSave.length){
        const localPhotoIds=[];
        for(const file of filesToSave){
          try{
            const blob=await compressImageBlob(file);
            const pid='ph_'+uid();
            await idbSet(pid, blob);
            localPhotoIds.push(pid);
          }catch(localErr){
            console.warn('Salvataggio foto locale fallito', localErr);
            try{
              const dataUrl=await compressImageFile(file);
              const pid='ph_'+uid();
              await idbSet(pid, dataUrl);
              localPhotoIds.push(pid);
              photoUploadWarning='Una o più foto salvate in modalità compatibile';
            }catch(fallbackErr){
              console.warn('Fallback foto fallito', fallbackErr);
              photoUploadWarning='Una o più foto non salvate';
            }
          }
        }
        obj.photoIds=[...new Set([...(obj.photoIds||[]), ...localPhotoIds])].slice(0,6);
      }
    }
    obj._ts=Date.now();
    const i=db.articoli.findIndex(x=>x.id===obj.id);
    if(i>=0) db.articoli[i]=obj; else db.articoli.unshift(obj);
    if(!saveDB(db)){
      const oldFoto=Array.isArray(old?.foto)?old.foto.filter(Boolean):[];
      const newlyUploaded=(Array.isArray(obj.foto)?obj.foto.filter(Boolean):[]).filter(path=>!oldFoto.includes(path));
      if(newlyUploaded.length){ try{ await deleteArticlePhotosFromSupabase(newlyUploaded); }catch(_e){} }
      return;
    }
    currentArtDuplicateData=null;
    currentArtPhotosCleared=false;
    hide('mArtEdit');
    if(photoUploadWarning) toast('Articolo salvato. '+photoUploadWarning);
    else toast('Articolo salvato');
    if(cloudEnabled()){
      try{
        const saved=await cloudSaveOne('art', obj, db);
        const idx=db.articoli.findIndex(x=>x.id===obj.id || x.codice===obj.codice);
        if(idx>=0) db.articoli[idx]={...db.articoli[idx], ...saved, _ts: Date.now()};
        saveDBLocal(db);
      }catch(cloudErr){
        console.error('Sync cloud articolo fallita', cloudErr);
        toast('Articolo salvato, ma cloud non aggiornato');
      }
    }
  }catch(err){
    toast('Errore salvataggio articolo'); console.error(err);
  }
}
async function deleteArt(){
  if(!currentArtId) return hide('mArtEdit');
  const artId=currentArtId;
  askConfirm('Elimino questo articolo?', async ()=>{
    const db=loadDB();
    const old=db.articoli.find(a=>a.id===artId);
    if(!old){ hide('mArtEdit'); hide('mArtView'); currentArtId=null; renderArt(); return; }
    for(const pid of (old?.photoIds||[])){
      try{ await idbDelete(pid); }catch(_e){}
    }
    try{ await deleteArticlePhotosFromSupabase(old?.foto||[]); }catch(_e){}
    db.articoli=db.articoli.filter(a=>a.id!==artId);
    currentArtId=null;
    if(!saveDB(db)) return;
    hide('mArtEdit');
    hide('mArtView');
    renderAll();
    if(old && cloudEnabled()){
      try{
        await cloudDeleteOne('art', old);
        toast('Articolo eliminato');
      }catch(err){
        console.error('Eliminazione cloud articolo fallita', err);
        toast('Articolo eliminato, ma cloud non aggiornato');
      }
    }else{
      toast('Articolo eliminato');
    }
  },'Elimina articolo');
}

function openCliView(id){
  const db=loadDB(); const c=db.clienti.find(x=>x.id===id);
  if(!c) return;
  currentCliId=id;
  document.getElementById('vCliNome').textContent=c.nome||'-';
  document.getElementById('vCliTel').textContent=withIntlPrefix(c.telefono||'')||'-';
  document.getElementById('vCliInd').textContent=c.indirizzo||'-';
  document.getElementById('vCliCap').textContent=c.cap||'-';
  document.getElementById('vCliCity').textContent=c.citta||'-';
  document.getElementById('vCliProv').textContent=c.provincia||'-';
  document.getElementById('vCliNote').textContent=c.note||'-';
  const ship=document.getElementById('vCliShip');
  ship.value=buildShippingAddress(c);
  fitTextarea(ship);
  const clientOrders=(db.ordini||[]).filter(o=>o.clienteId===id).sort((a,b)=>String(b.data||b._ts||'').localeCompare(String(a.data||a._ts||'')));
  const ordersEl=document.getElementById('vCliOrders');
  if(ordersEl){
    ordersEl.innerHTML=clientOrders.map(o=>{
      const righe=Array.isArray(o.righe)?o.righe:[];
      const desc=righe.map(r=>[r?.codice,r?.modello].filter(Boolean).join(' • ')).filter(Boolean).join(' · ') || 'Ordine';
      const subTotale=calcOrderSubtotal(righe);
      const scontoCliente=calcOrderDiscount(o);
      const totale=(Number(o?.totale)>0 || subTotale===0) ? Number(o?.totale||0) : calcOrderNetTotal(righe, scontoCliente);
      const pagato=orderPaidStatus(o) ? totale : orderIncassato({...o, totale});
      return `<div class="row" style="grid-template-columns:1fr auto"><div><div class="t">${esc(o.data||'-')}</div><div class="s">${esc(desc)}</div></div><div class="pill">${money(pagato)}</div></div>`;
    }).join('') || `<div class="card"><div class="small">Nessun acquisto</div></div>`;
  }
  const currentYear=new Date().getFullYear();
  const sameYear=o=>{ const d=new Date(String(o?.data||'')+'T12:00:00'); return !isNaN(d) && d.getFullYear()===currentYear; };
  const profitTotal=clientOrders.reduce((sum,o)=>sum+(orderPaidStatus(o)?orderMargin(o,db):0),0);
  const profitYear=clientOrders.filter(sameYear).reduce((sum,o)=>sum+(orderPaidStatus(o)?orderMargin(o,db):0),0);
  const profitTotalEl=document.getElementById('vCliProfitTotal');
  const profitYearEl=document.getElementById('vCliProfitYear');
  if(profitTotalEl) profitTotalEl.textContent=money(profitTotal);
  if(profitYearEl) profitYearEl.textContent=money(profitYear);
  show('mCliView');
}

let currentOrdExistingManualPhotos=[];

function mergeUniquePics(){
  const out=[];
  Array.from(arguments).flat().forEach(src=>{
    if(src && !out.includes(src)) out.push(src);
  });
  return out.slice(0,12);
}
async function getOrderArticleSnapshotPhotos(rows, db){
  const pics=[];
  for(const r of (rows||[])) {
    const art=(db.articoli||[]).find(a=>a.id===r.articoloId || a.codice===r.codice);
    if(!art) continue;
    try{
      const artPics=await getArticlePics(art);
      for(const src of (artPics||[])) {
        if(src && !pics.includes(src)) pics.push(src);
        if(pics.length>=12) return pics;
      }
    }catch(err){ console.warn('Lettura foto articolo per ordine fallita', err); }
  }
  return pics.slice(0,12);
}
async function refreshOrdPhotoPreviewFromState(){
  const input=document.getElementById('o_photo');
  const box=document.getElementById('o_photo_prev');
  if(!box) return;
  const db=loadDB();
  const articlePics=await getOrderArticleSnapshotPhotos(ordRows, db);
  const maxNew=Math.max(0, 12 - mergeUniquePics(articlePics, currentOrdExistingManualPhotos).length);
  const files=Array.from(input?.files||[]).filter(f=>f && String(f.type||'').startsWith('image/'));
  if(input && files.length>maxNew){
    toast(`Puoi aggiungere ancora ${maxNew} foto`);
    const dt=new DataTransfer();
    files.slice(0,maxNew).forEach(f=>dt.items.add(f));
    input.files=dt.files;
  }
  const selected=Array.from(input?.files||[]);
  const blobUrls=await filesToObjectUrls(selected, maxNew);
  const pics=mergeUniquePics(articlePics, currentOrdExistingManualPhotos, blobUrls);
  box.innerHTML=pics.map(src=>`<img src="${src}"/>`).join('') || `<div class="small">Nessuna foto ordine</div>`;
  setTimeout(()=>revokeObjectUrls(blobUrls), 1200);
}

async function openOrdView(id){
  const db=loadDB(); const o=db.ordini.find(x=>x.id===id);
  if(!o) return;
  currentOrdId=id;
  const c=db.clienti.find(x=>x.id===o.clienteId);
  const subTotale=calcOrderSubtotal(o.righe||[]);
  const scontoCliente=calcOrderDiscount(o);
  const totale=(Number(o?.totale)>0 || subTotale===0) ? Number(o?.totale||0) : calcOrderNetTotal(o.righe||[], scontoCliente);
  const paid=orderPaidStatus(o);
  const totalPagato=paid ? totale : orderIncassato({...o, totale});
  const profit=orderMargin(o, db);
  const totalEl=document.getElementById('vOrdTot');
  const profitEl=document.getElementById('vOrdProfit');
  const cumEl=document.getElementById('vOrdCumMeta');
  document.getElementById('vOrdCli').textContent=c?.nome||'-';
  document.getElementById('vOrdStato').textContent=o.stato||'-';
  document.getElementById('vOrdData').textContent=o.data||'-';
  document.getElementById('vOrdMis').textContent=o.mis||'-';
  document.getElementById('vOrdTrack').textContent=o.tracking||'-';
  document.getElementById('vOrdNote').textContent=o.note||'-';
  document.getElementById('vOrdSub').textContent=money(subTotale);
  document.getElementById('vOrdDiscount').textContent=money(scontoCliente);
  totalEl.textContent=money(totalPagato);
  totalEl.className='t '+(paid?'pricePaid':'priceHot');
  profitEl.textContent=money(profit);
  profitEl.className='t pricePaid';
  if(cumEl){
    cumEl.style.display='none';
    cumEl.textContent='';
  }
  const righeOrd=Array.isArray(o.righe)?o.righe:[];
  const rows=document.getElementById('vOrdRows');
  rows.innerHTML=righeOrd.map(r=>`<div class="row" style="grid-template-columns:1fr auto"><div><div class="t">${esc(r.codice||'')} • ${esc(r.modello||'')}</div><div class="s">Prezzo ${money(r.prezzo||0)}</div></div><div class="pill">Riga</div></div>`).join('') || `<div class="small">Nessuna riga</div>`;
  const ordPics=await getOrderPics(o, db);
  document.getElementById('vOrdPhotos').innerHTML=ordPics.map(src=>`<img src="${src}" onclick="window.open('${src}','_blank','noopener')"/>`).join('');
  document.getElementById('vOrdPhotosEmpty').style.display=ordPics.length?'none':'block';
  show('mOrdView');
}

/* ====== CLIENTI ====== */
let currentCliId=null;
function openCliEdit(id){
  const db=loadDB(); const c=id?db.clienti.find(x=>x.id===id):null;
  currentCliId=id||null;
  document.getElementById('cliEditTitle').textContent=c?'Modifica cliente':'Nuovo cliente';
  document.getElementById('c_nome').value=c?.nome||'';
  document.getElementById('c_tel').value=c?.telefono||'';
  document.getElementById('c_ind').value=c?.indirizzo||'';
  document.getElementById('c_cap').value=c?.cap||'';
  document.getElementById('c_citta').value=c?.citta||'';
  document.getElementById('c_prov').value=c?.provincia||'';
  document.getElementById('c_note').value=c?.note||'';
  refreshClientShipping();
  show('mCliEdit');
}
async function saveCli(){
  const db=loadDB();
  const nome=document.getElementById('c_nome').value.trim();
  if(!nome){ toast('Nome obbligatorio'); return; }

  const old=currentCliId?db.clienti.find(c=>c.id===currentCliId):null;
  const candidate={
    ...old,
    id: currentCliId||uid(),
    nome,
    cognome: old?.cognome||'',
    email: old?.email||'',
    telefono: document.getElementById('c_tel').value.trim(),
    indirizzo: document.getElementById('c_ind').value.trim(),
    cap: document.getElementById('c_cap').value.trim(),
    citta: document.getElementById('c_citta').value.trim(),
    provincia: document.getElementById('c_prov').value,
    note: document.getElementById('c_note').value,
    _ts: Date.now()
  };
  const candidateKey=normalizeClientDedupKey(candidate) || normalizeTextKey(candidate.nome);
  const exists = db.clienti.find(c => c.id !== currentCliId && (normalizeClientDedupKey(c) || normalizeTextKey(c?.nome)) === candidateKey);
  if(exists){
    toast('Cliente già esistente');
    return;
  }
  const obj={
    ...candidate,
    nome: normalizeClientDisplayName(candidate),
    telefono: normalizePhone(candidate.telefono),
    email: normalizeEmail(candidate.email),
    indirizzo: normalizeSpaceText(candidate.indirizzo),
    cap: normalizeSpaceText(candidate.cap),
    citta: normalizeSpaceText(candidate.citta),
    provincia: normalizeSpaceText(candidate.provincia)
  };
  const i=db.clienti.findIndex(x=>x.id===obj.id);
  if(i>=0) db.clienti[i]=obj; else db.clienti.unshift(obj);
  if(!saveDB(db)) return;
  hide('mCliEdit');
  toast('Cliente salvato');
  if(cloudEnabled()){
    try{
      const saved=await cloudSaveOne('cli', obj, db);
      const savedKey=normalizeClientDedupKey(saved) || normalizeClientDedupKey(obj) || normalizeTextKey(saved?.nome||obj?.nome);
      const idx=db.clienti.findIndex(x=>x.id===obj.id || x.id===saved?.id || (normalizeClientDedupKey(x) || normalizeTextKey(x?.nome))===savedKey);
      if(idx>=0) db.clienti[idx]={...db.clienti[idx], ...saved, nome:normalizeClientDisplayName({...db.clienti[idx], ...saved}), _ts: Date.now()};
      saveDBLocal(db);
    }catch(cloudErr){
      console.error('Sync cloud cliente fallita', cloudErr);
      toast('Cliente salvato, ma cloud non aggiornato');
    }
  }
}
async function deleteCli(){
  if(!currentCliId) return hide('mCliEdit');
  
  const db=loadDB();
  const old=db.clienti.find(c=>c.id===currentCliId);
  db.clienti=db.clienti.filter(c=>c.id!==currentCliId);
  if(!saveDB(db)) return;
  if(old && cloudEnabled()) await cloudDeleteOne('cli', old);
  hide('mCliEdit');
  toast(cloudEnabled() ? 'Cliente eliminato anche dal cloud' : 'Cliente eliminato');
}

/* ====== ORDINI ====== */
let currentOrdId=null;
let ordRows=[];
const ORDER_SHOE_SIZES=['34','35','36','37','38','39','40','41','42','43','44','45'];
function orderRowNeedsShoeSize(row, db){
  const art=(db?.articoli||[]).find(a=>a.id===row?.articoloId || (row?.codice && a.codice===row.codice));
  const cat=normalizeTextKey(art?.categoria||row?.categoria||'');
  return ['scarpa','scarpe','shoe','shoes'].some(token=>cat===token || cat.includes(token));
}
function orderNeedsShoeSize(rows, db){
  return (Array.isArray(rows)?rows:[]).some(row=>orderRowNeedsShoeSize(row, db||loadDB()));
}
function ensureOrderSizeOption(value){
  const sel=document.getElementById('o_mis');
  if(!sel) return;
  const clean=String(value||'').trim();
  Array.from(sel.querySelectorAll('option[data-temp-size="1"]')).forEach(opt=>opt.remove());
  if(clean && !ORDER_SHOE_SIZES.includes(clean) && !Array.from(sel.options).some(opt=>opt.value===clean)){
    const opt=document.createElement('option');
    opt.value=clean;
    opt.textContent=clean;
    opt.dataset.tempSize='1';
    sel.insertBefore(opt, sel.firstElementChild?.nextElementSibling || null);
  }
}
function updateOrderShoeSizeState(){
  const sel=document.getElementById('o_mis');
  const hint=document.getElementById('o_mis_hint');
  if(!sel) return false;
  const needed=orderNeedsShoeSize(ordRows, loadDB());
  sel.required=needed;
  const firstOpt=sel.querySelector('option[value=""]');
  if(firstOpt) firstOpt.textContent=needed ? 'Seleziona misura' : 'Non necessaria';
  if(!needed && !ORDER_SHOE_SIZES.includes(String(sel.value||''))) sel.value='';
  if(hint) hint.textContent=needed ? 'Per le scarpe la misura è obbligatoria.' : 'Obbligatoria solo per ordini con scarpe.';
  return needed;
}
async function openOrdEdit(id, prefillArticleId=null){
  const db=loadDB(); const o=id?db.ordini.find(x=>x.id===id):null;
  currentOrdId=id||null;
  document.getElementById('ordEditTitle').textContent=o?'Modifica ordine':'Nuovo ordine';
  document.getElementById('o_cli_q').value='';
  document.getElementById('o_art_q').value='';
  fillClientSelect(db);
  fillArtSelect(db);
  document.getElementById('o_cli').value=o?.clienteId||'';
  document.getElementById('o_stato').value=o?.stato||'Richiesto';
  document.getElementById('o_data').value=o?.data||todayStr();
  document.getElementById('o_note').value=o?.note||'';
  ensureOrderSizeOption(o?.mis||'');
  document.getElementById('o_mis').value=o?.mis||'';
  document.getElementById('o_tracking').value=o?.tracking||'';
  document.getElementById('o_discount').value=calcOrderDiscount(o) ? String(calcOrderDiscount(o)).replace('.', ',') : '';
  document.getElementById('o_art').value='';
  document.getElementById('o_price').value='';
  document.getElementById('o_photo').value='';
  currentOrdExistingManualPhotos=o ? await getOrderManualPics(o) : [];
  ordRows=(o?.righe||[]).slice();
  if(prefillArticleId){
    const a=db.articoli.find(x=>x.id===prefillArticleId);
    if(a && !ordRows.some(r=>r.articoloId===prefillArticleId)){
      ordRows.push({articoloId:a.id, codice:a?.codice||'', modello:a?.modello||'', prezzo:Number(currentPrice(a)||0)});
    }
  }
  renderOrdRows();
  updateOrderPriceFromSelection();
  updateOrderTotalsPreview();
  updateOrderShoeSizeState();
  await refreshOrdPhotoPreviewFromState();
  show('mOrdEdit');
}
function todayStr(){
  const d=new Date();
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
}
function fillClientSelect(db, filter=''){
  const sel=document.getElementById('o_cli');
  const q=filter.toLowerCase();
  const items=db.clienti.filter(c=>{
    const hay=(c.nome+' '+(c.telefono||'')+' '+(c.citta||'')).toLowerCase();
    return !q || hay.includes(q);
  });
  sel.innerHTML='<option value="">Seleziona</option>'+items.map(c=>`<option value="${c.id}">${esc(c.nome)} • ${esc(c.provincia||'')}</option>`).join('');
}
function fillArtSelect(db, filter=''){
  const sel=document.getElementById('o_art');
  const prev=Array.from(sel.selectedOptions||[]).map(o=>o.value);
  const q=filter.toLowerCase();
  const items=db.articoli.filter(a=>{
    const hay=((a.codice||'')+' '+(a.brand||'')+' '+(a.modello||'')+' '+(a.categoria||'')+' '+(a.descrizione||'')+' '+(a.colore||'')+' '+(a.taglia||'')+' '+(a.variante||'')).toLowerCase();
    return !q || hay.includes(q);
  });
  sel.innerHTML=items.map(a=>`<option value="${a.id}">${esc(a.brand||'')} ${esc(a.modello||'')} • ${esc(a.codice||'')}</option>`).join('');
  prev.forEach(v=>{ const opt=Array.from(sel.options).find(o=>o.value===v); if(opt) opt.selected=true; });
}
function selectedOrderArticleIds(){ return Array.from(document.getElementById('o_art').selectedOptions||[]).map(o=>o.value).filter(Boolean); }
function updateOrderPriceFromSelection(){
  const db=loadDB();
  const ids=selectedOrderArticleIds();
  const priceInput=document.getElementById('o_price');
  if(ids.length!==1){ if(ids.length===0) priceInput.value=''; return; }
  const a=db.articoli.find(x=>x.id===ids[0]);
  const price=currentPrice(a);
  priceInput.value = price ? String(price) : ''; 
}
function addRow(){
  const db=loadDB();
  const ids=selectedOrderArticleIds();
  if(!ids.length){ toast('Seleziona almeno un articolo'); return; }
  const manual=Number(document.getElementById('o_price').value||0);
  ids.forEach((artId,idx)=>{
    const a=db.articoli.find(x=>x.id===artId);
    if(!a) return;
    if(ordRows.some(r=>r.articoloId===artId)) return;
    const prezzo=(ids.length===1 && manual>0) ? manual : Number(currentPrice(a)||0);
    ordRows.push({articoloId:artId, codice:a?.codice||'', modello:a?.modello||'', prezzo});
  });
  Array.from(document.getElementById('o_art').options).forEach(o=>o.selected=false);
  document.getElementById('o_art_q').value='';
  document.getElementById('o_price').value='';
  fillArtSelect(db);
  renderOrdRows();
  updateOrderShoeSizeState();
}
function getTrackingValue(){
  const editVal=String(document.getElementById('o_tracking')?.value||'').trim();
  if(editVal) return editVal;
  const viewVal=String(document.getElementById('vOrdTrack')?.textContent||'').trim();
  return viewVal==='-' ? '' : viewVal;
}
function openTrack17(){
  const code=getTrackingValue();
  if(!code){ toast('Inserisci il tracking'); return; }
  window.open(`https://17track.net/en/track?nums=${encodeURIComponent(code)}`,'_blank','noopener');
}
function openTrackParcel(){
  const code=getTrackingValue();
  if(!code){ toast('Inserisci il tracking'); return; }
  const webUrl=`https://parcelsapp.com/it/tracking/${encodeURIComponent(code)}`;
  const win=window.open(webUrl,'_blank','noopener');
  if(!win) window.location.href=webUrl;
}
function renderOrdRows(){
  const box=document.getElementById('o_rows');
  box.innerHTML=ordRows.map((r,i)=>`<div class="row" style="grid-template-columns:1fr auto">
    <div><div class="t">${esc(r.codice)} • ${esc(r.modello)}</div><div class="s">${money(r.prezzo||0)}</div></div>
    <button class="btn danger" data-action="delRow" data-i="${i}">X</button>
  </div>`).join('') || `<div class="small">Nessuna riga</div>`;
  updateOrderTotalsPreview();
  updateOrderShoeSizeState();
  refreshOrdPhotoPreviewFromState().catch(err=>console.warn('Preview foto ordine fallita', err));
}
async function saveOrd(){
  const db=loadDB();
  const cli=document.getElementById('o_cli').value;
  if(!cli){ toast('Seleziona un cliente'); return; }
  if(!ordRows.length){ toast('Aggiungi almeno una riga'); return; }
  const totals=updateOrderTotalsPreview();
  const subtotal=totals.subtotal;
  const scontoCliente=totals.discount;
  const tot=totals.total;
  const misuraSel=document.getElementById('o_mis');
  const misuraValue=String(misuraSel?.value||'').trim();
  if(updateOrderShoeSizeState() && !ORDER_SHOE_SIZES.includes(misuraValue)){
    toast('Per le scarpe devi scegliere una misura da 34 a 45');
    misuraSel?.focus();
    return;
  }
  const old=currentOrdId?db.ordini.find(x=>x.id===currentOrdId):null;
  const articlePics=await getOrderArticleSnapshotPhotos(ordRows, db);
  const photoInput=document.getElementById('o_photo');
  const selectedFiles=Array.from(photoInput?.files||[]).filter(f=>f && String(f.type||'').startsWith('image/'));
  const existingManualIds=Array.isArray(old?.orderPhotoIds)?old.orderPhotoIds.filter(Boolean).slice(0,12):[];
  const existingManualLegacy=Array.isArray(old?.fotoManuali)?old.fotoManuali.filter(Boolean).slice(0,12):[];
  const existingManualCount=Math.max(existingManualIds.length, existingManualLegacy.length, Array.isArray(currentOrdExistingManualPhotos)?currentOrdExistingManualPhotos.length:0);
  const maxNew=Math.max(0, 12 - mergeUniquePics(articlePics, currentOrdExistingManualPhotos).length);
  const newManualIds=[];
  const newManualLegacy=[];
  for(const file of selectedFiles.slice(0,maxNew)){
    try{
      const blob=await compressImageBlob(file);
      const pid='oph_'+uid();
      await idbSet(pid, blob);
      newManualIds.push(pid);
    }catch(err){
      console.warn('Compressione foto ordine fallita', err);
      try{
        const dataUrl=await compressImageFile(file, 1400, 0.76);
        const pid='oph_'+uid();
        await idbSet(pid, dataUrl);
        newManualIds.push(pid);
        newManualLegacy.push(dataUrl);
      }catch(_e){}
    }
  }
  const manualCount=existingManualCount + newManualIds.length;
  const allOrderPics=mergeUniquePics(articlePics, currentOrdExistingManualPhotos);
  const newOrderId=currentOrdId||('ORD-'+uid().slice(0,6).toUpperCase());
  const obj={
    id: newOrderId,
    numeroOrdine: ensureOrderNumber({ id:newOrderId, numeroOrdine: old?.numeroOrdine }),
    clienteId: cli,
    stato: document.getElementById('o_stato').value,
    data: document.getElementById('o_data').value.trim()||todayStr(),
    note: document.getElementById('o_note').value.trim(),
    mis: misuraValue,
    tracking: document.getElementById('o_tracking').value.trim(),
    righe: ordRows.slice(),
    fotoArticoli: [],
    fotoManuali: [...existingManualLegacy, ...newManualLegacy].slice(0,12),
    orderPhotoIds: [...new Set([...existingManualIds, ...newManualIds])].slice(0,12),
    foto: [],
    subTotale: subtotal,
    scontoCliente,
    totale: tot,
    _ts: Date.now()
  };
  const i=db.ordini.findIndex(x=>x.id===obj.id);
  if(i>=0) db.ordini[i]=obj; else db.ordini.unshift(obj);
  if(!saveDB(db)) return;
  hide('mOrdEdit');
  toast(manualCount || articlePics.length ? 'Ordine salvato con foto' : 'Ordine salvato');
  if(cloudEnabled()){
    try{
      const saved=await cloudSaveOne('ord', obj, db);
      const idx=db.ordini.findIndex(x=>x.id===obj.id || x.id===saved?.id);
      if(idx>=0) db.ordini[idx]={...db.ordini[idx], ...saved, _ts: Date.now()};
      saveDBLocal(db);
    }catch(cloudErr){
      console.error('Sync cloud ordine fallita', cloudErr);
      toast('Ordine salvato, ma cloud non aggiornato');
    }
  }
}
async function deleteOrd(){
  if(!currentOrdId) return hide('mOrdEdit');
  
  const db=loadDB();
  const old=db.ordini.find(o=>o.id===currentOrdId);
  for(const pid of (old?.orderPhotoIds||[])){
    try{ await idbDelete(pid); }catch(_e){}
  }
  db.ordini=db.ordini.filter(o=>o.id!==currentOrdId);
  if(!saveDB(db)) return;
  if(old && cloudEnabled()) await cloudDeleteOne('ord', old);
  hide('mOrdEdit');
  toast(cloudEnabled() ? 'Ordine eliminato anche dal cloud' : 'Ordine eliminato');
}

/* ====== IMPORT/EXPORT ====== */
async function exportDB(mode){
  const db=loadDB();
  const out=JSON.parse(JSON.stringify(db));
  for(const art of out.articoli){
    if(mode==='lite') art.foto=[];
    else art.foto=await getArticlePics(art);
  }
  out.exportedAt=new Date().toISOString();
  const blob=new Blob([JSON.stringify(out,null,2)],{type:'application/json'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download=`vanity_glamour_${mode}_${Date.now()}.json`;
  a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1500);
  document.getElementById('importHint').textContent = `Export fatto (${mode}). Database esportato correttamente.`;
}
function importDB(file){
  const mode=(document.getElementById('importMode')?.value||'replace');
  const r=new FileReader();
  r.onload=async()=>{
    try{
      const parsed=JSON.parse(r.result);
      const incoming=normalizeDBShape(parsed);
      if(!incoming || !Array.isArray(incoming.articoli)||!Array.isArray(incoming.clienti)||!Array.isArray(incoming.ordini)) throw new Error('JSON non compatibile');
      for(const art of incoming.articoli){
        art.photoIds=Array.isArray(art.photoIds)?art.photoIds.filter(Boolean).slice(0,6):[];
        if(Array.isArray(art.foto) && art.foto.length){
          for(const src of art.foto.slice(0,6)){
            const pid='ph_'+uid();
            await idbSet(pid,src);
            art.photoIds.push(pid);
          }
        }
        art.foto=[];
      }
      let nextDb=incoming;
      if(mode==='merge'){
        const curr=loadDB();
        nextDb=normalizeDBShape({
          version: incoming.version || curr.version || 'v6.2',
          createdAt: curr.createdAt || incoming.createdAt || new Date().toISOString(),
          articoli: [...(curr.articoli||[]), ...(incoming.articoli||[])],
          clienti: [...(curr.clienti||[]), ...(incoming.clienti||[])],
          ordini: [...(curr.ordini||[]), ...(incoming.ordini||[])],
          categorie: [...new Set([...(curr.categorie||[]), ...(incoming.categorie||[])])],
          brands: [...new Set([...(curr.brands||[]), ...(incoming.brands||[])])]
        });
      }
      updateShippingNotifications(nextDb,'json-import');
      if(!saveDB(nextDb)) throw new Error('Salvataggio locale fallito');
      renderAll();
      document.getElementById('importHint').textContent = mode==='merge' ? 'Import OK. JSON unito ai dati già presenti.' : 'Import OK. Database sostituito con il JSON.';
      toast(mode==='merge' ? 'Import unito ai dati attuali' : 'Import sostitutivo completato');
    }catch(e){
      toast('Import fallito'); console.error(e);
    }
  };
  r.readAsText(file);
}


function searchStartsWith(candidate, query){
  const value=normalizeTextKey(candidate);
  const q=normalizeTextKey(query);
  if(!q || !value) return false;
  if(value.startsWith(q)) return true;
  return value.split(/[^a-z0-9àèéìòóù]+/i).some(part=>part && part.startsWith(q));
}
function getSearchSuggestions(kind, query){
  const q=String(query||'').trim();
  if(!q) return [];
  const db=loadDB();
  const out=[];
  const add=(value)=>{
    const clean=normalizeSpaceText(value);
    if(!clean) return;
    if(!searchStartsWith(clean, q)) return;
    if(out.some(v=>normalizeTextKey(v)===normalizeTextKey(clean))) return;
    out.push(clean);
  };
  if(kind==='art' || kind==='orderArt'){
    (db.articoli||[]).forEach(a=>{
      add(a.codice);
      add(a.modello);
      add(a.brand);
    });
  }
  if(kind==='cli' || kind==='orderCli'){
    (db.clienti||[]).forEach(c=>{
      add(c.nome);
      add(c.telefono);
      add(c.citta);
    });
  }
  if(kind==='ord'){
    (db.ordini||[]).forEach(o=>{
      add(o.numeroOrdine||o.id);
      add(o.id);
      add(o.stato);
      const cli=(db.clienti||[]).find(c=>c.id===o.clienteId);
      add(cli?.nome||'');
    });
  }
  return out.slice(0,8);
}
function hideSearchSuggest(boxId){
  const box=document.getElementById(boxId);
  if(!box) return;
  box.innerHTML='';
  box.classList.remove('show');
}
function renderSearchSuggest(boxId, items, onPick){
  const box=document.getElementById(boxId);
  if(!box) return;
  if(!items.length){ hideSearchSuggest(boxId); return; }
  box.innerHTML=items.map(item=>`<button type="button">${esc(item)}</button>`).join('');
  box.classList.add('show');
  Array.from(box.querySelectorAll('button')).forEach((btn,idx)=>btn.addEventListener('click',()=>onPick(items[idx])));
}
function bindSearchSuggest(inputId, boxId, kind, onApply){
  const input=document.getElementById(inputId);
  const box=document.getElementById(boxId);
  if(!input || !box) return;
  const apply=(value)=>{
    input.value=value;
    hideSearchSuggest(boxId);
    onApply(value);
  };
  input.addEventListener('input',()=>{
    const value=input.value||'';
    onApply(value);
    const items=getSearchSuggestions(kind, value);
    renderSearchSuggest(boxId, items, apply);
  });
  input.addEventListener('blur',()=>setTimeout(()=>hideSearchSuggest(boxId), 180));
  input.addEventListener('focus',()=>{
    const items=getSearchSuggestions(kind, input.value||'');
    renderSearchSuggest(boxId, items, apply);
  });
}

/* ====== EVENTS ====== */
document.addEventListener('click',(ev)=>{
  const el=ev.target.closest('[data-action],[data-go],[data-open]');
  if(!el) return;
  if(el.dataset.go){ ev.preventDefault(); go(el.dataset.go); return; }
  if(el.dataset.open){
    const id=el.dataset.id;
    if(el.dataset.open==='art') openArtView(id);
    if(el.dataset.open==='cli') openCliView(id);
    if(el.dataset.open==='ord') openOrdView(id);
    return;
  }
  const a=el.dataset.action;
  if(a==='newArt') return openArtEdit(null);
  if(a==='openArtCategory'){ setArtBrowse('brands', el.dataset.category||''); return renderArt(); }
  if(a==='openArtBrand'){ setArtBrowse('articoli', el.dataset.category||'', el.dataset.brand||''); return renderArt(); }
  if(a==='artBackToCategories'){ setArtBrowse('categorie'); return renderArt(); }
  if(a==='artBackToBrands'){ setArtBrowse('brands', artBrowseState.categoria||''); return renderArt(); }
  if(a==='newCli') return openCliEdit(null);
  if(a==='newOrd') return openOrdEdit(null);
  if(a==='exportFull') return exportDB('full');
  if(a==='exportLite') return exportDB('lite');
  if(a==='refreshDiag'){ renderDiagnostics(); toast('Diagnostica aggiornata'); return; }
  if(a==='saveUiPrefs'){ saveUiPrefsData(readUiEditor()); applyUiPrefs(); toast('Interfaccia aggiornata'); return; }
  if(a==='loadUiPrefs'){ fillUiEditor(); applyUiPrefs(); toast('Editor ricaricato'); return; }
  if(a==='resetUiPrefs'){ localStorage.removeItem(UI_KEY); fillUiEditor(); applyUiPrefs(); toast('Editor ripristinato'); return; }
  if(a==='repairArchive'){
    askConfirm('Riparo archivio foto e pulizia riferimenti sporchi?', ()=>repairArchive().then(()=>toast('Archivio riparato')).catch(err=>{toast('Riparazione fallita'); console.error(err);}),'Ripara archivio');
    return;
  }
  if(a==='hardReset'){
    askConfirm('Azzero tutti i dati locali di questa app? Cancello archivio locale, foto, cache e login cloud locale.', async ()=>{
      try{
        const keep=[];
        try{
          for(let i=0;i<localStorage.length;i++){
            const k=localStorage.key(i);
            if(k) keep.push(k);
          }
        }catch(_e){}
        const appKeys=[KEY, UI_KEY, SHIP_ALERTS_KEY, SHIP_SNAPSHOT_KEY, ...(typeof LEGACY_KEYS!=='undefined'?LEGACY_KEYS:[])];
        [...new Set([...keep, ...appKeys])].forEach(k=>{ try{ localStorage.removeItem(k); }catch(_e){} });
        try{ sessionStorage.clear(); }catch(_e){}
        try{
          if(typeof indexedDB!=='undefined'){
            await new Promise(res=>{
              const req=indexedDB.deleteDatabase(PHOTO_DB);
              req.onsuccess=req.onerror=req.onblocked=()=>res(true);
            });
          }
        }catch(_e){}
        try{
          if('serviceWorker' in navigator){
            const regs=await navigator.serviceWorker.getRegistrations();
            await Promise.all(regs.map(r=>r.unregister()));
          }
        }catch(_e){}
        try{
          if(window.caches){
            const ks=await caches.keys();
            await Promise.all(ks.map(k=>caches.delete(k)));
          }
        }catch(_e){}
        try{ cloudSession=null; cloudClient=null; }catch(_e){}
      }catch(err){ console.error('Hard reset fallito', err); }
      location.href='reset.html?ts='+Date.now();
    }, 'Reset totale');
    return;
  }
  if(a==='addCategory') return addCategory();
  if(a==='renameCategory') return renameCategory(el.dataset.name||'');
  if(a==='deleteCategory') return deleteCategory(el.dataset.name||'');
  if(a==='addBrand') return addBrand();
  if(a==='renameBrand') return renameBrand(el.dataset.name||'');
  if(a==='deleteBrand') return deleteBrand(el.dataset.name||'');
  if(a==='copyPost') return copyTextFrom(document.getElementById('vArtPost'));
  if(a==='downloadArtPhotos') return downloadCurrentArticlePhotos();
  if(a==='openSupplierLink'){ const link=String(document.getElementById('vArtSupplierLink')?.value||'').trim(); if(!link){ toast('Nessun link fornitore'); return; } const safe=/^https?:\/\//i.test(link)?link:'https://'+link; window.open(safe,'_blank'); return; }
  if(a==='copyCliShip') return copyTextFrom(document.getElementById('c_ship'));
  if(a==='copyCliShipView') return copyTextFrom(document.getElementById('vCliShip'));
  if(a==='editCliFromView'){ hide('mCliView', true); return openCliEdit(currentCliId); }
  if(a==='closeCliView') return hide('mCliView');
  if(a==='editOrdFromView'){ hide('mOrdView', true); return openOrdEdit(currentOrdId); }
  if(a==='closeOrdView') return hide('mOrdView');
  if(a==='track17View') return openTrack17();
  if(a==='openParcelView') return openTrackParcel();
  if(a==='openMonthSales') return openMonthSales(Number(el.dataset.year), Number(el.dataset.month), el.dataset.label||'');
  if(a==='addArtToOrder'){ const id=el.dataset.id; if(id) return openOrdEdit(null, id); return; }
  if(a==='addArtToOrderFromView'){
    if(!currentArtId){ toast('Articolo non trovato'); return; }
    hide('mArtView');
    requestAnimationFrame(()=>openOrdEdit(null, currentArtId));
    return;
  }
  if(a==='duplicateArt') return duplicateCurrentArticle(el.dataset.id || null);
  if(a==='editFromView'){ hide('mArtView', true); return openArtEdit(currentArtId); }
  if(a==='closeView') return hide('mArtView');
  if(a==='closeEdit') return hide('mArtEdit');
  if(a==='clearArtPhotos'){ currentArtExistingPics=[]; currentArtPhotosCleared=true; document.getElementById('a_photo').value=''; renderArtPhotoPrev([]); toast('Foto attuali rimosse'); return; }
  if(a==='saveArt') return saveArt();
  if(a==='deleteArt') return deleteArt();
  if(a==='saveCli') return saveCli();
  if(a==='closeCli') return hide('mCliEdit');
  if(a==='deleteCli') return deleteCli();
  if(a==='saveOrd') return saveOrd();
  if(a==='closeOrd') return hide('mOrdEdit');
  if(a==='deleteOrd') return deleteOrd();
  if(a==='addRow') return addRow();
  if(a==='track17') return openTrack17();
  if(a==='openParcel') return openTrackParcel();
  if(a==='closeMonthSales') return hide('mMonthSales');
  if(a==='cloudPull'){ document.getElementById('cloudSyncMini')?.classList.remove('show'); return pullCloudToLocal().catch(err=>{toast(err?.message||'Carica cloud fallita'); console.error(err);}); }
  if(a==='cloudPush'){ document.getElementById('cloudSyncMini')?.classList.remove('show'); return pushLocalToCloud().catch(err=>{toast(err?.message||'Invia cloud fallita'); console.error(err);}); }
  if(a==='doCloudLogin') return cloudLogin();
  if(a==='closeCloudLogin') return hide('mCloudLogin');
  if(a==='confirmYes') return closeConfirm(true);
  if(a==='confirmNo') return closeConfirm(false);
  if(a==='delRow'){ const i=Number(el.dataset.i); ordRows.splice(i,1); renderOrdRows(); updateOrderShoeSizeState(); return; }
});

bindSearchSuggest('qArt','qArtSuggest','art', ()=>renderArt());
document.getElementById('qArtCat')?.addEventListener('change', renderArt);
bindSearchSuggest('qCli','qCliSuggest','cli', ()=>renderCli());
['c_nome','c_tel','c_ind','c_cap','c_citta','c_prov'].forEach(id=>{ const el=document.getElementById(id); if(el) el.addEventListener('input', refreshClientShipping); if(el) el.addEventListener('change', refreshClientShipping); });
bindSearchSuggest('qOrd','qOrdSuggest','ord', ()=>renderOrd());
document.getElementById('catName')?.addEventListener('keydown',(ev)=>{ if(ev.key==='Enter'){ ev.preventDefault(); addCategory(); } });
document.getElementById('brandName')?.addEventListener('keydown',(ev)=>{ if(ev.key==='Enter'){ ev.preventDefault(); addBrand(); } });

['a_cod','a_brand','a_brand_custom','a_mod','a_mis','a_usd','a_promo_on','a_promo_price','a_promo_date','a_forn','a_desc','a_taglia','a_variante','a_colore'].forEach(id=>{
  const el=document.getElementById(id);
  const evt=(id==='a_promo_on' || id==='a_forn' || id==='a_brand') ? 'change' : 'input';
  el.addEventListener(evt, renderArtAutoFields);
  if(id==='a_cod') el.addEventListener('change', renderArtAutoFields);
});

bindSearchSuggest('o_cli_q','oCliSuggest','orderCli', value=>fillClientSelect(loadDB(), value));
bindSearchSuggest('o_art_q','oArtSuggest','orderArt', value=>{
  fillArtSelect(loadDB(), value);
  updateOrderPriceFromSelection();
});
document.getElementById('o_art').addEventListener('change', updateOrderPriceFromSelection);
document.getElementById('o_discount').addEventListener('input', updateOrderTotalsPreview);

document.getElementById('importFile').addEventListener('change',(e)=>{
  const f=e.target.files[0];
  if(f) importDB(f);
  e.target.value='';
});
document.getElementById('a_brand')?.addEventListener('change', handleBrandSelectionChange);
document.getElementById('a_photo')?.addEventListener('change', refreshArtPhotoPreviewFromInput);
document.getElementById('btnCloudLogin')?.addEventListener('click', ()=>show('mCloudLogin'));
document.getElementById('btnCloudLogout')?.addEventListener('click', cloudLogout);
document.addEventListener('visibilitychange', ()=>{ if(!document.hidden) autoCloudPullNow('visible'); });
window.addEventListener('focus', ()=>autoCloudPullNow('focus'));

// Province select
const provSel=document.getElementById('c_prov');
provSel.innerHTML='<option value="">Seleziona</option>'+PROVINCE.map(p=>`<option value="${p}">${p}</option>`).join('');

/* ====== CLOUD / SUPABASE ====== */
let cloudClient=null;
let cloudSession=null;
let cloudBusy=false;

const VG_BUILD='2026-03-18-cloudfix-r2';
const AUTO_CLOUD_PULL_MS=180000;
let autoCloudPullTimer=null;
let autoCloudPullRunning=false;
let autoCloudPullLastAt=0;
function refreshAutoCloudPull(){
  if(autoCloudPullTimer){ clearInterval(autoCloudPullTimer); autoCloudPullTimer=null; }
  if(!cloudEnabled()) return;
  autoCloudPullTimer=setInterval(()=>{ autoCloudPullNow('timer'); }, AUTO_CLOUD_PULL_MS);
}
async function autoCloudPullNow(reason='manual'){
  if(!cloudEnabled() || autoCloudPullRunning || cloudBusy || document.hidden) return;
  const now=Date.now();
  if(reason!=='focus' && reason!=='visible' && (now-autoCloudPullLastAt)<60000) return;
  autoCloudPullRunning=true;
  autoCloudPullLastAt=now;
  try{
    await pullCloudToLocal({silent:true, background:true});
    console.log('Auto cloud pull ok', reason);
  }catch(err){
    console.warn('Auto cloud pull fallita', reason, err);
  }finally{
    autoCloudPullRunning=false;
  }
}
const UUID_RE=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const SUPABASE_BUCKET='articoli';
const isUuid=v=>UUID_RE.test(String(v||''));
function cloudUi(){
  const uiPrefs=loadUiPrefs();
  const s=document.getElementById('cloudState');
  const bIn=document.getElementById('btnCloudLogin');
  const bPull=document.getElementById('btnCloudPull');
  const bPush=document.getElementById('btnCloudPush');
  const bOut=document.getElementById('btnCloudLogout');
  if(!s||!bIn||!bPull||!bPush||!bOut) return;
  const logged=!!cloudSession;
  const hide=(el,on)=>{ el.hidden=!!on; el.style.display=on?'none':''; };
  const setDisabled=(el,on)=>{ el.disabled=!!on; el.style.opacity=on?'.65':''; };
  if(!window.VG_SUPABASE_READY){
    s.textContent=uiPrefs.cloud||'Cloud';
    hide(bIn,true); hide(bPull,true); hide(bPush,true); hide(bOut,true);
    return;
  }
  if(cloudBusy){ s.textContent=(uiPrefs.cloud||'Cloud')+': lavoro in corso…'; }
  else if(cloudSession?.user?.email){ s.textContent=`${uiPrefs.cloud||'Cloud'}: ${cloudSession.user.email}`; }
  else { s.textContent=uiPrefs.cloud||'Cloud'; }
  hide(bIn,logged);
  hide(bPull,!logged);
  hide(bPush,!logged);
  hide(bOut,!logged);
  setDisabled(bIn,cloudBusy);
  setDisabled(bPull,cloudBusy||!logged);
  setDisabled(bPush,cloudBusy||!logged);
  setDisabled(bOut,cloudBusy||!logged);
}
function cloudEnabled(){ return !!(window.VG_SUPABASE_READY && cloudSession); }
async function cloudSaveOne(type, payload, dbRef){
  if(!cloudEnabled()) return payload;
  cloudBusy=true; cloudUi();
  try{
    if(type==='art') return await upsertCloudArticle(payload);
    if(type==='cli') return await upsertCloudClient(payload);
    if(type==='ord') return await upsertCloudOrder(payload, dbRef||loadDB());
    return payload;
  }finally{
    cloudBusy=false; cloudUi();
  }
}
async function cloudDeleteOne(type, payload){
  if(!cloudEnabled() || !payload) return;
  cloudBusy=true; cloudUi();
  try{
    if(type==='art') return await deleteCloudArticle(payload);
    if(type==='cli') return await deleteCloudClient(payload);
    if(type==='ord') return await deleteCloudOrder(payload);
  }finally{
    cloudBusy=false; cloudUi();
  }
}
async function ensureCloud(){
  if(cloudClient) return cloudClient;
  if(!window.VG_SUPABASE_READY) return null;
  cloudClient=await window.VG_SUPABASE_READY;
  const {data:{session}}=await cloudClient.auth.getSession();
  cloudSession=session||null;
  cloudClient.auth.onAuthStateChange((_e,session)=>{ cloudSession=session||null; cloudUi(); refreshAutoCloudPull(); if(cloudSession) setTimeout(()=>autoCloudPullNow('login'), 1500); });
  cloudUi();
  return cloudClient;
}
function saveDBLocal(db){
  try{
    const cleanDb=normalizeDBShape(db||defDB());
    const raw=JSON.stringify(cleanDb);
    localStorage.setItem(KEY, raw);
    try{ localStorage.setItem(KEY+'_backup_latest', raw); }catch(_e){}
  }catch(err){ console.error(err); }
}
async function ensureCategoryId(nome){
  if(!nome) return null;
  const sb=await ensureCloud();
  if(!sb||!cloudSession) return null;
  const {data,error}=await sb.from('categorie').upsert({nome:String(nome).trim()},{onConflict:'nome'}).select('id,nome').single();
  if(error) throw error;
  return data?.id||null;
}
async function upsertCloudArticle(art){
  const sb=await ensureCloud();
  if(!sb||!cloudSession) return art;
  const categoria_id=await ensureCategoryId(art.categoria||'');
  const payload={
    sku: art.codice||null,
    nome: art.modello || art.codice || [art.brand, art.modello].filter(Boolean).join(' ').trim() || 'Articolo',
    descrizione: packCloudArticleDescription(art),
    categoria_id,
    marca: art.brand || null,
    colore: art.colore || null,
    taglia: art.taglia || null,
    materiale: art.variante || art.misura || null,
    prezzo_acquisto: Number(art.costoEur || 0),
    prezzo_vendita: Number(art.prezzoVendita || 0),
    giacenza: 0,
    attivo: true
  };
  if(isUuid(art.id)) payload.id=art.id;
  const {data,error}=await sb.from('prodotti').upsert(payload,{onConflict:'sku'}).select('*').single();
  if(error) throw error;
  const pics=await getArticleCloudSyncSources(art);
  let cloudFoto=[];
  try{
    cloudFoto=await syncArticlePhotosToCloud(data.id, art.codice||data.sku||data.id, pics);
  }catch(err){
    console.warn('Sync foto cloud fallita', err);
  }
  const finalFoto=normalizeCloudPhotoPathList(cloudFoto.length?cloudFoto:(art.foto||[]));
  try{
    await sb.from('prodotti').update({ descrizione: packCloudArticleDescription({...art, foto: finalFoto}) }).eq('id', data.id);
  }catch(metaErr){
    console.warn('Aggiornamento meta cloud articolo fallito', metaErr);
  }
  return {...art, id:data.id, foto: finalFoto, _cloud:true};
}
async function deleteCloudArticle(art){
  const sb=await ensureCloud();
  if(!sb||!cloudSession) return;
  try{
    if(isUuid(art?.id)){
      const { data:rows } = await sb.from('prodotti_foto').select('path').eq('prodotto_id', art.id);
      const paths=(rows||[]).map(r=>r.path).filter(Boolean);
      if(paths.length) await deleteArticlePhotosFromSupabase(paths);
      await sb.from('prodotti_foto').delete().eq('prodotto_id', art.id);
      const {error}=await sb.from('prodotti').delete().eq('id', art.id);
      if(error) throw error;
    }else if(art?.codice){
      const {error}=await sb.from('prodotti').delete().eq('sku', art.codice);
      if(error) throw error;
    }
  }catch(err){ throw err; }
}
async function upsertCloudClient(cli){
  const sb=await ensureCloud();
  if(!sb||!cloudSession) return cli;
  const nameParts=splitClientNameForCloud(cli);
  const payload={
    nome: nameParts.nome || 'Cliente',
    cognome: nameParts.cognome || null,
    telefono: normalizePhone(cli.telefono || null) || null,
    email: normalizeEmail(cli.email || null) || null,
    indirizzo: cli.indirizzo || null,
    citta: cli.citta || null,
    cap: cli.cap || null,
    provincia: cli.provincia || null,
    paese: 'Italia',
    note: cli.note || null
  };
  let data=null, error=null;
  let matchedId=isUuid(cli.id) ? cli.id : null;

  if(!matchedId && payload.email){
    const existing=await sb.from('clienti').select('*').eq('email', payload.email).maybeSingle();
    if(existing.data && !existing.error) matchedId=existing.data.id;
  }
  if(!matchedId && payload.telefono){
    const existing=await sb.from('clienti').select('*').eq('telefono', payload.telefono).maybeSingle();
    if(existing.data && !existing.error) matchedId=existing.data.id;
  }
  if(!matchedId && payload.nome){
    const probeKey=normalizeClientDedupKey({...cli, nome:normalizeClientDisplayName(cli), cognome:nameParts.cognome, email:payload.email, telefono:payload.telefono});
    const existing=await sb.from('clienti').select('*').eq('nome', payload.nome).limit(20);
    const rows=Array.isArray(existing.data) ? existing.data : [];
    const match=rows.find(row=>normalizeClientDedupKey({nome:[row.nome,row.cognome].filter(Boolean).join(' ').trim(), cognome:row.cognome, telefono:row.telefono, email:row.email, indirizzo:row.indirizzo, citta:row.citta, cap:row.cap})===probeKey);
    if(match) matchedId=match.id;
  }

  if(matchedId){
    ({data,error}=await sb.from('clienti').upsert({...payload,id:matchedId}).select('*').single());
  }else{
    ({data,error}=await sb.from('clienti').insert(payload).select('*').single());
  }
  if(error) throw error;
  return {...cli, id:data.id, nome:normalizeClientDisplayName({nome:data.nome, cognome:data.cognome}), cognome:data.cognome||cli.cognome||'', telefono:data.telefono||cli.telefono||'', email:data.email||cli.email||'', _cloud:true};
}
async function deleteCloudClient(cli){
  const sb=await ensureCloud();
  if(!sb||!cloudSession||!isUuid(cli?.id)) return;
  const {error}=await sb.from('clienti').delete().eq('id', cli.id);
  if(error) throw error;
}
async function upsertCloudOrder(ord, db){
  const sb=await ensureCloud();
  if(!sb||!cloudSession) return ord;
  let clienteId=ord.clienteId;
  if(!isUuid(clienteId)){
    const localCli=(db.clienti||[]).find(c=>c.id===clienteId);
    if(localCli){
      const savedCli=await upsertCloudClient(localCli);
      clienteId=savedCli.id;
      const ci=db.clienti.findIndex(c=>c.id===localCli.id);
      if(ci>=0) db.clienti[ci]=savedCli;
    }
  }
  if(!isUuid(clienteId)) throw new Error('Cliente ordine non sincronizzato');
  const payload={
    numero_ordine: ord.numeroOrdine || (isUuid(ord.id)?('VGAPP-'+ord.id.slice(0,8)):String(ord.id||'VGAPP-'+uid().slice(0,6)).slice(0,50)),
    cliente_id: clienteId,
    data_ordine: ord.data || todayStr(),
    stato: (ord.stato||'Richiesto').toLowerCase().includes('conseg') ? 'consegnato' : ((ord.stato||'').toLowerCase().includes('sped') ? 'spedito' : ((ord.stato||'').toLowerCase().includes('ann') ? 'annullato' : 'in_lavorazione')),
    totale: Number(ord.totale || 0),
    pagato: true,
    note: buildOrderCloudNote(ord),
    tracking_code: ord.tracking || null,
    tracking_url: ord.tracking ? `https://17track.net/en/track?nums=${encodeURIComponent(ord.tracking)}` : null
  };
  if(isUuid(ord.id)) payload.id=ord.id;
  const {data,error}=await sb.from('ordini').upsert(payload,{onConflict:'numero_ordine'}).select('*').single();
  if(error) throw error;
  const ordineId=data.id;
  const {error:delErr}=await sb.from('righe_ordine').delete().eq('ordine_id', ordineId);
  if(delErr) throw delErr;
  const righe=[];
  let remainingDiscount=calcOrderDiscount(ord);
  for(const r of (ord.righe||[])){
    let prodottoId=r.articoloId;
    if(!isUuid(prodottoId)){
      const localArt=(db.articoli||[]).find(a=>a.id===r.articoloId || a.codice===r.codice);
      if(localArt){
        const savedArt=await upsertCloudArticle(localArt);
        prodottoId=savedArt.id;
        const ai=db.articoli.findIndex(a=>a.id===localArt.id);
        if(ai>=0) db.articoli[ai]=savedArt;
      }
    }
    if(!isUuid(prodottoId)) continue;
    const prezzoUnitario=Math.max(0, Number(r.prezzo||0));
    const lineDiscount=Math.min(remainingDiscount, prezzoUnitario);
    remainingDiscount=Math.max(0, remainingDiscount-lineDiscount);
    righe.push({ordine_id:ordineId, prodotto_id:prodottoId, quantita:1, prezzo_unitario:prezzoUnitario, sconto:Number(lineDiscount.toFixed(2))});
  }
  if(righe.length){
    const {error:righeErr}=await sb.from('righe_ordine').insert(righe);
    if(righeErr) throw righeErr;
  }
  return {...ord, id:ordineId, clienteId, numeroOrdine:data.numero_ordine, _cloud:true};
}
async function deleteCloudOrder(ord){
  const sb=await ensureCloud();
  if(!sb||!cloudSession) return;
  let error=null;
  if(isUuid(ord?.id)) ({error}=await sb.from('ordini').delete().eq('id', ord.id));
  else ({error}=await sb.from('ordini').delete().eq('numero_ordine', String(ord?.id||'')));
  if(error) throw error;
}
async function pullCloudToLocal(opts={}){
  const sb=await ensureCloud();
  if(!sb||!cloudSession) throw new Error('Login cloud mancante');
  const bg=!!opts.background;
  if(!bg){
    try{ localStorage.setItem(KEY+'_backup_before_cloud_pull', localStorage.getItem(KEY)||''); }catch(_){ }
    cloudBusy=true; cloudUi();
  }
  try{
    const [{data:cats,error:catsErr},{data:prod,error:prodErr},{data:cli,error:cliErr},{data:ord,error:ordErr},{data:righe,error:righeErr},{data:fotos,error:fotosErr}] = await Promise.all([
      sb.from('categorie').select('id,nome'),
      sb.from('prodotti').select('*').order('created_at',{ascending:false}),
      sb.from('clienti').select('*').order('created_at',{ascending:false}),
      sb.from('ordini').select('*').order('data_ordine',{ascending:false}),
      sb.from('righe_ordine').select('ordine_id,prodotto_id,prezzo_unitario,sconto,prodotti(id,sku,nome)'),
      sb.from('prodotti_foto').select('prodotto_id,path,ordine').order('ordine',{ascending:true})
    ]);
    if(catsErr||prodErr||cliErr||ordErr||righeErr||fotosErr) throw (catsErr||prodErr||cliErr||ordErr||righeErr||fotosErr);
    const catMap=new Map((cats||[]).map(c=>[c.id,c.nome]));
    const prodMap=new Map((prod||[]).map(p=>[p.id,p]));
    const fotoByProd=new Map();
    (fotos||[]).forEach(r=>{
      const arr=fotoByProd.get(r.prodotto_id)||[];
      const rawPath=String(r?.path||'').trim();
      if(rawPath && !/^(blob:|data:|https?:\/\/)/i.test(rawPath)) arr.push(rawPath);
      fotoByProd.set(r.prodotto_id, arr);
    });
    for (const p of (prod||[])) {
      const validRows = normalizeCloudPhotoPathList(fotoByProd.get(p.id) || []);
      if (validRows.length) {
        fotoByProd.set(p.id, validRows);
        continue;
      }
      const packed=unpackCloudArticleDescription(p.descrizione||'');
      const meta=(packed.meta&&typeof packed.meta==='object')?packed.meta:{};
      const metaPaths=normalizeCloudPhotoPathList(meta.foto || meta.fotoCloud || []);
      if (metaPaths.length) {
        fotoByProd.set(p.id, metaPaths);
        continue;
      }
      const fallbackPaths = normalizeCloudPhotoPathList(await listCloudFotoPathsByCode(p.sku||''));
      if (fallbackPaths.length) fotoByProd.set(p.id, fallbackPaths);
    }
    const righeByOrd=new Map();
    (righe||[]).forEach(r=>{
      const arr=righeByOrd.get(r.ordine_id)||[];
      arr.push({articoloId:r.prodotto_id,codice:r.prodotti?.sku||prodMap.get(r.prodotto_id)?.sku||'',modello:r.prodotti?.nome||prodMap.get(r.prodotto_id)?.nome||'',prezzo:Number(r.prezzo_unitario||0),sconto:Number(r.sconto||0)});
      righeByOrd.set(r.ordine_id,arr);
    });
    const localDb=loadDB();
    const localArtById=new Map((localDb.articoli||[]).map(a=>[a.id,a]));
    const localArtByCode=new Map((localDb.articoli||[]).map(a=>[safeLower(a.codice),a]));
    const localOrdById=new Map((localDb.ordini||[]).map(o=>[o.id,o]));
    const localOrdByNumero=new Map((localDb.ordini||[]).map(o=>[normalizeTextKey(ensureOrderNumber(o)),o]).filter(([k])=>k));
    const localOrdByFingerprint=new Map((localDb.ordini||[]).map(o=>[normalizeOrderFingerprint(o),o]).filter(([k])=>k));
    const db={version:'v6',createdAt:new Date().toISOString(),
      articoli:(prod||[]).map(p=>{
        const local=localArtById.get(p.id)||localArtByCode.get(safeLower(p.sku));
        const packed=unpackCloudArticleDescription(p.descrizione||'');
        const legacy=parseLegacyCloudDescription(packed.plain);
        const meta=(packed.meta&&typeof packed.meta==='object')?packed.meta:{};
        const cleanBrand=normalizeSpaceText(p.marca||meta.brand||meta.marca||local?.brand||'');
        const pulledModel=stripBrandFromText(meta.modello||p.nome||'', cleanBrand) || stripBrandFromText(p.nome||'', cleanBrand) || local?.modello || '';
        const pulledDescr=(meta.descrizione||legacy.descrizione||local?.descrizione||'').trim();
        const pulledNote=(meta.note||legacy.note||local?.note||'').trim();
        const pulledPost=(meta.post||local?.post||'').trim();
        const finalFoto=normalizeCloudPhotoPathList(fotoByProd.get(p.id) || meta.foto || meta.fotoCloud || local?.foto || []);
        const pulledCostoUsd=firstFiniteNumber(meta.costoUsd, local?.costoUsd, 0);
        const pulledCostoEur=firstFiniteNumber(p.prezzo_acquisto, p.costo, p.costo_eur, meta.costoEur, local?.costoEur, 0);
        const pulledPrezzoVendita=firstFiniteNumber(p.prezzo_vendita, p.prezzo, p.prezzo_vendita_iva, meta.prezzoVendita, meta.prezzo, local?.prezzoVendita, 0);
        return {id:p.id,codice:p.sku||'',brand:cleanBrand,modello:pulledModel,categoria:meta.categoria||catMap.get(p.categoria_id)||local?.categoria||'',descrizione:pulledDescr,fornitore:meta.fornitore||local?.fornitore||'',fornitoreLink:meta.fornitoreLink||local?.fornitoreLink||'',taglia:meta.taglia||p.taglia||local?.taglia||'',variante:meta.variante||p.materiale||local?.variante||'',colore:meta.colore||p.colore||local?.colore||'',misura:meta.misura||local?.misura||'',costoUsd:pulledCostoUsd,costoEur:pulledCostoEur,prezzoVendita:pulledPrezzoVendita,promoAttiva:(typeof meta.promoAttiva==='boolean') ? meta.promoAttiva : !!local?.promoAttiva,prezzoPromo:firstFiniteNumber(meta.prezzoPromo, local?.prezzoPromo, 0),scadenzaPromo:meta.scadenzaPromo||local?.scadenzaPromo||'',post:pulledPost,note:pulledNote,foto:finalFoto,photoIds:Array.isArray(local?.photoIds)?local.photoIds.filter(Boolean).slice(0,6):[],_ts:Date.now(),_cloud:true};
      }),
      clienti:(cli||[]).map(c=>({id:c.id,nome:normalizeClientDisplayName({nome:c.nome,cognome:c.cognome}),cognome:c.cognome||'',telefono:normalizePhone(c.telefono||''),email:normalizeEmail(c.email||''),indirizzo:c.indirizzo||'',cap:c.cap||'',citta:c.citta||'',provincia:c.provincia||'',note:c.note||'',_ts:Date.now(),_cloud:true})),
      ordini:(ord||[]).map(o=>{ const noteRaw=o.note||''; const noteMeta=extractOrderNoteMeta(noteRaw); const righeOrd=righeByOrd.get(o.id)||[]; const righeDiscount=righeOrd.reduce((sum,row)=>sum+Number(row?.sconto||0),0); const shadow={id:o.id,numeroOrdine:o.numero_ordine,data:o.data_ordine||todayStr(),tracking:o.tracking_code||'',totale:Number(o.totale||0),note:noteMeta.cleanNote,righe:righeOrd}; const local=localOrdById.get(o.id)||localOrdByNumero.get(normalizeTextKey(o.numero_ordine||''))||localOrdByFingerprint.get(normalizeOrderFingerprint(shadow)); const scontoCliente=firstFiniteNumber(noteMeta.scontoCliente, righeDiscount, local?.scontoCliente, 0); const subTotale=calcOrderSubtotal(righeOrd); return {id:o.id,numeroOrdine:ensureOrderNumber({id:o.id,numeroOrdine:o.numero_ordine}),clienteId:o.cliente_id,stato:o.stato==='in_lavorazione'?'Richiesto':(o.stato==='spedito'?'Spedito':(o.stato==='consegnato'?'Consegnato':'Annullato')),data:o.data_ordine||todayStr(),note:noteMeta.cleanNote,mis:noteMeta.mis||'',tracking:o.tracking_code||'',righe:righeOrd,fotoArticoli:[],fotoManuali:Array.isArray(local?.fotoManuali)?local.fotoManuali.filter(Boolean).slice(0,12):[],orderPhotoIds:Array.isArray(local?.orderPhotoIds)?local.orderPhotoIds.filter(Boolean).slice(0,12):[],foto:[],subTotale,scontoCliente,totale:(Number(o.totale)>0 || subTotale===0) ? Number(o.totale||0) : calcOrderNetTotal(righeOrd, scontoCliente),_ts:Date.now(),_cloud:true}; })
    };
    updateShippingNotifications(db, bg?'cloud-auto':'cloud');
    saveDBLocal(db);
    renderAll();
    renderDiagnostics();
    if(!opts.silent) toast('Dati cloud caricati');
  } finally { if(!bg){ cloudBusy=false; cloudUi(); } }
}
async function pushLocalToCloud(){
  const sb=await ensureCloud();
  if(!sb||!cloudSession) throw new Error('Login cloud mancante');
  cloudBusy=true; cloudUi();
  try{
    const db=loadDB();
    if(!db.articoli.length && !db.clienti.length && !db.ordini.length){
      toast('Niente da inviare al cloud');
      return;
    }
    const artIdMap=new Map();
    const cliIdMap=new Map();
    for(let i=0;i<db.articoli.length;i++){
      const oldId=db.articoli[i]?.id;
      const saved=await upsertCloudArticle(db.articoli[i]);
      db.articoli[i]=saved;
      if(oldId && saved?.id && oldId!==saved.id) artIdMap.set(oldId, saved.id);
    }
    for(let i=0;i<db.clienti.length;i++){
      const oldId=db.clienti[i]?.id;
      const saved=await upsertCloudClient(db.clienti[i]);
      db.clienti[i]=saved;
      if(oldId && saved?.id && oldId!==saved.id) cliIdMap.set(oldId, saved.id);
    }
    if(cliIdMap.size || artIdMap.size){
      db.ordini=(db.ordini||[]).map(o=>({
        ...o,
        clienteId: cliIdMap.get(o.clienteId) || o.clienteId,
        righe: (o.righe||[]).map(r=>({ ...r, articoloId: artIdMap.get(r.articoloId) || r.articoloId }))
      }));
    }
    const failed=[];
    for(let i=0;i<db.ordini.length;i++){
      try{
        db.ordini[i]=await upsertCloudOrder(db.ordini[i], db);
      }catch(err){
        console.error('Ordine cloud fallito', db.ordini[i], err);
        failed.push(db.ordini[i]?.numeroOrdine || db.ordini[i]?.id || ('ordine-'+(i+1)));
      }
    }
    saveDBLocal(db);
    renderAll();
    renderDiagnostics();
    if(failed.length){
      toast('Cloud parziale: '+failed.length+' ordini non inviati');
    }else{
      toast('Dati locali mandati nel cloud');
    }
  } finally { cloudBusy=false; cloudUi(); }
}
async function cloudLogin(){
  try{
    const sb=await ensureCloud();
    if(!sb){ toast('Supabase non disponibile'); return; }
    const email=document.getElementById('cloudEmail')?.value.trim();
    const password=document.getElementById('cloudPassword')?.value||'';
    if(!email || !password){ toast('Inserisci email e password'); return; }
    cloudBusy=true; cloudUi();
    const {data,error}=await sb.auth.signInWithPassword({email,password});
    if(error) throw error;
    cloudSession=data.session||null;
    hide('mCloudLogin');
    document.getElementById('cloudPassword').value='';
    cloudUi();
    toast('Login cloud riuscito');
  }catch(err){ toast('Login cloud fallito'); console.error(err); }
  finally{ cloudBusy=false; cloudUi(); }
}
async function cloudLogout(){
  try{
    const sb=await ensureCloud(); if(!sb) return;
    await sb.auth.signOut(); cloudSession=null; cloudUi(); toast('Cloud scollegato');
  }catch(err){ toast('Logout cloud fallito'); console.error(err); }
}

/* init */
renderAll();
renderDiagnostics();
fillUiEditor();
applyUiPrefs();
const initial=location.hash.replace('#','')||'home';
history.replaceState({page:initial, artBrowse:{...artBrowseState}},'', '#'+initial);
go(initial,false);
cloudUi();
refreshAutoCloudPull();
requestPersistentStorage();
ensureCloud().catch(err=>console.warn('Cloud init fallita', err));
